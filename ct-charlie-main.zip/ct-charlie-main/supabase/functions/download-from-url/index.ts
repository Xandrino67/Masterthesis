import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  try {
    const { study_id, download_url } = await req.json()

    if (!study_id || !download_url) {
      throw new Error('Missing required parameters')
    }

    console.log(`Downloading file from URL for study: ${study_id}`)

    // Download file from URL
    const downloadResponse = await fetch(download_url)
    
    if (!downloadResponse.ok) {
      throw new Error(`Download failed: ${downloadResponse.statusText}`)
    }

    // Get file content
    const fileBlob = await downloadResponse.blob()
    const fileBuffer = await fileBlob.arrayBuffer()
    
    console.log(`Downloaded ${fileBuffer.byteLength} bytes`)

    // Determine filename from URL or use default
    const urlParts = new URL(download_url).pathname.split('/')
    const filename = urlParts[urlParts.length - 1] || 'downloaded_file.zip'
    
    // Upload to Supabase storage
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    const uploadPath = `${study_id}/uploads/${filename}`
    
    const { error: uploadError } = await supabase.storage
      .from('dose-files')
      .upload(uploadPath, fileBuffer, {
        contentType: fileBlob.type || 'application/zip',
        cacheControl: '3600',
      })

    if (uploadError) {
      console.error('Upload error:', uploadError)
      throw uploadError
    }

    console.log(`File uploaded successfully to: ${uploadPath}`)

    // Trigger ZIP processing
    const { data: processData, error: processError } = await supabase.functions.invoke('process-zip-upload', {
      body: {
        study_id,
        zip_path: uploadPath,
        file_size: fileBuffer.byteLength,
      },
    })

    if (processError) {
      console.error('Processing error:', processError)
      throw processError
    }

    return new Response(
      JSON.stringify({ 
        success: true,
        path: uploadPath,
        file_count: processData?.file_count || 0
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  } catch (error) {
    console.error('Error:', error)
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : 'Unknown error' }),
      { 
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    )
  }
})
