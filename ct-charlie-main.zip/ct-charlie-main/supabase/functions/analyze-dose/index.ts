import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.7.1";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface AnalysisRequest {
  study_id: string;
  series_ids: string[];
  method: "ct_only" | "cbct_only" | "ct_cbct_cumulative";
  params: {
    resample?: "linear" | "nearest";
    dvh_bins?: number;
    organ_ids?: string[];
  };
}

interface OrganStats {
  organ_id: string;
  label: string;
  volume_ml: number;
  d_mean: number;
  d_min: number;
  d_max: number;
  d_median: number;
  d_p5: number;
  d_p95: number;
  dvh_cumulative: number[][];
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
    );

    // Get user from auth header
    const authHeader = req.headers.get("Authorization")!;
    const token = authHeader.replace("Bearer ", "");
    const { data: { user }, error: authError } = await supabaseClient.auth.getUser(token);

    if (authError || !user) {
      return new Response(
        JSON.stringify({ error: "Unauthorized" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    const requestData: AnalysisRequest = await req.json();
    const { study_id, series_ids, method, params } = requestData;

    // Create analysis run record
    const run_id = `RUN-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    
    const { data: analysisRun, error: createError } = await supabaseClient
      .from("analysis_runs")
      .insert({
        run_id,
        study_id,
        input_refs: { series_ids, method },
        params,
        status: "running",
        started_at: new Date().toISOString(),
        code_version: "1.0.0",
        impact_mc_version: "3.0",
      })
      .select()
      .single();

    if (createError) {
      throw createError;
    }

    // Simulate dose analysis (in production, this would process actual NIfTI files)
    const { data: organs } = await supabaseClient
      .from("organs")
      .select("*")
      .in("id", params.organ_ids || [])
      .order("label");

    // Simulate organ statistics calculation
    // NOTE: This edge function generates mock data for testing
    // Real DVH calculation is now performed by calculateOrganDoses() in doseCalculation.ts
    const organStats: OrganStats[] = (organs || []).map((organ) => {
      // Simulated values - in production would calculate from actual dose grids
      const base_dose = Math.random() * 50; // mGy
      
      return {
        organ_id: organ.id,
        label: organ.label,
        volume_ml: Math.random() * 500 + 50,
        d_mean: base_dose * (0.8 + Math.random() * 0.4),
        d_min: base_dose * 0.1,
        d_max: base_dose * 1.5,
        d_median: base_dose * (0.85 + Math.random() * 0.3),
        d_p5: base_dose * 0.2,
        d_p95: base_dose * 1.3,
        // Mock DVH - real calculation done in calculateOrganDoses()
        dvh_cumulative: Array.from({ length: 50 }, (_, i) => [
          i * (base_dose * 1.5) / 50,
          100 - (i * 2),
        ]),
      };
    });

    // Calculate effective dose (E) using ICRP-103 weights
    let effective_dose_mSv = 0;
    const { data: weightedOrgans } = await supabaseClient
      .from("organs")
      .select("*")
      .not("weight_factor", "is", null);

    if (weightedOrgans) {
      for (const organ of weightedOrgans) {
        const stats = organStats.find(s => s.organ_id === organ.id);
        if (stats && organ.weight_factor) {
          // E = Σ w_T * H_T (simplified: H_T ≈ D_mean for photons)
          effective_dose_mSv += parseFloat(organ.weight_factor) * stats.d_mean;
        }
      }
    }

    // Update analysis run with results
    const { error: updateError } = await supabaseClient
      .from("analysis_runs")
      .update({
        status: "completed",
        finished_at: new Date().toISOString(),
        results: {
          organ_statistics: organStats,
          effective_dose_mSv,
          method_used: method,
          provenance: {
            timestamp: new Date().toISOString(),
            user_id: user.id,
            parameters: params,
          },
        },
      })
      .eq("id", analysisRun.id);

    if (updateError) {
      throw updateError;
    }

    // Log to audit
    await supabaseClient.from("audit_logs").insert({
      user_id: user.id,
      action: "analysis_completed",
      resource_type: "analysis_run",
      resource_id: run_id,
      details: {
        study_id,
        method,
        effective_dose_mSv,
        organ_count: organStats.length,
      },
    });

    return new Response(
      JSON.stringify({
        success: true,
        run_id,
        results: {
          organ_statistics: organStats,
          effective_dose_mSv: effective_dose_mSv.toFixed(2),
          status: "completed",
        },
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  } catch (error) {
    console.error("Analysis error:", error);
    const errorMessage = error instanceof Error ? error.message : "Unknown error occurred";
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  }
});
