// Deno edge function for organ dose orchestration

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface CalculationRequest {
  study_id: string;
  dose_files: string[]; // Paths to DICOM files in storage
  organ_masks: { [key: string]: string }; // { organ_name: nifti_file_path }
}

Deno.serve(async (req) => {
  // Handle CORS preflight
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log('Starting organ dose calculation...');
    
    const requestData: CalculationRequest = await req.json();
    const { study_id, dose_files, organ_masks } = requestData;

    console.log(`Processing study: ${study_id}`);
    console.log(`Dose files: ${dose_files.length}`);
    console.log(`Organ masks: ${Object.keys(organ_masks).length}`);

    // Call Python calculation service
    const pythonResponse = await fetch(
      `${Deno.env.get('SUPABASE_URL')}/functions/v1/calculate-dose-python`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': req.headers.get('Authorization') || '',
        },
        body: JSON.stringify({
          study_id,
          dose_files,
          organ_masks,
        }),
      }
    );

    if (!pythonResponse.ok) {
      const error = await pythonResponse.text();
      console.error('Python calculation failed:', error);
      throw new Error(`Calculation failed: ${error}`);
    }

    const results = await pythonResponse.json();
    console.log('Calculation completed successfully');

    return new Response(
      JSON.stringify({
        success: true,
        study_id,
        results,
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      }
    );

  } catch (error) {
    console.error('Error in calculate-organ-dose:', error);
    return new Response(
      JSON.stringify({ 
        error: error instanceof Error ? error.message : 'Unknown error',
        details: 'Failed to calculate organ doses',
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500,
      }
    );
  }
});
