import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.7.1";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface ReportRequest {
  study_id: string;
  analysis_run_id?: string;
  format: "json" | "html";
  include_sections: string[];
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
    );

    const authHeader = req.headers.get("Authorization")!;
    const token = authHeader.replace("Bearer ", "");
    const { data: { user }, error: authError } = await supabaseClient.auth.getUser(token);

    if (authError || !user) {
      return new Response(
        JSON.stringify({ error: "Unauthorized" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    const requestData: ReportRequest = await req.json();
    const { study_id, analysis_run_id, format, include_sections } = requestData;

    // Fetch study data with all related information
    const { data: study, error: studyError } = await supabaseClient
      .from("studies")
      .select(`
        *,
        patient:patients(*),
        protocol:protocols(*),
        institution:institutions(*),
        device:devices(*),
        physician:physicians(*),
        series(*),
        analysis_runs(*)
      `)
      .eq("id", study_id)
      .single();

    if (studyError || !study) {
      throw new Error("Study not found");
    }

    // Find the specific analysis run or use the latest completed one
    let analysisRun = null;
    if (analysis_run_id) {
      analysisRun = study.analysis_runs?.find((r: any) => r.id === analysis_run_id);
    } else {
      analysisRun = study.analysis_runs?.find((r: any) => r.status === "completed");
    }

    if (!analysisRun) {
      throw new Error("No completed analysis found for this study");
    }

    const results = analysisRun.results as any;

    // Generate report structure
    const report = {
      metadata: {
        generated_at: new Date().toISOString(),
        generated_by: user.email,
        report_version: "1.0.0",
        study_id: study.study_id,
      },
      study_information: {
        study_id: study.study_id,
        study_date: study.study_date,
        patient: study.patient?.pseudonym_id,
        institution: study.institution?.name,
        modality: study.modality_set,
        protocol: study.protocol?.name,
        device: study.device ? `${study.device.vendor} ${study.device.model}` : null,
      },
      methodology: {
        impact_mc_version: analysisRun.impact_mc_version,
        code_version: analysisRun.code_version,
        analysis_method: results.method_used,
        parameters: analysisRun.params,
        started_at: analysisRun.started_at,
        finished_at: analysisRun.finished_at,
      },
      results: {
        effective_dose_mSv: results.effective_dose_mSv,
        organ_statistics: results.organ_statistics,
        provenance: results.provenance,
      },
      disclaimer: {
        text: "RESEARCH USE ONLY: This report is generated for research purposes only and is not approved for clinical decision-making. Effective dose calculations are based on ICRP-103 organ weighting factors and provide population-averaged risk estimates. Individual patient risk assessment requires clinical context and cannot be based solely on effective dose values.",
        certification: "Not CE-marked. Not FDA-approved. For research and educational purposes only.",
      },
    };

    if (format === "json") {
      // Log to audit
      await supabaseClient.from("audit_logs").insert({
        user_id: user.id,
        action: "report_generated",
        resource_type: "study",
        resource_id: study.study_id,
        details: {
          format: "json",
          analysis_run_id: analysisRun.id,
        },
      });

      return new Response(
        JSON.stringify(report, null, 2),
        { 
          headers: { 
            ...corsHeaders, 
            "Content-Type": "application/json",
            "Content-Disposition": `attachment; filename="report-${study.study_id}-${Date.now()}.json"`,
          } 
        },
      );
    } else if (format === "html") {
      // Generate HTML report
      const html = generateHtmlReport(report);

      // Log to audit
      await supabaseClient.from("audit_logs").insert({
        user_id: user.id,
        action: "report_generated",
        resource_type: "study",
        resource_id: study.study_id,
        details: {
          format: "html",
          analysis_run_id: analysisRun.id,
        },
      });

      return new Response(html, {
        headers: {
          ...corsHeaders,
          "Content-Type": "text/html",
          "Content-Disposition": `attachment; filename="report-${study.study_id}-${Date.now()}.html"`,
        },
      });
    }

    return new Response(
      JSON.stringify({ error: "Invalid format" }),
      { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  } catch (error) {
    console.error("Report generation error:", error);
    const errorMessage = error instanceof Error ? error.message : "Unknown error occurred";
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  }
});

function generateHtmlReport(report: any): string {
  return `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>IMPACT-MC Dose Analysis Report - ${report.study_information.study_id}</title>
  <style>
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      max-width: 1000px;
      margin: 0 auto;
      padding: 40px 20px;
      line-height: 1.6;
      color: #333;
    }
    .header {
      border-bottom: 3px solid #3b82f6;
      padding-bottom: 20px;
      margin-bottom: 30px;
    }
    h1 { color: #1e40af; margin: 0; }
    h2 { color: #3b82f6; margin-top: 30px; border-bottom: 2px solid #e5e7eb; padding-bottom: 10px; }
    h3 { color: #475569; margin-top: 20px; }
    table {
      width: 100%;
      border-collapse: collapse;
      margin: 20px 0;
    }
    th, td {
      padding: 12px;
      text-align: left;
      border-bottom: 1px solid #e5e7eb;
    }
    th {
      background-color: #f8fafc;
      font-weight: 600;
      color: #475569;
    }
    .meta-info {
      background: #f8fafc;
      padding: 15px;
      border-radius: 8px;
      margin: 20px 0;
    }
    .disclaimer {
      background: #fef3c7;
      border-left: 4px solid #f59e0b;
      padding: 15px;
      margin: 30px 0;
      border-radius: 4px;
    }
    .highlight {
      background: #dbeafe;
      padding: 20px;
      border-radius: 8px;
      text-align: center;
      font-size: 1.2em;
      margin: 20px 0;
    }
    .footer {
      margin-top: 50px;
      padding-top: 20px;
      border-top: 1px solid #e5e7eb;
      font-size: 0.9em;
      color: #6b7280;
    }
  </style>
</head>
<body>
  <div class="header">
    <h1>IMPACT-MC Dose Analysis Report</h1>
    <p>Study: ${report.study_information.study_id}</p>
    <p>Generated: ${new Date(report.metadata.generated_at).toLocaleString()}</p>
  </p>
  </div>

  <h2>Executive Summary</h2>
  <div class="highlight">
    <strong>Effective Dose (E):</strong> ${report.results.effective_dose_mSv} mSv
  </div>

  <h2>Study Information</h2>
  <div class="meta-info">
    <p><strong>Patient:</strong> ${report.study_information.patient}</p>
    <p><strong>Study Date:</strong> ${report.study_information.study_date}</p>
    <p><strong>Institution:</strong> ${report.study_information.institution || "—"}</p>
    <p><strong>Modality:</strong> ${report.study_information.modality.join(", ")}</p>
    <p><strong>Protocol:</strong> ${report.study_information.protocol || "—"}</p>
    <p><strong>Device:</strong> ${report.study_information.device || "—"}</p>
  </div>

  <h2>Methodology</h2>
  <p><strong>IMPACT-MC Version:</strong> ${report.methodology.impact_mc_version}</p>
  <p><strong>Analysis Method:</strong> ${report.methodology.analysis_method}</p>
  <p><strong>Analysis Completed:</strong> ${new Date(report.methodology.finished_at).toLocaleString()}</p>

  <h2>Organ Dose Statistics</h2>
  <table>
    <thead>
      <tr>
        <th>Organ</th>
        <th>Volume (ml)</th>
        <th>D<sub>mean</sub> (Gy)</th>
        <th>D<sub>min</sub> (Gy)</th>
        <th>D<sub>max</sub> (Gy)</th>
        <th>D<sub>median</sub> (Gy)</th>
      </tr>
    </thead>
    <tbody>
      ${report.results.organ_statistics.map((stat: any) => `
        <tr>
          <td><strong>${stat.label}</strong></td>
          <td>${stat.volume_ml.toFixed(1)}</td>
          <td>${stat.d_mean.toFixed(3)}</td>
          <td>${stat.d_min.toFixed(3)}</td>
          <td>${stat.d_max.toFixed(3)}</td>
          <td>${stat.d_median.toFixed(3)}</td>
        </tr>
      `).join("")}
    </tbody>
  </table>

  <h2>Effective Dose Calculation</h2>
  <p>Effective dose was calculated using ICRP-103 tissue weighting factors according to:</p>
  <p style="text-align: center; font-style: italic;">E = Σ w<sub>T</sub> × H<sub>T</sub></p>
  <p>where H<sub>T</sub> ≈ D<sub>mean</sub> for photon radiation.</p>

  <div class="disclaimer">
    <h3 style="margin-top: 0;">⚠️ Important Disclaimer</h3>
    <p><strong>${report.disclaimer.text}</strong></p>
    <p><strong>Certification Status:</strong> ${report.disclaimer.certification}</p>
  </div>

  <div class="footer">
    <p><strong>Report Metadata:</strong></p>
    <p>Generated by: ${report.metadata.generated_by}</p>
    <p>Report Version: ${report.metadata.report_version}</p>
    <p>Study ID: ${report.metadata.study_id}</p>
  </div>
</body>
</html>
  `.trim();
}
