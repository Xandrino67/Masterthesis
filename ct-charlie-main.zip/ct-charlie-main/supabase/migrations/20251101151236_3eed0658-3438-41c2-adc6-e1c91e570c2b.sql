-- Create table to track chunked uploads
CREATE TABLE IF NOT EXISTS public.chunked_uploads (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  upload_id TEXT NOT NULL UNIQUE,
  study_id UUID NOT NULL,
  filename TEXT NOT NULL,
  total_chunks INTEGER NOT NULL,
  chunks_received INTEGER DEFAULT 0,
  total_size BIGINT,
  status TEXT DEFAULT 'uploading',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  completed_at TIMESTAMP WITH TIME ZONE
);

-- Enable RLS
ALTER TABLE public.chunked_uploads ENABLE ROW LEVEL SECURITY;

-- Policy: Allow service role full access (used by edge functions)
CREATE POLICY "Service role can manage chunked uploads"
  ON public.chunked_uploads
  FOR ALL
  USING (auth.jwt()->>'role' = 'service_role')
  WITH CHECK (auth.jwt()->>'role' = 'service_role');