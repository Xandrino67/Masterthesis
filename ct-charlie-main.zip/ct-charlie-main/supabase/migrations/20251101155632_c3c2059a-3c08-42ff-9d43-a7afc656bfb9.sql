-- Create extracted_files table for storing ZIP file hierarchy
CREATE TABLE public.extracted_files (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  study_id UUID NOT NULL REFERENCES public.studies(id) ON DELETE CASCADE,
  original_path TEXT NOT NULL,
  storage_bucket TEXT NOT NULL,
  storage_path TEXT NOT NULL,
  file_type TEXT NOT NULL,
  file_size BIGINT NOT NULL,
  parent_path TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  created_by UUID REFERENCES auth.users(id)
);

-- Create index for faster hierarchy queries
CREATE INDEX idx_extracted_files_study_id ON public.extracted_files(study_id);
CREATE INDEX idx_extracted_files_parent_path ON public.extracted_files(parent_path);

-- Enable RLS
ALTER TABLE public.extracted_files ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Authenticated users can view extracted files"
  ON public.extracted_files
  FOR SELECT
  USING (true);

CREATE POLICY "Researchers can insert extracted files"
  ON public.extracted_files
  FOR INSERT
  WITH CHECK (
    has_role(auth.uid(), 'researcher'::app_role) OR 
    has_role(auth.uid(), 'data_manager'::app_role)
  );

CREATE POLICY "Researchers can delete extracted files"
  ON public.extracted_files
  FOR DELETE
  USING (
    has_role(auth.uid(), 'researcher'::app_role) OR 
    has_role(auth.uid(), 'data_manager'::app_role)
  );