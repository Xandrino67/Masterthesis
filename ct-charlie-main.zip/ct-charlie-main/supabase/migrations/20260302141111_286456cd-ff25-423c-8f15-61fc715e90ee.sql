ALTER TABLE public.studies DROP CONSTRAINT studies_upload_mode_check;

ALTER TABLE public.studies ADD CONSTRAINT studies_upload_mode_check CHECK (upload_mode = ANY (ARRAY['essential'::text, 'all'::text, 'ct-only'::text, 'nuclear_medicine'::text]));