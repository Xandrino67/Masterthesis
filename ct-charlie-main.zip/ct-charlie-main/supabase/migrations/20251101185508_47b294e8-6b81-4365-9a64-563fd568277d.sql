-- Update dose-files bucket to allow more MIME types including ZIP files
UPDATE storage.buckets 
SET allowed_mime_types = ARRAY[
  'application/dicom',
  'application/x-gzip', 
  'application/gzip',
  'application/octet-stream',
  'application/x-nifti',
  'image/x-dicom',
  'application/json',
  'text/plain',
  'application/zip',
  'application/x-zip-compressed',
  'application/x-compressed'
]
WHERE id = 'dose-files';