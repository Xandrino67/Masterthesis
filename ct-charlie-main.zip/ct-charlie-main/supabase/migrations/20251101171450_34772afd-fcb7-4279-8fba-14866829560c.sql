-- Make all master data tables readable for everyone
-- This ensures data consistency and proper relationships

-- Institutions
DROP POLICY IF EXISTS "Authenticated users can view institutions" ON public.institutions;
CREATE POLICY "Anyone can view institutions"
ON public.institutions FOR SELECT TO public USING (true);

-- Departments  
DROP POLICY IF EXISTS "Authenticated users can view departments" ON public.departments;
CREATE POLICY "Anyone can view departments"
ON public.departments FOR SELECT TO public USING (true);

-- Devices
DROP POLICY IF EXISTS "Authenticated users can view devices" ON public.devices;
CREATE POLICY "Anyone can view devices"
ON public.devices FOR SELECT TO public USING (true);

-- Protocols
DROP POLICY IF EXISTS "Authenticated users can view protocols" ON public.protocols;
CREATE POLICY "Anyone can view protocols"
ON public.protocols FOR SELECT TO public USING (true);

-- Physicians
DROP POLICY IF EXISTS "Authenticated users can view physicians" ON public.physicians;
CREATE POLICY "Anyone can view physicians"
ON public.physicians FOR SELECT TO public USING (true);

-- Organs
DROP POLICY IF EXISTS "Authenticated users can view organs" ON public.organs;
CREATE POLICY "Anyone can view organs"
ON public.organs FOR SELECT TO public USING (true);

-- Extracted files
DROP POLICY IF EXISTS "Authenticated users can view extracted files" ON public.extracted_files;
CREATE POLICY "Anyone can view extracted files"
ON public.extracted_files FOR SELECT TO public USING (true);