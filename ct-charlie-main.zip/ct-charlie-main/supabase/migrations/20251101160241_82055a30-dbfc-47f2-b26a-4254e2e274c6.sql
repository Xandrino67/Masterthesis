-- Add zip_deleted_at timestamp to chunked_uploads for audit trail
ALTER TABLE public.chunked_uploads 
ADD COLUMN zip_deleted_at timestamp with time zone;