-- Fix Storage RLS Policies for dose-files bucket
-- Drop existing restrictive policies if they exist
DROP POLICY IF EXISTS "Users can upload files to dose-files bucket" ON storage.objects;
DROP POLICY IF EXISTS "Users can read files from dose-files bucket" ON storage.objects;
DROP POLICY IF EXISTS "Authenticated users can upload to dose-files" ON storage.objects;
DROP POLICY IF EXISTS "Authenticated users can read from dose-files" ON storage.objects;
DROP POLICY IF EXISTS "Authenticated users can update dose-files" ON storage.objects;
DROP POLICY IF EXISTS "Authenticated users can delete from dose-files" ON storage.objects;

-- Create permissive policies for authenticated users
CREATE POLICY "Authenticated users can upload to dose-files"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (bucket_id = 'dose-files');

CREATE POLICY "Authenticated users can read from dose-files"
ON storage.objects FOR SELECT
TO authenticated
USING (bucket_id = 'dose-files');

CREATE POLICY "Authenticated users can update dose-files"
ON storage.objects FOR UPDATE
TO authenticated
USING (bucket_id = 'dose-files');

CREATE POLICY "Authenticated users can delete from dose-files"
ON storage.objects FOR DELETE
TO authenticated
USING (bucket_id = 'dose-files');

-- Update bucket file size limit to 500MB
UPDATE storage.buckets 
SET file_size_limit = 524288000
WHERE id = 'dose-files';