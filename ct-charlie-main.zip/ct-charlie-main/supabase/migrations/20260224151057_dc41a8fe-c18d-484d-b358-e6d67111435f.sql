
-- =============================================
-- Restrict all "Anyone can view" SELECT policies 
-- to authenticated users only
-- =============================================

-- 1. patients
DROP POLICY IF EXISTS "Anyone can view patients" ON public.patients;
CREATE POLICY "Authenticated users can view patients"
  ON public.patients FOR SELECT TO authenticated
  USING (true);

-- 2. studies
DROP POLICY IF EXISTS "Anyone can view studies" ON public.studies;
CREATE POLICY "Authenticated users can view studies"
  ON public.studies FOR SELECT TO authenticated
  USING (true);

-- 3. series
DROP POLICY IF EXISTS "Anyone can view series" ON public.series;
CREATE POLICY "Authenticated users can view series"
  ON public.series FOR SELECT TO authenticated
  USING (true);

-- 4. analysis_runs
DROP POLICY IF EXISTS "Anyone can view analysis runs" ON public.analysis_runs;
CREATE POLICY "Authenticated users can view analysis runs"
  ON public.analysis_runs FOR SELECT TO authenticated
  USING (true);

-- 5. extracted_files
DROP POLICY IF EXISTS "Anyone can view extracted files" ON public.extracted_files;
CREATE POLICY "Authenticated users can view extracted files"
  ON public.extracted_files FOR SELECT TO authenticated
  USING (true);

-- 6. profiles - restrict to own profile + admins
DROP POLICY IF EXISTS "Users can view all profiles" ON public.profiles;
CREATE POLICY "Users can view own profile or admins can view all"
  ON public.profiles FOR SELECT TO authenticated
  USING (
    auth.uid() = id
    OR has_role(auth.uid(), 'platform_admin'::app_role)
    OR has_role(auth.uid(), 'tenant_admin'::app_role)
  );

-- 7. cohorts
DROP POLICY IF EXISTS "Anyone can view cohorts" ON public.cohorts;
CREATE POLICY "Authenticated users can view cohorts"
  ON public.cohorts FOR SELECT TO authenticated
  USING (true);

-- 8. cohort_studies
DROP POLICY IF EXISTS "Anyone can view cohort studies" ON public.cohort_studies;
CREATE POLICY "Authenticated users can view cohort studies"
  ON public.cohort_studies FOR SELECT TO authenticated
  USING (true);

-- 9. institutions
DROP POLICY IF EXISTS "Anyone can view institutions" ON public.institutions;
CREATE POLICY "Authenticated users can view institutions"
  ON public.institutions FOR SELECT TO authenticated
  USING (true);

-- 10. departments
DROP POLICY IF EXISTS "Anyone can view departments" ON public.departments;
CREATE POLICY "Authenticated users can view departments"
  ON public.departments FOR SELECT TO authenticated
  USING (true);

-- 11. devices
DROP POLICY IF EXISTS "Anyone can view devices" ON public.devices;
CREATE POLICY "Authenticated users can view devices"
  ON public.devices FOR SELECT TO authenticated
  USING (true);

-- 12. protocols
DROP POLICY IF EXISTS "Anyone can view protocols" ON public.protocols;
CREATE POLICY "Authenticated users can view protocols"
  ON public.protocols FOR SELECT TO authenticated
  USING (true);

-- 13. physicians
DROP POLICY IF EXISTS "Anyone can view physicians" ON public.physicians;
CREATE POLICY "Authenticated users can view physicians"
  ON public.physicians FOR SELECT TO authenticated
  USING (true);

-- 14. organs
DROP POLICY IF EXISTS "Anyone can view organs" ON public.organs;
CREATE POLICY "Authenticated users can view organs"
  ON public.organs FOR SELECT TO authenticated
  USING (true);

-- 15. user_roles - also restrict to authenticated
DROP POLICY IF EXISTS "Users can view all roles" ON public.user_roles;
CREATE POLICY "Authenticated users can view roles"
  ON public.user_roles FOR SELECT TO authenticated
  USING (true);

-- 16. processed_images
DROP POLICY IF EXISTS "Anyone can view processed images" ON public.processed_images;
CREATE POLICY "Authenticated users can view processed images"
  ON public.processed_images FOR SELECT TO authenticated
  USING (true);

-- 17. processed_overlays
DROP POLICY IF EXISTS "Anyone can view processed overlays" ON public.processed_overlays;
CREATE POLICY "Authenticated users can view processed overlays"
  ON public.processed_overlays FOR SELECT TO authenticated
  USING (true);

-- 18. audit_logs INSERT policy for authenticated users (currently missing)
CREATE POLICY "Authenticated users can insert audit logs"
  ON public.audit_logs FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);
