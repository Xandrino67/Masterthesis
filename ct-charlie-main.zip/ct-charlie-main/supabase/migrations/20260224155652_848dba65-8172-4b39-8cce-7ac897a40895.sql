
-- Fix patients UPDATE policy: allow same roles as INSERT + row creator
DROP POLICY IF EXISTS "Data managers can update patients" ON public.patients;
CREATE POLICY "Authorized users can update patients"
  ON public.patients FOR UPDATE TO authenticated
  USING (
    auth.uid() = created_by
    OR has_role(auth.uid(), 'data_manager'::app_role)
    OR has_role(auth.uid(), 'tenant_admin'::app_role)
    OR has_role(auth.uid(), 'platform_admin'::app_role)
    OR has_role(auth.uid(), 'researcher'::app_role)
  );

-- Fix protocols UPDATE policy: add platform_admin + researcher
DROP POLICY IF EXISTS "Data managers can manage protocols" ON public.protocols;
CREATE POLICY "Authorized users can manage protocols"
  ON public.protocols FOR ALL TO authenticated
  USING (
    auth.uid() = created_by
    OR has_role(auth.uid(), 'data_manager'::app_role)
    OR has_role(auth.uid(), 'tenant_admin'::app_role)
    OR has_role(auth.uid(), 'platform_admin'::app_role)
    OR has_role(auth.uid(), 'researcher'::app_role)
  );

-- Fix physicians UPDATE policy
DROP POLICY IF EXISTS "Data managers can manage physicians" ON public.physicians;
CREATE POLICY "Authorized users can manage physicians"
  ON public.physicians FOR ALL TO authenticated
  USING (
    auth.uid() = created_by
    OR has_role(auth.uid(), 'data_manager'::app_role)
    OR has_role(auth.uid(), 'tenant_admin'::app_role)
    OR has_role(auth.uid(), 'platform_admin'::app_role)
    OR has_role(auth.uid(), 'researcher'::app_role)
  );

-- Fix devices UPDATE policy
DROP POLICY IF EXISTS "Data managers can manage devices" ON public.devices;
CREATE POLICY "Authorized users can manage devices"
  ON public.devices FOR ALL TO authenticated
  USING (
    auth.uid() = created_by
    OR has_role(auth.uid(), 'data_manager'::app_role)
    OR has_role(auth.uid(), 'tenant_admin'::app_role)
    OR has_role(auth.uid(), 'platform_admin'::app_role)
    OR has_role(auth.uid(), 'researcher'::app_role)
  );

-- Fix institutions UPDATE policy
DROP POLICY IF EXISTS "Data managers and admins can manage institutions" ON public.institutions;
CREATE POLICY "Authorized users can manage institutions"
  ON public.institutions FOR ALL TO authenticated
  USING (
    auth.uid() = created_by
    OR has_role(auth.uid(), 'data_manager'::app_role)
    OR has_role(auth.uid(), 'tenant_admin'::app_role)
    OR has_role(auth.uid(), 'platform_admin'::app_role)
    OR has_role(auth.uid(), 'researcher'::app_role)
  );

-- Fix organs UPDATE policy
DROP POLICY IF EXISTS "Admins can manage organs" ON public.organs;
CREATE POLICY "Authorized users can manage organs"
  ON public.organs FOR ALL TO authenticated
  USING (
    auth.uid() = created_by
    OR has_role(auth.uid(), 'data_manager'::app_role)
    OR has_role(auth.uid(), 'tenant_admin'::app_role)
    OR has_role(auth.uid(), 'platform_admin'::app_role)
    OR has_role(auth.uid(), 'researcher'::app_role)
  );
