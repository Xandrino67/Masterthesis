-- Create storage buckets for dose data, masks, and results
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES 
  ('dose-files', 'dose-files', false, 104857600, ARRAY['application/x-nifti', 'application/gzip', 'application/octet-stream', 'application/zip']),
  ('mask-files', 'mask-files', false, 104857600, ARRAY['application/dicom', 'application/x-nifti', 'application/gzip', 'application/octet-stream']),
  ('reports', 'reports', false, 52428800, ARRAY['application/pdf', 'application/json', 'image/png', 'image/svg+xml']);

-- RLS policies for dose-files bucket
CREATE POLICY "Authenticated users can view dose files"
ON storage.objects FOR SELECT
TO authenticated
USING (bucket_id = 'dose-files');

CREATE POLICY "Researchers can upload dose files"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'dose-files' AND
  (public.has_role(auth.uid(), 'researcher') OR public.has_role(auth.uid(), 'data_manager'))
);

CREATE POLICY "File owners can update their dose files"
ON storage.objects FOR UPDATE
TO authenticated
USING (
  bucket_id = 'dose-files' AND
  (owner = auth.uid() OR public.has_role(auth.uid(), 'data_manager'))
);

CREATE POLICY "File owners can delete their dose files"
ON storage.objects FOR DELETE
TO authenticated
USING (
  bucket_id = 'dose-files' AND
  (owner = auth.uid() OR public.has_role(auth.uid(), 'data_manager'))
);

-- RLS policies for mask-files bucket
CREATE POLICY "Authenticated users can view mask files"
ON storage.objects FOR SELECT
TO authenticated
USING (bucket_id = 'mask-files');

CREATE POLICY "Researchers can upload mask files"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'mask-files' AND
  (public.has_role(auth.uid(), 'researcher') OR public.has_role(auth.uid(), 'data_manager'))
);

CREATE POLICY "File owners can update their mask files"
ON storage.objects FOR UPDATE
TO authenticated
USING (
  bucket_id = 'mask-files' AND
  (owner = auth.uid() OR public.has_role(auth.uid(), 'data_manager'))
);

CREATE POLICY "File owners can delete their mask files"
ON storage.objects FOR DELETE
TO authenticated
USING (
  bucket_id = 'mask-files' AND
  (owner = auth.uid() OR public.has_role(auth.uid(), 'data_manager'))
);

-- RLS policies for reports bucket
CREATE POLICY "Authenticated users can view reports"
ON storage.objects FOR SELECT
TO authenticated
USING (bucket_id = 'reports');

CREATE POLICY "Researchers can upload reports"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'reports' AND
  (public.has_role(auth.uid(), 'researcher') OR public.has_role(auth.uid(), 'data_manager'))
);

CREATE POLICY "Report owners can delete their reports"
ON storage.objects FOR DELETE
TO authenticated
USING (
  bucket_id = 'reports' AND
  (owner = auth.uid() OR public.has_role(auth.uid(), 'data_manager'))
);
