-- Change study_id column type from uuid to text in chunked_uploads table
-- This is needed because the study ID is a text identifier (like "ST-1234"), not a UUID
-- The study record is created after the upload completes, so we can't reference the UUID yet

ALTER TABLE public.chunked_uploads 
ALTER COLUMN study_id TYPE text;