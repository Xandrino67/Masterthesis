-- Add upload_mode column to studies table to track which files were uploaded
ALTER TABLE public.studies 
ADD COLUMN upload_mode text CHECK (upload_mode IN ('essential', 'all', 'ct-only'));