-- Add file categorization columns to extracted_files table
ALTER TABLE public.extracted_files
ADD COLUMN IF NOT EXISTS organ_name TEXT,
ADD COLUMN IF NOT EXISTS series_number INTEGER;

-- Update file types for existing files based on path patterns
-- Mark dose distribution DICOM files
UPDATE public.extracted_files
SET file_type = 'dicom_dose'
WHERE file_type = 'dicom' 
  AND original_path ILIKE '%DoseDistribution%'
  AND original_path ILIKE '%.dcm';

-- Mark dose distribution NIfTI files (converted from DICOM)
UPDATE public.extracted_files
SET file_type = 'nifti_dose'
WHERE file_type = 'nifti_mask'
  AND original_path ILIKE '%DoseDistribution%';

-- Update organ mask files with organ names based on filename
UPDATE public.extracted_files
SET organ_name = 'Liver'
WHERE file_type = 'nifti_mask'
  AND (original_path ILIKE '%liver%' OR original_path ILIKE '%lever%');

UPDATE public.extracted_files
SET organ_name = 'Esophagus'
WHERE file_type = 'nifti_mask'
  AND (original_path ILIKE '%esophagus%' OR original_path ILIKE '%slokdarm%');

UPDATE public.extracted_files
SET organ_name = 'Kidneys'
WHERE file_type = 'nifti_mask'
  AND original_path ILIKE '%nieren%';

UPDATE public.extracted_files
SET organ_name = 'Vertebrae'
WHERE file_type = 'nifti_mask'
  AND original_path ILIKE '%wervel%';

UPDATE public.extracted_files
SET organ_name = 'Ribs'
WHERE file_type = 'nifti_mask'
  AND original_path ILIKE '%ribben%';

UPDATE public.extracted_files
SET organ_name = 'Heart'
WHERE file_type = 'nifti_mask'
  AND original_path ILIKE '%hart%';

UPDATE public.extracted_files
SET organ_name = 'Lungs'
WHERE file_type = 'nifti_mask'
  AND original_path ILIKE '%longen%';

-- Create index for faster queries
CREATE INDEX IF NOT EXISTS idx_extracted_files_file_type ON public.extracted_files(file_type);
CREATE INDEX IF NOT EXISTS idx_extracted_files_organ_name ON public.extracted_files(organ_name);
CREATE INDEX IF NOT EXISTS idx_extracted_files_study_file_type ON public.extracted_files(study_id, file_type);