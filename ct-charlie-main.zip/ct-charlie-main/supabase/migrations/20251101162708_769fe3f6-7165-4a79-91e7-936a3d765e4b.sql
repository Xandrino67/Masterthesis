-- Update the dose-files bucket to allow medical imaging MIME types
UPDATE storage.buckets
SET allowed_mime_types = ARRAY[
  'application/dicom',           -- DICOM files (.dcm)
  'application/x-gzip',          -- Gzipped files (.nii.gz)
  'application/gzip',            -- Alternative gzip MIME type
  'application/octet-stream',    -- Generic binary data
  'application/x-nifti',         -- NIfTI files
  'image/x-dicom',              -- Alternative DICOM MIME type
  'application/json',            -- JSON metadata
  'text/plain'                   -- Text files
]
WHERE id = 'dose-files';

-- Also update mask-files bucket for consistency
UPDATE storage.buckets
SET allowed_mime_types = ARRAY[
  'application/dicom',
  'application/x-gzip',
  'application/gzip',
  'application/octet-stream',
  'application/x-nifti',
  'image/x-dicom',
  'application/json',
  'text/plain'
]
WHERE id = 'mask-files';