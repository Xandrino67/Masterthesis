-- Add upload tracking columns to extracted_files
ALTER TABLE public.extracted_files 
ADD COLUMN IF NOT EXISTS uploaded_at timestamp with time zone DEFAULT now(),
ADD COLUMN IF NOT EXISTS uploaded_by uuid REFERENCES auth.users(id);

-- Create index for faster filtering
CREATE INDEX IF NOT EXISTS idx_extracted_files_uploaded_at ON public.extracted_files(uploaded_at DESC);
CREATE INDEX IF NOT EXISTS idx_extracted_files_uploaded_by ON public.extracted_files(uploaded_by);

-- Update existing records to have uploaded_by from created_by
UPDATE public.extracted_files 
SET uploaded_by = created_by 
WHERE uploaded_by IS NULL AND created_by IS NOT NULL;