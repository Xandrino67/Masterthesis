-- First drop the existing foreign key constraint
ALTER TABLE public.extracted_files 
DROP CONSTRAINT IF EXISTS extracted_files_study_id_fkey;

-- Change study_id column from uuid to text
ALTER TABLE public.extracted_files 
ALTER COLUMN study_id TYPE text USING study_id::text;

-- Create new foreign key constraint with explicit reference to studies.study_id text field
ALTER TABLE public.extracted_files 
ADD CONSTRAINT extracted_files_study_id_text_fkey 
FOREIGN KEY (study_id) 
REFERENCES public.studies(study_id) 
ON DELETE CASCADE;