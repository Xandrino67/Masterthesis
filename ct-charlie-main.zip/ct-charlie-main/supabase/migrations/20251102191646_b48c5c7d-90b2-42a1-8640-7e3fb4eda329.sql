-- Add mock data flags to existing tables
ALTER TABLE studies ADD COLUMN IF NOT EXISTS is_mock_data BOOLEAN DEFAULT FALSE;
ALTER TABLE patients ADD COLUMN IF NOT EXISTS is_mock_data BOOLEAN DEFAULT FALSE;
ALTER TABLE analysis_runs ADD COLUMN IF NOT EXISTS is_mock_data BOOLEAN DEFAULT FALSE;

-- Create cohorts table for managing patient/study subsets
CREATE TABLE IF NOT EXISTS cohorts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  description TEXT,
  filters JSONB DEFAULT '{}'::jsonb,
  include_mock_data BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  created_by UUID REFERENCES auth.users(id),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Create cohort_studies junction table
CREATE TABLE IF NOT EXISTS cohort_studies (
  cohort_id UUID REFERENCES cohorts(id) ON DELETE CASCADE,
  study_id UUID REFERENCES studies(id) ON DELETE CASCADE,
  added_at TIMESTAMPTZ DEFAULT NOW(),
  PRIMARY KEY (cohort_id, study_id)
);

-- Enable RLS on new tables
ALTER TABLE cohorts ENABLE ROW LEVEL SECURITY;
ALTER TABLE cohort_studies ENABLE ROW LEVEL SECURITY;

-- RLS policies for cohorts
CREATE POLICY "Anyone can view cohorts"
  ON cohorts FOR SELECT
  USING (true);

CREATE POLICY "Researchers can create cohorts"
  ON cohorts FOR INSERT
  WITH CHECK (has_role(auth.uid(), 'researcher'::app_role) OR has_role(auth.uid(), 'data_manager'::app_role));

CREATE POLICY "Cohort creators can update their cohorts"
  ON cohorts FOR UPDATE
  USING (created_by = auth.uid() OR has_role(auth.uid(), 'data_manager'::app_role));

CREATE POLICY "Cohort creators can delete their cohorts"
  ON cohorts FOR DELETE
  USING (created_by = auth.uid() OR has_role(auth.uid(), 'data_manager'::app_role));

-- RLS policies for cohort_studies
CREATE POLICY "Anyone can view cohort studies"
  ON cohort_studies FOR SELECT
  USING (true);

CREATE POLICY "Researchers can manage cohort studies"
  ON cohort_studies FOR ALL
  USING (
    EXISTS (
      SELECT 1 FROM cohorts 
      WHERE cohorts.id = cohort_studies.cohort_id 
      AND (cohorts.created_by = auth.uid() OR has_role(auth.uid(), 'data_manager'::app_role))
    )
  );

-- Add trigger for cohorts updated_at
CREATE TRIGGER update_cohorts_updated_at
  BEFORE UPDATE ON cohorts
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();