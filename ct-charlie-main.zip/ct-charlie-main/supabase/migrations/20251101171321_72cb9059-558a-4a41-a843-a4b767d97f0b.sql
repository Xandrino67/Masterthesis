-- Temporarily make studies fully readable for debugging
-- Drop and recreate the view policy to be absolutely sure it works
DROP POLICY IF EXISTS "Authenticated users can view studies" ON public.studies;

CREATE POLICY "Anyone can view studies"
ON public.studies
FOR SELECT
TO public
USING (true);

-- Same for patients
DROP POLICY IF EXISTS "Authenticated users can view patients" ON public.patients;

CREATE POLICY "Anyone can view patients"
ON public.patients
FOR SELECT
TO public
USING (true);

-- Same for series
DROP POLICY IF EXISTS "Authenticated users can view series" ON public.series;

CREATE POLICY "Anyone can view series"
ON public.series
FOR SELECT
TO public
USING (true);

-- Same for analysis_runs
DROP POLICY IF EXISTS "Authenticated users can view analysis runs" ON public.analysis_runs;

CREATE POLICY "Anyone can view analysis runs"
ON public.analysis_runs
FOR SELECT
TO public
USING (true);