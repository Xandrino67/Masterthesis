-- Create enum for user roles
CREATE TYPE public.app_role AS ENUM (
  'platform_admin',
  'tenant_admin', 
  'data_manager',
  'researcher',
  'viewer',
  'auditor'
);

-- Create enum for modality types
CREATE TYPE public.modality_type AS ENUM (
  'CT',
  'CBCT',
  'PET',
  'SPECT'
);

-- Create enum for analysis status
CREATE TYPE public.analysis_status AS ENUM (
  'pending',
  'running',
  'completed',
  'failed',
  'cancelled'
);

-- User profiles table (extends auth.users)
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  display_name TEXT,
  email TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- User roles table
CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
  role public.app_role NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  created_by UUID REFERENCES public.profiles(id),
  UNIQUE(user_id, role)
);

ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

-- Security definer function to check user roles
CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role public.app_role)
RETURNS BOOLEAN
LANGUAGE SQL
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles
    WHERE user_id = _user_id AND role = _role
  )
$$;

-- Institutions table
CREATE TABLE public.institutions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  address TEXT,
  country TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  created_by UUID REFERENCES public.profiles(id)
);

ALTER TABLE public.institutions ENABLE ROW LEVEL SECURITY;

-- Departments table
CREATE TABLE public.departments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  institution_id UUID REFERENCES public.institutions(id) ON DELETE CASCADE NOT NULL,
  name TEXT NOT NULL,
  modality_types public.modality_type[] DEFAULT '{}',
  contact_info TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  created_by UUID REFERENCES public.profiles(id)
);

ALTER TABLE public.departments ENABLE ROW LEVEL SECURITY;

-- Patients table (pseudonymized)
CREATE TABLE public.patients (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  pseudonym_id TEXT UNIQUE NOT NULL,
  birth_year INTEGER,
  sex TEXT CHECK (sex IN ('M', 'F', 'O', 'U')),
  notes TEXT,
  consent_flags JSONB DEFAULT '{}',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  created_by UUID REFERENCES public.profiles(id)
);

ALTER TABLE public.patients ENABLE ROW LEVEL SECURITY;

-- Physicians/Researchers table
CREATE TABLE public.physicians (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  role TEXT,
  affiliation TEXT,
  institution_id UUID REFERENCES public.institutions(id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  created_by UUID REFERENCES public.profiles(id)
);

ALTER TABLE public.physicians ENABLE ROW LEVEL SECURITY;

-- Devices table (CT/CBCT machines)
CREATE TABLE public.devices (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  device_id TEXT UNIQUE NOT NULL,
  vendor TEXT NOT NULL,
  model TEXT NOT NULL,
  serial_number TEXT,
  modality public.modality_type NOT NULL,
  department_id UUID REFERENCES public.departments(id),
  kvp_range JSONB,
  mas_range JSONB,
  geometry_params JSONB,
  bowtie_filter_type TEXT,
  isocenter JSONB,
  field_size JSONB,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  created_by UUID REFERENCES public.profiles(id)
);

ALTER TABLE public.devices ENABLE ROW LEVEL SECURITY;

-- Protocols table
CREATE TABLE public.protocols (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  modality public.modality_type NOT NULL,
  kvp NUMERIC,
  mas NUMERIC,
  pitch NUMERIC,
  collimation NUMERIC,
  rotation_time NUMERIC,
  exposure_settings JSONB,
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  created_by UUID REFERENCES public.profiles(id)
);

ALTER TABLE public.protocols ENABLE ROW LEVEL SECURITY;

-- Studies table
CREATE TABLE public.studies (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  study_id TEXT UNIQUE NOT NULL,
  patient_id UUID REFERENCES public.patients(id) NOT NULL,
  study_date DATE NOT NULL,
  indication TEXT,
  modality_set public.modality_type[] DEFAULT '{}',
  protocol_id UUID REFERENCES public.protocols(id),
  institution_id UUID REFERENCES public.institutions(id),
  device_id UUID REFERENCES public.devices(id),
  physician_id UUID REFERENCES public.physicians(id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  created_by UUID REFERENCES public.profiles(id)
);

ALTER TABLE public.studies ENABLE ROW LEVEL SECURITY;

-- Series table
CREATE TABLE public.series (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  series_id TEXT UNIQUE NOT NULL,
  study_id UUID REFERENCES public.studies(id) ON DELETE CASCADE NOT NULL,
  series_type TEXT NOT NULL CHECK (series_type IN ('CT', 'CBCT', 'Dose', 'Mask')),
  frame_of_reference_uid TEXT,
  voxel_spacing JSONB,
  origin JSONB,
  orientation JSONB,
  grid_size JSONB,
  unit TEXT DEFAULT 'Gy',
  file_path TEXT,
  checksum TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  created_by UUID REFERENCES public.profiles(id)
);

ALTER TABLE public.series ENABLE ROW LEVEL SECURITY;

-- ROIs/Organs library table
CREATE TABLE public.organs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  label TEXT NOT NULL,
  snomed_code TEXT,
  icrp_code TEXT,
  color TEXT,
  weight_factor NUMERIC,
  is_system_default BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  created_by UUID REFERENCES public.profiles(id)
);

ALTER TABLE public.organs ENABLE ROW LEVEL SECURITY;

-- Analysis runs table
CREATE TABLE public.analysis_runs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  run_id TEXT UNIQUE NOT NULL,
  study_id UUID REFERENCES public.studies(id) ON DELETE CASCADE NOT NULL,
  input_refs JSONB,
  code_version TEXT,
  impact_mc_version TEXT,
  params JSONB,
  started_at TIMESTAMP WITH TIME ZONE,
  finished_at TIMESTAMP WITH TIME ZONE,
  status public.analysis_status DEFAULT 'pending',
  checksums JSONB,
  provenance JSONB,
  results JSONB,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  created_by UUID REFERENCES public.profiles(id)
);

ALTER TABLE public.analysis_runs ENABLE ROW LEVEL SECURITY;

-- Audit log table
CREATE TABLE public.audit_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES public.profiles(id),
  action TEXT NOT NULL,
  resource_type TEXT NOT NULL,
  resource_id TEXT,
  details JSONB,
  ip_address TEXT,
  user_agent TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;

-- RLS Policies for profiles
CREATE POLICY "Users can view all profiles"
  ON public.profiles FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can update own profile"
  ON public.profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id);

-- RLS Policies for user_roles
CREATE POLICY "Admins can manage roles"
  ON public.user_roles FOR ALL
  TO authenticated
  USING (
    public.has_role(auth.uid(), 'platform_admin') OR
    public.has_role(auth.uid(), 'tenant_admin')
  );

CREATE POLICY "Users can view all roles"
  ON public.user_roles FOR SELECT
  TO authenticated
  USING (true);

-- RLS Policies for master data (institutions, departments, etc.)
CREATE POLICY "Authenticated users can view institutions"
  ON public.institutions FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Data managers and admins can manage institutions"
  ON public.institutions FOR ALL
  TO authenticated
  USING (
    public.has_role(auth.uid(), 'platform_admin') OR
    public.has_role(auth.uid(), 'tenant_admin') OR
    public.has_role(auth.uid(), 'data_manager')
  );

CREATE POLICY "Authenticated users can view departments"
  ON public.departments FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Data managers and admins can manage departments"
  ON public.departments FOR ALL
  TO authenticated
  USING (
    public.has_role(auth.uid(), 'platform_admin') OR
    public.has_role(auth.uid(), 'tenant_admin') OR
    public.has_role(auth.uid(), 'data_manager')
  );

-- RLS Policies for patients
CREATE POLICY "Authenticated users can view patients"
  ON public.patients FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Researchers and data managers can create patients"
  ON public.patients FOR INSERT
  TO authenticated
  WITH CHECK (
    public.has_role(auth.uid(), 'researcher') OR
    public.has_role(auth.uid(), 'data_manager') OR
    public.has_role(auth.uid(), 'tenant_admin')
  );

CREATE POLICY "Data managers can update patients"
  ON public.patients FOR UPDATE
  TO authenticated
  USING (
    public.has_role(auth.uid(), 'data_manager') OR
    public.has_role(auth.uid(), 'tenant_admin')
  );

-- RLS Policies for physicians
CREATE POLICY "Authenticated users can view physicians"
  ON public.physicians FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Data managers can manage physicians"
  ON public.physicians FOR ALL
  TO authenticated
  USING (
    public.has_role(auth.uid(), 'data_manager') OR
    public.has_role(auth.uid(), 'tenant_admin')
  );

-- RLS Policies for devices
CREATE POLICY "Authenticated users can view devices"
  ON public.devices FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Data managers can manage devices"
  ON public.devices FOR ALL
  TO authenticated
  USING (
    public.has_role(auth.uid(), 'data_manager') OR
    public.has_role(auth.uid(), 'tenant_admin')
  );

-- RLS Policies for protocols
CREATE POLICY "Authenticated users can view protocols"
  ON public.protocols FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Data managers can manage protocols"
  ON public.protocols FOR ALL
  TO authenticated
  USING (
    public.has_role(auth.uid(), 'data_manager') OR
    public.has_role(auth.uid(), 'tenant_admin')
  );

-- RLS Policies for studies
CREATE POLICY "Authenticated users can view studies"
  ON public.studies FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Researchers can create studies"
  ON public.studies FOR INSERT
  TO authenticated
  WITH CHECK (
    public.has_role(auth.uid(), 'researcher') OR
    public.has_role(auth.uid(), 'data_manager')
  );

CREATE POLICY "Study creators can update their studies"
  ON public.studies FOR UPDATE
  TO authenticated
  USING (created_by = auth.uid() OR public.has_role(auth.uid(), 'data_manager'));

-- RLS Policies for series
CREATE POLICY "Authenticated users can view series"
  ON public.series FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Researchers can manage series"
  ON public.series FOR ALL
  TO authenticated
  USING (
    public.has_role(auth.uid(), 'researcher') OR
    public.has_role(auth.uid(), 'data_manager')
  );

-- RLS Policies for organs
CREATE POLICY "Authenticated users can view organs"
  ON public.organs FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins can manage organs"
  ON public.organs FOR ALL
  TO authenticated
  USING (
    public.has_role(auth.uid(), 'platform_admin') OR
    public.has_role(auth.uid(), 'tenant_admin')
  );

-- RLS Policies for analysis runs
CREATE POLICY "Authenticated users can view analysis runs"
  ON public.analysis_runs FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Researchers can create analysis runs"
  ON public.analysis_runs FOR INSERT
  TO authenticated
  WITH CHECK (
    public.has_role(auth.uid(), 'researcher') OR
    public.has_role(auth.uid(), 'data_manager')
  );

CREATE POLICY "Run creators can update their runs"
  ON public.analysis_runs FOR UPDATE
  TO authenticated
  USING (created_by = auth.uid() OR public.has_role(auth.uid(), 'data_manager'));

-- RLS Policies for audit logs
CREATE POLICY "Auditors and admins can view audit logs"
  ON public.audit_logs FOR SELECT
  TO authenticated
  USING (
    public.has_role(auth.uid(), 'auditor') OR
    public.has_role(auth.uid(), 'platform_admin')
  );

-- Trigger function to update updated_at timestamp
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Apply updated_at triggers to all relevant tables
CREATE TRIGGER update_profiles_updated_at
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_institutions_updated_at
  BEFORE UPDATE ON public.institutions
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_departments_updated_at
  BEFORE UPDATE ON public.departments
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_patients_updated_at
  BEFORE UPDATE ON public.patients
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_physicians_updated_at
  BEFORE UPDATE ON public.physicians
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_devices_updated_at
  BEFORE UPDATE ON public.devices
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_protocols_updated_at
  BEFORE UPDATE ON public.protocols
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_studies_updated_at
  BEFORE UPDATE ON public.studies
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_series_updated_at
  BEFORE UPDATE ON public.series
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_organs_updated_at
  BEFORE UPDATE ON public.organs
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_analysis_runs_updated_at
  BEFORE UPDATE ON public.analysis_runs
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Function to handle new user profile creation
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, email, display_name)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'display_name', split_part(NEW.email, '@', 1))
  );
  RETURN NEW;
END;
$$;

-- Trigger to create profile on user signup
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Insert default organ weight factors (ICRP-103 based)
INSERT INTO public.organs (label, icrp_code, weight_factor, is_system_default) VALUES
  ('Gonads', 'T01', 0.08, true),
  ('Bone Marrow (Red)', 'T02', 0.12, true),
  ('Colon', 'T03', 0.12, true),
  ('Lung', 'T04', 0.12, true),
  ('Stomach', 'T05', 0.12, true),
  ('Breast', 'T06', 0.12, true),
  ('Bladder', 'T07', 0.04, true),
  ('Esophagus', 'T08', 0.04, true),
  ('Liver', 'T09', 0.04, true),
  ('Thyroid', 'T10', 0.04, true),
  ('Bone Surface', 'T11', 0.01, true),
  ('Brain', 'T12', 0.01, true),
  ('Salivary Glands', 'T13', 0.01, true),
  ('Skin', 'T14', 0.01, true);
