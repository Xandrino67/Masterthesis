-- Enable realtime for extracted_files table
ALTER TABLE public.extracted_files REPLICA IDENTITY FULL;
ALTER PUBLICATION supabase_realtime ADD TABLE public.extracted_files;