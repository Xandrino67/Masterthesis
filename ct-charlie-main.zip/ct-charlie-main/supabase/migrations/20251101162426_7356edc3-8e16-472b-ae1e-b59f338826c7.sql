-- Add upload_status column to extracted_files table for tracking individual file uploads
ALTER TABLE public.extracted_files 
ADD COLUMN IF NOT EXISTS upload_status text DEFAULT 'completed';

-- Add index on study_id and original_path for faster queries
CREATE INDEX IF NOT EXISTS idx_extracted_files_study_path 
ON public.extracted_files(study_id, original_path);

-- Drop the chunked_uploads table as it's no longer needed with direct folder uploads
DROP TABLE IF EXISTS public.chunked_uploads;