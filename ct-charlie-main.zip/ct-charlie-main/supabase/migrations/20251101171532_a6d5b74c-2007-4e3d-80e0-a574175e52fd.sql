-- Allow researchers to delete studies and their associated data
DROP POLICY IF EXISTS "Researchers can delete studies" ON public.studies;
CREATE POLICY "Researchers can delete studies"
ON public.studies FOR DELETE
TO authenticated
USING (
  has_role(auth.uid(), 'researcher'::app_role) OR 
  has_role(auth.uid(), 'data_manager'::app_role) OR
  created_by = auth.uid()
);

-- Allow deletion of series when study is deleted
DROP POLICY IF EXISTS "Researchers can delete series" ON public.series;
CREATE POLICY "Researchers can delete series"
ON public.series FOR DELETE
TO authenticated
USING (
  has_role(auth.uid(), 'researcher'::app_role) OR 
  has_role(auth.uid(), 'data_manager'::app_role)
);

-- Allow deletion of analysis runs
DROP POLICY IF EXISTS "Researchers can delete analysis runs" ON public.analysis_runs;
CREATE POLICY "Researchers can delete analysis runs"
ON public.analysis_runs FOR DELETE
TO authenticated
USING (
  has_role(auth.uid(), 'researcher'::app_role) OR 
  has_role(auth.uid(), 'data_manager'::app_role) OR
  created_by = auth.uid()
);