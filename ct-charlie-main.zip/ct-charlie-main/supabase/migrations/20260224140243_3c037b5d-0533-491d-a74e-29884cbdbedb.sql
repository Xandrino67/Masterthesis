-- Allow platform_admin and tenant_admin to delete profiles
CREATE POLICY "Admins can delete profiles"
ON public.profiles
FOR DELETE
USING (
  has_role(auth.uid(), 'platform_admin'::app_role) OR 
  has_role(auth.uid(), 'tenant_admin'::app_role)
);

-- Allow platform_admin and tenant_admin to update any profile
CREATE POLICY "Admins can update any profile"
ON public.profiles
FOR UPDATE
USING (
  has_role(auth.uid(), 'platform_admin'::app_role) OR 
  has_role(auth.uid(), 'tenant_admin'::app_role)
);