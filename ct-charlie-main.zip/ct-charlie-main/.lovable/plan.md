

# Patient-Centric Studies View with Cumulative Dose Tracking

## Overview

Restructure the Studies page from a flat list of studies to a **patient-grouped view**, where each patient is a collapsible row that reveals all their image acquisitions. Add a new **Patient Detail page** showing cumulative organ doses across all studies for that patient.

## Current State

- Studies page shows a flat list of all studies, each clickable to open StudyDetail
- Each study belongs to a patient (via `patient_id`), and patients already have multiple studies in the database
- Analysis results (organ doses) are stored per-study in `analysis_runs.results`
- No patient-level overview or cumulative dose view exists

## Proposed Changes

### 1. Restructure Studies Page (`src/pages/Studies.tsx`)

**Group studies by patient** instead of showing a flat list:

- Each row shows the **patient pseudonym**, number of studies, and date range
- Clicking the patient row expands/collapses a dropdown showing all studies for that patient (sorted by date)
- Each individual study in the dropdown is still clickable to navigate to `/study/:id` (existing behavior preserved)
- Add a **"View Patient Overview"** button/link per patient that navigates to `/patient/:patientId`
- Keep all existing filters (modality, date range, search) -- they now filter studies, and patients with no matching studies are hidden
- Keep all existing per-study actions (delete, upload CT, re-upload, file tree toggle)

```text
+--------------------------------------------------+
| Patient: MOCK-PT-0001  |  8 studies  | 2023-2025 |
|  [View Patient Overview]                         |
+--------------------------------------------------+
|  > Study MOCK-ST-...-2025-12-19  CT  1.24 mSv   |
|  > Study MOCK-ST-...-2025-10-24  CT  0.89 mSv   |
|  > Study MOCK-ST-...-2025-07-22  CT  --          |
|  ...                                              |
+--------------------------------------------------+
| Patient: MOCK-PT-0002  |  4 studies  | 2023-2025 |
+--------------------------------------------------+
```

### 2. New Patient Detail Page (`src/pages/PatientDetail.tsx`)

A new page at route `/patient/:patientId` showing:

**Header**: Patient pseudonym, sex, birth year, total number of studies

**Summary Cards**:
- Total number of image acquisitions
- Total cumulative effective dose (sum of all studies' effective doses)
- Date range of imaging history

**Studies Timeline Table**:
- All studies for this patient ordered by date
- Columns: Date, Study ID, Modality, Effective Dose, Status (has analysis or not)
- Each row clickable to navigate to the individual study detail page

**Cumulative Organ Dose Table**:
- Aggregates organ doses from all completed `analysis_runs` for this patient's studies
- For each organ: shows cumulative D_mean (sum across studies), plus per-study breakdown
- Only includes studies that have completed analysis runs

**Cumulative Dose Over Time Chart** (using Recharts):
- X-axis: study dates
- Y-axis: cumulative dose (mSv)
- Line chart showing how cumulative effective dose grows over time
- Optional: per-organ lines

### 3. Route Addition (`src/App.tsx`)

Add new route:
```
/patient/:patientId -> PatientDetail
```

### 4. Navigation Updates

- Add "Patient Overview" button in the Studies page per patient group
- In StudyDetail header, add a link back to the patient overview (next to back button)

## Technical Details

### Data Fetching (PatientDetail)

```typescript
// Fetch patient + all their studies + analysis results
const { data } = await supabase
  .from("patients")
  .select("*, studies(*, analysis_runs(results, status, finished_at))")
  .eq("id", patientId)
  .order("study_date", { referencedTable: "studies", ascending: true })
  .single();
```

### Cumulative Dose Calculation (client-side aggregation)

```typescript
// For each organ, sum d_mean across all completed analysis runs
const cumulativeDoses = {};
for (const study of patient.studies) {
  const latestRun = study.analysis_runs
    ?.filter(r => r.status === 'completed')
    .sort((a, b) => new Date(b.finished_at) - new Date(a.finished_at))[0];
  
  if (latestRun?.results?.organ_doses) {
    for (const [organ, data] of Object.entries(latestRun.results.organ_doses)) {
      cumulativeDoses[organ] = (cumulativeDoses[organ] || 0) + data.d_mean;
    }
  }
}
```

### Studies Page Grouping

```typescript
// Group studies by patient_id
const patientGroups = studies.reduce((groups, study) => {
  const patientId = study.patient_id;
  if (!groups[patientId]) groups[patientId] = [];
  groups[patientId].push(study);
  return groups;
}, {});
```

### Files to Create/Modify

| File | Action |
|------|--------|
| `src/pages/Studies.tsx` | Modify - group by patient with expand/collapse |
| `src/pages/PatientDetail.tsx` | Create - new patient overview page |
| `src/App.tsx` | Modify - add `/patient/:patientId` route |

### No Database Changes Required

All data already exists in the current schema. Cumulative doses are computed client-side by aggregating `analysis_runs.results` across a patient's studies.

