import { useEffect, useRef } from 'react';
import { supabase } from '@/integrations/supabase/client';

/**
 * Hook to automatically refresh the session to prevent expiration
 * Refreshes proactively before token expires and on user activity
 */
export const useSessionRefresh = () => {
  const refreshIntervalRef = useRef<NodeJS.Timeout>();
  const lastActivityRef = useRef<number>(Date.now());
  const activityTimeoutRef = useRef<NodeJS.Timeout>();

  useEffect(() => {
    // Function to refresh the session
    const refreshSession = async () => {
      try {
        const { data: { session }, error } = await supabase.auth.refreshSession();
        
        if (error) {
          console.error('Session refresh error:', error);
          return;
        }
        
        if (session) {
          const expiresAt = new Date(session.expires_at! * 1000);
          const timeUntilExpiry = expiresAt.getTime() - Date.now();
          const minutesUntilExpiry = Math.floor(timeUntilExpiry / 60000);
          
          console.log(`✅ Session refreshed successfully (expires in ${minutesUntilExpiry} minutes)`);
        }
      } catch (error) {
        console.error('Exception during session refresh:', error);
      }
    };

    // Check if session is about to expire and refresh preemptively
    const checkAndRefreshIfNeeded = async () => {
      try {
        const { data: { session } } = await supabase.auth.getSession();
        
        if (session?.expires_at) {
          const expiresAt = new Date(session.expires_at * 1000);
          const timeUntilExpiry = expiresAt.getTime() - Date.now();
          const minutesUntilExpiry = Math.floor(timeUntilExpiry / 60000);
          
          // If less than 10 minutes until expiry, refresh now
          if (timeUntilExpiry < 10 * 60 * 1000 && timeUntilExpiry > 0) {
            console.log(`⚠️ Session expires in ${minutesUntilExpiry} minutes - refreshing now...`);
            await refreshSession();
          }
        }
      } catch (error) {
        console.error('Error checking session expiry:', error);
      }
    };

    // Refresh token every 15 minutes to stay well ahead of expiry
    const startPeriodicRefresh = () => {
      if (refreshIntervalRef.current) {
        clearInterval(refreshIntervalRef.current);
      }
      
      // Refresh every 15 minutes
      refreshIntervalRef.current = setInterval(() => {
        console.log('🔄 Periodic session refresh (15 min interval)...');
        refreshSession();
      }, 15 * 60 * 1000);
    };

    // Handle user activity - refresh if there's been activity after 10 minutes of inactivity
    const handleActivity = () => {
      const now = Date.now();
      const timeSinceLastActivity = now - lastActivityRef.current;
      
      // If more than 10 minutes since last activity, refresh session
      if (timeSinceLastActivity > 10 * 60 * 1000) {
        console.log('🔄 Refreshing session after user activity...');
        refreshSession();
      }
      
      lastActivityRef.current = now;
      
      // Clear existing timeout
      if (activityTimeoutRef.current) {
        clearTimeout(activityTimeoutRef.current);
      }
      
      // Set new timeout to refresh after 10 minutes of inactivity
      activityTimeoutRef.current = setTimeout(() => {
        console.log('🔄 Refreshing session due to inactivity threshold...');
        refreshSession();
      }, 10 * 60 * 1000);
    };

    // Start periodic refresh
    startPeriodicRefresh();
    
    // Add activity listeners
    const events = ['mousedown', 'keydown', 'scroll', 'touchstart'];
    events.forEach(event => {
      window.addEventListener(event, handleActivity, { passive: true });
    });

    // Check session expiry every minute
    const expiryCheckInterval = setInterval(() => {
      checkAndRefreshIfNeeded();
    }, 60 * 1000);

    // Initial refresh on mount
    refreshSession();

    // Cleanup
    return () => {
      if (refreshIntervalRef.current) {
        clearInterval(refreshIntervalRef.current);
      }
      if (activityTimeoutRef.current) {
        clearTimeout(activityTimeoutRef.current);
      }
      if (expiryCheckInterval) {
        clearInterval(expiryCheckInterval);
      }
      events.forEach(event => {
        window.removeEventListener(event, handleActivity);
      });
    };
  }, []);
};
