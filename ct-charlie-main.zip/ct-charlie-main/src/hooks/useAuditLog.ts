import { supabase } from "@/integrations/supabase/client";

interface AuditLogParams {
  action: string;
  resource_type: string;
  resource_id?: string;
  details?: Record<string, any>;
}

export const useAuditLog = () => {
  const logAction = async (params: AuditLogParams) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) {
        console.warn("Cannot log action: user not authenticated");
        return;
      }

      const { error } = await supabase.from("audit_logs").insert({
        user_id: user.id,
        action: params.action,
        resource_type: params.resource_type,
        resource_id: params.resource_id,
        details: params.details,
        ip_address: null, // Could be captured server-side
        user_agent: navigator.userAgent,
      });

      if (error) {
        console.error("Audit log error:", error);
      }
    } catch (error) {
      console.error("Failed to log action:", error);
    }
  };

  return { logAction };
};
