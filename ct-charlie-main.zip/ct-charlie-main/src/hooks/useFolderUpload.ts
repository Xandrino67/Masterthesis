import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";

interface FileNode {
  path: string;
  name: string;
  size: number;
  file: File;
  relativePath: string;
  status: 'pending' | 'uploading' | 'success' | 'error' | 'skipped';
  skipReason?: string;
  fileType?: string;
  organName?: string | null;
}

interface UploadProgress {
  totalFiles: number;
  uploadedFiles: number;
  failedFiles: number;
  skippedFiles: number;
  currentFile: string | null;
  fileProgress: Map<string, number>;
  newlyUploadedPaths: string[];
  failedFileReasons: Map<string, { error: string; errorType: string; size: number }>;
}

export const useFolderUpload = () => {
  const [uploading, setUploading] = useState(false);
  const [checking, setChecking] = useState(false);
  const [progress, setProgress] = useState<UploadProgress>({
    totalFiles: 0,
    uploadedFiles: 0,
    failedFiles: 0,
    skippedFiles: 0,
    currentFile: null,
    fileProgress: new Map(),
    newlyUploadedPaths: [],
    failedFileReasons: new Map(),
  });

  const processFolderStructure = (files: FileList, skipCtImages: boolean = true): FileNode[] => {
    const fileNodes: FileNode[] = [];
    let skippedCount = 0;
    const topLevelFolders = new Set<string>();
    const allFolders = new Set<string>();
    
    console.log(`📁 Processing ${files.length} files from folder selection (skipCtImages: ${skipCtImages})`);
    
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const webkitPath = (file as any).webkitRelativePath || file.name;
      const parts = webkitPath.split('/');
      
      // Track all folder paths
      if (parts.length > 1) {
        topLevelFolders.add(parts[1]); // First subfolder after root
        for (let j = 1; j < parts.length - 1; j++) {
          allFolders.add(parts.slice(0, j + 2).join('/'));
        }
      }
      
      // Skip hidden files and system files
      if (parts.some(part => part.startsWith('.') || part === '__MACOSX' || part === 'Thumbs.db')) {
        skippedCount++;
        continue;
      }
      
      // Include valid file extensions AND DICOM files without extension
      const fileName = file.name.toLowerCase();
      const isDicomWithoutExt = /^IM-\d+-\d+-\d+$/i.test(file.name); // DICOM naming pattern
      
      if (!fileName.endsWith('.dcm') && 
          !fileName.endsWith('.nii') && 
          !fileName.endsWith('.nii.gz') &&
          !fileName.endsWith('.json') &&
          !fileName.endsWith('.txt') &&
          !fileName.endsWith('.zip') &&
          !fileName.endsWith('.gz') &&
          !isDicomWithoutExt) {
        skippedCount++;
        continue;
      }

      // Keep the full path hierarchy as it is in Finder
      const relativePath = webkitPath;
      const fileType = detectFileType(file.name, relativePath);
      
      // Skip CT images if skipCtImages is true
      if (skipCtImages && (fileType === 'dicom_other' || fileType === 'dicom_ct_fusie' || fileType === 'dicom_ct_wb')) {
        skippedCount++;
        continue;
      }
      
      const organName = fileType === 'nifti_mask' ? detectOrganName(relativePath) : null;
      
      fileNodes.push({
        path: webkitPath,
        name: file.name,
        size: file.size,
        file,
        relativePath,
        status: 'pending',
        fileType,
        organName
      });
    }
    
    console.log(`✅ Processed ${fileNodes.length} valid files (skipped ${skippedCount} invalid/hidden files)`);
    
    // Log folder structure detected
    console.log('📂 Top-level folders found:', Array.from(topLevelFolders).sort());
    console.log('⚠️ Expected folders: CT_Beelden, DoseDistribution_WB_CT_NM, Segmentatie, TotalSegmentator');
    console.log('⚠️ CT subfolders expected: CT Voor Fusie 1.25 - 3, CT WB 3.0 Bot - 4');
    
    // Check if CT folders are present
    const ctFolders = Array.from(allFolders).filter(f => f.toLowerCase().includes('ct'));
    console.log('🔍 CT-related folders found:', ctFolders);
    
    // Log file type breakdown
    const typeBreakdown: Record<string, number> = {};
    fileNodes.forEach(f => {
      typeBreakdown[f.fileType || 'unknown'] = (typeBreakdown[f.fileType || 'unknown'] || 0) + 1;
    });
    console.log('📊 File type breakdown:', typeBreakdown);
    
    return fileNodes;
  };

  const detectFileType = (fileName: string, relativePath: string): string => {
    const lower = fileName.toLowerCase();
    const pathLower = relativePath.toLowerCase();
    const isDicomWithoutExt = /^IM-\d+-\d+-\d+$/i.test(fileName);
    
    // DICOM dose files in DoseDistribution folder
    if ((lower.endsWith('.dcm') || isDicomWithoutExt) && pathLower.includes('dosedistribution')) {
      return 'dicom_dose';
    }
    
    // Converted dose distribution NIfTI in DoseDistribution folder
    if ((lower.endsWith('.nii') || lower.endsWith('.nii.gz')) && 
        pathLower.includes('dosedistribution')) {
      return 'nifti_dose';
    }
    
    // Organ segmentations in TotalSegmentator folder
    if ((lower.endsWith('.nii') || lower.endsWith('.nii.gz')) && 
        pathLower.includes('totalsegmentator')) {
      return 'nifti_mask';
    }
    
    // CT images - distinguish between fusie and wb scans
    if (lower.endsWith('.dcm') || isDicomWithoutExt) {
      if (pathLower.includes('fusie')) {
        return 'dicom_ct_fusie';
      } else if (pathLower.includes('wb') || pathLower.includes('whole') || pathLower.includes('bot')) {
        return 'dicom_ct_wb';
      }
      // Generic CT images if not in specific folders
      return 'dicom_other';
    }
    
    // Other NIfTI files (e.g., in Segmentatie folder - optional)
    if (lower.endsWith('.nii') || lower.endsWith('.nii.gz')) return 'nifti_other';
    
    // Archive files
    if (lower.endsWith('.zip')) return 'zip_archive';
    if (lower.endsWith('.gz') && !lower.endsWith('.nii.gz')) return 'gz_archive';
    
    // Metadata files
    if (lower.endsWith('.json')) return 'metadata';
    if (lower.endsWith('.txt')) return 'text';
    
    return 'unknown';
  };

  const detectOrganName = (relativePath: string): string | null => {
    const pathLower = relativePath.toLowerCase();
    
    if (pathLower.includes('liver') || pathLower.includes('lever')) return 'Liver';
    if (pathLower.includes('esophagus') || pathLower.includes('slokdarm')) return 'Esophagus';
    if (pathLower.includes('nieren')) return 'Kidneys';
    if (pathLower.includes('wervel')) return 'Vertebrae';
    if (pathLower.includes('ribben')) return 'Ribs';
    if (pathLower.includes('hart') || pathLower.includes('heart')) return 'Heart';
    if (pathLower.includes('longen') || pathLower.includes('lung')) return 'Lungs';
    
    return null;
  };

  interface ValidationResult {
    isValid: boolean;
    errors: string[];
    warnings: string[];
    stats: {
      dicomCount: number;
      doseNiftiCount: number;
      organMaskCount: number;
      hasRequiredStructure: boolean;
    };
  }

  const validateFolderStructure = (files: FileNode[]): ValidationResult => {
    const errors: string[] = [];
    const warnings: string[] = [];
    
    // Check for required folders in paths
    const hasDoseDistribution = files.some(f => 
      f.relativePath.toLowerCase().includes('dosedistribution')
    );
    const hasTotalSegmentator = files.some(f => 
      f.relativePath.toLowerCase().includes('totalsegmentator')
    );
    
    if (!hasDoseDistribution) {
      errors.push('Missing DoseDistribution_WB_CT_NM folder');
    }
    
    if (!hasTotalSegmentator) {
      errors.push('Missing TotalSegmentator folder');
    }
    
    // Count file types by category
    const filesByType = {
      dicom_dose: files.filter(f => f.fileType === 'dicom_dose'),
      dicom_other: files.filter(f => f.fileType === 'dicom_other'),
      nifti_dose: files.filter(f => f.fileType === 'nifti_dose'),
      nifti_mask: files.filter(f => f.fileType === 'nifti_mask'),
      nifti_other: files.filter(f => f.fileType === 'nifti_other'),
      zip_archive: files.filter(f => f.fileType === 'zip_archive'),
      metadata: files.filter(f => f.fileType === 'metadata'),
      other: files.filter(f => f.fileType === 'text' || f.fileType === 'gz_archive' || f.fileType === 'unknown')
    };
    
    // Validate required files
    if (filesByType.dicom_dose.length === 0 && filesByType.nifti_dose.length === 0) {
      errors.push('No dose distribution files found (need DICOM .dcm files or converted NIfTI in DoseDistribution folder)');
    }
    
    if (filesByType.nifti_mask.length === 0) {
      errors.push('No organ segmentations found in TotalSegmentator folder');
    }
    
    // Check for required organs
    const requiredOrgans = ['liver', 'esophagus', 'nieren', 'wervel', 'ribben', 'hart', 'longen'];
    const foundOrgans = new Set<string>();
    
    files.forEach(f => {
      const pathLower = f.relativePath.toLowerCase();
      requiredOrgans.forEach(organ => {
        if (pathLower.includes(organ) || 
            (organ === 'esophagus' && pathLower.includes('slokdarm'))) {
          foundOrgans.add(organ);
        }
      });
    });
    
    const missingOrgans = requiredOrgans.filter(o => !foundOrgans.has(o));
    if (missingOrgans.length > 0) {
      warnings.push(`Missing organ segmentations: ${missingOrgans.join(', ')}`);
    }
    
    // Info about optional files
    if (filesByType.dicom_other.length > 0) {
      warnings.push(`Found ${filesByType.dicom_other.length} additional CT images (e.g., CT_Beelden) - these will be uploaded but not used in dose calculations`);
    }
    
    if (filesByType.zip_archive.length > 0) {
      warnings.push(`Found ${filesByType.zip_archive.length} ZIP archives - these will be uploaded but may need manual extraction`);
    }
    
    return {
      isValid: errors.length === 0,
      errors,
      warnings,
      stats: {
        dicomCount: filesByType.dicom_dose.length + filesByType.dicom_other.length,
        doseNiftiCount: filesByType.nifti_dose.length,
        organMaskCount: filesByType.nifti_mask.length,
        hasRequiredStructure: hasDoseDistribution && hasTotalSegmentator,
      },
    };
  };

  const uploadFileToStorage = async (
    file: File,
    studyId: string,
    relativePath: string,
    onProgress?: (progress: number) => void,
    retryCount: number = 0
  ): Promise<{ success: boolean; storagePath?: string; error?: string; errorType?: string; alreadyExists?: boolean }> => {
    const MAX_RETRIES = 3;
    const LARGE_FILE_THRESHOLD = 50 * 1024 * 1024; // 50MB
    const isLargeFile = file.size > LARGE_FILE_THRESHOLD;
    
    try {
      const storagePath = `studies/${studyId}/${relativePath}`;
      
      // Use resumable upload for large files
      if (isLargeFile) {
        console.log(`Using resumable upload for large file: ${relativePath} (${(file.size / 1024 / 1024).toFixed(2)}MB)`);
        
        // CRITICAL FIX: Refresh session before large file upload to ensure valid token
        console.log('🔐 Refreshing authentication token for large file upload...');
        const { data: { session: refreshedSession }, error: refreshError } = await supabase.auth.refreshSession();
        
        if (refreshError || !refreshedSession) {
          console.error('Failed to refresh session:', refreshError);
          return { 
            success: false, 
            error: 'Authentication token expired. Please refresh the page and try again.',
            errorType: 'auth_expired'
          };
        }
        
        console.log('✅ Token refreshed successfully');
        
        const { error: uploadError } = await supabase.storage
          .from('dose-files')
          .upload(storagePath, file, {
            cacheControl: '3600',
            upsert: false,
          });

        if (uploadError) {
          console.error('Large file upload error:', uploadError);
          
          // Check if file already exists
          if (uploadError.message.includes('already exists') || uploadError.message.includes('resource already exists')) {
            return { 
              success: false, 
              error: 'File already exists in storage',
              errorType: 'already_exists',
              alreadyExists: true
            };
          }
          
          // Special handling for RLS/auth errors - refresh token and retry
          if (uploadError.message.includes('row-level security') || uploadError.message.includes('Unauthorized')) {
            if (retryCount < 2) { // Max 2 retries for auth issues
              console.log(`🔄 Authentication failed, refreshing token and retrying (attempt ${retryCount + 1}/2)...`);
              const delay = 1000; // Fixed 1s delay for auth retries
              await new Promise(resolve => setTimeout(resolve, delay));
              return uploadFileToStorage(file, studyId, relativePath, onProgress, retryCount + 1);
            }
            return { 
              success: false, 
              error: 'Authentication failed after retries. Please refresh the page and log in again.',
              errorType: 'rls'
            };
          }
          
          // Retry logic for other errors with exponential backoff
          if (retryCount < MAX_RETRIES) {
            const delay = Math.pow(2, retryCount) * 1000; // 1s, 2s, 4s
            console.log(`Retrying upload in ${delay}ms (attempt ${retryCount + 1}/${MAX_RETRIES})...`);
            await new Promise(resolve => setTimeout(resolve, delay));
            return uploadFileToStorage(file, studyId, relativePath, onProgress, retryCount + 1);
          }
          
          return { 
            success: false, 
            error: uploadError.message,
            errorType: 'network'
          };
        }
      } else {
        // Standard upload for smaller files
        const { error: uploadError } = await supabase.storage
          .from('dose-files')
          .upload(storagePath, file, {
            cacheControl: '3600',
            upsert: false,
          });

        if (uploadError) {
          console.error('Upload error:', uploadError);
          
          // Check if file already exists
          if (uploadError.message.includes('already exists') || uploadError.message.includes('resource already exists')) {
            return { 
              success: false, 
              error: 'File already exists in storage',
              errorType: 'already_exists',
              alreadyExists: true
            };
          }
          
          // Retry logic for small files too
          if (retryCount < MAX_RETRIES && !uploadError.message.includes('row-level security')) {
            const delay = Math.pow(2, retryCount) * 500; // 0.5s, 1s, 2s
            await new Promise(resolve => setTimeout(resolve, delay));
            return uploadFileToStorage(file, studyId, relativePath, onProgress, retryCount + 1);
          }
          
          return { 
            success: false, 
            error: uploadError.message,
            errorType: uploadError.message.includes('row-level security') ? 'rls' : 'network'
          };
        }
      }

      return { success: true, storagePath };
    } catch (error) {
      console.error('Upload exception:', error);
      
      // Retry on exception (network issues, etc.)
      if (retryCount < MAX_RETRIES) {
        const delay = Math.pow(2, retryCount) * 1000;
        await new Promise(resolve => setTimeout(resolve, delay));
        return uploadFileToStorage(file, studyId, relativePath, onProgress, retryCount + 1);
      }
      
      return { 
        success: false, 
        error: error instanceof Error ? error.message : 'Unknown error',
        errorType: 'exception'
      };
    }
  };

  const uploadFilesInBatches = async (
    files: FileNode[],
    studyId: string,
    batchSize: number = 5
  ): Promise<{ success: boolean; uploadedCount: number; failedCount: number; skippedCount: number; newlyUploadedPaths: string[] }> => {
    setChecking(true);
    
    // First, try to refresh the session to ensure we have valid tokens
    console.log('🔐 Checking authentication...');
    const { data: { session }, error: sessionError } = await supabase.auth.getSession();
    
    if (sessionError) {
      console.error('Session error:', sessionError);
      setChecking(false);
      throw new Error(`Authentication error: ${sessionError.message}`);
    }
    
    if (!session) {
      console.error('No active session found');
      setChecking(false);
      throw new Error('Your session has expired. Please refresh the page and log in again.');
    }
    
    // Verify we have a valid user
    const { data: { user }, error: userError } = await supabase.auth.getUser();
    if (userError || !user) {
      console.error('User verification failed:', userError);
      setChecking(false);
      throw new Error('User not authenticated. Please refresh the page and log in again.');
    }
    
    console.log('✅ Authentication verified for user:', user.email);

    // Check for existing files
    const { data: existingFiles, error: checkError } = await supabase
      .from('extracted_files')
      .select('original_path, file_size')
      .eq('study_id', studyId);

    if (checkError) {
      console.error('Error checking existing files:', checkError);
    }

    console.log(`🔍 Found ${existingFiles?.length || 0} existing files in database for study ${studyId}`);

    const existingFileMap = new Map(
      existingFiles?.map(f => [f.original_path, f.file_size]) || []
    );

    // Filter out files that already exist with same size
    const filesToUpload = files.filter(f => {
      const existingSize = existingFileMap.get(f.relativePath);
      if (existingSize !== undefined && existingSize === f.size) {
        f.status = 'skipped';
        f.skipReason = 'Already uploaded';
        console.log(`⏭️  Skipping ${f.fileType}: ${f.relativePath} (already exists, ${f.size} bytes)`);
        return false;
      }
      return true;
    });

    const skippedCount = files.length - filesToUpload.length;
    console.log(`📤 ${filesToUpload.length} new files to upload, ${skippedCount} already exist`);
    
    // Log breakdown of files to upload by type
    const uploadTypeBreakdown: Record<string, number> = {};
    filesToUpload.forEach(f => {
      uploadTypeBreakdown[f.fileType || 'unknown'] = (uploadTypeBreakdown[f.fileType || 'unknown'] || 0) + 1;
    });
    console.log('📊 Files to upload by type:', uploadTypeBreakdown);
    
    setChecking(false);
    setUploading(true);
    
    const LARGE_FILE_THRESHOLD = 50 * 1024 * 1024; // 50MB
    
    // Separate large and small files for optimized processing
    const largeFiles = filesToUpload.filter(f => f.file.size > LARGE_FILE_THRESHOLD);
    const smallFiles = filesToUpload.filter(f => f.file.size <= LARGE_FILE_THRESHOLD);
    
    console.log(`Processing ${filesToUpload.length} files: ${largeFiles.length} large, ${smallFiles.length} small`);
    
    setProgress({
      totalFiles: files.length,
      uploadedFiles: 0,
      failedFiles: 0,
      skippedFiles: skippedCount,
      currentFile: null,
      fileProgress: new Map(),
      newlyUploadedPaths: [],
      failedFileReasons: new Map(),
    });

    let uploadedCount = 0;
    let failedCount = 0;
    const failedFiles: Array<FileNode & { error?: string; errorType?: string }> = [];
    const newlyUploadedPaths: string[] = [];

    // Track session refresh timing to prevent upload timeouts
    let lastRefreshTime = Date.now();
    const REFRESH_INTERVAL = 2 * 60 * 1000; // Refresh every 2 minutes

    // Process small files in parallel batches
    for (let i = 0; i < smallFiles.length; i += batchSize) {
      // Check if we need to refresh the session
      const timeSinceRefresh = Date.now() - lastRefreshTime;
      if (timeSinceRefresh > REFRESH_INTERVAL) {
        console.log('🔐 Refreshing session during batch upload...');
        const { error: refreshError } = await supabase.auth.refreshSession();
        if (refreshError) {
          console.error('Session refresh failed:', refreshError);
        } else {
          console.log('✅ Session refreshed successfully');
          lastRefreshTime = Date.now();
        }
      }
      
      const batch = smallFiles.slice(i, i + batchSize);
      
      await Promise.all(
        batch.map(async (fileNode) => {
          setProgress(prev => ({
            ...prev,
            currentFile: fileNode.relativePath,
          }));

          const result = await uploadFileToStorage(
            fileNode.file,
            studyId,
            fileNode.relativePath,
            (fileProgress) => {
              setProgress(prev => {
                const newFileProgress = new Map(prev.fileProgress);
                newFileProgress.set(fileNode.relativePath, fileProgress);
                return { ...prev, fileProgress: newFileProgress };
              });
            }
          );

          // If file already exists in storage, treat as skip instead of failure
          if (result.alreadyExists) {
            setProgress(prev => ({
              ...prev,
              skippedFiles: prev.skippedFiles + 1,
            }));
            return;
          }

          if (result.success && result.storagePath) {
            const fileType = fileNode.fileType || detectFileType(fileNode.name, fileNode.relativePath);
            
            // Extract series number from DICOM files if present in the filename
            let seriesNumber: number | null = null;
            if (fileType === 'dicom_dose') {
              const match = fileNode.name.match(/\d+/);
              if (match) {
                seriesNumber = parseInt(match[0], 10);
              }
            }
            
            // Insert record into extracted_files table
            const { error: dbError } = await supabase
              .from('extracted_files')
              .insert({
                study_id: studyId,
                original_path: fileNode.relativePath,
                storage_path: result.storagePath,
                storage_bucket: 'dose-files',
                file_type: fileType,
                file_size: fileNode.size,
                series_number: seriesNumber,
                organ_name: fileNode.organName || null,
                uploaded_by: user.id,
                uploaded_at: new Date().toISOString(),
              });

            if (dbError) {
              console.error('Database insert error:', dbError);
              failedCount++;
              failedFiles.push({ ...fileNode, error: dbError.message, errorType: 'database' });
              setProgress(prev => ({
                ...prev,
                failedFiles: prev.failedFiles + 1,
                failedFileReasons: new Map(prev.failedFileReasons).set(fileNode.relativePath, {
                  error: dbError.message,
                  errorType: 'database',
                  size: fileNode.size
                }),
              }));
            } else {
              uploadedCount++;
              newlyUploadedPaths.push(fileNode.relativePath);
              setProgress(prev => ({
                ...prev,
                uploadedFiles: prev.uploadedFiles + 1,
                newlyUploadedPaths: [...prev.newlyUploadedPaths, fileNode.relativePath],
              }));
            }
          } else {
            failedCount++;
            failedFiles.push({ ...fileNode, error: result.error, errorType: result.errorType });
            setProgress(prev => ({
              ...prev,
              failedFiles: prev.failedFiles + 1,
              failedFileReasons: new Map(prev.failedFileReasons).set(fileNode.relativePath, {
                error: result.error || 'Unknown upload error',
                errorType: result.errorType || 'unknown',
                size: fileNode.size
              }),
            }));
          }
        })
      );
    }

    // Process large files sequentially to avoid timeouts
    for (const fileNode of largeFiles) {
      // Check if we need to refresh the session (in addition to per-file refresh)
      const timeSinceRefresh = Date.now() - lastRefreshTime;
      if (timeSinceRefresh > REFRESH_INTERVAL) {
        console.log('🔐 Refreshing session during large file processing...');
        const { error: refreshError } = await supabase.auth.refreshSession();
        if (!refreshError) {
          lastRefreshTime = Date.now();
        }
      }
      
      setProgress(prev => ({
        ...prev,
        currentFile: fileNode.relativePath,
      }));

      console.log(`Uploading large file: ${fileNode.relativePath} (${(fileNode.file.size / 1024 / 1024).toFixed(2)}MB)`);

      const result = await uploadFileToStorage(
        fileNode.file,
        studyId,
        fileNode.relativePath,
        (fileProgress) => {
          setProgress(prev => {
            const newFileProgress = new Map(prev.fileProgress);
            newFileProgress.set(fileNode.relativePath, fileProgress);
            return { ...prev, fileProgress: newFileProgress };
          });
        }
      );

      // If file already exists in storage, create DB record to reconcile mismatch
      if (result.alreadyExists) {
        console.log(`📝 File exists in storage, creating DB record for: ${fileNode.name}`);
        const fileType = fileNode.fileType || detectFileType(fileNode.name, fileNode.relativePath);
        let seriesNumber: number | null = null;
        if (fileType === 'dicom_dose') {
          const match = fileNode.name.match(/\d+/);
          if (match) {
            seriesNumber = parseInt(match[0], 10);
          }
        }
        
        // Get current user
        const { data: { user: currentUser } } = await supabase.auth.getUser();
        
        // Insert record into extracted_files table
        const { error: dbError } = await supabase
          .from('extracted_files')
          .insert({
            study_id: studyId,
            original_path: fileNode.relativePath,
            storage_path: `${studyId}/${fileNode.relativePath}`,
            storage_bucket: 'dose-files',
            file_type: fileType,
            file_size: fileNode.file.size,
            series_number: seriesNumber,
            organ_name: fileNode.organName || null,
            uploaded_by: currentUser?.id,
            uploaded_at: new Date().toISOString(),
          });
          
        if (dbError) {
          console.error('Database insert error during reconciliation:', dbError);
        }
        
        setProgress(prev => ({
          ...prev,
          skippedFiles: prev.skippedFiles + 1,
        }));
        continue;
      }

      if (result.success && result.storagePath) {
        const fileType = fileNode.fileType || detectFileType(fileNode.name, fileNode.relativePath);
        
        // Extract series number from DICOM files if present in the filename
        let seriesNumber: number | null = null;
        if (fileType === 'dicom_dose') {
          const match = fileNode.name.match(/\d+/);
          if (match) {
            seriesNumber = parseInt(match[0], 10);
          }
        }
        
        const { error: dbError } = await supabase
          .from('extracted_files')
          .insert({
            study_id: studyId,
            original_path: fileNode.relativePath,
            storage_path: result.storagePath,
            storage_bucket: 'dose-files',
            file_type: fileType,
            file_size: fileNode.size,
            series_number: seriesNumber,
            organ_name: fileNode.organName || null,
            uploaded_by: user.id,
            uploaded_at: new Date().toISOString(),
          });

        if (dbError) {
          console.error('Database insert error:', dbError);
          failedCount++;
          failedFiles.push({ ...fileNode, error: dbError.message, errorType: 'database' });
          setProgress(prev => ({
            ...prev,
            failedFiles: prev.failedFiles + 1,
            failedFileReasons: new Map(prev.failedFileReasons).set(fileNode.relativePath, {
              error: dbError.message,
              errorType: 'database',
              size: fileNode.size
            }),
          }));
        } else {
          uploadedCount++;
          newlyUploadedPaths.push(fileNode.relativePath);
          console.log(`✓ Large file uploaded successfully: ${fileNode.relativePath}`);
          setProgress(prev => ({
            ...prev,
            uploadedFiles: prev.uploadedFiles + 1,
            newlyUploadedPaths: [...prev.newlyUploadedPaths, fileNode.relativePath],
          }));
        }
      } else {
        console.error(`✗ Large file upload failed: ${fileNode.relativePath}`, result.error);
        failedCount++;
        failedFiles.push({ ...fileNode, error: result.error, errorType: result.errorType });
        setProgress(prev => ({
          ...prev,
          failedFiles: prev.failedFiles + 1,
          failedFileReasons: new Map(prev.failedFileReasons).set(fileNode.relativePath, {
            error: result.error || 'Unknown upload error',
            errorType: result.errorType || 'unknown',
            size: fileNode.size
          }),
        }));
      }
    }

    setUploading(false);
    
    // Log summary
    console.log(`Upload complete: ${uploadedCount} succeeded, ${failedCount} failed, ${skippedCount} skipped`);
    if (failedFiles.length > 0) {
      console.log('Failed files:', failedFiles.map(f => `${f.relativePath} (${f.errorType}: ${f.error})`));
    }
    
    return {
      success: failedCount === 0,
      uploadedCount,
      failedCount,
      skippedCount,
      newlyUploadedPaths,
    };
  };

  const resetProgress = () => {
    setProgress({
      totalFiles: 0,
      uploadedFiles: 0,
      failedFiles: 0,
      skippedFiles: 0,
      currentFile: null,
      fileProgress: new Map(),
      newlyUploadedPaths: [],
      failedFileReasons: new Map(),
    });
  };

  const uploadCtImagesOnly = async (files: FileList, studyId: string, batchSize: number = 5) => {
    console.log('📤 Starting CT images only upload');
    
    // Process folder but ONLY include CT image files
    const allFileNodes = processFolderStructure(files, false); // Don't skip CT images
    const ctImageFiles = allFileNodes.filter(f => 
      f.fileType === 'dicom_other' || 
      f.fileType === 'dicom_ct_fusie' || 
      f.fileType === 'dicom_ct_wb'
    );
    
    if (ctImageFiles.length === 0) {
      console.log('⚠️ No CT images found in selected folder');
      return {
        success: false,
        uploadedCount: 0,
        failedCount: 0,
        skippedCount: 0,
        newlyUploadedPaths: [],
        error: 'No CT images found in selected folder'
      };
    }
    
    console.log(`Found ${ctImageFiles.length} CT image files to upload`);
    
    // Use the existing uploadFilesInBatches logic but with filtered files
    setChecking(true);
    
    // Get current user
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      throw new Error('User not authenticated');
    }
    
    // Check for existing files
    const { data: existingFiles } = await supabase
      .from('extracted_files')
      .select('original_path, file_size')
      .eq('study_id', studyId);
    
    const existingFileMap = new Map<string, number>();
    existingFiles?.forEach(f => {
      existingFileMap.set(f.original_path, f.file_size);
    });
    
    // Filter out files that already exist
    const filesToUpload = ctImageFiles.filter(f => {
      const existingSize = existingFileMap.get(f.relativePath);
      if (existingSize !== undefined && existingSize === f.size) {
        f.status = 'skipped';
        f.skipReason = 'Already uploaded';
        return false;
      }
      return true;
    });
    
    const skippedCount = ctImageFiles.length - filesToUpload.length;
    console.log(`📤 ${filesToUpload.length} new CT images to upload, ${skippedCount} already exist`);
    
    setChecking(false);
    setUploading(true);
    
    setProgress({
      totalFiles: ctImageFiles.length,
      uploadedFiles: 0,
      failedFiles: 0,
      skippedFiles: skippedCount,
      currentFile: null,
      fileProgress: new Map(),
      newlyUploadedPaths: [],
      failedFileReasons: new Map(),
    });
    
    let uploadedCount = 0;
    let failedCount = 0;
    const newlyUploadedPaths: string[] = [];
    
    // Process CT images in batches
    for (let i = 0; i < filesToUpload.length; i += batchSize) {
      const batch = filesToUpload.slice(i, i + batchSize);
      
      await Promise.all(
        batch.map(async (fileNode) => {
          setProgress(prev => ({
            ...prev,
            currentFile: fileNode.relativePath,
          }));
          
          const result = await uploadFileToStorage(
            fileNode.file,
            studyId,
            fileNode.relativePath
          );
          
          // If file already exists in storage, treat as skip instead of failure
          if (result.alreadyExists) {
            setProgress(prev => ({
              ...prev,
              skippedFiles: prev.skippedFiles + 1,
            }));
            return;
          }
          
          if (result.success && result.storagePath) {
            // Detect series number from path structure
            let seriesNumber: number | null = null;
            if (fileNode.fileType === 'dicom_ct_fusie') {
              seriesNumber = 1; // Fusie series
            } else if (fileNode.fileType === 'dicom_ct_wb') {
              seriesNumber = 2; // WB series  
            }
            
            const { error: dbError } = await supabase
              .from('extracted_files')
              .insert({
                study_id: studyId,
                original_path: fileNode.relativePath,
                storage_path: result.storagePath,
                storage_bucket: 'dose-files',
                file_type: fileNode.fileType,
                file_size: fileNode.size,
                series_number: seriesNumber,
                organ_name: null,
                uploaded_by: user.id,
                uploaded_at: new Date().toISOString(),
              });
            
            if (!dbError) {
              uploadedCount++;
              newlyUploadedPaths.push(fileNode.relativePath);
              setProgress(prev => ({
                ...prev,
                uploadedFiles: prev.uploadedFiles + 1,
                newlyUploadedPaths: [...prev.newlyUploadedPaths, fileNode.relativePath],
              }));
            } else {
              failedCount++;
              setProgress(prev => ({
                ...prev,
                failedFiles: prev.failedFiles + 1,
                failedFileReasons: new Map(prev.failedFileReasons).set(fileNode.relativePath, {
                  error: dbError.message,
                  errorType: 'database',
                  size: fileNode.size
                }),
              }));
            }
          } else {
            failedCount++;
            setProgress(prev => ({
              ...prev,
              failedFiles: prev.failedFiles + 1,
              failedFileReasons: new Map(prev.failedFileReasons).set(fileNode.relativePath, {
                error: result.error || 'Unknown upload error',
                errorType: result.errorType || 'unknown',
                size: fileNode.size
              }),
            }));
          }
        })
      );
    }
    
    setUploading(false);
    console.log(`CT images upload complete: ${uploadedCount} succeeded, ${failedCount} failed, ${skippedCount} skipped`);
    
    return {
      success: failedCount === 0,
      uploadedCount,
      failedCount,
      skippedCount,
      newlyUploadedPaths,
    };
  };

  /**
   * Filter files to only include essential files for the application
   * Essential files: CT_Beelden, DoseDistribution, TotalSegmentator/segmentations
   */
  const filterEssentialFiles = (files: FileNode[]): FileNode[] => {
    // Filter by essential folder paths instead of file types
    const essentialFiles = files.filter(file => {
      const pathLower = file.relativePath.toLowerCase();
      
      // Include files from these essential folders:
      // 1. TotalSegmentator/segmentations (organ segmentations only)
      // 2. CT_beelden or CT folders (CT images)
      // 3. DoseDistribution (dose data)
      return pathLower.includes('totalsegmentator/segmentations/') ||
             pathLower.includes('ct_beelden') ||
             pathLower.includes('ct beelden') ||
             pathLower.includes('dosedistribution');
    });
    
    console.log(`[filterEssentialFiles] Filtered ${files.length} files to ${essentialFiles.length} essential files by folder path`);
    return essentialFiles;
  };

  /**
   * Re-upload files for an existing study based on the original upload mode
   * This respects the initial file selection (essential, all, or ct-only)
   */
  const reuploadFilesForStudy = async (
    files: FileList,
    studyId: string,
    uploadMode: string | null
  ): Promise<{
    success: boolean;
    uploadedCount: number;
    skippedCount: number;
    failedCount: number;
    error?: string;
  }> => {
    try {
      console.log(`🔄 Starting re-upload for study ${studyId} in ${uploadMode || 'essential'} mode`);
      
      // Process folder structure
      const allFileNodes = processFolderStructure(files, false);
      
      // Filter files based on saved upload mode
      let filesToUpload = allFileNodes;
      const effectiveMode = uploadMode || 'essential'; // Default to essential for old studies
      
      if (effectiveMode === 'essential') {
        filesToUpload = filterEssentialFiles(allFileNodes);
        console.log(`📋 Filtered to ${filesToUpload.length} essential files (from ${allFileNodes.length} total)`);
      } else if (effectiveMode === 'ct-only') {
        filesToUpload = allFileNodes.filter(f => 
          f.fileType === 'dicom_ct_fusie' || f.fileType === 'dicom_ct_wb'
        );
        console.log(`📋 Filtered to ${filesToUpload.length} CT files (from ${allFileNodes.length} total)`);
      } else {
        console.log(`📋 Using all ${allFileNodes.length} files`);
      }
      
      // Upload the filtered files
      const result = await uploadFilesInBatches(filesToUpload, studyId);
      
      return result;
    } catch (error: any) {
      console.error('Re-upload error:', error);
      return {
        success: false,
        uploadedCount: 0,
        skippedCount: 0,
        failedCount: 0,
        error: error.message || 'Re-upload failed',
      };
    }
  };

  return {
    uploading,
    checking,
    progress,
    processFolderStructure,
    uploadFilesInBatches,
    uploadCtImagesOnly,
    resetProgress,
    validateFolderStructure,
    filterEssentialFiles,
    reuploadFilesForStudy,
  };
};
