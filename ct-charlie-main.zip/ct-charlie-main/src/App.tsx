import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { lazy, Suspense, useEffect } from "react";
import Index from "./pages/Index";
import Auth from "./pages/Auth";
import Dashboard from "./pages/Dashboard";
import NotFound from "./pages/NotFound";
import ProtectedRoute from "./components/ProtectedRoute";

function lazyRetry<T extends React.ComponentType<any>>(
  factory: () => Promise<{ default: T }>,
  retries = 3
) {
  return lazy(() =>
    factory().catch((err) => {
      if (retries > 0) {
        return new Promise<{ default: T }>((resolve, reject) =>
          setTimeout(() => {
            factory().then(resolve).catch(reject);
          }, 1000 * (4 - retries))
        ).catch(() => lazyRetryInner(factory, retries - 1));
      }
      console.error("Failed to load module after retries:", err);
      // Force reload to get fresh chunks
      window.location.reload();
      return factory();
    })
  );
}

function lazyRetryInner<T extends React.ComponentType<any>>(
  factory: () => Promise<{ default: T }>,
  retries: number
): Promise<{ default: T }> {
  return factory().catch((err) => {
    if (retries > 0) {
      return new Promise<{ default: T }>((resolve, reject) =>
        setTimeout(() => {
          factory().then(resolve).catch(reject);
        }, 1000 * (4 - retries))
      ).catch(() => lazyRetryInner(factory, retries - 1));
    }
    console.error("Failed to load module after retries:", err);
    window.location.reload();
    return factory();
  });
}

const Studies = lazyRetry(() => import("./pages/Studies"));
const StudyDetail = lazyRetry(() => import("./pages/StudyDetail"));
const Upload = lazyRetry(() => import("./pages/Upload"));
const MasterData = lazyRetry(() => import("./pages/MasterData"));
const AdvancedVisualization = lazyRetry(() => import("./pages/AdvancedVisualization"));
const AdminPanel = lazyRetry(() => import("./pages/AdminPanel"));
const AuditLog = lazyRetry(() => import("./pages/AuditLog"));
const Cohorts = lazyRetry(() => import("./pages/Cohorts"));
const CohortAnalysis = lazyRetry(() => import("./pages/CohortAnalysis"));
const PatientDetail = lazyRetry(() => import("./pages/PatientDetail"));

const queryClient = new QueryClient();

const App = () => {
  useEffect(() => {
    const handleRejection = (event: PromiseRejectionEvent) => {
      console.error("Unhandled rejection:", event.reason);
      event.preventDefault();
    };
    window.addEventListener("unhandledrejection", handleRejection);
    return () => window.removeEventListener("unhandledrejection", handleRejection);
  }, []);

  return (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/auth" element={<Auth />} />
          <Route path="/dashboard" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
          <Route path="/studies" element={<ProtectedRoute><Suspense fallback={<div>Loading...</div>}><Studies /></Suspense></ProtectedRoute>} />
          <Route path="/upload" element={<ProtectedRoute><Suspense fallback={<div>Loading...</div>}><Upload /></Suspense></ProtectedRoute>} />
          <Route path="/master-data" element={<ProtectedRoute><Suspense fallback={<div>Loading...</div>}><MasterData /></Suspense></ProtectedRoute>} />
          <Route path="/study/:id" element={<ProtectedRoute><Suspense fallback={<div>Loading...</div>}><StudyDetail /></Suspense></ProtectedRoute>} />
          <Route path="/visualization/:studyId" element={<ProtectedRoute><Suspense fallback={<div>Loading...</div>}><AdvancedVisualization /></Suspense></ProtectedRoute>} />
          <Route path="/admin" element={<ProtectedRoute><Suspense fallback={<div>Loading...</div>}><AdminPanel /></Suspense></ProtectedRoute>} />
          <Route path="/audit" element={<ProtectedRoute><Suspense fallback={<div>Loading...</div>}><AuditLog /></Suspense></ProtectedRoute>} />
          <Route path="/cohorts" element={<ProtectedRoute><Suspense fallback={<div>Loading...</div>}><Cohorts /></Suspense></ProtectedRoute>} />
          <Route path="/cohorts/:id/analysis" element={<ProtectedRoute><Suspense fallback={<div>Loading...</div>}><CohortAnalysis /></Suspense></ProtectedRoute>} />
          <Route path="/patient/:patientId" element={<ProtectedRoute><Suspense fallback={<div>Loading...</div>}><PatientDetail /></Suspense></ProtectedRoute>} />
          {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
  );
};

export default App;
