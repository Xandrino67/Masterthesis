import { useState, useMemo } from "react";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { AlertCircle, Atom, Calculator, Info, BookOpen, ChevronDown, ChevronUp } from "lucide-react";
import {
  getTracersForModality,
  RADIOTRACERS,
  AGE_GROUPS,
  calculateNuclearMedicineDoses,
  type RadioTracer,
  type NuclearMedicineOrganDose,
  type AgeGroup,
} from "@/services/nuclearMedicineDoseCoefficients";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";

interface NuclearMedicineInputProps {
  modality: "PET" | "SPECT";
  onCalculateAndCreate: (results: {
    tracer: RadioTracer;
    activityMBq: number;
    ageGroup: AgeGroup;
    organDoses: NuclearMedicineOrganDose[];
    effectiveDose_mSv: number;
  }) => void;
  disabled?: boolean;
  isCreating?: boolean;
}

export function NuclearMedicineInput({ modality, onCalculateAndCreate, disabled, isCreating }: NuclearMedicineInputProps) {
  const tracers = useMemo(() => getTracersForModality(modality), [modality]);
  const [selectedTracerId, setSelectedTracerId] = useState<string>(tracers[0]?.id || "");
  const [ageGroup, setAgeGroup] = useState<AgeGroup>("Adult");
  const [activityMBq, setActivityMBq] = useState<string>("");
  const [results, setResults] = useState<{
    organDoses: NuclearMedicineOrganDose[];
    effectiveDose_mSv: number;
  } | null>(null);
  const [showCoefficients, setShowCoefficients] = useState(false);

  const selectedTracer = RADIOTRACERS.find((t) => t.id === selectedTracerId);

  const handleTracerChange = (id: string) => {
    setSelectedTracerId(id);
    setResults(null);
    const tracer = RADIOTRACERS.find((t) => t.id === id);
    if (tracer) {
      setActivityMBq(tracer.defaultActivityMBq.toString());
    }
  };

  const handleCalculateAndCreate = () => {
    if (!selectedTracer || !activityMBq) return;
    const activity = parseFloat(activityMBq);
    if (isNaN(activity) || activity <= 0) return;

    const res = calculateNuclearMedicineDoses(selectedTracer, activity, ageGroup);
    setResults(res);
    onCalculateAndCreate({
      tracer: selectedTracer,
      activityMBq: activity,
      ageGroup,
      ...res,
    });
  };

  /** Format scientific notation for display */
  const formatCoeff = (v: number): string => {
    if (v >= 1) return v.toFixed(2);
    const exp = Math.floor(Math.log10(Math.abs(v)));
    const mantissa = v / Math.pow(10, exp);
    return `${mantissa.toFixed(1)}E${exp >= 0 ? "+" : ""}${exp}`;
  };

  return (
    <Card className="p-6">
      <div className="flex items-center gap-2 mb-4">
        <Atom className="h-5 w-5 text-primary" />
        <h2 className="text-lg font-semibold">Nuclear Medicine Dose Estimation</h2>
      </div>

      <div className="mb-4 p-3 bg-amber-500/10 border border-amber-500/20 rounded-lg">
        <div className="flex items-start gap-2 text-amber-700 dark:text-amber-400">
          <AlertCircle className="h-4 w-4 mt-0.5 flex-shrink-0" />
          <div className="text-sm">
            <p className="font-medium">No file upload required for {modality}</p>
            <p className="text-xs mt-1">
              Organ doses are estimated using ICRP Publication 128 age-dependent conversion coefficients based on administered activity and radiotracer selection.
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
        <div className="space-y-2">
          <Label>Radiotracer *</Label>
          <Select value={selectedTracerId} onValueChange={handleTracerChange}>
            <SelectTrigger>
              <SelectValue placeholder="Select tracer" />
            </SelectTrigger>
            <SelectContent>
              {tracers.map((t) => (
                <SelectItem key={t.id} value={t.id}>
                  {t.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label>Patient Age Group *</Label>
          <Select value={ageGroup} onValueChange={(v) => { setAgeGroup(v as AgeGroup); setResults(null); }}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {AGE_GROUPS.map((ag) => (
                <SelectItem key={ag} value={ag}>
                  {ag}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label>Administered Activity (MBq) *</Label>
          <Input
            type="number"
            min="0"
            step="any"
            placeholder={selectedTracer ? `e.g. ${selectedTracer.defaultActivityMBq}` : "Enter activity"}
            value={activityMBq}
            onChange={(e) => {
              setActivityMBq(e.target.value);
              setResults(null);
            }}
          />
        </div>
      </div>

      {selectedTracer && (
        <div className="mb-4 p-3 bg-muted/50 rounded-lg space-y-1">
          <div className="flex items-center gap-2 flex-wrap">
            <Badge variant="outline">{selectedTracer.radionuclide}</Badge>
            <Badge variant="outline">T½ = {selectedTracer.halfLife}</Badge>
            <Badge variant="outline">{selectedTracer.icrpTable}</Badge>
            {selectedTracer.isTherapeutic && (
              <Badge variant="destructive">Therapeutic</Badge>
            )}
          </div>
          <p className="text-xs text-muted-foreground mt-1">
            Source: {selectedTracer.source}
          </p>
        </div>
      )}

      {/* Expandable ICRP coefficient reference table */}
      {selectedTracer && (
        <Collapsible open={showCoefficients} onOpenChange={setShowCoefficients} className="mb-6">
          <CollapsibleTrigger asChild>
            <Button variant="ghost" size="sm" className="w-full justify-between text-muted-foreground hover:text-foreground">
              <span className="flex items-center gap-2">
                <BookOpen className="h-4 w-4" />
                View ICRP 128 Coefficient Table ({selectedTracer.icrpTable})
              </span>
              {showCoefficients ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
            </Button>
          </CollapsibleTrigger>
          <CollapsibleContent>
            <div className="mt-2 border rounded-lg overflow-hidden">
              <div className="p-3 bg-muted/30 border-b">
                <p className="text-xs text-muted-foreground">
                  <strong>{selectedTracer.name}</strong> — Absorbed dose per unit activity administered (mGy MBq⁻¹).
                  Source: {selectedTracer.source}. Selected age group highlighted.
                </p>
              </div>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="sticky left-0 bg-background z-10">Organ</TableHead>
                      {AGE_GROUPS.map((ag) => (
                        <TableHead
                          key={ag}
                          className={`text-right text-xs whitespace-nowrap ${ag === ageGroup ? "bg-primary/10 font-bold" : ""}`}
                        >
                          {ag}
                        </TableHead>
                      ))}
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {Object.entries(selectedTracer.organCoefficients).map(([organ, coeffs]) => (
                      <TableRow key={organ}>
                        <TableCell className="sticky left-0 bg-background z-10 font-medium text-xs whitespace-nowrap">
                          {organ}
                        </TableCell>
                        {AGE_GROUPS.map((ag) => (
                          <TableCell
                            key={ag}
                            className={`text-right font-mono text-xs ${ag === ageGroup ? "bg-primary/10 font-bold" : "text-muted-foreground"}`}
                          >
                            {formatCoeff(coeffs[ag])}
                          </TableCell>
                        ))}
                      </TableRow>
                    ))}
                    {/* Effective dose row */}
                    <TableRow className="border-t-2">
                      <TableCell className="sticky left-0 bg-background z-10 font-bold text-xs">
                        Effective dose (mSv MBq⁻¹)
                      </TableCell>
                      {AGE_GROUPS.map((ag) => (
                        <TableCell
                          key={ag}
                          className={`text-right font-mono text-xs font-bold ${ag === ageGroup ? "bg-primary/10" : "text-muted-foreground"}`}
                        >
                          {formatCoeff(selectedTracer.effectiveDoseCoefficient[ag])}
                        </TableCell>
                      ))}
                    </TableRow>
                  </TableBody>
                </Table>
              </div>
            </div>
          </CollapsibleContent>
        </Collapsible>
      )}

      <Button
        onClick={handleCalculateAndCreate}
        disabled={disabled || isCreating || !selectedTracer || !activityMBq || parseFloat(activityMBq) <= 0}
        className="w-full mb-6"
        size="lg"
      >
        <Calculator className="h-5 w-5 mr-2" />
        {isCreating ? "Creating Study..." : "Calculate & Create Study"}
      </Button>

      {results && selectedTracer && (
        <div className="space-y-4">
          {/* Effective dose summary */}
          <div className="p-4 bg-primary/10 border border-primary/20 rounded-lg">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium">Effective Dose ({ageGroup})</p>
                <p className="text-2xl font-bold text-primary">
                  {results.effectiveDose_mSv.toFixed(2)} mSv
                </p>
              </div>
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger>
                    <Info className="h-4 w-4 text-muted-foreground" />
                  </TooltipTrigger>
                  <TooltipContent className="max-w-xs">
                    <p className="text-xs">
                      Effective dose = {formatCoeff(selectedTracer.effectiveDoseCoefficient[ageGroup])} mSv/MBq × {parseFloat(activityMBq)} MBq
                    </p>
                    <p className="text-xs mt-1">
                      Source: {selectedTracer.source}
                    </p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            </div>
          </div>

          {/* Organ dose table */}
          <div className="border rounded-lg overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Organ</TableHead>
                  <TableHead className="text-right">Coefficient (mGy/MBq)</TableHead>
                  <TableHead className="text-right">Absorbed Dose (mGy)</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {results.organDoses.map((od) => (
                  <TableRow key={od.organ_name}>
                    <TableCell className="font-medium">{od.organ_name}</TableCell>
                    <TableCell className="text-right text-muted-foreground font-mono text-xs">
                      {formatCoeff(od.coefficient_mGy_per_MBq)}
                    </TableCell>
                    <TableCell className="text-right font-mono">
                      {od.dose_mGy.toFixed(2)}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </div>
      )}
    </Card>
  );
}
