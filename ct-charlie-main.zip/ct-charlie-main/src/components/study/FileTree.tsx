import { useState, useEffect } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { ChevronRight, ChevronDown, Folder, File, FileText, Search, X } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

interface FileTreeNode {
  name: string;
  path: string;
  type: 'file' | 'folder';
  size?: number;
  fileType?: string;
  children?: FileTreeNode[];
  uploaded_at?: string;
  uploaded_by?: string;
  created_at?: string;
  parent_path?: string;
}

interface FileTreeProps {
  studyId: string;
  initialFilter?: {
    uploadedPaths?: string[];
  };
}

const FileTree = ({ studyId, initialFilter }: FileTreeProps) => {
  const queryClient = useQueryClient();
  const [searchQuery, setSearchQuery] = useState("");
  const [fileTypeFilter, setFileTypeFilter] = useState<string>("all");
  const [minSize, setMinSize] = useState<string>("");
  const [maxSize, setMaxSize] = useState<string>("");
  const [uploadedByFilter, setUploadedByFilter] = useState<string>("all");
  const [dateFrom, setDateFrom] = useState<string>("");
  const [dateTo, setDateTo] = useState<string>("");
  const [showOnlyNew, setShowOnlyNew] = useState(!!initialFilter?.uploadedPaths);

  const { data: files, isLoading } = useQuery({
    queryKey: ["extracted-files-all", studyId],
    queryFn: async () => {
      console.log('🔄 Fetching ALL files with pagination...');
      
      let allFiles: any[] = [];
      let start = 0;
      const pageSize = 1000;
      let hasMore = true;

      while (hasMore) {
        const { data, error, count } = await supabase
          .from("extracted_files")
          .select("*", { count: 'exact' })
          .eq("study_id", studyId)
          .order("original_path")
          .range(start, start + pageSize - 1);
        
        if (error) {
          console.error('Query error:', error);
          throw error;
        }

        if (data && data.length > 0) {
          allFiles = [...allFiles, ...data];
          console.log(`📦 Fetched chunk: ${data.length} files (total so far: ${allFiles.length}/${count || '?'})`);
          
          // Check if we have more data to fetch
          hasMore = data.length === pageSize;
          start += pageSize;
        } else {
          hasMore = false;
        }
      }
      
      console.log(`✅ Successfully fetched ALL ${allFiles.length} files for study ${studyId}`);
      return allFiles;
    },
    staleTime: 0,
  });

  const { data: users } = useQuery({
    queryKey: ["users-who-uploaded", studyId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("extracted_files")
        .select("uploaded_by")
        .eq("study_id", studyId)
        .not("uploaded_by", "is", null);
      
      if (error) throw error;
      
      const uniqueUserIds = [...new Set(data.map(f => f.uploaded_by))];
      
      const { data: profiles } = await supabase
        .from("profiles")
        .select("id, email, display_name")
        .in("id", uniqueUserIds);
      
      return profiles || [];
    },
  });

  // Subscribe to real-time updates for new files
  useEffect(() => {
    const channel = supabase
      .channel(`extracted-files-${studyId}`)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'extracted_files',
          filter: `study_id=eq.${studyId}`
        },
        (payload) => {
          console.log('New file detected:', payload.new);
          queryClient.invalidateQueries({ queryKey: ["extracted-files-all", studyId] });
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [studyId, queryClient]);

  const getFileTypes = (files: any[] | undefined): string[] => {
    if (!files) return [];
    const types = new Set(files.map(f => f.file_type));
    return Array.from(types).sort();
  };

  const filterFiles = (files: any[] | undefined): any[] => {
    if (!files) return [];

    return files.filter(file => {
      // Show only newly uploaded files filter
      if (showOnlyNew && initialFilter?.uploadedPaths) {
        if (!initialFilter.uploadedPaths.includes(file.original_path)) {
          return false;
        }
      }

      // Search filter
      if (searchQuery && !file.original_path.toLowerCase().includes(searchQuery.toLowerCase())) {
        return false;
      }

      // File type filter
      if (fileTypeFilter !== "all" && file.file_type !== fileTypeFilter) {
        return false;
      }

      // User filter
      if (uploadedByFilter !== "all" && file.uploaded_by !== uploadedByFilter) {
        return false;
      }

      // Date range filter
      if (dateFrom && file.uploaded_at) {
        const uploadDate = new Date(file.uploaded_at);
        const fromDate = new Date(dateFrom);
        if (uploadDate < fromDate) {
          return false;
        }
      }
      if (dateTo && file.uploaded_at) {
        const uploadDate = new Date(file.uploaded_at);
        const toDate = new Date(dateTo);
        toDate.setHours(23, 59, 59, 999); // End of day
        if (uploadDate > toDate) {
          return false;
        }
      }

      // File size filter
      const fileSizeMB = file.file_size / (1024 * 1024);
      if (minSize && fileSizeMB < parseFloat(minSize)) {
        return false;
      }
      if (maxSize && fileSizeMB > parseFloat(maxSize)) {
        return false;
      }

      return true;
    });
  };

  const filteredFiles = filterFiles(files);
  const fileTypes = getFileTypes(files);
  const hasActiveFilters = searchQuery || fileTypeFilter !== "all" || minSize || maxSize || uploadedByFilter !== "all" || dateFrom || dateTo || showOnlyNew;

  const clearFilters = () => {
    setSearchQuery("");
    setFileTypeFilter("all");
    setMinSize("");
    setMaxSize("");
    setUploadedByFilter("all");
    setDateFrom("");
    setDateTo("");
    setShowOnlyNew(false);
  };

  const buildTree = (files: any[]): FileTreeNode[] => {
    const tree: FileTreeNode[] = [];
    const folderMap = new Map<string, FileTreeNode>();

    files.forEach((file) => {
      const parts = file.original_path.split('/');
      let currentPath = '';
      
      parts.forEach((part, index) => {
        const isLastPart = index === parts.length - 1;
        currentPath = currentPath ? `${currentPath}/${part}` : part;

        // Create node if it doesn't exist
        if (!folderMap.has(currentPath)) {
          const node: FileTreeNode = {
            name: part,
            path: currentPath,
            type: isLastPart ? 'file' : 'folder',
            size: isLastPart ? file.file_size : undefined,
            fileType: isLastPart ? file.file_type : undefined,
            uploaded_at: isLastPart ? file.uploaded_at : undefined,
            uploaded_by: isLastPart ? file.uploaded_by : undefined,
            created_at: isLastPart ? file.created_at : undefined,
            parent_path: isLastPart ? file.parent_path : undefined,
            children: isLastPart ? undefined : [],
          };

          // Add to tree root or to parent's children
          if (index === 0) {
            tree.push(node);
          } else {
            const parentPath = parts.slice(0, index).join('/');
            const parent = folderMap.get(parentPath);
            if (parent && parent.children) {
              parent.children.push(node);
            }
          }

          folderMap.set(currentPath, node);
        }
      });
    });

    return tree;
  };

  // Recursively count all files (not folders) in a node's descendants
  const countDescendantFiles = (node: FileTreeNode): number => {
    if (node.type === 'file') return 1;
    if (!node.children || node.children.length === 0) return 0;
    return node.children.reduce((sum, child) => sum + countDescendantFiles(child), 0);
  };

  const formatFileSize = (bytes: number): string => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  const getFileTypeColor = (fileType: string): string => {
    if (fileType.includes('dicom')) return 'bg-blue-500/10 text-blue-500';
    if (fileType.includes('nifti')) return 'bg-green-500/10 text-green-500';
    return 'bg-muted text-muted-foreground';
  };

  if (isLoading) {
    return (
      <Card className="p-6">
        <div className="text-sm text-muted-foreground">Loading file structure...</div>
      </Card>
    );
  }

  if (!files || files.length === 0) {
    return (
      <Card className="p-12 text-center">
        <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
        <p className="text-muted-foreground">No files extracted yet</p>
      </Card>
    );
  }

  const tree = buildTree(filteredFiles);

  return (
    <Card className="p-6">
      <div className="mb-4 flex items-center justify-between">
        <h3 className="font-semibold">Extracted Files</h3>
        <div className="flex items-center gap-2">
          <Badge variant="outline">{filteredFiles.length} of {files.length} files</Badge>
          {hasActiveFilters && (
            <Button variant="ghost" size="sm" onClick={clearFilters}>
              <X className="h-4 w-4 mr-1" />
              Clear
            </Button>
          )}
        </div>
      </div>

      {/* Filters */}
      <div className="mb-6 space-y-4 p-4 border rounded-lg bg-muted/20">
        {initialFilter?.uploadedPaths && initialFilter.uploadedPaths.length > 0 && (
          <div className="flex items-center gap-2 pb-2 border-b">
            <Badge variant="default" className="text-xs">
              {initialFilter.uploadedPaths.length} newly uploaded files
            </Badge>
            <label className="flex items-center gap-2 text-sm">
              <input
                type="checkbox"
                checked={showOnlyNew}
                onChange={(e) => setShowOnlyNew(e.target.checked)}
                className="rounded"
              />
              Show only new files
            </label>
          </div>
        )}
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {/* Search */}
          <div className="space-y-2">
            <Label>Search</Label>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search filename..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
              />
            </div>
          </div>

          {/* File Type */}
          <div className="space-y-2">
            <Label>File Type</Label>
            <Select value={fileTypeFilter} onValueChange={setFileTypeFilter}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                {fileTypes.map(type => (
                  <SelectItem key={type} value={type}>{type}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Uploaded By */}
          <div className="space-y-2">
            <Label>Uploaded By</Label>
            <Select value={uploadedByFilter} onValueChange={setUploadedByFilter}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Users</SelectItem>
                {users?.map(user => (
                  <SelectItem key={user.id} value={user.id}>
                    {user.display_name || user.email}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Upload Date From */}
          <div className="space-y-2">
            <Label>Uploaded From</Label>
            <Input
              type="date"
              value={dateFrom}
              onChange={(e) => setDateFrom(e.target.value)}
            />
          </div>

          {/* Upload Date To */}
          <div className="space-y-2">
            <Label>Uploaded To</Label>
            <Input
              type="date"
              value={dateTo}
              onChange={(e) => setDateTo(e.target.value)}
            />
          </div>

          {/* Min Size */}
          <div className="space-y-2">
            <Label>Min Size (MB)</Label>
            <Input
              type="number"
              placeholder="0"
              value={minSize}
              onChange={(e) => setMinSize(e.target.value)}
              min="0"
              step="0.1"
            />
          </div>

          {/* Max Size */}
          <div className="space-y-2">
            <Label>Max Size (MB)</Label>
            <Input
              type="number"
              placeholder="Any"
              value={maxSize}
              onChange={(e) => setMaxSize(e.target.value)}
              min="0"
              step="0.1"
            />
          </div>
        </div>
      </div>

      {/* File Tree */}
      {filteredFiles.length > 0 ? (
        <div className="space-y-1">
          <FileTreeItems 
            nodes={tree} 
            formatFileSize={formatFileSize} 
            getFileTypeColor={getFileTypeColor}
            countDescendantFiles={countDescendantFiles}
          />
        </div>
      ) : (
        <div className="text-center py-8 text-muted-foreground">
          No files match your filters
        </div>
      )}
    </Card>
  );
};

interface FileTreeItemsProps {
  nodes: FileTreeNode[];
  level?: number;
  formatFileSize: (bytes: number) => string;
  getFileTypeColor: (fileType: string) => string;
  countDescendantFiles: (node: FileTreeNode) => number;
}

const FileTreeItems = ({ nodes, level = 0, formatFileSize, getFileTypeColor, countDescendantFiles }: FileTreeItemsProps) => {
  return (
    <>
      {nodes.map((node) => (
        <FileTreeItem 
          key={node.path} 
          node={node} 
          level={level} 
          formatFileSize={formatFileSize}
          getFileTypeColor={getFileTypeColor}
          countDescendantFiles={countDescendantFiles}
        />
      ))}
    </>
  );
};

interface FileTreeItemProps {
  node: FileTreeNode;
  level: number;
  formatFileSize: (bytes: number) => string;
  getFileTypeColor: (fileType: string) => string;
  countDescendantFiles: (node: FileTreeNode) => number;
}

const FileTreeItem = ({ node, level, formatFileSize, getFileTypeColor, countDescendantFiles }: FileTreeItemProps) => {
  const [isOpen, setIsOpen] = useState(false);

  if (node.type === 'folder') {
    const fileCount = countDescendantFiles(node);
    
    return (
      <Collapsible open={isOpen} onOpenChange={setIsOpen}>
        <CollapsibleTrigger className="w-full">
          <div 
            className="flex items-center gap-2 py-1 px-2 hover:bg-accent rounded-sm text-sm"
            style={{ paddingLeft: `${level * 1.5 + 0.5}rem` }}
          >
            {isOpen ? (
              <ChevronDown className="h-4 w-4 text-muted-foreground" />
            ) : (
              <ChevronRight className="h-4 w-4 text-muted-foreground" />
            )}
            <Folder className="h-4 w-4 text-primary" />
            <span className="font-medium">{node.name}</span>
            <Badge variant="secondary" className="ml-auto text-xs">
              {fileCount}
            </Badge>
          </div>
        </CollapsibleTrigger>
        <CollapsibleContent>
          {node.children && (
            <FileTreeItems 
              nodes={node.children} 
              level={level + 1} 
              formatFileSize={formatFileSize}
              getFileTypeColor={getFileTypeColor}
              countDescendantFiles={countDescendantFiles}
            />
          )}
        </CollapsibleContent>
      </Collapsible>
    );
  }

  return (
    <div 
      className="flex items-center gap-2 py-1 px-2 hover:bg-accent rounded-sm text-sm group"
      style={{ paddingLeft: `${level * 1.5 + 0.5}rem` }}
    >
      <File className="h-4 w-4 text-muted-foreground flex-shrink-0" />
      <span className="flex-1 min-w-0 truncate">{node.name}</span>
      <div className="flex items-center gap-2 ml-auto">
        {node.fileType && (
          <Badge className={`text-xs ${getFileTypeColor(node.fileType)}`}>
            {node.fileType}
          </Badge>
        )}
        {node.size !== undefined && (
          <span className="text-xs text-muted-foreground whitespace-nowrap">
            {formatFileSize(node.size)}
          </span>
        )}
        {node.uploaded_at && (
          <span 
            className="text-xs text-muted-foreground whitespace-nowrap" 
            title={`Uploaded: ${new Date(node.uploaded_at).toLocaleString()}`}
          >
            {new Date(node.uploaded_at).toLocaleDateString()}
          </span>
        )}
      </div>
    </div>
  );
};

export default FileTree;
