import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Progress } from "@/components/ui/progress";
import { CheckCircle2, XCircle, SkipForward, Loader2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Button } from "@/components/ui/button";

interface UploadProgressDialogProps {
  open: boolean;
  checking: boolean;
  uploading: boolean;
  progress: {
    totalFiles: number;
    uploadedFiles: number;
    failedFiles: number;
    skippedFiles: number;
    currentFile: string | null;
  };
  uploadMode?: 'essential' | 'all' | 'ct-only';
  onClose?: () => void;
}

export function UploadProgressDialog({ 
  open, 
  checking, 
  uploading, 
  progress,
  uploadMode = 'all',
  onClose
}: UploadProgressDialogProps) {
  const completedFiles = progress.uploadedFiles + progress.failedFiles + progress.skippedFiles;
  const percentComplete = progress.totalFiles > 0 
    ? Math.round((completedFiles / progress.totalFiles) * 100) 
    : 0;
  
  const isComplete = !checking && !uploading && completedFiles === progress.totalFiles && progress.totalFiles > 0;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>
            {checking ? "Checking Files" : "Uploading Files"}
          </DialogTitle>
          <DialogDescription>
            {checking 
              ? "Verifying which files need to be uploaded..."
              : uploadMode === 'essential'
              ? `Uploading essential files only (${progress.totalFiles} files)...`
              : uploadMode === 'ct-only'
              ? `Uploading CT images only (${progress.totalFiles} files)...`
              : `Uploading all files (${progress.totalFiles} files)...`
            }
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {/* Progress Bar */}
          <div className="space-y-3">
            <div className="flex justify-between items-center text-sm">
              <span className="text-muted-foreground">Overall Progress</span>
              <span className="font-semibold text-lg">{percentComplete}%</span>
            </div>
            <Progress value={percentComplete} className="h-3" />
          </div>

          {/* Status Counters */}
          <div className="grid grid-cols-3 gap-3">
            <div className="flex flex-col items-center gap-2 p-3 rounded-lg bg-muted/50 border border-border/50">
              <CheckCircle2 className="h-5 w-5 text-green-500" />
              <div className="text-center">
                <div className="text-lg font-bold">{progress.uploadedFiles}</div>
                <div className="text-xs text-muted-foreground">Uploaded</div>
              </div>
            </div>
            <div className="flex flex-col items-center gap-2 p-3 rounded-lg bg-muted/50 border border-border/50">
              <SkipForward className="h-5 w-5 text-blue-500" />
              <div className="text-center">
                <div className="text-lg font-bold">{progress.skippedFiles}</div>
                <div className="text-xs text-muted-foreground">Skipped</div>
              </div>
            </div>
            <div className="flex flex-col items-center gap-2 p-3 rounded-lg bg-muted/50 border border-border/50">
              <XCircle className="h-5 w-5 text-red-500" />
              <div className="text-center">
                <div className="text-lg font-bold">{progress.failedFiles}</div>
                <div className="text-xs text-muted-foreground">Failed</div>
              </div>
            </div>
          </div>

          {/* Current File */}
          {progress.currentFile && (
            <div className="space-y-2">
              <div className="text-sm font-medium text-muted-foreground">Current file:</div>
              <div className="flex items-start gap-3 p-3 rounded-lg bg-muted/50 border border-border/50">
                <Loader2 className="h-5 w-5 mt-0.5 animate-spin text-primary shrink-0" />
                <div className="flex-1 min-w-0 space-y-2">
                  <div className="text-xs font-mono break-all" title={progress.currentFile}>
                    {progress.currentFile}
                  </div>
                  <Badge variant="secondary" className="text-xs">
                    {checking ? "Checking..." : "Uploading..."}
                  </Badge>
                </div>
              </div>
            </div>
          )}

          {/* Summary */}
          <div className="text-sm text-muted-foreground text-center pt-3 border-t">
            Processing <span className="font-semibold">{completedFiles}</span> of <span className="font-semibold">{progress.totalFiles}</span> files
          </div>

          {/* Close button when complete */}
          {isComplete && onClose && (
            <div className="flex justify-end pt-4 border-t">
              <Button onClick={onClose} variant="default">
                Close
              </Button>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
