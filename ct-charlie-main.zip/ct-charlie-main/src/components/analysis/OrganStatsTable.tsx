import { Card } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";

interface OrganStat {
  organ_id: string;
  label: string;
  volume_ml: number;
  d_mean: number;
  d_min: number;
  d_max: number;
  d_median: number;
  d_p5: number;
  d_p95: number;
}

interface OrganStatsTableProps {
  stats: OrganStat[];
  title?: string;
}

const OrganStatsTable = ({ stats, title = "Organ Dose Statistics" }: OrganStatsTableProps) => {
  if (!stats || stats.length === 0) {
    return (
      <Card className="p-6">
        <p className="text-center text-muted-foreground">No organ statistics available</p>
      </Card>
    );
  }

  return (
    <Card className="p-6">
      <h3 className="text-lg font-semibold mb-4">{title}</h3>
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Organ</TableHead>
              <TableHead className="text-right">Volume (ml)</TableHead>
              <TableHead className="text-right">D<sub>mean</sub> (mGy)</TableHead>
              <TableHead className="text-right">D<sub>min</sub> (mGy)</TableHead>
              <TableHead className="text-right">D<sub>max</sub> (mGy)</TableHead>
              <TableHead className="text-right">D<sub>median</sub> (mGy)</TableHead>
              <TableHead className="text-right">D<sub>5%</sub> (mGy)</TableHead>
              <TableHead className="text-right">D<sub>95%</sub> (mGy)</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {stats.map((stat) => (
              <TableRow key={stat.organ_id}>
                <TableCell className="font-medium">{stat.label}</TableCell>
                <TableCell className="text-right">{stat.volume_ml.toFixed(1)}</TableCell>
                <TableCell className="text-right">
                  <Badge variant="secondary">{stat.d_mean.toFixed(3)}</Badge>
                </TableCell>
                <TableCell className="text-right">{stat.d_min.toFixed(3)}</TableCell>
                <TableCell className="text-right">{stat.d_max.toFixed(3)}</TableCell>
                <TableCell className="text-right">{stat.d_median.toFixed(3)}</TableCell>
                <TableCell className="text-right">{stat.d_p5.toFixed(3)}</TableCell>
                <TableCell className="text-right">{stat.d_p95.toFixed(3)}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </Card>
  );
};

export default OrganStatsTable;
