import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Activity, AlertCircle } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";

interface EffectiveDoseCardProps {
  effectiveDose: number;
  method: string;
  organCount: number;
}

const EffectiveDoseCard = ({ effectiveDose, method, organCount }: EffectiveDoseCardProps) => {
  // Calculate nominal risk (configurable, default: 5% per Sv for stochastic effects)
  const nominalRiskPercent = effectiveDose * 0.05;

  return (
    <Card className="p-6">
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-primary/10 rounded-lg">
            <Activity className="h-6 w-6 text-primary" />
          </div>
          <div>
            <h3 className="text-lg font-semibold">Effective Dose (E)</h3>
            <p className="text-sm text-muted-foreground">ICRP-103 organ weighting</p>
          </div>
        </div>
        <Badge variant="outline">{method}</Badge>
      </div>

      <div className="mb-6">
        <div className="text-4xl font-bold text-primary mb-2">
          {effectiveDose.toFixed(2)} <span className="text-xl text-muted-foreground">mSv</span>
        </div>
        <p className="text-sm text-muted-foreground">
          Calculated from {organCount} organs with weight factors
        </p>
      </div>

      <div className="space-y-3">
        <div className="p-3 bg-muted/50 rounded-lg">
          <div className="flex justify-between items-center mb-1">
            <span className="text-sm font-medium">Nominal Risk</span>
            <Badge variant="secondary">{nominalRiskPercent.toFixed(4)}%</Badge>
          </div>
          <p className="text-xs text-muted-foreground">
            Based on 5% per Sv coefficient (ICRP-103)
          </p>
        </div>

        <Alert>
          <AlertCircle className="h-4 w-4" />
          <AlertDescription className="text-xs">
            <strong>Research Context:</strong> This calculation is for research purposes only. 
            Effective dose provides a population-averaged risk estimate and should not be used 
            for individual patient counseling without clinical context. Not approved for clinical 
            decision-making (no CE marking).
          </AlertDescription>
        </Alert>
      </div>

      <div className="mt-4 pt-4 border-t">
        <h4 className="text-sm font-semibold mb-2">Calculation Method</h4>
        <p className="text-xs text-muted-foreground">
          E = Σ w<sub>T</sub> × H<sub>T</sub>, where H<sub>T</sub> ≈ D<sub>mean</sub> for photons
        </p>
      </div>
    </Card>
  );
};

export default EffectiveDoseCard;
