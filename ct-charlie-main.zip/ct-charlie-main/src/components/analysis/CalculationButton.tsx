import { Button } from "@/components/ui/button";
import { Calculator, Download } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";
import { Progress } from "@/components/ui/progress";
import { calculateOrganDoses, CalculationProgress } from "@/services/doseCalculation";
import { exportToExcel, exportDetailedToExcel } from "@/services/excelExport";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";

/**
 * ICRP-103 tissue weighting factors mapped to TotalSegmentator organ names.
 * Used to compute effective dose E = Σ wT × HT (where HT ≈ Dmean for photons).
 */
const ICRP103_WEIGHT_FACTORS: Record<string, number> = {
  'Lungs': 0.12,
  'Colon': 0.12,
  'Stomach': 0.12,
  'Esophagus': 0.12,  // Remainder organ but sometimes listed separately
  'Liver': 0.04,
  'Kidneys': 0.04,    // Remainder organ
  'Heart': 0.04,      // Remainder organ
  'Urinary Bladder': 0.04,
  'Small Bowel': 0.04, // Remainder organ
  'Spleen': 0.04,     // Remainder organ
  'Pancreas': 0.04,   // Remainder organ
  'Adrenal Glands': 0.04, // Remainder organ
  'Brain': 0.01,
};

/** Compute effective dose from organ dose results using ICRP-103 weights */
function computeEffectiveDose(organDoses: Array<{ organ_name: string; d_mean: number; status: string }>): number {
  let effectiveDose = 0;
  for (const organ of organDoses) {
    if (organ.status !== 'success') continue;
    const weight = ICRP103_WEIGHT_FACTORS[organ.organ_name];
    if (weight) {
      effectiveDose += weight * organ.d_mean;
    }
  }
  return effectiveDose;
}

interface CalculationButtonProps {
  studyId: string;
  onCalculationComplete?: (results: any) => void;
  latestRun?: any; // Pass the latest run from parent
}

const CalculationButton = ({
  studyId,
  onCalculationComplete,
  latestRun,
}: CalculationButtonProps) => {
  const { toast } = useToast();
  const [calculating, setCalculating] = useState(false);
  const [progress, setProgress] = useState<CalculationProgress | null>(null);
  const [comparisonMode, setComparisonMode] = useState(false);
  const [allOrgans, setAllOrgans] = useState(false);

  // Check if there's a completed run with organ_doses data
  const hasCompletedRun = latestRun && 
    latestRun.status === 'completed' && 
    latestRun.results && 
    typeof latestRun.results === 'object' && 
    'organ_doses' in latestRun.results;

  const handleExport = (detailed: boolean = false) => {
    if (!hasCompletedRun) {
      toast({
        variant: "destructive",
        title: "No results to export",
        description: "Please run a calculation first",
      });
      return;
    }

    try {
      console.log('Starting export...', { detailed, latestRun });
      const results = latestRun.results as any;
      const meanmAs = results.mean_mAs;
      
      console.log('Results:', results);
      console.log('Mean mAs:', meanmAs);
      console.log('Organ doses:', results.organ_doses);
      
      // Convert organ_doses object to array format for export
      const organDoses = Object.entries(results.organ_doses).map(([organName, organ]: [string, any]) => {
        console.log(`Processing organ: ${organName}`, organ);
        return {
          organ_name: organName,
          d_mean: organ.d_mean || 0,
          d_min: organ.d_min || 0,
          d_max: organ.d_max || 0,
          d_median: organ.d_median || 0,
          d_p5: organ.d_p5 || 0,
          d_p95: organ.d_p95 || 0,
          volume_ml: organ.volume_ml || 0,
          unit: organ.unit || 'Gy',
          relative_dose: organ.relative_dose || 0,
          status: organ.status || 'unknown',
          error_message: organ.error_message || '',
          dvh_cumulative: organ.dvh_cumulative || []
        };
      });

      console.log('Converted organ doses:', organDoses);
      console.log(`Calling export function with ${organDoses.length} organs`);

      if (detailed) {
        exportDetailedToExcel(studyId, meanmAs, organDoses);
      } else {
        exportToExcel(studyId, meanmAs, organDoses);
      }

      console.log('Export completed successfully');

      toast({
        title: "Export successful",
        description: "Results exported to Excel",
      });
    } catch (error) {
      console.error('Export error details:', error);
      toast({
        variant: "destructive",
        title: "Export failed",
        description: error instanceof Error ? error.message : "Unknown error occurred",
      });
    }
  };

  const handleCalculate = async () => {
    setCalculating(true);
    setProgress({ stage: 'starting', current: 0, total: 100, message: 'Initializing...' });
    
    try {
      if (comparisonMode) {
        // Run both methods for comparison
        toast({
          title: "Starting comparison",
          description: "Running both old and new methods...",
        });

        // Run old method
        console.log('========== RUNNING OLD METHOD ==========');
        setProgress({ stage: 'old', current: 0, total: 100, message: 'Running old method...' });
        const oldResults = await calculateOrganDoses(studyId, setProgress, true, allOrgans);
        console.log('OLD METHOD RESULTS:', oldResults);

        // Run new method
        console.log('========== RUNNING NEW METHOD ==========');
        setProgress({ stage: 'new', current: 0, total: 100, message: 'Running new method...' });
        const newResults = await calculateOrganDoses(studyId, setProgress, false, allOrgans);
        console.log('NEW METHOD RESULTS:', newResults);

        // Compare results
        console.log('========== COMPARISON ==========');
        console.table(
          oldResults.organ_doses.map((oldOrgan, idx) => {
            const newOrgan = newResults.organ_doses.find(o => o.organ_name === oldOrgan.organ_name);
            return {
              Organ: oldOrgan.organ_name,
              'Old D_mean (mGy)': oldOrgan.d_mean.toFixed(3),
              'New D_mean (mGy)': newOrgan?.d_mean.toFixed(3) || 'N/A',
              'Difference (%)': newOrgan 
                ? (((newOrgan.d_mean - oldOrgan.d_mean) / oldOrgan.d_mean) * 100).toFixed(1) 
                : 'N/A'
            };
          })
        );

        toast({
          title: "Comparison complete",
          description: "Check console for detailed results",
        });

        // Store new method results
        const { error: insertError } = await supabase
          .from('analysis_runs')
          .insert({
            study_id: studyId,
            run_id: `RUN-${Date.now()}`,
            status: 'completed',
            started_at: new Date().toISOString(),
            finished_at: new Date().toISOString(),
          results: {
              mean_mAs: newResults.meanmAs,
              metadata: newResults.metadata,
              effective_dose_mSv: computeEffectiveDose(newResults.organ_doses),
              organ_doses: newResults.organ_doses.reduce((acc, organ) => {
                acc[organ.organ_name] = {
                  d_mean: organ.d_mean,
                  d_min: organ.d_min,
                  d_max: organ.d_max,
                  d_median: organ.d_median,
                  d_p5: organ.d_p5,
                  d_p95: organ.d_p95,
                  volume_ml: organ.volume_ml,
                  unit: organ.unit,
                  relative_dose: organ.relative_dose,
                  status: organ.status,
                  dvh_cumulative: organ.dvh_cumulative
                };
                return acc;
              }, {} as any)
            },
            created_by: (await supabase.auth.getUser()).data.user?.id
          });

        if (insertError) {
          console.error('Failed to store results:', insertError);
        }

        if (onCalculationComplete) {
          onCalculationComplete(newResults);
        }

      } else {
        // Normal calculation with new method
        toast({
          title: "Starting calculation",
          description: "Processing DICOM and NIfTI files...",
        });

        // Call the client-side calculation engine (new method by default)
        const results = await calculateOrganDoses(studyId, (prog) => {
          setProgress(prog);
        }, false, allOrgans);

      // Store results in database
      const { error: insertError } = await supabase
        .from('analysis_runs')
        .insert({
          study_id: studyId,
          run_id: `RUN-${Date.now()}`,
          status: 'completed',
          started_at: new Date().toISOString(),
          finished_at: new Date().toISOString(),
          results: {
            mean_mAs: results.meanmAs,
            metadata: results.metadata,
            effective_dose_mSv: computeEffectiveDose(results.organ_doses),
            organ_doses: results.organ_doses.reduce((acc, organ) => {
              acc[organ.organ_name] = {
                d_mean: organ.d_mean,
                d_min: organ.d_min,
                d_max: organ.d_max,
                d_median: organ.d_median,
                d_p5: organ.d_p5,
                d_p95: organ.d_p95,
                volume_ml: organ.volume_ml,
                unit: organ.unit,
                relative_dose: organ.relative_dose,
                status: organ.status,
                dvh_cumulative: organ.dvh_cumulative
              };
              return acc;
            }, {} as any)
          },
          created_by: (await supabase.auth.getUser()).data.user?.id
        });

      if (insertError) {
        console.error('Failed to store results:', insertError);
      }

      toast({
        title: "Calculation complete",
        description: `Processed ${results.metadata.num_organs_processed} organs successfully`,
      });

        if (onCalculationComplete) {
          onCalculationComplete(results);
        }
      }
    } catch (error) {
      console.error('Calculation error:', error);
      toast({
        variant: "destructive",
        title: "Calculation failed",
        description: error instanceof Error ? error.message : "Unknown error occurred",
      });
    } finally {
      setCalculating(false);
      setProgress(null);
    }
  };

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center gap-4 mb-2">
        <div className="flex items-center gap-2">
          <Switch
            id="all-organs-mode"
            checked={allOrgans}
            onCheckedChange={setAllOrgans}
            disabled={calculating}
          />
          <Label htmlFor="all-organs-mode" className="text-sm text-muted-foreground">
            Calculate all organs (not just main 7)
          </Label>
        </div>
        <div className="flex items-center gap-2">
          <Switch
            id="comparison-mode"
            checked={comparisonMode}
            onCheckedChange={setComparisonMode}
            disabled={calculating}
          />
          <Label htmlFor="comparison-mode" className="text-sm text-muted-foreground">
            Compare with old method (check console)
          </Label>
        </div>
      </div>
      <div className="flex gap-2">
        <Button
          onClick={handleCalculate}
          disabled={calculating}
          className="gap-2"
        >
          <Calculator className="h-4 w-4" />
          {calculating ? "Calculating..." : "Calculate Organ Doses"}
        </Button>

        {hasCompletedRun && (
          <>
            <Button
              onClick={() => handleExport(false)}
              variant="outline"
              className="gap-2"
            >
              <Download className="h-4 w-4" />
              Export to Excel
            </Button>
            <Button
              onClick={() => handleExport(true)}
              variant="outline"
              className="gap-2"
            >
              <Download className="h-4 w-4" />
              Export Detailed
            </Button>
          </>
        )}
      </div>

      {calculating && progress && (
        <div className="space-y-2">
          <Progress value={progress.current} className="w-full" />
          <div className="text-sm text-muted-foreground text-center space-y-1">
            <p className="font-medium">{progress.message}</p>
            <p className="text-xs">
              {Math.round(progress.current)}% complete • Stage: {progress.stage}
            </p>
          </div>
        </div>
      )}
    </div>
  );
};

export default CalculationButton;
