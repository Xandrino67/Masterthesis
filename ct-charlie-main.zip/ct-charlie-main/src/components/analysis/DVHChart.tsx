import { useMemo } from "react";
import { Card } from "@/components/ui/card";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";

interface DVHData {
  organ_id: string;
  label: string;
  dvh_cumulative: number[][];
}

interface DVHChartProps {
  data: DVHData[];
  title?: string;
}

const COLORS = [
  "#3b82f6", "#ef4444", "#10b981", "#f59e0b", "#8b5cf6",
  "#ec4899", "#06b6d4", "#84cc16", "#f97316", "#6366f1"
];

const DVHChart = ({ data, title = "Dose-Volume Histogram" }: DVHChartProps) => {
  const chartData = useMemo(() => {
    if (!data || data.length === 0) return [];

    // Find maximum dose bin count across all organs
    const maxBins = Math.max(...data.map(d => d.dvh_cumulative.length));
    
    // Create unified data array with dose bins
    const unified = Array.from({ length: maxBins }, (_, i) => {
      const dataPoint: any = { dose: 0 };
      
      data.forEach((organ, organIndex) => {
        if (i < organ.dvh_cumulative.length) {
          const [dose, volume] = organ.dvh_cumulative[i];
          dataPoint.dose = dose;
          dataPoint[organ.label] = volume;
        }
      });
      
      return dataPoint;
    });

    return unified;
  }, [data]);

  if (!data || data.length === 0) {
    return (
      <Card className="p-6">
        <p className="text-center text-muted-foreground">No DVH data available</p>
      </Card>
    );
  }

  return (
    <Card className="p-6">
      <h3 className="text-lg font-semibold mb-4">{title}</h3>
      <div className="w-full h-[400px]">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
            <XAxis
              dataKey="dose"
              label={{ value: "Dose (Gy)", position: "insideBottom", offset: -5 }}
              stroke="hsl(var(--foreground))"
            />
            <YAxis
              label={{ value: "Volume (%)", angle: -90, position: "insideLeft" }}
              stroke="hsl(var(--foreground))"
            />
            <Tooltip
              contentStyle={{
                backgroundColor: "hsl(var(--background))",
                border: "1px solid hsl(var(--border))",
                borderRadius: "8px",
              }}
            />
            <Legend />
            {data.map((organ, index) => (
              <Line
                key={organ.organ_id}
                type="monotone"
                dataKey={organ.label}
                stroke={COLORS[index % COLORS.length]}
                strokeWidth={2}
                dot={false}
                activeDot={{ r: 4 }}
              />
            ))}
          </LineChart>
        </ResponsiveContainer>
      </div>
    </Card>
  );
};

export default DVHChart;
