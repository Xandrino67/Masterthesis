import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Checkbox } from "@/components/ui/checkbox";
import { ScrollArea } from "@/components/ui/scroll-area";
import { toast } from "sonner";
import { format } from "date-fns";
import { CalendarIcon, Loader2, Search } from "lucide-react";
import { cn } from "@/lib/utils";

interface CohortStudySelectorProps {
  cohortId: string;
  cohortName: string;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

interface Study {
  id: string;
  study_id: string;
  study_date: string;
  modality_set: string[];
  is_mock_data: boolean;
  patients: {
    pseudonym_id: string;
  } | null;
}

export function CohortStudySelector({ cohortId, cohortName, open, onOpenChange }: CohortStudySelectorProps) {
  const queryClient = useQueryClient();
  const [searchQuery, setSearchQuery] = useState("");
  const [dateFrom, setDateFrom] = useState<Date>();
  const [dateTo, setDateTo] = useState<Date>();
  const [modalityFilter, setModalityFilter] = useState<string>("all");
  const [dataTypeFilter, setDataTypeFilter] = useState<string>("all");
  const [selectedStudyIds, setSelectedStudyIds] = useState<Set<string>>(new Set());

  // Fetch all studies
  const { data: allStudies = [], isLoading: loadingStudies } = useQuery({
    queryKey: ["all-studies"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("studies")
        .select(`
          id,
          study_id,
          study_date,
          modality_set,
          is_mock_data,
          patients (
            pseudonym_id
          )
        `)
        .order("study_date", { ascending: false });

      if (error) throw error;
      return data as Study[];
    },
  });

  // Fetch current cohort studies
  const { data: cohortStudies = [], isLoading: loadingCohortStudies } = useQuery({
    queryKey: ["cohort-studies", cohortId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("cohort_studies")
        .select("study_id")
        .eq("cohort_id", cohortId);

      if (error) throw error;
      return data;
    },
  });

  // Initialize selected studies from cohort
  useEffect(() => {
    if (cohortStudies.length > 0) {
      setSelectedStudyIds(new Set(cohortStudies.map((cs) => cs.study_id)));
    }
  }, [cohortStudies]);

  // Filter studies
  const filteredStudies = allStudies.filter((study) => {
    // Search filter
    if (searchQuery && !study.study_id.toLowerCase().includes(searchQuery.toLowerCase()) &&
        !study.patients?.pseudonym_id.toLowerCase().includes(searchQuery.toLowerCase())) {
      return false;
    }

    // Date filters
    if (dateFrom && new Date(study.study_date) < dateFrom) return false;
    if (dateTo && new Date(study.study_date) > dateTo) return false;

    // Modality filter
    if (modalityFilter !== "all" && !study.modality_set?.includes(modalityFilter)) return false;

    // Data type filter
    if (dataTypeFilter === "real" && study.is_mock_data) return false;
    if (dataTypeFilter === "mock" && !study.is_mock_data) return false;

    return true;
  });

  const availableStudies = filteredStudies.filter((s) => !selectedStudyIds.has(s.id));
  const selectedStudies = allStudies.filter((s) => selectedStudyIds.has(s.id));

  // Save mutation
  const saveMutation = useMutation({
    mutationFn: async () => {
      // Delete all existing entries
      await supabase.from("cohort_studies").delete().eq("cohort_id", cohortId);

      // Insert new selections
      if (selectedStudyIds.size > 0) {
        const entries = Array.from(selectedStudyIds).map((studyId) => ({
          cohort_id: cohortId,
          study_id: studyId,
        }));

        const { error } = await supabase.from("cohort_studies").insert(entries);
        if (error) throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["cohorts"] });
      queryClient.invalidateQueries({ queryKey: ["cohort-studies", cohortId] });
      toast.success(`Updated cohort with ${selectedStudyIds.size} studies`);
      onOpenChange(false);
    },
    onError: (error: Error) => {
      toast.error(`Failed to save: ${error.message}`);
    },
  });

  const toggleStudy = (studyId: string) => {
    const newSet = new Set(selectedStudyIds);
    if (newSet.has(studyId)) {
      newSet.delete(studyId);
    } else {
      newSet.add(studyId);
    }
    setSelectedStudyIds(newSet);
  };

  const addAllFiltered = () => {
    const newSet = new Set(selectedStudyIds);
    availableStudies.forEach((study) => newSet.add(study.id));
    setSelectedStudyIds(newSet);
    toast.success(`Added ${availableStudies.length} studies`);
  };

  const clearAll = () => {
    setSelectedStudyIds(new Set());
    toast.info("Cleared all selections");
  };

  const StudyCard = ({ study, selected, onToggle }: { study: Study; selected: boolean; onToggle: () => void }) => (
    <div
      className={cn(
        "flex items-start gap-3 p-3 rounded-lg border transition-colors cursor-pointer hover:bg-accent/50",
        selected && "bg-accent border-primary"
      )}
      onClick={onToggle}
    >
      <Checkbox checked={selected} onCheckedChange={onToggle} onClick={(e) => e.stopPropagation()} />
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <p className="font-medium text-sm truncate">{study.study_id}</p>
          {study.is_mock_data && (
            <span className="text-xs px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-700 dark:text-amber-300">
              🧪 MOCK
            </span>
          )}
        </div>
        <p className="text-xs text-muted-foreground">
          {study.patients?.pseudonym_id || "Unknown Patient"}
        </p>
        <div className="flex items-center gap-2 mt-1">
          <span className="text-xs text-muted-foreground">{format(new Date(study.study_date), "PP")}</span>
          {study.modality_set && study.modality_set.length > 0 && (
            <span className="text-xs px-1.5 py-0.5 rounded bg-secondary text-secondary-foreground">
              {study.modality_set.join(", ")}
            </span>
          )}
        </div>
      </div>
    </div>
  );

  const isLoading = loadingStudies || loadingCohortStudies;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-6xl max-h-[90vh]">
        <DialogHeader>
          <DialogTitle>Manage Studies: {cohortName}</DialogTitle>
        </DialogHeader>

        {/* Filters */}
        <div className="space-y-3">
          <div className="flex gap-3">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search by Study ID or Patient..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
              />
            </div>
            <Select value={modalityFilter} onValueChange={setModalityFilter}>
              <SelectTrigger className="w-[150px]">
                <SelectValue placeholder="Modality" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Modalities</SelectItem>
                <SelectItem value="CT">CT</SelectItem>
                <SelectItem value="MR">MR</SelectItem>
                <SelectItem value="XA">XA</SelectItem>
                <SelectItem value="CR">CR</SelectItem>
              </SelectContent>
            </Select>
            <Select value={dataTypeFilter} onValueChange={setDataTypeFilter}>
              <SelectTrigger className="w-[150px]">
                <SelectValue placeholder="Data Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Data</SelectItem>
                <SelectItem value="real">Real Only</SelectItem>
                <SelectItem value="mock">Mock Only</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex gap-3">
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" className="w-[200px] justify-start">
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {dateFrom ? format(dateFrom, "PP") : "Date From"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0">
                <Calendar mode="single" selected={dateFrom} onSelect={setDateFrom} />
              </PopoverContent>
            </Popover>

            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" className="w-[200px] justify-start">
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {dateTo ? format(dateTo, "PP") : "Date To"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0">
                <Calendar mode="single" selected={dateTo} onSelect={setDateTo} />
              </PopoverContent>
            </Popover>

            {(dateFrom || dateTo) && (
              <Button variant="ghost" onClick={() => { setDateFrom(undefined); setDateTo(undefined); }}>
                Clear Dates
              </Button>
            )}
          </div>
        </div>

        {/* Dual Panel */}
        <div className="grid grid-cols-2 gap-4 h-[500px]">
          {/* Available Studies */}
          <div className="flex flex-col border rounded-lg overflow-hidden">
            <div className="p-3 border-b bg-muted/50 flex-shrink-0">
              <div className="flex items-center justify-between">
                <h3 className="font-medium">Available Studies</h3>
                <span className="text-sm text-muted-foreground">{availableStudies.length} studies</span>
              </div>
              <Button size="sm" variant="outline" className="w-full mt-2" onClick={addAllFiltered} disabled={availableStudies.length === 0}>
                Add All Filtered
              </Button>
            </div>
            <ScrollArea className="flex-1 h-full">
              <div className="p-3">
                {isLoading ? (
                  <div className="flex items-center justify-center h-full">
                    <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
                  </div>
                ) : availableStudies.length === 0 ? (
                  <p className="text-sm text-muted-foreground text-center py-8">No available studies</p>
                ) : (
                  <div className="space-y-2">
                    {availableStudies.map((study) => (
                      <StudyCard key={study.id} study={study} selected={false} onToggle={() => toggleStudy(study.id)} />
                    ))}
                  </div>
                )}
              </div>
            </ScrollArea>
          </div>

          {/* Selected Studies */}
          <div className="flex flex-col border rounded-lg overflow-hidden">
            <div className="p-3 border-b bg-muted/50 flex-shrink-0">
              <div className="flex items-center justify-between">
                <h3 className="font-medium">Selected Studies</h3>
                <span className="text-sm text-muted-foreground">{selectedStudyIds.size} studies</span>
              </div>
              <Button size="sm" variant="outline" className="w-full mt-2" onClick={clearAll} disabled={selectedStudyIds.size === 0}>
                Clear All
              </Button>
            </div>
            <ScrollArea className="flex-1 h-full">
              <div className="p-3">
                {selectedStudies.length === 0 ? (
                  <p className="text-sm text-muted-foreground text-center py-8">No studies selected</p>
                ) : (
                  <div className="space-y-2">
                    {selectedStudies.map((study) => (
                      <StudyCard key={study.id} study={study} selected={true} onToggle={() => toggleStudy(study.id)} />
                    ))}
                  </div>
                )}
              </div>
            </ScrollArea>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={() => saveMutation.mutate()} disabled={saveMutation.isPending}>
            {saveMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Save Selection
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
