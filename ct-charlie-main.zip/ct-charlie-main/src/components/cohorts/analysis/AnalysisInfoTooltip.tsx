import { Info } from "lucide-react";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

interface AnalysisInfoTooltipProps {
  title: string;
  description: string;
  interpretation?: string;
  references?: string[];
}

export const AnalysisInfoTooltip = ({ 
  title, 
  description, 
  interpretation,
  references 
}: AnalysisInfoTooltipProps) => {
  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <button className="inline-flex items-center justify-center rounded-full p-1 hover:bg-muted transition-colors">
            <Info className="h-4 w-4 text-muted-foreground" />
          </button>
        </TooltipTrigger>
        <TooltipContent className="max-w-sm p-4" side="right">
          <div className="space-y-2">
            <h4 className="font-semibold text-sm">{title}</h4>
            <p className="text-xs text-muted-foreground leading-relaxed">{description}</p>
            {interpretation && (
              <div className="pt-2 border-t">
                <p className="text-xs font-medium mb-1">Interpretation:</p>
                <p className="text-xs text-muted-foreground leading-relaxed">{interpretation}</p>
              </div>
            )}
            {references && references.length > 0 && (
              <div className="pt-2 border-t">
                <p className="text-xs font-medium mb-1">References:</p>
                <ul className="text-xs text-muted-foreground space-y-1">
                  {references.map((ref, i) => (
                    <li key={i}>• {ref}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
};
