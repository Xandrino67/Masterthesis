import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine } from "recharts";
import { AnalysisInfoTooltip } from "./AnalysisInfoTooltip";

interface EffectiveDoseDistributionProps {
  doses: number[];
}

export const EffectiveDoseDistribution = ({ doses }: EffectiveDoseDistributionProps) => {
  console.log('EffectiveDoseDistribution - doses:', doses);
  
  // Handle empty or invalid data
  if (!doses || doses.length === 0) {
    return (
      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <CardTitle>Effective Dose Distribution</CardTitle>
            <AnalysisInfoTooltip
              title="Effective Dose Distribution"
              description="Histogram showing the frequency distribution of effective doses across the cohort."
              interpretation="No effective dose data available for this cohort."
              references={["ICRP Publication 103"]}
            />
          </div>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground text-center py-8">
            No effective dose data available
          </p>
        </CardContent>
      </Card>
    );
  }
  
  // Create histogram bins
  const numBins = 15;
  const min = Math.min(...doses);
  const max = Math.max(...doses);
  const binSize = (max - min) / numBins || 1;
  
  const bins = Array.from({ length: numBins }, (_, i) => {
    const binStart = min + i * binSize;
    const binEnd = binStart + binSize;
    const count = doses.filter(d => d >= binStart && d < binEnd).length;
    
    return {
      range: `${binStart.toFixed(1)}-${binEnd.toFixed(1)}`,
      count,
      binStart
    };
  });

  // Reference values
  const naturalBackground = 3; // mSv per year
  const mean = doses.reduce((a, b) => a + b, 0) / doses.length;

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center gap-2">
          <CardTitle>Effective Dose Distribution</CardTitle>
          <AnalysisInfoTooltip
            title="Effective Dose Distribution"
            description="Histogram showing the frequency distribution of effective doses across the cohort. The shape reveals the dose pattern and any potential outliers."
            interpretation="Normal distribution indicates consistent protocols. Skewed distribution suggests variable practices. Multiple peaks may indicate different protocol groups. Compare to natural background radiation (~3 mSv/year)."
            references={["ICRP Publication 103", "UNSCEAR 2008 Report"]}
          />
        </div>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={bins}>
            <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
            <XAxis 
              dataKey="range" 
              angle={-45}
              textAnchor="end"
              height={80}
              tick={{ fontSize: 11 }}
              label={{ value: 'Effective Dose (mSv)', position: 'insideBottom', offset: -20 }}
            />
            <YAxis 
              label={{ value: 'Frequency', angle: -90, position: 'insideLeft' }}
            />
            <Tooltip 
              contentStyle={{ 
                backgroundColor: 'hsl(var(--popover))',
                border: '1px solid hsl(var(--border))',
                borderRadius: '6px'
              }}
              formatter={(value: number) => [`${value} studies`, 'Count']}
            />
            <ReferenceLine 
              x={bins.find(b => b.binStart <= mean && b.binStart + binSize > mean)?.range} 
              stroke="hsl(var(--primary))" 
              strokeDasharray="3 3"
              label={{ value: 'Mean', position: 'top' }}
            />
            <ReferenceLine 
              x={bins.find(b => b.binStart <= naturalBackground && b.binStart + binSize > naturalBackground)?.range} 
              stroke="hsl(var(--destructive))" 
              strokeDasharray="5 5"
              label={{ value: 'Natural BG/year', position: 'top', fontSize: 10 }}
            />
            <Bar dataKey="count" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
};
