import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AnalysisInfoTooltip } from "./AnalysisInfoTooltip";
import { AlertCircle, TrendingDown, TrendingUp } from "lucide-react";
import { OrganDoseData, calculateCorrelationMatrix } from "@/services/cohortStatistics";

interface StatisticalTestsProps {
  organData: OrganDoseData[];
  outliers: Array<{
    studyId: string;
    organ: string;
    value: number;
    zScore: number;
  }>;
}

export const StatisticalTests = ({ organData, outliers }: StatisticalTestsProps) => {
  const correlationMatrix = calculateCorrelationMatrix(organData);

  // Calculate high correlations (> 0.7)
  const highCorrelations = [];
  for (let i = 0; i < organData.length; i++) {
    for (let j = i + 1; j < organData.length; j++) {
      const corr = correlationMatrix[i][j];
      if (Math.abs(corr) > 0.7) {
        highCorrelations.push({
          organ1: organData[i].label,
          organ2: organData[j].label,
          correlation: corr
        });
      }
    }
  }

  // Get color based on correlation value
  const getCorrelationColor = (value: number) => {
    const absValue = Math.abs(value);
    if (absValue > 0.7) return value > 0 ? 'bg-blue-500' : 'bg-red-500';
    if (absValue > 0.4) return value > 0 ? 'bg-blue-300' : 'bg-red-300';
    if (absValue > 0.2) return value > 0 ? 'bg-blue-100' : 'bg-red-100';
    return 'bg-gray-100';
  };

  return (
    <div className="space-y-6">
      {/* Correlation Matrix */}
      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <CardTitle>Organ Dose Correlation Matrix</CardTitle>
            <AnalysisInfoTooltip
              title="Correlation Analysis"
              description="Shows Pearson correlation coefficients between organ doses. Values range from -1 (perfect negative correlation) to +1 (perfect positive correlation). Zero indicates no linear relationship."
              interpretation="High positive correlation (>0.7): Organs receive similar doses together, likely from same beam paths. Low correlation (<0.3): Doses are independent. Use this to understand exposure patterns and beam geometry effects."
              references={["Pearson, K. (1895)", "Statistical Methods in Medical Research"]}
            />
          </div>
        </CardHeader>
        <CardContent>
          {organData.length < 2 ? (
            <p className="text-muted-foreground text-center py-8">
              Need at least 2 organs for correlation analysis
            </p>
          ) : (
            <>
              {/* Custom Heatmap Implementation */}
              <div className="overflow-x-auto">
                <div className="inline-block min-w-full">
                  <table className="border-collapse">
                    <thead>
                      <tr>
                        <th className="w-32"></th>
                        {organData.map((organ, i) => (
                          <th 
                            key={i} 
                            className="text-xs font-medium text-center p-1 rotate-[-45deg] origin-bottom-left"
                            style={{ minWidth: '60px', height: '100px', verticalAlign: 'bottom' }}
                          >
                            <div className="transform translate-y-6">
                              {organ.label}
                            </div>
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {organData.map((rowOrgan, i) => (
                        <tr key={i}>
                          <td className="text-xs font-medium p-2 text-right pr-4 sticky left-0 bg-background">
                            {rowOrgan.label}
                          </td>
                          {organData.map((colOrgan, j) => {
                            const value = correlationMatrix[i][j];
                            const colorClass = getCorrelationColor(value);
                            const textColor = Math.abs(value) > 0.5 ? 'text-white' : 'text-foreground';
                            return (
                              <td 
                                key={j} 
                                className={`p-2 text-center border ${colorClass} ${textColor}`}
                                title={`${rowOrgan.label} vs ${colOrgan.label}: ${value.toFixed(3)}`}
                              >
                                <span className="text-xs font-medium">
                                  {value.toFixed(2)}
                                </span>
                              </td>
                            );
                          })}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <div className="mt-4 flex items-center gap-4 text-xs">
                  <span className="font-medium">Correlation Scale:</span>
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-4 bg-red-500"></div>
                    <span>-1.0</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-4 bg-gray-100"></div>
                    <span>0.0</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-4 bg-blue-500"></div>
                    <span>+1.0</span>
                  </div>
                </div>
              </div>
              
              {highCorrelations.length > 0 && (
                <div className="mt-4 p-4 bg-muted/50 rounded-lg">
                  <h4 className="text-sm font-medium mb-2">High Correlations (|r| &gt; 0.7)</h4>
                  <div className="space-y-2">
                    {highCorrelations.map((item, idx) => (
                      <div key={idx} className="flex items-center justify-between text-sm">
                        <span>
                          {item.organ1} ↔ {item.organ2}
                        </span>
                        <Badge variant={item.correlation > 0 ? "default" : "secondary"}>
                          r = {item.correlation.toFixed(3)}
                        </Badge>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </>
          )}
        </CardContent>
      </Card>

      {/* Outlier Detection */}
      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <CardTitle>Outlier Detection</CardTitle>
            <AnalysisInfoTooltip
              title="Statistical Outliers"
              description="Studies identified as statistical outliers using Z-score method. Outliers are values more than 2 standard deviations from the mean (|Z| > 2)."
              interpretation="Outliers may indicate: (1) Unusual patient anatomy, (2) Protocol deviations, (3) Technical issues, or (4) Data entry errors. Investigate each outlier for clinical relevance."
              references={["Grubbs, F.E. (1969)", "Outlier Detection Methods"]}
            />
          </div>
        </CardHeader>
        <CardContent>
          {outliers.length === 0 ? (
            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                No statistical outliers detected (all values within 2 SD of mean).
              </AlertDescription>
            </Alert>
          ) : (
            <>
              <Alert className="mb-4">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  Found {outliers.length} outlier{outliers.length > 1 ? 's' : ''} across {new Set(outliers.map(o => o.studyId)).size} stud{new Set(outliers.map(o => o.studyId)).size > 1 ? 'ies' : 'y'}
                </AlertDescription>
              </Alert>
              
              <div className="space-y-2">
                {outliers.slice(0, 20).map((outlier, idx) => (
                  <div 
                    key={idx} 
                    className="flex items-center justify-between p-3 border rounded-lg hover:bg-muted/50 transition-colors"
                  >
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <span className="font-medium text-sm">{outlier.organ}</span>
                        <Badge variant="outline" className="text-xs">
                          {outlier.studyId}
                        </Badge>
                      </div>
                      <p className="text-xs text-muted-foreground mt-1">
                        Dose: {outlier.value.toFixed(3)} Gy
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      {outlier.zScore > 0 ? (
                        <TrendingUp className="h-4 w-4 text-red-500" />
                      ) : (
                        <TrendingDown className="h-4 w-4 text-blue-500" />
                      )}
                      <Badge variant={Math.abs(outlier.zScore) > 3 ? "destructive" : "secondary"}>
                        Z = {outlier.zScore.toFixed(2)}
                      </Badge>
                    </div>
                  </div>
                ))}
                {outliers.length > 20 && (
                  <p className="text-xs text-muted-foreground text-center pt-2">
                    Showing first 20 outliers. Total: {outliers.length}
                  </p>
                )}
              </div>
            </>
          )}
        </CardContent>
      </Card>

      {/* Dose Variability Summary */}
      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <CardTitle>Dose Variability Summary</CardTitle>
            <AnalysisInfoTooltip
              title="Coefficient of Variation Analysis"
              description="CV% measures relative variability: (SD / Mean) × 100. Lower CV indicates more consistent dosing practices."
              interpretation="CV < 20%: Excellent consistency. CV 20-40%: Acceptable variability. CV > 40%: High variability, protocol review recommended."
            />
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {organData.map(organ => {
              const mean = organ.doses.reduce((a, b) => a + b, 0) / organ.doses.length;
              const variance = organ.doses.reduce((sum, d) => sum + Math.pow(d - mean, 2), 0) / organ.doses.length;
              const sd = Math.sqrt(variance);
              const cv = mean !== 0 ? (sd / mean) * 100 : 0;
              
              const getVariabilityLevel = (cv: number) => {
                if (cv < 20) return { label: 'Low', variant: 'default' as const, color: 'text-green-600' };
                if (cv < 40) return { label: 'Medium', variant: 'secondary' as const, color: 'text-yellow-600' };
                return { label: 'High', variant: 'destructive' as const, color: 'text-red-600' };
              };
              
              const level = getVariabilityLevel(cv);
              
              return (
                <Card key={organ.organ_id} className="p-4">
                  <h4 className="font-medium text-sm mb-2">{organ.label}</h4>
                  <div className="space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-muted-foreground">CV:</span>
                      <span className={`text-sm font-medium ${level.color}`}>
                        {cv.toFixed(1)}%
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-muted-foreground">Level:</span>
                      <Badge variant={level.variant} className="text-xs">
                        {level.label}
                      </Badge>
                    </div>
                    <div className="text-xs text-muted-foreground pt-1">
                      {mean.toFixed(3)} ± {sd.toFixed(3)} Gy
                    </div>
                  </div>
                </Card>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
