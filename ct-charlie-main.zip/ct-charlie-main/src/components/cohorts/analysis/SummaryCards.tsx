import { Users, FileText, Calendar, Activity, TrendingUp, Database } from "lucide-react";
import { StatsCard } from "@/components/ui/stats-card";
import { AnalysisInfoTooltip } from "./AnalysisInfoTooltip";

interface SummaryCardsProps {
  totalPatients: number;
  totalStudies: number;
  dateRange: { start: string; end: string };
  meanAge: number;
  meanEffectiveDose: number;
  sdEffectiveDose: number;
  hasMockData: boolean;
}

export const SummaryCards = ({
  totalPatients,
  totalStudies,
  dateRange,
  meanAge,
  meanEffectiveDose,
  sdEffectiveDose,
  hasMockData
}: SummaryCardsProps) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
      <div className="relative">
        <StatsCard
          title="Total Patients"
          value={totalPatients}
          icon={Users}
          variant={hasMockData ? "mock" : "default"}
        />
        <div className="absolute top-2 right-2">
          <AnalysisInfoTooltip
            title="Total Patients"
            description="The total number of unique patients included in this cohort analysis."
            interpretation="A larger cohort provides more statistical power for detecting differences and trends. Minimum recommended size is 30 patients for basic statistical analyses."
          />
        </div>
      </div>

      <div className="relative">
        <StatsCard
          title="Total Studies"
          value={totalStudies}
          icon={FileText}
          variant={hasMockData ? "mock" : "default"}
        />
        <div className="absolute top-2 right-2">
          <AnalysisInfoTooltip
            title="Total Studies"
            description="The total number of imaging studies (scans) in this cohort. Multiple studies may exist per patient for longitudinal analyses."
            interpretation="Studies per patient ratio indicates whether this is a cross-sectional (1:1) or longitudinal (>1:1) cohort."
          />
        </div>
      </div>

      <div className="relative">
        <StatsCard
          title="Date Range"
          value={`${dateRange.start} - ${dateRange.end}`}
          icon={Calendar}
          variant={hasMockData ? "mock" : "default"}
        />
        <div className="absolute top-2 right-2">
          <AnalysisInfoTooltip
            title="Study Date Range"
            description="The time span from the earliest to latest study in the cohort."
            interpretation="Longer date ranges allow for temporal trend analysis and evaluation of protocol changes over time. Be aware of potential confounding factors in multi-year studies."
          />
        </div>
      </div>

      <div className="relative">
        <StatsCard
          title="Mean Age"
          value={`${meanAge.toFixed(1)} years`}
          icon={Activity}
          variant={hasMockData ? "mock" : "default"}
        />
        <div className="absolute top-2 right-2">
          <AnalysisInfoTooltip
            title="Mean Patient Age"
            description="Average age of patients at the time of their scan. Calculated from birth year and study date."
            interpretation="Age is a critical factor in dose optimization and risk assessment. Pediatric patients require special consideration for radiation protection."
            references={["ICRP Publication 103", "Image Gently Campaign"]}
          />
        </div>
      </div>

      <div className="relative">
        <StatsCard
          title="Mean Effective Dose"
          value={`${meanEffectiveDose.toFixed(2)} ± ${sdEffectiveDose.toFixed(2)} mSv`}
          icon={TrendingUp}
          variant={hasMockData ? "mock" : "default"}
        />
        <div className="absolute top-2 right-2">
          <AnalysisInfoTooltip
            title="Effective Dose"
            description="Effective dose (E) is a weighted sum of organ doses that represents the stochastic health risk from the exposure. Calculated according to ICRP-103 tissue weighting factors."
            interpretation="Compare to typical background radiation (~3 mSv/year) and diagnostic reference levels. Lower doses with adequate image quality indicate optimization success."
            references={["ICRP Publication 103", "ACR Dose Index Registry"]}
          />
        </div>
      </div>

      <div className="relative">
        <StatsCard
          title="Data Quality"
          value={hasMockData ? "Mixed" : "Real"}
          subtitle={hasMockData ? "Contains mock data" : "All real data"}
          icon={Database}
          variant={hasMockData ? "mock" : "default"}
        />
        <div className="absolute top-2 right-2">
          <AnalysisInfoTooltip
            title="Data Quality Indicator"
            description="Indicates whether the cohort contains only real clinical data or includes synthetically generated mock data for testing purposes."
            interpretation="Mixed or mock data cohorts should only be used for system validation, not for clinical research or publication."
          />
        </div>
      </div>
    </div>
  );
};
