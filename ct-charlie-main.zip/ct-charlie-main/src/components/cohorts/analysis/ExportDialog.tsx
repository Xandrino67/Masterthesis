import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Checkbox } from "@/components/ui/checkbox";
import { Download, FileSpreadsheet, FileText, FileImage } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import * as XLSX from 'xlsx';
import { DescriptiveStats } from "@/services/cohortStatistics";

interface OrganDoseStats extends DescriptiveStats {
  organLabel: string;
}

interface ExportDialogProps {
  cohortName: string;
  summary: {
    totalPatients: number;
    totalStudies: number;
    meanEffectiveDose: number;
    sdEffectiveDose: number;
  };
  organStats: OrganDoseStats[];
  rawData?: any[];
}

export const ExportDialog = ({
  cohortName,
  summary,
  organStats,
  rawData = []
}: ExportDialogProps) => {
  const [open, setOpen] = useState(false);
  const [selectedFormats, setSelectedFormats] = useState({
    summary: true,
    organStats: true,
    rawData: false,
  });
  const { toast } = useToast();

  const handleExport = () => {
    try {
      const workbook = XLSX.utils.book_new();

      // Summary sheet
      if (selectedFormats.summary) {
        const summaryData = [
          ['Cohort Analysis Summary'],
          ['Cohort Name:', cohortName],
          ['Export Date:', new Date().toLocaleString()],
          [''],
          ['Total Patients:', summary.totalPatients],
          ['Total Studies:', summary.totalStudies],
          ['Mean Effective Dose (mSv):', summary.meanEffectiveDose.toFixed(2)],
          ['SD Effective Dose (mSv):', summary.sdEffectiveDose.toFixed(2)],
        ];
        
        const summarySheet = XLSX.utils.aoa_to_sheet(summaryData);
        XLSX.utils.book_append_sheet(workbook, summarySheet, 'Summary');
      }

      // Organ statistics sheet
      if (selectedFormats.organStats) {
        const organData = [
          ['Organ', 'N Studies', 'Mean (Gy)', 'SD (Gy)', 'Median (Gy)', 'Min (Gy)', 'Max (Gy)', 'Q1 (Gy)', 'Q3 (Gy)', 'IQR (Gy)', 'CV (%)'],
          ...organStats.map(stat => [
            stat.organLabel,
            stat.n,
            stat.mean.toFixed(4),
            stat.sd.toFixed(4),
            stat.median.toFixed(4),
            stat.min.toFixed(4),
            stat.max.toFixed(4),
            stat.q1.toFixed(4),
            stat.q3.toFixed(4),
            stat.iqr.toFixed(4),
            stat.cv.toFixed(2)
          ])
        ];
        
        const organSheet = XLSX.utils.aoa_to_sheet(organData);
        XLSX.utils.book_append_sheet(workbook, organSheet, 'Organ Statistics');
      }

      // Raw data sheet (if available and selected)
      if (selectedFormats.rawData && rawData.length > 0) {
        const rawSheet = XLSX.utils.json_to_sheet(rawData);
        XLSX.utils.book_append_sheet(workbook, rawSheet, 'Raw Data');
      }

      // Generate filename and download
      const filename = `${cohortName.replace(/\s+/g, '_')}_analysis_${new Date().toISOString().split('T')[0]}.xlsx`;
      XLSX.writeFile(workbook, filename);

      toast({
        title: "Export Successful",
        description: `Cohort analysis exported to ${filename}`,
      });
      
      setOpen(false);
    } catch (error) {
      toast({
        title: "Export Failed",
        description: "There was an error exporting the data. Please try again.",
        variant: "destructive",
      });
      console.error('Export error:', error);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" className="gap-2">
          <Download className="h-4 w-4" />
          Export Results
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Export Cohort Analysis</DialogTitle>
          <DialogDescription>
            Select the data you want to include in the export. Data will be exported as an Excel file.
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4 py-4">
          <div className="flex items-center space-x-3">
            <Checkbox
              id="summary"
              checked={selectedFormats.summary}
              onCheckedChange={(checked) =>
                setSelectedFormats(prev => ({ ...prev, summary: checked as boolean }))
              }
            />
            <label
              htmlFor="summary"
              className="flex items-center gap-2 text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
            >
              <FileText className="h-4 w-4 text-muted-foreground" />
              Summary Statistics
            </label>
          </div>

          <div className="flex items-center space-x-3">
            <Checkbox
              id="organStats"
              checked={selectedFormats.organStats}
              onCheckedChange={(checked) =>
                setSelectedFormats(prev => ({ ...prev, organStats: checked as boolean }))
              }
            />
            <label
              htmlFor="organStats"
              className="flex items-center gap-2 text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
            >
              <FileSpreadsheet className="h-4 w-4 text-muted-foreground" />
              Organ Dose Statistics
            </label>
          </div>

          <div className="flex items-center space-x-3">
            <Checkbox
              id="rawData"
              checked={selectedFormats.rawData}
              onCheckedChange={(checked) =>
                setSelectedFormats(prev => ({ ...prev, rawData: checked as boolean }))
              }
              disabled={rawData.length === 0}
            />
            <label
              htmlFor="rawData"
              className="flex items-center gap-2 text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
            >
              <FileSpreadsheet className="h-4 w-4 text-muted-foreground" />
              Raw Study Data
              {rawData.length === 0 && (
                <span className="text-xs text-muted-foreground">(not available)</span>
              )}
            </label>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => setOpen(false)}>
            Cancel
          </Button>
          <Button 
            onClick={handleExport}
            disabled={!selectedFormats.summary && !selectedFormats.organStats && !selectedFormats.rawData}
          >
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
