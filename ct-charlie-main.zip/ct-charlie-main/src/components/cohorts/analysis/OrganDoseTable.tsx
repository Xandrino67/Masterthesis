import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { DescriptiveStats } from "@/services/cohortStatistics";
import { AnalysisInfoTooltip } from "./AnalysisInfoTooltip";
import { useState } from "react";
import { ArrowUpDown } from "lucide-react";

interface OrganDoseStats extends DescriptiveStats {
  organLabel: string;
}

interface OrganDoseTableProps {
  organStats: OrganDoseStats[];
}

type SortField = keyof OrganDoseStats;
type SortDirection = 'asc' | 'desc';

export const OrganDoseTable = ({ organStats }: OrganDoseTableProps) => {
  const [sortField, setSortField] = useState<SortField>('mean');
  const [sortDirection, setSortDirection] = useState<SortDirection>('desc');

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('desc');
    }
  };

  const sortedStats = [...organStats].sort((a, b) => {
    const aVal = a[sortField];
    const bVal = b[sortField];
    const multiplier = sortDirection === 'asc' ? 1 : -1;
    
    if (typeof aVal === 'string' && typeof bVal === 'string') {
      return multiplier * aVal.localeCompare(bVal);
    }
    return multiplier * ((aVal as number) - (bVal as number));
  });

  const getCVBadge = (cv: number) => {
    if (cv < 20) return <Badge variant="secondary" className="bg-green-500/10 text-green-700 dark:text-green-400">Low</Badge>;
    if (cv < 40) return <Badge variant="secondary" className="bg-yellow-500/10 text-yellow-700 dark:text-yellow-400">Medium</Badge>;
    return <Badge variant="secondary" className="bg-red-500/10 text-red-700 dark:text-red-400">High</Badge>;
  };

  const SortableHeader = ({ field, children }: { field: SortField; children: React.ReactNode }) => (
    <TableHead className="cursor-pointer hover:bg-muted/50" onClick={() => handleSort(field)}>
      <div className="flex items-center gap-1">
        {children}
        <ArrowUpDown className="h-3 w-3" />
      </div>
    </TableHead>
  );

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center gap-2">
          <CardTitle>Organ Dose Statistics (Aggregate)</CardTitle>
          <AnalysisInfoTooltip
            title="Organ Dose Statistics"
            description="Statistical summary of radiation doses received by each organ across all studies in the cohort. All dose values are mean organ doses in Gray (Gy)."
            interpretation="Compare organ doses to published diagnostic reference levels. High CV% indicates inconsistent protocols. IQR shows the middle 50% spread of data."
            references={["ICRP Publication 103", "ACR Appropriateness Criteria"]}
          />
        </div>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <SortableHeader field="organLabel">Organ</SortableHeader>
                <SortableHeader field="n">N Studies</SortableHeader>
                <SortableHeader field="mean">
                  Mean ± SD <span className="text-xs">(Gy)</span>
                </SortableHeader>
                <SortableHeader field="median">
                  Median <span className="text-xs">(Gy)</span>
                </SortableHeader>
                <SortableHeader field="iqr">
                  IQR <span className="text-xs">(Q1-Q3)</span>
                </SortableHeader>
                <TableHead>
                  Range <span className="text-xs">(Min-Max)</span>
                </TableHead>
                <SortableHeader field="cv">
                  <div className="flex items-center gap-1">
                    CV%
                    <AnalysisInfoTooltip
                      title="Coefficient of Variation"
                      description="CV% = (Standard Deviation / Mean) × 100. Measures relative variability independent of the units or magnitude."
                      interpretation="Low CV (<20%): Consistent dosing. Medium CV (20-40%): Moderate variability. High CV (>40%): High variability, investigate protocols."
                    />
                  </div>
                </SortableHeader>
              </TableRow>
            </TableHeader>
            <TableBody>
              {sortedStats.map((stat) => (
                <TableRow key={stat.organLabel}>
                  <TableCell className="font-medium">{stat.organLabel}</TableCell>
                  <TableCell>{stat.n}</TableCell>
                  <TableCell>
                    <Badge variant="secondary">
                      {stat.mean.toFixed(3)} ± {stat.sd.toFixed(3)}
                    </Badge>
                  </TableCell>
                  <TableCell>{stat.median.toFixed(3)}</TableCell>
                  <TableCell className="text-xs">
                    {stat.q1.toFixed(3)} - {stat.q3.toFixed(3)}
                  </TableCell>
                  <TableCell className="text-xs text-muted-foreground">
                    {stat.min.toFixed(3)} - {stat.max.toFixed(3)}
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <span className="text-sm">{stat.cv.toFixed(1)}%</span>
                      {getCVBadge(stat.cv)}
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
};
