import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { AnalysisInfoTooltip } from "./AnalysisInfoTooltip";
import { DescriptiveStats } from "@/services/cohortStatistics";
import { useMemo } from "react";

interface OrganDoseStats extends DescriptiveStats {
  organLabel: string;
}

interface OrganDoseBoxPlotsProps {
  organStats: OrganDoseStats[];
}

export const OrganDoseBoxPlots = ({ organStats }: OrganDoseBoxPlotsProps) => {
  const maxDose = useMemo(() => 
    Math.max(...organStats.map(s => s.max)), 
    [organStats]
  );

  const BoxPlot = ({ stat }: { stat: OrganDoseStats }) => {
    const scale = 100 / maxDose; // Scale to percentage
    
    const minPos = stat.min * scale;
    const q1Pos = stat.q1 * scale;
    const medianPos = stat.median * scale;
    const q3Pos = stat.q3 * scale;
    const maxPos = stat.max * scale;

    return (
      <div className="flex items-center gap-3 py-2">
        <div className="w-32 text-sm font-medium truncate" title={stat.organLabel}>
          {stat.organLabel}
        </div>
        <div className="flex-1 relative h-8">
          {/* Whisker line (min to max) */}
          <div 
            className="absolute top-1/2 h-0.5 bg-muted-foreground"
            style={{ 
              left: `${minPos}%`, 
              width: `${maxPos - minPos}%`,
              transform: 'translateY(-50%)'
            }}
          />
          
          {/* Min whisker */}
          <div 
            className="absolute top-1/2 w-0.5 h-6 bg-muted-foreground"
            style={{ 
              left: `${minPos}%`,
              transform: 'translate(-50%, -50%)'
            }}
          />
          
          {/* Box (Q1 to Q3) */}
          <div 
            className="absolute top-1/2 h-6 border-2 border-primary bg-primary/10 rounded"
            style={{ 
              left: `${q1Pos}%`, 
              width: `${q3Pos - q1Pos}%`,
              transform: 'translateY(-50%)'
            }}
          />
          
          {/* Median line */}
          <div 
            className="absolute top-1/2 w-0.5 h-6 bg-primary"
            style={{ 
              left: `${medianPos}%`,
              transform: 'translate(-50%, -50%)'
            }}
          />
          
          {/* Max whisker */}
          <div 
            className="absolute top-1/2 w-0.5 h-6 bg-muted-foreground"
            style={{ 
              left: `${maxPos}%`,
              transform: 'translate(-50%, -50%)'
            }}
          />
        </div>
        <div className="w-24 text-xs text-muted-foreground text-right">
          {stat.median.toFixed(3)} Gy
        </div>
      </div>
    );
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center gap-2">
          <CardTitle>Organ Dose Distribution (Box Plots)</CardTitle>
          <AnalysisInfoTooltip
            title="Box Plot Visualization"
            description="Box plots (box-and-whisker plots) show the distribution of organ doses. The box represents the interquartile range (IQR, middle 50% of data), with the median line inside. Whiskers extend to minimum and maximum values."
            interpretation="Wide boxes indicate high variability. Symmetric boxes suggest normal distribution. The median position within the box shows skewness. Compare box positions to identify which organs receive highest/lowest doses."
            references={["Tukey, J.W. (1977). Exploratory Data Analysis"]}
          />
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-1">
          {organStats
            .sort((a, b) => b.median - a.median)
            .map(stat => (
              <BoxPlot key={stat.organLabel} stat={stat} />
            ))}
        </div>
        <div className="mt-4 text-xs text-muted-foreground">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <div className="w-4 h-0.5 bg-muted-foreground" />
              <span>Min/Max</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 border-2 border-primary bg-primary/10" />
              <span>IQR (Q1-Q3)</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-0.5 h-4 bg-primary" />
              <span>Median</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
