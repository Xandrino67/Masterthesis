import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ScatterChart, Scatter } from "recharts";
import { AnalysisInfoTooltip } from "./AnalysisInfoTooltip";
import { format, parseISO } from "date-fns";
import { calculateMovingAverage, calculateTrendLine } from "@/services/cohortStatistics";
import { useMemo } from "react";

interface TemporalDataPoint {
  date: string;
  effectiveDose: number;
  studyId: string;
  patientId: string;
}

interface TemporalAnalysisProps {
  data: TemporalDataPoint[];
}

export const TemporalAnalysis = ({ data }: TemporalAnalysisProps) => {
  const sortedData = useMemo(() => 
    [...data].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()),
    [data]
  );

  const chartData = useMemo(() => {
    return sortedData.map((d, idx) => ({
      ...d,
      dateFormatted: format(parseISO(d.date), 'MMM yyyy'),
      index: idx,
      timestamp: new Date(d.date).getTime()
    }));
  }, [sortedData]);

  const movingAvgData = useMemo(() => {
    if (chartData.length < 3) return [];
    
    const doses = chartData.map(d => d.effectiveDose);
    const windowSize = Math.min(Math.floor(chartData.length / 5), 10);
    const movingAvg = calculateMovingAverage(doses, windowSize);
    
    return chartData.map((d, idx) => ({
      ...d,
      movingAverage: movingAvg[idx]
    }));
  }, [chartData]);

  const trendData = useMemo(() => {
    if (chartData.length < 2) return null;
    
    const timestamps = chartData.map(d => d.timestamp);
    const doses = chartData.map(d => d.effectiveDose);
    const trend = calculateTrendLine(timestamps, doses);
    
    return {
      ...trend,
      data: chartData.map((d, idx) => ({
        ...d,
        trendLine: trend.predictions[idx]
      }))
    };
  }, [chartData]);

  // Group data by patient for trajectory analysis
  const patientTrajectories = useMemo(() => {
    const grouped = new Map<string, typeof chartData>();
    
    chartData.forEach(d => {
      if (!grouped.has(d.patientId)) {
        grouped.set(d.patientId, []);
      }
      grouped.get(d.patientId)!.push(d);
    });
    
    // Only include patients with 2+ studies
    return Array.from(grouped.entries())
      .filter(([_, studies]) => studies.length >= 2)
      .map(([patientId, studies]) => ({
        patientId,
        studies: studies.sort((a, b) => a.timestamp - b.timestamp)
      }));
  }, [chartData]);

  if (data.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Temporal Analysis</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground text-center py-8">
            No temporal data available
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Time Series with Moving Average */}
      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <CardTitle>Dose Trends Over Time</CardTitle>
            <AnalysisInfoTooltip
              title="Time Series Analysis"
              description="Shows how effective dose changes over time across the cohort. The blue line shows individual studies, and the orange line shows the moving average to smooth out short-term fluctuations."
              interpretation="Downward trends indicate successful dose optimization. Upward trends may suggest protocol drift or changes in patient population. Stable trends indicate consistent practices."
              references={["ICRP Publication 135", "ACR DIR"]}
            />
          </div>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={movingAvgData}>
              <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
              <XAxis 
                dataKey="dateFormatted"
                angle={-45}
                textAnchor="end"
                height={80}
                interval="preserveStartEnd"
              />
              <YAxis 
                label={{ value: 'Effective Dose (mSv)', angle: -90, position: 'insideLeft' }}
              />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'hsl(var(--popover))',
                  border: '1px solid hsl(var(--border))',
                  borderRadius: '6px'
                }}
                formatter={(value: number) => [`${value.toFixed(2)} mSv`, '']}
              />
              <Legend />
              <Line 
                type="monotone" 
                dataKey="effectiveDose" 
                stroke="hsl(var(--primary))" 
                strokeWidth={2}
                dot={{ r: 3 }}
                name="Effective Dose"
              />
              {movingAvgData.length > 0 && (
                <Line 
                  type="monotone" 
                  dataKey="movingAverage" 
                  stroke="hsl(var(--chart-2))" 
                  strokeWidth={3}
                  dot={false}
                  name="Moving Average"
                />
              )}
            </LineChart>
          </ResponsiveContainer>
          
          {trendData && (
            <div className="mt-4 p-4 bg-muted/50 rounded-lg">
              <h4 className="text-sm font-medium mb-2">Trend Analysis</h4>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-muted-foreground">Slope:</span>
                  <span className="ml-2 font-medium">
                    {(trendData.slope * 86400000 * 365).toFixed(4)} mSv/year
                  </span>
                </div>
                <div>
                  <span className="text-muted-foreground">R² (fit quality):</span>
                  <span className="ml-2 font-medium">
                    {trendData.rSquared.toFixed(3)}
                  </span>
                </div>
              </div>
              <p className="text-xs text-muted-foreground mt-2">
                {trendData.slope < 0 
                  ? `✓ Dose is decreasing over time (${Math.abs(trendData.slope * 86400000 * 365).toFixed(2)} mSv/year reduction)`
                  : `⚠ Dose is increasing over time (${(trendData.slope * 86400000 * 365).toFixed(2)} mSv/year increase)`
                }
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Patient Trajectories */}
      {patientTrajectories.length > 0 && (
        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              <CardTitle>Patient Dose Trajectories</CardTitle>
              <AnalysisInfoTooltip
                title="Longitudinal Patient Tracking"
                description="Shows cumulative dose progression for individual patients with multiple scans. Each line represents one patient's journey through sequential studies."
                interpretation="Steep slopes indicate rapid dose accumulation. Plateaus suggest long intervals between scans. Use this to identify patients approaching cumulative dose thresholds."
                references={["ICRP Publication 103", "Dose Tracking Recommendations"]}
              />
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground mb-4">
              Showing {patientTrajectories.length} patients with 2+ studies
            </p>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart>
                <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                <XAxis 
                  label={{ value: 'Scan Sequence', position: 'insideBottom', offset: -5 }}
                  domain={[1, 'dataMax']}
                />
                <YAxis 
                  label={{ value: 'Cumulative Dose (mSv)', angle: -90, position: 'insideLeft' }}
                />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'hsl(var(--popover))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '6px'
                  }}
                />
                
                {patientTrajectories.slice(0, 20).map((trajectory, idx) => {
                  const cumulativeData = trajectory.studies.map((study, scanIdx) => ({
                    scanNumber: scanIdx + 1,
                    cumulativeDose: trajectory.studies
                      .slice(0, scanIdx + 1)
                      .reduce((sum, s) => sum + s.effectiveDose, 0)
                  }));
                  
                  return (
                    <Line 
                      key={trajectory.patientId}
                      data={cumulativeData}
                      type="monotone" 
                      dataKey="cumulativeDose" 
                      stroke={`hsl(${(idx * 360 / 20)}, 70%, 50%)`}
                      strokeWidth={2}
                      strokeOpacity={0.6}
                      dot={{ r: 4 }}
                    />
                  );
                })}
              </LineChart>
            </ResponsiveContainer>
            {patientTrajectories.length > 20 && (
              <p className="text-xs text-muted-foreground text-center mt-2">
                Showing first 20 patients for clarity
              </p>
            )}
          </CardContent>
        </Card>
      )}

      {/* Scatter Plot: Dose vs Time */}
      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <CardTitle>Dose Distribution by Date</CardTitle>
            <AnalysisInfoTooltip
              title="Temporal Scatter Plot"
              description="Each point represents a single study. The scatter pattern reveals dose consistency over time and identifies outliers."
              interpretation="Dense horizontal bands indicate consistent dosing. Wide spread suggests high variability. Outliers (isolated points) warrant investigation."
            />
          </div>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <ScatterChart>
              <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
              <XAxis 
                dataKey="timestamp" 
                type="number"
                domain={['dataMin', 'dataMax']}
                tickFormatter={(timestamp) => format(new Date(timestamp), 'MMM yy')}
                angle={-45}
                textAnchor="end"
                height={80}
              />
              <YAxis 
                dataKey="effectiveDose"
                label={{ value: 'Effective Dose (mSv)', angle: -90, position: 'insideLeft' }}
              />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'hsl(var(--popover))',
                  border: '1px solid hsl(var(--border))',
                  borderRadius: '6px'
                }}
                formatter={(value: number) => [`${value.toFixed(2)} mSv`, 'Dose']}
                labelFormatter={(timestamp) => format(new Date(timestamp as number), 'MMM dd, yyyy')}
              />
              <Scatter 
                data={chartData}
                fill="hsl(var(--primary))" 
                fillOpacity={0.6}
              />
            </ScatterChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
    </div>
  );
};
