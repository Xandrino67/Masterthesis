import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Area, AreaChart } from "recharts";
import { AnalysisInfoTooltip } from "./AnalysisInfoTooltip";
import { AggregateDVH, DVHCurve, DVHPoint } from "@/services/dvhAnalysis";
import { useState, useMemo } from "react";
import { Skeleton } from "@/components/ui/skeleton";

interface DVHComparisonProps {
  aggregateDVHs: AggregateDVH[];
  isLoading?: boolean;
}

const COLORS = [
  'hsl(var(--chart-1))',
  'hsl(var(--chart-2))',
  'hsl(var(--chart-3))',
  'hsl(var(--chart-4))',
  'hsl(var(--chart-5))',
];

export const DVHComparison = ({ aggregateDVHs, isLoading }: DVHComparisonProps) => {
  const [selectedOrgan, setSelectedOrgan] = useState<string>(
    aggregateDVHs.length > 0 ? aggregateDVHs[0].organLabel : ''
  );

  const selectedDVH = useMemo(() => 
    aggregateDVHs.find(d => d.organLabel === selectedOrgan),
    [aggregateDVHs, selectedOrgan]
  );

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>DVH Analysis</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Skeleton className="h-8 w-48" />
          <Skeleton className="h-[400px] w-full" />
        </CardContent>
      </Card>
    );
  }

  if (aggregateDVHs.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>DVH Analysis</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground text-center py-8">
            No DVH data available for this cohort
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center gap-2">
          <CardTitle>Dose-Volume Histogram Analysis</CardTitle>
          <AnalysisInfoTooltip
            title="Dose-Volume Histogram (DVH)"
            description="DVH curves show the cumulative volume of an organ receiving at least a given dose. The x-axis is dose (Gy), y-axis is volume (%). A point at (20 Gy, 30%) means 30% of the organ volume received at least 20 Gy."
            interpretation="Curves to the right indicate higher doses. Steep curves indicate uniform dose distribution. Shallow curves indicate heterogeneous dose distribution. Compare curves between protocols or time periods to evaluate optimization."
            references={["AAPM Report 166", "ICRU Report 83"]}
          />
        </div>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="mean" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="mean">Mean DVH</TabsTrigger>
            <TabsTrigger value="individual">Individual Curves</TabsTrigger>
            <TabsTrigger value="comparison">Multi-Organ</TabsTrigger>
          </TabsList>

          <TabsContent value="mean" className="space-y-4">
            <div className="flex items-center gap-4">
              <label className="text-sm font-medium">Select Organ:</label>
              <Select value={selectedOrgan} onValueChange={setSelectedOrgan}>
                <SelectTrigger className="w-64">
                  <SelectValue placeholder="Select an organ..." />
                </SelectTrigger>
                <SelectContent>
                  {aggregateDVHs.length > 0 ? (
                    aggregateDVHs.map(dvh => (
                      <SelectItem key={dvh.organLabel} value={dvh.organLabel}>
                        {dvh.organLabel}
                      </SelectItem>
                    ))
                  ) : (
                    <div className="p-2 text-sm text-muted-foreground">No organs available</div>
                  )}
                </SelectContent>
              </Select>
            </div>

            {selectedDVH && (
              <ResponsiveContainer width="100%" height={400}>
                <AreaChart data={selectedDVH.meanCurve}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                  <XAxis 
                    dataKey="dose" 
                    label={{ value: 'Dose (Gy)', position: 'insideBottom', offset: -5 }}
                  />
                  <YAxis 
                    label={{ value: 'Volume (%)', angle: -90, position: 'insideLeft' }}
                    domain={[0, 100]}
                  />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'hsl(var(--popover))',
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '6px'
                    }}
                    formatter={(value: number) => [`${value.toFixed(1)}%`, 'Volume']}
                    labelFormatter={(label) => `Dose: ${Number(label).toFixed(2)} Gy`}
                  />
                  <Legend />
                  <Area 
                    type="monotone" 
                    dataKey="volume" 
                    stroke="hsl(var(--primary))" 
                    fill="hsl(var(--primary))"
                    fillOpacity={0.3}
                    name="Mean DVH"
                    strokeWidth={2}
                  />
                  {/* Upper and lower bounds */}
                  <Area 
                    type="monotone" 
                    data={selectedDVH.upperBound}
                    dataKey="volume" 
                    stroke="hsl(var(--primary))" 
                    fill="hsl(var(--primary))"
                    fillOpacity={0.1}
                    strokeDasharray="3 3"
                    name="± 1 SD"
                    strokeWidth={1}
                  />
                  <Area 
                    type="monotone" 
                    data={selectedDVH.lowerBound}
                    dataKey="volume" 
                    stroke="hsl(var(--primary))" 
                    fill="transparent"
                    strokeDasharray="3 3"
                    strokeWidth={1}
                  />
                </AreaChart>
              </ResponsiveContainer>
            )}
          </TabsContent>

          <TabsContent value="individual" className="space-y-4">
            <div className="flex items-center gap-4">
              <label className="text-sm font-medium">Select Organ:</label>
              <Select value={selectedOrgan} onValueChange={setSelectedOrgan}>
                <SelectTrigger className="w-64">
                  <SelectValue placeholder="Select an organ..." />
                </SelectTrigger>
                <SelectContent>
                  {aggregateDVHs.length > 0 ? (
                    aggregateDVHs.map(dvh => (
                      <SelectItem key={dvh.organLabel} value={dvh.organLabel}>
                        {dvh.organLabel}
                      </SelectItem>
                    ))
                  ) : (
                    <div className="p-2 text-sm text-muted-foreground">No organs available</div>
                  )}
                </SelectContent>
              </Select>
            </div>

            {selectedDVH && (
              <>
                <p className="text-sm text-muted-foreground">
                  Showing {selectedDVH.individualCurves.length} individual DVH curves (semi-transparent) 
                  with mean curve highlighted.
                </p>
                <ResponsiveContainer width="100%" height={400}>
                  <LineChart>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                    <XAxis 
                      dataKey="dose" 
                      type="number"
                      domain={['dataMin', 'dataMax']}
                      label={{ value: 'Dose (Gy)', position: 'insideBottom', offset: -5 }}
                    />
                    <YAxis 
                      label={{ value: 'Volume (%)', angle: -90, position: 'insideLeft' }}
                      domain={[0, 100]}
                    />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: 'hsl(var(--popover))',
                        border: '1px solid hsl(var(--border))',
                        borderRadius: '6px'
                      }}
                    />
                    <Legend />
                    
                    {/* Individual curves (semi-transparent) */}
                    {selectedDVH.individualCurves.map((curve, idx) => (
                      <Line 
                        key={curve.studyId}
                        data={curve.points}
                        type="monotone" 
                        dataKey="volume" 
                        stroke="hsl(var(--muted-foreground))"
                        strokeWidth={1}
                        strokeOpacity={0.2}
                        dot={false}
                        isAnimationActive={false}
                      />
                    ))}
                    
                    {/* Mean curve (bold) */}
                    <Line 
                      data={selectedDVH.meanCurve}
                      type="monotone" 
                      dataKey="volume" 
                      stroke="hsl(var(--primary))" 
                      strokeWidth={3}
                      name="Mean DVH"
                      dot={false}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </>
            )}
          </TabsContent>

          <TabsContent value="comparison" className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Comparing mean DVH curves across all organs in the cohort.
            </p>
            {(() => {
              // Merge all DVH curves into a single dataset with interpolation
              const organsToShow = aggregateDVHs.slice(0, 5);
              if (organsToShow.length === 0) {
                return <p className="text-muted-foreground text-center py-8">No DVH data available</p>;
              }
              
              console.log('First organ meanCurve sample:', organsToShow[0]?.organLabel, organsToShow[0]?.meanCurve.slice(0, 3));
              
              // Helper function to interpolate volume at a given dose
              const interpolateVolume = (curve: DVHPoint[], targetDose: number): number => {
                if (curve.length === 0) return 0;
                
                // Find surrounding points
                let before = curve[0];
                let after = curve[curve.length - 1];
                
                for (let i = 0; i < curve.length - 1; i++) {
                  if (curve[i].dose <= targetDose && curve[i + 1].dose >= targetDose) {
                    before = curve[i];
                    after = curve[i + 1];
                    break;
                  }
                }
                
                // Linear interpolation
                if (before.dose === after.dose) return Math.min(100, Math.max(0, before.volume));
                const t = (targetDose - before.dose) / (after.dose - before.dose);
                const interpolated = before.volume + t * (after.volume - before.volume);
                return Math.min(100, Math.max(0, interpolated)); // Clamp to 0-100
              };
              
              // Find global dose range
              const allDoses = organsToShow.flatMap(dvh => dvh.meanCurve.map(p => p.dose));
              const minDose = Math.min(...allDoses);
              const maxDose = Math.max(...allDoses);
              
              // Create 100 evenly spaced dose points
              const numPoints = 100;
              const unifiedData = Array.from({ length: numPoints }, (_, i) => {
                const dose = minDose + (i * (maxDose - minDose) / (numPoints - 1));
                const dataPoint: any = { dose };
                
                organsToShow.forEach(dvh => {
                  const volume = interpolateVolume(dvh.meanCurve, dose);
                  // Ensure we always have a valid number
                  dataPoint[dvh.organLabel] = isNaN(volume) ? 0 : volume;
                });
                
                return dataPoint;
              });
              
              console.log('Unified DVH data sample:', unifiedData.slice(0, 3), 'Total points:', unifiedData.length);
              
              return (
                <ResponsiveContainer width="100%" height={400}>
                  <LineChart data={unifiedData}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                    <XAxis 
                      dataKey="dose" 
                      type="number"
                      domain={['dataMin', 'dataMax']}
                      label={{ value: 'Dose (Gy)', position: 'insideBottom', offset: -5 }}
                    />
                    <YAxis 
                      label={{ value: 'Volume (%)', angle: -90, position: 'insideLeft' }}
                      domain={[0, 100]}
                    />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: 'hsl(var(--popover))',
                        border: '1px solid hsl(var(--border))',
                        borderRadius: '6px'
                      }}
                      formatter={(value: number) => [`${value.toFixed(1)}%`, 'Volume']}
                      labelFormatter={(label) => `Dose: ${Number(label).toFixed(2)} Gy`}
                    />
                    <Legend />
                    
                    {organsToShow.map((dvh, idx) => (
                      <Line 
                        key={dvh.organLabel}
                        type="monotone" 
                        dataKey={dvh.organLabel}
                        stroke={COLORS[idx % COLORS.length]}
                        strokeWidth={2}
                        dot={false}
                        isAnimationActive={false}
                        connectNulls={true}
                      />
                    ))}
                  </LineChart>
                </ResponsiveContainer>
              );
            })()}
            {aggregateDVHs.length > 5 && (
              <p className="text-xs text-muted-foreground text-center">
                Showing first 5 organs. Use organ selector in other tabs for individual analysis.
              </p>
            )}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
};
