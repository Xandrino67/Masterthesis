import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle, ChevronDown, ChevronRight } from "lucide-react";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";

export interface OrganDoseEntry {
  /** Canonical / merged organ name */
  organ: string;
  /** Total cumulative d_mean across all parts & studies */
  totalDose: number;
  /** Individual contributions that were summed into this organ */
  parts: { name: string; dose: number }[];
}

interface Props {
  entries: OrganDoseEntry[];
}

const CumulativeOrganDoseTable = ({ entries }: Props) => {
  const [expandedOrgans, setExpandedOrgans] = useState<Set<string>>(new Set());

  const toggle = (organ: string) => {
    setExpandedOrgans((prev) => {
      const next = new Set(prev);
      if (next.has(organ)) next.delete(organ);
      else next.add(organ);
      return next;
    });
  };

  // Sort alphabetically
  const sorted = [...entries].sort((a, b) => a.organ.localeCompare(b.organ));

  return (
    <Card>
      <CardHeader>
        <CardTitle>Cumulative Organ Doses</CardTitle>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-[300px]">Organ</TableHead>
              <TableHead className="text-right">Cumulative D_mean (mGy)</TableHead>
              <TableHead className="text-right">Status</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {sorted.map(({ organ, totalDose, parts }) => {
              const exceedsThreshold = totalDose >= 100;
              const hasMultipleParts = parts.length > 1;
              const isExpanded = expandedOrgans.has(organ);

              return (
                <Collapsible key={organ} asChild open={isExpanded} onOpenChange={() => toggle(organ)}>
                  <>
                    <TableRow className={exceedsThreshold ? "bg-destructive/5" : ""}>
                      <TableCell className="font-medium">
                        {hasMultipleParts ? (
                          <CollapsibleTrigger asChild>
                            <button className="flex items-center gap-1.5 hover:text-primary transition-colors text-left">
                              {isExpanded
                                ? <ChevronDown className="h-3.5 w-3.5 shrink-0" />
                                : <ChevronRight className="h-3.5 w-3.5 shrink-0" />}
                              {organ}
                              <span className="text-xs text-muted-foreground ml-1">
                                ({parts.length})
                              </span>
                            </button>
                          </CollapsibleTrigger>
                        ) : (
                          <span className="pl-5">{organ}</span>
                        )}
                      </TableCell>
                      <TableCell className="text-right font-mono">{totalDose.toFixed(4)}</TableCell>
                      <TableCell className="text-right">
                        {exceedsThreshold && (
                          <Badge variant="destructive" className="gap-1">
                            <AlertTriangle className="h-3 w-3" />
                            &gt; 100 mSv
                          </Badge>
                        )}
                      </TableCell>
                    </TableRow>
                    {hasMultipleParts && (
                      <CollapsibleContent asChild>
                        <>
                          {[...parts]
                            .sort((a, b) => b.dose - a.dose)
                            .map((part) => (
                              <TableRow key={part.name} className="bg-muted/30">
                                <TableCell className="pl-10 text-sm text-muted-foreground">
                                  {part.name === organ ? `${part.name} (merged)` : part.name}
                                </TableCell>
                                <TableCell className="text-right font-mono text-sm text-muted-foreground">
                                  {part.dose.toFixed(4)}
                                </TableCell>
                                <TableCell />
                              </TableRow>
                            ))}
                        </>
                      </CollapsibleContent>
                    )}
                  </>
                </Collapsible>
              );
            })}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
};

export default CumulativeOrganDoseTable;
