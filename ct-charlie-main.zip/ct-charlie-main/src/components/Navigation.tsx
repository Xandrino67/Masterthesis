import { useState, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { User, LogOut, Database, Upload, Settings, Shield, FileSearch, FolderOpen, Users } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import charlieLogoWide from "@/assets/charlie-logo-wide.png";

const Navigation = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { toast } = useToast();
  const [userEmail, setUserEmail] = useState<string>("");

  useEffect(() => {
    const getUser = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        setUserEmail(user.email || "");
      }
    };
    getUser();
  }, []);

  const handleLogout = async () => {
    const { error } = await supabase.auth.signOut();
    if (error) {
      toast({
        variant: "destructive",
        title: "Logout failed",
        description: error.message,
      });
    } else {
      toast({
        title: "Logged out",
        description: "You've been successfully logged out.",
      });
      navigate("/auth");
    }
  };

  const isActive = (path: string) => location.pathname === path;

  return (
    <nav className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center gap-8">
            <button
              onClick={() => navigate("/dashboard")}
              className="hover:opacity-80 transition-opacity"
            >
              <img src={charlieLogoWide} alt="Charlie - AI Powered Dose Analyzer" className="h-8 w-auto" />
            </button>

            <div className="hidden md:flex items-center gap-2">
              <Button
                variant={isActive("/dashboard") ? "default" : "ghost"}
                onClick={() => navigate("/dashboard")}
              >
                <Database className="mr-2 h-4 w-4" />
                Dashboard
              </Button>
              <Button
                variant={isActive("/studies") ? "default" : "ghost"}
                onClick={() => navigate("/studies")}
              >
                <FolderOpen className="mr-2 h-4 w-4" />
                Studies
              </Button>
              <Button
                variant={isActive("/upload") ? "default" : "ghost"}
                onClick={() => navigate("/upload")}
              >
                <Upload className="mr-2 h-4 w-4" />
                Upload
              </Button>
              <Button
                variant={isActive("/master-data") ? "default" : "ghost"}
                onClick={() => navigate("/master-data")}
              >
                <Settings className="mr-2 h-4 w-4" />
                Master Data
              </Button>
              <Button
                variant={isActive("/admin") ? "default" : "ghost"}
                onClick={() => navigate("/admin")}
              >
                <Shield className="mr-2 h-4 w-4" />
                Admin
              </Button>
              <Button
                variant={isActive("/audit") ? "default" : "ghost"}
                onClick={() => navigate("/audit")}
              >
                <FileSearch className="mr-2 h-4 w-4" />
                Audit
              </Button>
              <Button
                variant={isActive("/cohorts") ? "default" : "ghost"}
                onClick={() => navigate("/cohorts")}
              >
                <Users className="mr-2 h-4 w-4" />
                Cohorts
              </Button>
            </div>
          </div>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="rounded-full">
                <User className="h-5 w-5" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56">
              <DropdownMenuLabel>
                <div className="flex flex-col space-y-1">
                  <p className="text-sm font-medium">My Account</p>
                  <p className="text-xs text-muted-foreground truncate">{userEmail}</p>
                </div>
              </DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={handleLogout} className="text-destructive cursor-pointer">
                <LogOut className="mr-2 h-4 w-4" />
                Logout
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </nav>
  );
};

export default Navigation;
