import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ChevronLeft, ChevronRight, RotateCcw, ZoomIn, ZoomOut, RefreshCw } from "lucide-react";

interface ViewerControlsProps {
  currentSlice: number;
  totalSlices: number;
  onSliceChange: (slice: number) => void;
  windowWidth: number;
  windowCenter: number;
  onWindowLevelChange: (window: number, level: number) => void;
  zoom: number;
  onZoomChange: (zoom: number) => void;
  onResetView: () => void;
  onRefresh?: () => void;
}

const WINDOW_LEVEL_PRESETS = {
  abdomen: { window: 400, level: 50, label: 'Abdomen' },
  lung: { window: 1500, level: -600, label: 'Lung' },
  bone: { window: 2000, level: 300, label: 'Bone' },
  brain: { window: 80, level: 40, label: 'Brain' },
  liver: { window: 150, level: 90, label: 'Liver' },
};

export function ViewerControls({
  currentSlice,
  totalSlices,
  onSliceChange,
  windowWidth,
  windowCenter,
  onWindowLevelChange,
  zoom,
  onZoomChange,
  onResetView,
  onRefresh,
}: ViewerControlsProps) {
  const handlePresetChange = (preset: string) => {
    const { window, level } = WINDOW_LEVEL_PRESETS[preset as keyof typeof WINDOW_LEVEL_PRESETS];
    onWindowLevelChange(window, level);
  };

  const handlePreviousSlice = () => {
    if (currentSlice > 0) {
      onSliceChange(currentSlice - 1);
    }
  };

  const handleNextSlice = () => {
    if (currentSlice < totalSlices - 1) {
      onSliceChange(currentSlice + 1);
    }
  };

  const handleZoomIn = () => {
    onZoomChange(Math.min(zoom + 0.2, 5));
  };

  const handleZoomOut = () => {
    onZoomChange(Math.max(zoom - 0.2, 0.1));
  };

  return (
    <div className="space-y-4 p-4 border rounded-lg bg-card">
      {/* Slice Navigation */}
      <div className="space-y-2">
        <div className="flex items-center justify-between text-sm">
          <span className="font-medium">Slice Navigation</span>
          <span className="text-muted-foreground">
            {currentSlice + 1} / {totalSlices}
          </span>
        </div>
        
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="icon"
            onClick={handlePreviousSlice}
            disabled={currentSlice === 0}
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          
          <Slider
            value={[currentSlice]}
            onValueChange={([value]) => onSliceChange(value)}
            max={totalSlices - 1}
            step={1}
            className="flex-1"
          />
          
          <Button
            variant="outline"
            size="icon"
            onClick={handleNextSlice}
            disabled={currentSlice === totalSlices - 1}
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Window/Level Controls */}
      <div className="space-y-2">
        <div className="flex items-center justify-between text-sm">
          <span className="font-medium">Window/Level</span>
          <span className="text-muted-foreground">
            W: {Math.round(windowWidth)} L: {Math.round(windowCenter)}
          </span>
        </div>
        
        <Select onValueChange={handlePresetChange}>
          <SelectTrigger>
            <SelectValue placeholder="Select preset" />
          </SelectTrigger>
          <SelectContent>
            {Object.entries(WINDOW_LEVEL_PRESETS).map(([key, preset]) => (
              <SelectItem key={key} value={key}>
                {preset.label} (W:{preset.window} L:{preset.level})
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        
        <div className="space-y-1">
          <label className="text-xs text-muted-foreground">Window Width</label>
          <Slider
            value={[windowWidth]}
            onValueChange={([value]) => onWindowLevelChange(value, windowCenter)}
            min={1}
            max={4000}
            step={10}
          />
        </div>
        
        <div className="space-y-1">
          <label className="text-xs text-muted-foreground">Window Center</label>
          <Slider
            value={[windowCenter + 1000]}
            onValueChange={([value]) => onWindowLevelChange(windowWidth, value - 1000)}
            min={0}
            max={2000}
            step={10}
          />
        </div>
      </div>

      {/* Zoom Controls */}
      <div className="space-y-2">
        <div className="flex items-center justify-between text-sm">
          <span className="font-medium">Zoom</span>
          <span className="text-muted-foreground">{Math.round(zoom * 100)}%</span>
        </div>
        
        <div className="flex items-center gap-2">
          <Button variant="outline" size="icon" onClick={handleZoomOut}>
            <ZoomOut className="h-4 w-4" />
          </Button>
          
          <Slider
            value={[zoom]}
            onValueChange={([value]) => onZoomChange(value)}
            min={0.1}
            max={5}
            step={0.1}
            className="flex-1"
          />
          
          <Button variant="outline" size="icon" onClick={handleZoomIn}>
            <ZoomIn className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Reset View */}
      <div className="flex gap-2">
        <Button variant="outline" className="flex-1" onClick={onResetView}>
          <RotateCcw className="h-4 w-4 mr-2" />
          Reset View
        </Button>
        {onRefresh && (
          <Button variant="outline" className="flex-1" onClick={onRefresh}>
            <RefreshCw className="h-4 w-4 mr-2" />
            Reload
          </Button>
        )}
      </div>
    </div>
  );
}
