import { useEffect, useRef, useState, useCallback } from 'react';
import cornerstone from 'cornerstone-core';
import { loadDicomStack, preloadAdjacentSlices, clearImageCache } from '@/services/dicomImageLoader';
import { dicomCache } from '@/services/dicomCache';
import { ViewerControls } from './ViewerControls';
import { OverlayControls, OrganConfig, DoseConfig } from './OverlayControls';
import { CacheStatus } from './CacheStatus';
import { DoseLegend } from './DoseLegend';
import { Card } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Skeleton } from '@/components/ui/skeleton';
import { AlertCircle, Layers } from 'lucide-react';
import { loadOrganMasks, loadDoseDistribution, getDoseRange } from '@/services/overlayLoader';
import { renderOrganOverlay, renderDoseOverlay, renderOrganDoseOverlay, renderCombinedOverlay, clearOverlay, OrganOverlay, DoseOverlay, CombinedViewConfig } from '@/services/overlayRenderer';
import { NiftiData } from '@/services/niftiLoader';
import { toast } from 'sonner';
import { dicomPreloader } from '@/services/dicomPreloader';

interface DicomViewerProps {
  studyId: string;
  fileType?: 'dicom_dose' | 'dicom_other' | 'dicom_ct_fusie' | 'dicom_ct_wb';
  initialSlice?: number;
  showControls?: boolean;
  showOverlay?: boolean;
}

export function DicomViewer({
  studyId,
  fileType = 'dicom_other',
  initialSlice = 0,
  showControls = true,
  showOverlay = true,
}: DicomViewerProps) {
  const canvasRef = useRef<HTMLDivElement>(null);
  const overlayCanvasRef = useRef<HTMLCanvasElement>(null);
  const requestIdRef = useRef(0); // For request coalescing
  const [isLoading, setIsLoading] = useState(true);
  const [loadingProgress, setLoadingProgress] = useState({ loaded: 0, total: 0 });
  const [reloadKey, setReloadKey] = useState(0); // For refresh functionality
  const [error, setError] = useState<string | null>(null);
  const [imageIds, setImageIds] = useState<string[]>([]);
  const [currentSlice, setCurrentSlice] = useState(initialSlice);
  const [viewport, setViewport] = useState({
    windowWidth: 400,
    windowCenter: 50,
    zoom: 1.0,
    translation: { x: 0, y: 0 },
  });

  // Overlay state
  const [loadingOverlays, setLoadingOverlays] = useState(false);
  const [organMasks, setOrganMasks] = useState<Map<string, { data: NiftiData; color: string }>>(new Map());
  const [doseData, setDoseData] = useState<NiftiData | null>(null);
  const [organConfigs, setOrganConfigs] = useState<OrganConfig[]>([]);
  const [doseConfig, setDoseConfig] = useState<DoseConfig | null>(null);
  const [filterDoseByOrgans, setFilterDoseByOrgans] = useState(false);
  const [showOverlayPanel, setShowOverlayPanel] = useState(false);
  const [mousePosition, setMousePosition] = useState<{ x: number; y: number } | null>(null);
  const [doseValueAtCursor, setDoseValueAtCursor] = useState<number | null>(null);

  // Initialize Cornerstone and load DICOM stack
  useEffect(() => {
    const element = canvasRef.current;
    if (!element) return;

    let isSubscribed = true;

    const initializeViewer = async () => {
      try {
        setIsLoading(true);
        setError(null);
        setLoadingProgress({ loaded: 0, total: 0 });

        // Enable cornerstone on element
        cornerstone.enable(element);

        // Load DICOM stack with progress updates
        const stack = await loadDicomStack(studyId, fileType, (loaded, total) => {
          if (isSubscribed) {
            setLoadingProgress({ loaded, total });
          }
        });
        
        if (!isSubscribed) return;

        setImageIds(stack.imageIds);
        setCurrentSlice(initialSlice);

        // Load and display first image
        const image = await cornerstone.loadImage(stack.imageIds[initialSlice]);
        cornerstone.displayImage(element, image);

        // Set initial viewport
        const currentViewport = cornerstone.getViewport(element);
        setViewport({
          windowWidth: currentViewport.voi.windowWidth,
          windowCenter: currentViewport.voi.windowCenter,
          zoom: currentViewport.scale,
          translation: currentViewport.translation,
        });

        // Preload adjacent slices (small window for responsiveness)
        preloadAdjacentSlices(stack.imageIds, initialSlice, 2);

        // NO full-series background preloading - keep viewer responsive

        setIsLoading(false);
      } catch (err) {
        if (!isSubscribed) return;
        console.error('Error initializing DICOM viewer:', err);
        const errorMessage = err instanceof Error ? err.message : 'Failed to load DICOM images';
        
        // Provide more helpful error context
        if (errorMessage.includes('No valid DICOM slices')) {
          setError(
            `⚠️ De DICOM bestanden zijn geregistreerd in de database maar ontbreken in storage.\n\n` +
            `Dit betekent dat de ZIP extractie en upload naar storage niet correct is verlopen. ` +
            `De bestanden moeten opnieuw worden geüpload via een complete ZIP upload workflow.`
          );
        } else {
          setError(errorMessage);
        }
        setIsLoading(false);
      }
    };

    initializeViewer();

    return () => {
      isSubscribed = false;
      dicomPreloader.cancelPreloading(); // Cancel any ongoing preloading
      if (element && cornerstone.getEnabledElement(element)) {
        cornerstone.disable(element);
      }
    };
  }, [studyId, fileType, initialSlice, reloadKey]); // Include reloadKey to reinitialize on refresh

  // Handle slice change with request coalescing
  const handleSliceChange = useCallback(
    async (newSlice: number) => {
      const element = canvasRef.current;
      if (!element) return;

      // Request coalescing: only process the latest request
      requestIdRef.current += 1;
      const currentRequestId = requestIdRef.current;

      try {
        setCurrentSlice(newSlice);
        
        // Resolve lazy image ID to actual signed URL
        const { resolveLazyImageId } = await import('@/services/dicomImageLoader');
        const resolvedImageId = await resolveLazyImageId(imageIds[newSlice]);
        
        const image = await cornerstone.loadImage(resolvedImageId);
        
        // Only update if this is still the latest request
        if (currentRequestId !== requestIdRef.current) {
          return; // Newer request has been made, skip this one
        }
        
        cornerstone.displayImage(element, image);
        
        // Apply current viewport settings
        const currentViewport = cornerstone.getViewport(element);
        cornerstone.setViewport(element, {
          ...currentViewport,
          voi: {
            windowWidth: viewport.windowWidth,
            windowCenter: viewport.windowCenter,
          },
          scale: viewport.zoom,
          translation: viewport.translation,
        });

        // Smart preloading: small window around current slice
        preloadAdjacentSlices(imageIds, newSlice, 2).catch(err => {
          console.warn('Failed to preload adjacent slices:', err);
        });
        
        // Intelligent preloading based on navigation pattern (small window)
        dicomPreloader.preloadAround(imageIds, newSlice, studyId).catch(err => {
          console.warn('Failed to preload around slice:', err);
        });
      } catch (err) {
        console.error('Error changing slice:', err);
        toast.error('Failed to load slice');
      }
    },
    [imageIds, viewport, studyId]
  );

  // Load overlays (organ masks and dose distribution)
  const loadOverlays = useCallback(async () => {
    setLoadingOverlays(true);
    try {
      toast.info('Loading overlays...');

      // Load organ masks
      const masks = await loadOrganMasks(studyId, (current, total) => {
        console.log(`Loading organ masks: ${current}/${total}`);
      });
      setOrganMasks(masks);

      // Initialize organ configs (hidden by default, user can toggle them on)
      const configs: OrganConfig[] = Array.from(masks.entries()).map(([name, { color }]) => ({
        name,
        color,
        visible: false,
        opacity: 0.5,
      }));
      setOrganConfigs(configs);

      // Load dose distribution
      const dose = await loadDoseDistribution(studyId);
      setDoseData(dose);

      if (dose) {
        const { min, max } = getDoseRange(dose);
        // Show dose overlay by default when loaded
        setDoseConfig({
          visible: true,
          opacity: 0.6,
          minDose: min,
          maxDose: max,
          colorScheme: 'hot',
        });
      }

      setShowOverlayPanel(true);
      toast.success(`Loaded ${masks.size} organ masks${dose ? ' and dose distribution' : ''}`);
    } catch (err) {
      console.error('Error loading overlays:', err);
      toast.error('Failed to load overlays');
    } finally {
      setLoadingOverlays(false);
    }
  }, [studyId]);

  // Render overlays on canvas with debouncing
  const renderOverlays = useCallback(() => {
    const canvas = overlayCanvasRef.current;
    if (!canvas) return;

    // Use requestAnimationFrame for smooth rendering
    requestAnimationFrame(() => {
      clearOverlay(canvas);

      // Get DICOM orientation for precise mapping
      const enabledEl = cornerstone.getEnabledElement(canvasRef.current!);
      const img: any = enabledEl?.image;
      const dicomOrientation = img ? {
        rowCosines: (img.rowCosines || [1,0,0]) as [number,number,number],
        columnCosines: (img.columnCosines || [0,1,0]) as [number,number,number],
        imagePositionPatient: (img.imagePositionPatient || [0,0,0]) as [number,number,number],
        pixelSpacing: [img.rowPixelSpacing || 1, img.columnPixelSpacing || 1] as [number,number],
      } : undefined;

      // If filtering dose by organs, use combined view
      if (filterDoseByOrgans && organConfigs.length > 0 && doseData && doseConfig) {
        const organOverlays: OrganOverlay[] = organConfigs
          .filter((config) => config.visible)
          .map((config) => {
            const maskData = organMasks.get(config.name);
            return maskData
              ? {
                  organName: config.name,
                  data: maskData.data,
                  config: {
                    opacity: config.opacity,
                    color: config.color,
                    visible: config.visible,
                  },
                }
              : null;
          })
          .filter((overlay): overlay is OrganOverlay => overlay !== null);

        const doseOverlay: DoseOverlay = {
          data: doseData,
          config: doseConfig,
        };

        const combinedConfig: CombinedViewConfig = {
          enabled: true,
          showBoundaries: true,
          showDoseInside: true,
          // Disable highlight override so we see the true heatmap colors
          highlightThreshold: Number.POSITIVE_INFINITY,
          boundaryThickness: 1,
          doseOpacity: doseConfig.opacity,
        };

        renderCombinedOverlay(canvas, organOverlays, doseOverlay, currentSlice, combinedConfig, dicomOrientation);
        return;
      }

      // Otherwise, render layers separately
      const hasVisibleOrgans = organConfigs.some(c => c.visible);
      
      // If organs are visible with dose data, render dose inside organs only
      // Otherwise, render full dose overlay if no organs are visible
      if (doseData && doseConfig?.visible && !hasVisibleOrgans) {
        const overlay: DoseOverlay = {
          data: doseData,
          config: doseConfig,
        };
        renderDoseOverlay(canvas, overlay, currentSlice, dicomOrientation);
      }

      // Render organ overlays - use dose heatmap inside organs if dose data exists
      organConfigs.forEach((config) => {
        if (!config.visible) return;
        const maskData = organMasks.get(config.name);
        if (!maskData) return;

        const organOverlay: OrganOverlay = {
          organName: config.name,
          data: maskData.data,
          config: {
            opacity: config.opacity,
            color: config.color,
            visible: config.visible,
          },
        };

        // If dose data exists, render dose heatmap inside organ
        if (doseData && doseConfig) {
          renderOrganDoseOverlay(canvas, organOverlay, doseData, doseConfig, currentSlice, dicomOrientation);
        } else {
          // Otherwise, render solid color
          renderOrganOverlay(canvas, organOverlay, currentSlice, dicomOrientation);
        }
      });
    });
  }, [organMasks, doseData, organConfigs, doseConfig, currentSlice, filterDoseByOrgans]);

  // Update overlay canvas when slice or configs change (debounced)
  useEffect(() => {
    if (!isLoading && (organConfigs.length > 0 || doseData)) {
      // Debounce rendering to avoid excessive updates
      const timeoutId = setTimeout(() => {
        renderOverlays();
      }, 16); // ~60fps

      return () => clearTimeout(timeoutId);
    }
  }, [currentSlice, organConfigs, doseConfig, isLoading, renderOverlays]);

  // Initialize overlay canvas dimensions to match DICOM canvas
  useEffect(() => {
    const element = canvasRef.current;
    const canvas = overlayCanvasRef.current;
    if (!element || !canvas || isLoading) return;

    try {
      const enabledElement = cornerstone.getEnabledElement(element);
      if (enabledElement?.image) {
        canvas.width = enabledElement.image.width;
        canvas.height = enabledElement.image.height;
        console.log(`Overlay canvas initialized: ${canvas.width}x${canvas.height}`);
      }
    } catch (err) {
      console.warn('Could not get DICOM image dimensions:', err);
    }
  }, [isLoading, imageIds]);

  // Overlay control handlers
  const handleOrganToggle = useCallback((organName: string) => {
    setOrganConfigs((prev) =>
      prev.map((config) =>
        config.name === organName ? { ...config, visible: !config.visible } : config
      )
    );
  }, []);

  const handleOrganOpacityChange = useCallback((organName: string, opacity: number) => {
    setOrganConfigs((prev) =>
      prev.map((config) =>
        config.name === organName ? { ...config, opacity } : config
      )
    );
  }, []);

  const handleDoseToggle = useCallback(() => {
    setDoseConfig((prev) => (prev ? { ...prev, visible: !prev.visible } : null));
  }, []);

  const handleDoseOpacityChange = useCallback((opacity: number) => {
    setDoseConfig((prev) => (prev ? { ...prev, opacity } : null));
  }, []);

  const handleDoseRangeChange = useCallback((min: number, max: number) => {
    setDoseConfig((prev) => (prev ? { ...prev, minDose: min, maxDose: max } : null));
  }, []);

  const handleDoseColorSchemeChange = useCallback((scheme: 'hot' | 'jet' | 'viridis') => {
    setDoseConfig((prev) => (prev ? { ...prev, colorScheme: scheme } : null));
  }, []);

  const handleFilterDoseByOrgansToggle = useCallback((checked: boolean) => {
    setFilterDoseByOrgans(checked);
    
    // Auto-hide all organs when filter is disabled
    if (!checked) {
      setOrganConfigs((prev) => prev.map((config) => ({ ...config, visible: false })));
    }
  }, []);

  // Handle mouse move to show dose values
  const handleMouseMove = useCallback((e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = overlayCanvasRef.current;
    if (!canvas || !doseData) return;

    const rect = canvas.getBoundingClientRect();
    const x = Math.floor((e.clientX - rect.left) * (canvas.width / rect.width));
    const y = Math.floor((e.clientY - rect.top) * (canvas.height / rect.height));

    // Store position relative to canvas
    setMousePosition({ x: e.clientX - rect.left, y: e.clientY - rect.top });

    // Calculate dose value at cursor position
    const { data, dimensions } = doseData;
    const [width, height, depth] = dimensions;

    if (x >= 0 && x < width && y >= 0 && y < height && currentSlice >= 0 && currentSlice < depth) {
      const index = currentSlice * width * height + y * width + x;
      const doseValue = data[index];
      setDoseValueAtCursor(doseValue > 0 ? doseValue : null);
    } else {
      setDoseValueAtCursor(null);
    }
  }, [doseData, currentSlice]);

  const handleMouseLeave = useCallback(() => {
    setMousePosition(null);
    setDoseValueAtCursor(null);
  }, []);

  // Handle window/level change
  const handleWindowLevelChange = useCallback(
    (windowWidth: number, windowCenter: number) => {
      const element = canvasRef.current;
      if (!element) return;

      setViewport(prev => ({ ...prev, windowWidth, windowCenter }));

      const currentViewport = cornerstone.getViewport(element);
      cornerstone.setViewport(element, {
        ...currentViewport,
        voi: { windowWidth, windowCenter },
      });
    },
    []
  );

  // Handle zoom change
  const handleZoomChange = useCallback((zoom: number) => {
    const element = canvasRef.current;
    if (!element) return;

    setViewport(prev => ({ ...prev, zoom }));

    const currentViewport = cornerstone.getViewport(element);
    cornerstone.setViewport(element, {
      ...currentViewport,
      scale: zoom,
    });
  }, []);

  // Handle reset view
  const handleResetView = useCallback(() => {
    const element = canvasRef.current;
    if (!element) return;

    const newViewport = {
      windowWidth: 400,
      windowCenter: 50,
      zoom: 1.0,
      translation: { x: 0, y: 0 },
    };

    setViewport(newViewport);

    cornerstone.reset(element);
    cornerstone.setViewport(element, {
      voi: {
        windowWidth: newViewport.windowWidth,
        windowCenter: newViewport.windowCenter,
      },
      scale: newViewport.zoom,
      translation: newViewport.translation,
    });
  }, []);

  // Handle refresh - clear cache and force full reload
  const handleRefresh = useCallback(() => {
    const element = canvasRef.current;
    if (!element) return;

    // Clear all caches
    clearImageCache();
    dicomCache.clearStudy(studyId);
    dicomPreloader.cancelPreloading();
    
    // Disable cornerstone
    if (cornerstone.getEnabledElement(element)) {
      cornerstone.disable(element);
    }
    
    // Reset state and bump reload key to trigger reinitialization
    setIsLoading(true);
    setImageIds([]);
    setCurrentSlice(0);
    setReloadKey(prev => prev + 1);
    
    toast.info('Reloading CT images...');
  }, [studyId]);

  // Mouse wheel handler for slice navigation
  useEffect(() => {
    const element = canvasRef.current;
    if (!element) return;

    const handleWheel = (event: WheelEvent) => {
      event.preventDefault();
      const delta = event.deltaY > 0 ? 1 : -1;
      const newSlice = Math.max(0, Math.min(imageIds.length - 1, currentSlice + delta));
      if (newSlice !== currentSlice) {
        handleSliceChange(newSlice);
      }
    };

    element.addEventListener('wheel', handleWheel, { passive: false });
    return () => element.removeEventListener('wheel', handleWheel);
  }, [currentSlice, imageIds.length, handleSliceChange]);

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'ArrowUp' || event.key === 'ArrowLeft') {
        event.preventDefault();
        if (currentSlice > 0) {
          handleSliceChange(currentSlice - 1);
        }
      } else if (event.key === 'ArrowDown' || event.key === 'ArrowRight') {
        event.preventDefault();
        if (currentSlice < imageIds.length - 1) {
          handleSliceChange(currentSlice + 1);
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [currentSlice, imageIds.length, handleSliceChange]);

  if (error) {
    return (
      <Alert variant="destructive">
        <AlertCircle className="h-4 w-4" />
        <AlertDescription>
          <div className="space-y-3">
            <p className="font-medium whitespace-pre-line">{error}</p>
            <div className="border-t pt-2 mt-2">
              <p className="text-sm font-medium mb-1">Mogelijke oplossingen:</p>
              <ul className="text-sm list-disc list-inside space-y-1 ml-1">
                <li>Verwijder de huidige study uit de database</li>
                <li>Upload de ZIP bestanden opnieuw</li>
                <li>Zorg dat alle bestanden succesvol naar storage zijn geüpload</li>
              </ul>
            </div>
            <div className="border-t pt-2 mt-2">
              <p className="text-xs text-muted-foreground">
                Technische details: De extracted_files tabel bevat records maar de corresponderende bestanden 
                in de dose-files storage bucket kunnen niet worden gevonden.
              </p>
            </div>
          </div>
        </AlertDescription>
      </Alert>
    );
  }

  return (
    <div className="grid gap-4 grid-cols-[1fr_300px]">
      {/* Canvas Area */}
      <Card className="p-4">
        <div className="space-y-4">
          {showOverlay && !isLoading && (
            <div className="flex items-center justify-between text-sm">
              <span className="font-medium">CT Scan Viewer</span>
              <div className="flex items-center gap-2">
                <button
                  onClick={loadOverlays}
                  disabled={loadingOverlays}
                  className="flex items-center gap-1 px-3 py-1 text-xs bg-primary text-primary-foreground rounded hover:opacity-90 disabled:opacity-50"
                >
                  <Layers className="h-3 w-3" />
                  {loadingOverlays ? 'Loading...' : 'Load Overlays'}
                </button>
                <span className="text-muted-foreground">
                  Slice {currentSlice + 1} of {imageIds.length}
                </span>
              </div>
            </div>
          )}
          
          <div className="relative aspect-square bg-black rounded-lg overflow-hidden">
            {isLoading && (
              <div className="absolute inset-0 flex items-center justify-center bg-black/90 z-10">
                <div className="space-y-4 w-full max-w-md p-8">
                  <div className="text-center space-y-2">
                    <div className="text-lg font-medium text-white">
                      Loading CT scan data
                    </div>
                    {loadingProgress.total > 0 && (
                      <>
                        <div className="text-sm text-muted-foreground">
                          Slice {loadingProgress.loaded} of {loadingProgress.total}
                        </div>
                        <div className="w-full bg-muted rounded-full h-2 overflow-hidden">
                          <div 
                            className="bg-primary h-full transition-all duration-300"
                            style={{ 
                              width: `${(loadingProgress.loaded / loadingProgress.total) * 100}%` 
                            }}
                          />
                        </div>
                        <div className="text-xs text-muted-foreground">
                          {Math.round((loadingProgress.loaded / loadingProgress.total) * 100)}% complete
                        </div>
                      </>
                    )}
                  </div>
                </div>
              </div>
            )}
            
            {/* DICOM canvas */}
            <div
              ref={canvasRef}
              className="w-full h-full absolute inset-0"
              style={{ 
                cursor: isLoading ? 'wait' : 'crosshair'
              }}
            />
            
            {/* Overlay canvas - positioned on top */}
            <canvas
              ref={overlayCanvasRef}
              className="absolute inset-0"
              style={{
                width: '100%',
                height: '100%',
                pointerEvents: (doseData && doseConfig?.visible) ? 'auto' : 'none',
                cursor: (doseData && doseConfig?.visible) ? 'crosshair' : 'default',
              }}
              onMouseMove={handleMouseMove}
              onMouseLeave={handleMouseLeave}
            />
            
            {/* Dose value tooltip */}
            {doseValueAtCursor !== null && mousePosition && doseConfig?.visible && (
              <div
                className="absolute pointer-events-none bg-popover text-popover-foreground border px-3 py-1.5 rounded-md text-sm font-medium shadow-md z-50"
                style={{
                  left: `${mousePosition.x + 15}px`,
                  top: `${mousePosition.y + 15}px`,
                }}
              >
                {doseValueAtCursor.toFixed(3)} mGy
              </div>
            )}
            
            {/* Dose Legend */}
            {((doseConfig?.visible) || (organConfigs.some(o => o.visible) && doseData)) && doseConfig && (
              <div className="absolute bottom-4 right-4 z-30 pointer-events-none">
                <DoseLegend
                  colorScheme={doseConfig.colorScheme}
                  minDose={doseConfig.minDose}
                  maxDose={doseConfig.maxDose}
                />
              </div>
            )}
            
            {showOverlay && !isLoading && (
              <div className="absolute top-2 left-2 text-xs text-white bg-black/50 px-2 py-1 rounded z-20">
                <div>W: {Math.round(viewport.windowWidth)}</div>
                <div>L: {Math.round(viewport.windowCenter)}</div>
                <div>Zoom: {Math.round(viewport.zoom * 100)}%</div>
              </div>
            )}
          </div>
          
          <p className="text-xs text-muted-foreground text-center">
            Use arrow keys or mouse wheel to navigate slices • Middle-click to pan
          </p>
        </div>
      </Card>

      {/* Controls */}
      {showControls && !isLoading && (
        <div className="space-y-4">
          {/* Cache Status */}
          <CacheStatus studyId={studyId} />
          
            <ViewerControls
              currentSlice={currentSlice}
              totalSlices={imageIds.length}
              onSliceChange={handleSliceChange}
              windowWidth={viewport.windowWidth}
              windowCenter={viewport.windowCenter}
              onWindowLevelChange={handleWindowLevelChange}
              zoom={viewport.zoom}
              onZoomChange={handleZoomChange}
              onResetView={handleResetView}
              onRefresh={handleRefresh}
            />
          
          {/* Overlay Controls */}
          {showOverlayPanel && (
            <OverlayControls
              organs={organConfigs}
              doseConfig={doseConfig}
              onOrganToggle={handleOrganToggle}
              onOrganOpacityChange={handleOrganOpacityChange}
              onDoseToggle={handleDoseToggle}
              onDoseOpacityChange={handleDoseOpacityChange}
              onDoseRangeChange={handleDoseRangeChange}
              onDoseColorSchemeChange={handleDoseColorSchemeChange}
              filterDoseByOrgans={filterDoseByOrgans}
              onFilterDoseByOrgansToggle={handleFilterDoseByOrgansToggle}
            />
          )}
        </div>
      )}
    </div>
  );
}
