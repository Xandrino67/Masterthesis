import { useEffect, useState } from 'react';
import { Card } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Database, Zap, Trash2, RefreshCw, HardDrive, AlertTriangle } from 'lucide-react';
import { dicomCache } from '@/services/dicomCache';
import { dicomPreloader } from '@/services/dicomPreloader';
import { toast } from 'sonner';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';

interface CacheStatusProps {
  studyId?: string;
}

export function CacheStatus({ studyId }: CacheStatusProps) {
  const [stats, setStats] = useState<{
    totalSize: number;
    imageCount: number;
    uniqueImages: number;
    studies: number;
    byFileType?: Record<string, { count: number; size: number }>;
  } | null>(null);
  const [overlayStats, setOverlayStats] = useState<{
    totalSize: number;
    overlayCount: number;
  } | null>(null);
  const [preloadProgress, setPreloadProgress] = useState<{
    queued: number;
    isActive: boolean;
  }>({ queued: 0, isActive: false });
  const [storageQuota, setStorageQuota] = useState<{
    usage: number;
    quota: number;
    percentUsed: number;
    available: number;
  } | null>(null);
  const [isClearing, setIsClearing] = useState(false);
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null);

  const updateStats = async () => {
    try {
      const cacheStats = await dicomCache.getStats(studyId);
      setStats(cacheStats);
      
      const overlayCacheStats = await dicomCache.getOverlayStats(studyId);
      setOverlayStats(overlayCacheStats);
      
      const preloadStats = dicomPreloader.getProgress();
      setPreloadProgress(preloadStats);

      const quota = await dicomCache.getStorageQuota();
      setStorageQuota(quota);
      
      setLastUpdate(new Date());
    } catch (error) {
      console.warn('Failed to fetch cache stats:', error);
      setStats({ totalSize: 0, imageCount: 0, uniqueImages: 0, studies: 0 });
      setOverlayStats({ totalSize: 0, overlayCount: 0 });
    }
  };

  useEffect(() => {
    updateStats();
    const interval = setInterval(updateStats, 2000);
    return () => clearInterval(interval);
  }, [studyId]);

  const handleClearStudy = async () => {
    if (!studyId) return;
    
    setIsClearing(true);
    try {
      await dicomCache.clearStudy(studyId);
      await dicomCache.clearStudyOverlays(studyId);
      toast.success('Study cache cleared successfully');
      await updateStats();
    } catch (error) {
      console.error('Failed to clear study cache:', error);
      toast.error('Failed to clear cache');
    } finally {
      setIsClearing(false);
    }
  };

  const getFileTypeLabel = (fileType: string): string => {
    const labels: Record<string, string> = {
      'dicom_dose': 'Dose Distribution',
      'dicom_ct_wb': 'CT Whole Body',
      'dicom_ct_fusie': 'CT Fusion',
      'dicom_other': 'Other CT',
      'unknown': 'Unknown'
    };
    return labels[fileType] || fileType;
  };

  const handleClearAll = async () => {
    setIsClearing(true);
    try {
      await dicomCache.clearAllCache();
      toast.success('All cache cleared successfully');
      await updateStats();
    } catch (error) {
      console.error('Failed to clear all cache:', error);
      toast.error('Failed to clear cache');
    } finally {
      setIsClearing(false);
    }
  };

  if (!stats || !overlayStats) return null;

  const imagesSizeMB = (stats.totalSize / (1024 * 1024)).toFixed(1);
  const overlaysSizeMB = (overlayStats.totalSize / (1024 * 1024)).toFixed(1);
  const totalSizeMB = ((stats.totalSize + overlayStats.totalSize) / (1024 * 1024)).toFixed(1);
  
  const quotaUsageMB = storageQuota ? (storageQuota.usage / (1024 * 1024)).toFixed(0) : '?';
  const quotaTotalMB = storageQuota ? (storageQuota.quota / (1024 * 1024)).toFixed(0) : '?';
  const quotaPercent = storageQuota?.percentUsed || 0;
  const isStoragePressure = quotaPercent > 80;

  return (
    <Card className="p-3 space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Database className="h-4 w-4 text-muted-foreground" />
          <span className="text-sm font-medium">Cache Status</span>
        </div>
        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="sm"
            onClick={updateStats}
            className="h-6 px-2"
            title="Refresh cache stats"
          >
            <RefreshCw className="h-3 w-3" />
          </Button>
        </div>
      </div>

      {/* Storage Quota Display */}
      {storageQuota && (
        <div className="space-y-1.5">
          <div className="flex items-center justify-between text-xs">
            <div className="flex items-center gap-1.5">
              <HardDrive className="h-3 w-3 text-muted-foreground" />
              <span className="text-muted-foreground">Storage</span>
              {isStoragePressure && (
                <AlertTriangle className="h-3 w-3 text-warning" />
              )}
            </div>
            <span className="font-medium">
              {quotaUsageMB} / {quotaTotalMB} MB ({quotaPercent.toFixed(0)}%)
            </span>
          </div>
          <Progress 
            value={quotaPercent} 
            className="h-1.5"
          />
        </div>
      )}

      {/* Cache Stats */}
      <div className="space-y-1">
        <div className="flex justify-between text-xs">
          <span className="text-muted-foreground">Cache Size</span>
          <Badge variant="secondary" className="text-xs h-5">
            {totalSizeMB} MB
          </Badge>
        </div>
        
        {/* Per-Series Breakdown (when viewing a study) */}
        {studyId && stats.byFileType && Object.keys(stats.byFileType).length > 0 ? (
          <div className="space-y-1 pt-1">
            <div className="text-xs font-medium text-muted-foreground">Series Breakdown:</div>
            {Object.entries(stats.byFileType).map(([fileType, data]) => (
              <div key={fileType} className="flex justify-between text-xs pl-2">
                <span className="text-muted-foreground">{getFileTypeLabel(fileType)}</span>
                <span className="font-mono">
                  {data.count} images · {(data.size / (1024 * 1024)).toFixed(1)} MB
                </span>
              </div>
            ))}
          </div>
        ) : (
          <>
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>CT Images</span>
              <span>{stats.uniqueImages} unique · {stats.imageCount} cached · {imagesSizeMB} MB</span>
            </div>
          </>
        )}
        
        <div className="flex justify-between text-xs text-muted-foreground">
          <span>Overlays</span>
          <span>{overlayStats.overlayCount} files · {overlaysSizeMB} MB</span>
        </div>
        
        {!studyId && stats.studies > 0 && (
          <div className="flex justify-between text-xs text-muted-foreground">
            <span>Studies</span>
            <span>{stats.studies} cached</span>
          </div>
        )}
      </div>

      {/* Preload Progress */}
      {preloadProgress.isActive && (
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <Zap className="h-3 w-3 text-primary animate-pulse" />
            <span className="text-xs text-muted-foreground">
              Preloading... ({preloadProgress.queued} queued)
            </span>
          </div>
          <Progress value={100} className="h-1" />
        </div>
      )}

      {/* Cache Controls */}
      <div className="flex gap-2 pt-1">
        {studyId && (
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button
                variant="outline"
                size="sm"
                className="h-7 text-xs flex-1"
                disabled={isClearing || stats.imageCount === 0}
              >
                <Trash2 className="h-3 w-3 mr-1" />
                Clear Study
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Clear Study Cache?</AlertDialogTitle>
                <AlertDialogDescription>
                  This will remove all cached images and overlays for this study ({imagesSizeMB}MB + {overlaysSizeMB}MB). 
                  You'll need to reload them if you view this study again.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction onClick={handleClearStudy}>Clear Cache</AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        )}
        
        <AlertDialog>
          <AlertDialogTrigger asChild>
            <Button
              variant="outline"
              size="sm"
              className="h-7 text-xs flex-1"
              disabled={isClearing || (stats.imageCount === 0 && overlayStats.overlayCount === 0)}
            >
              <Trash2 className="h-3 w-3 mr-1" />
              Clear All
            </Button>
          </AlertDialogTrigger>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Clear All Cache?</AlertDialogTitle>
              <AlertDialogDescription>
                This will remove all cached data ({totalSizeMB}MB) from {stats.studies} {stats.studies === 1 ? 'study' : 'studies'}. 
                This action cannot be undone.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction onClick={handleClearAll}>Clear All Cache</AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>

      {/* Last Update Timestamp */}
      {lastUpdate && (
        <div className="text-xs text-muted-foreground text-center pt-1 border-t">
          Updated {lastUpdate.toLocaleTimeString()}
        </div>
      )}
    </Card>
  );
}
