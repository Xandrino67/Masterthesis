/**
 * Dose Legend Component
 * Displays a vertical gradient bar showing dose-to-color mapping
 */

import { useEffect, useRef } from 'react';
import { Card } from '@/components/ui/card';

interface DoseLegendProps {
  colorScheme: 'hot' | 'jet' | 'viridis';
  minDose: number;
  maxDose: number;
}

// Import getDoseColor from overlayRenderer
const getDoseColor = (
  value: number,
  minDose: number,
  maxDose: number,
  scheme: 'hot' | 'jet' | 'viridis'
): { r: number; g: number; b: number } => {
  const normalized = Math.max(0, Math.min(1, (value - minDose) / (maxDose - minDose)));
  
  switch (scheme) {
    case 'hot':
      if (normalized < 0.33) {
        const t = normalized / 0.33;
        return { r: Math.round(255 * t), g: 0, b: 0 };
      } else if (normalized < 0.66) {
        const t = (normalized - 0.33) / 0.33;
        return { r: 255, g: Math.round(255 * t), b: 0 };
      } else {
        const t = (normalized - 0.66) / 0.34;
        return { r: 255, g: 255, b: Math.round(255 * t) };
      }
    
    case 'jet':
      if (normalized < 0.25) {
        const t = normalized / 0.25;
        return { r: 0, g: 0, b: Math.round(128 + 127 * t) };
      } else if (normalized < 0.5) {
        const t = (normalized - 0.25) / 0.25;
        return { r: 0, g: Math.round(255 * t), b: 255 };
      } else if (normalized < 0.75) {
        const t = (normalized - 0.5) / 0.25;
        return { r: Math.round(255 * t), g: 255, b: Math.round(255 * (1 - t)) };
      } else {
        const t = (normalized - 0.75) / 0.25;
        return { r: 255, g: Math.round(255 * (1 - t)), b: 0 };
      }
    
    case 'viridis':
      if (normalized < 0.33) {
        const t = normalized / 0.33;
        return {
          r: Math.round(68 + (48 - 68) * t),
          g: Math.round(1 + (86 - 1) * t),
          b: Math.round(84 + (141 - 84) * t),
        };
      } else if (normalized < 0.66) {
        const t = (normalized - 0.33) / 0.33;
        return {
          r: Math.round(48 + (53 - 48) * t),
          g: Math.round(86 + (183 - 86) * t),
          b: Math.round(141 + (121 - 141) * t),
        };
      } else {
        const t = (normalized - 0.66) / 0.34;
        return {
          r: Math.round(53 + (254 - 53) * t),
          g: Math.round(183 + (231 - 183) * t),
          b: Math.round(121 + (36 - 121) * t),
        };
      }
  }
};

export function DoseLegend({ colorScheme, minDose, maxDose }: DoseLegendProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = 40;
    const height = 200;
    canvas.width = width;
    canvas.height = height;

    // Draw gradient bar from top (max) to bottom (min)
    for (let y = 0; y < height; y++) {
      const doseValue = maxDose - (y / height) * (maxDose - minDose);
      const color = getDoseColor(doseValue, minDose, maxDose, colorScheme);
      ctx.fillStyle = `rgb(${color.r}, ${color.g}, ${color.b})`;
      ctx.fillRect(0, y, width, 1);
    }
  }, [colorScheme, minDose, maxDose]);

  const schemeName = colorScheme.charAt(0).toUpperCase() + colorScheme.slice(1);

  return (
    <Card className="bg-background/90 backdrop-blur-sm p-3 shadow-lg pointer-events-auto">
      <div className="flex items-center gap-3">
        <div className="flex flex-col items-end text-xs font-mono text-foreground">
          <div className="h-[200px] flex flex-col justify-between">
            <span className="font-semibold">{maxDose.toFixed(1)}</span>
            <span className="text-muted-foreground">{((maxDose + minDose) / 2).toFixed(1)}</span>
            <span className="font-semibold">{minDose.toFixed(1)}</span>
          </div>
        </div>
        <canvas ref={canvasRef} className="border border-border rounded" />
        <div className="flex flex-col justify-between h-[200px] text-xs text-muted-foreground">
          <span className="font-semibold text-foreground">{schemeName}</span>
          <span className="writing-mode-vertical-rl transform rotate-180">mGy</span>
        </div>
      </div>
    </Card>
  );
}
