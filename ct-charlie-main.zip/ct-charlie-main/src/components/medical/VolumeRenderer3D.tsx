import { useRef, useMemo, useState, useEffect } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls, PerspectiveCamera } from '@react-three/drei';
import * as THREE from 'three';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { RotateCcw, Box, Info } from 'lucide-react';
import { NiftiData } from '@/services/niftiLoader';

interface VolumeRenderer3DProps {
  organMasks?: Map<string, { data: NiftiData; color: string }>;
  doseData?: NiftiData | null;
  showOrgans?: boolean;
  showDose?: boolean;
  doseThreshold?: number;
  initialDoseRange?: [number, number];
}

type ViewMode = 'full-body' | 'organs-only';

// Colormap functions
type ColormapType = 'rainbow' | 'hot' | 'jet' | 'viridis';

function applyColormap(value: number, min: number, max: number, colormap: ColormapType): [number, number, number] {
  // Normalize value to 0-1 range
  const t = Math.max(0, Math.min(1, (value - min) / (max - min)));
  
  if (colormap === 'rainbow') {
    // Rainbow/Turbo colormap: dark blue -> cyan -> green -> yellow -> orange -> red
    // This provides intuitive thermal-style visualization (cold = blue, hot = red)
    if (t < 0.15) {
      // Dark blue to blue
      const localT = t / 0.15;
      return [0, 0, 0.5 + localT * 0.5];
    } else if (t < 0.35) {
      // Blue to cyan
      const localT = (t - 0.15) / 0.2;
      return [0, localT, 1];
    } else if (t < 0.5) {
      // Cyan to green
      const localT = (t - 0.35) / 0.15;
      return [0, 1, 1 - localT];
    } else if (t < 0.65) {
      // Green to yellow
      const localT = (t - 0.5) / 0.15;
      return [localT, 1, 0];
    } else if (t < 0.85) {
      // Yellow to orange
      const localT = (t - 0.65) / 0.2;
      return [1, 1 - localT * 0.5, 0];
    } else {
      // Orange to red
      const localT = (t - 0.85) / 0.15;
      return [1, 0.5 - localT * 0.5, 0];
    }
  } else if (colormap === 'hot') {
    // Hot colormap: black -> red -> yellow -> white
    if (t < 0.33) {
      return [t * 3, 0, 0];
    } else if (t < 0.67) {
      return [1, (t - 0.33) * 3, 0];
    } else {
      return [1, 1, (t - 0.67) * 3];
    }
  } else if (colormap === 'jet') {
    // Jet colormap: blue -> cyan -> green -> yellow -> red
    const r = Math.max(0, Math.min(1, 1.5 - Math.abs(4 * t - 3)));
    const g = Math.max(0, Math.min(1, 1.5 - Math.abs(4 * t - 2)));
    const b = Math.max(0, Math.min(1, 1.5 - Math.abs(4 * t - 1)));
    return [r, g, b];
  } else {
    // Viridis colormap (approximate)
    const viridisColors = [
      [0.267, 0.005, 0.329],
      [0.283, 0.141, 0.458],
      [0.254, 0.265, 0.530],
      [0.207, 0.372, 0.553],
      [0.164, 0.471, 0.558],
      [0.128, 0.567, 0.551],
      [0.135, 0.659, 0.518],
      [0.267, 0.749, 0.441],
      [0.478, 0.821, 0.318],
      [0.741, 0.873, 0.150],
      [0.993, 0.906, 0.144],
    ];
    
    const idx = t * (viridisColors.length - 1);
    const i1 = Math.floor(idx);
    const i2 = Math.min(i1 + 1, viridisColors.length - 1);
    const frac = idx - i1;
    
    const c1 = viridisColors[i1];
    const c2 = viridisColors[i2];
    
    return [
      c1[0] + (c2[0] - c1[0]) * frac,
      c1[1] + (c2[1] - c1[1]) * frac,
      c1[2] + (c2[2] - c1[2]) * frac,
    ];
  }
}

interface DoseColoredOrganMeshProps {
  organData: NiftiData;
  doseData: NiftiData | null;
  opacity: number;
  doseThreshold: number;
  colormap: ColormapType;
  doseRange: [number, number];
  quality: 'standard' | 'high';
  doseScaleFactor?: number; // To convert mGy to Gy if needed
}

// Component to render organ colored by dose values
function DoseColoredOrganMesh({ 
  organData, 
  doseData, 
  opacity, 
  doseThreshold,
  colormap,
  doseRange,
  quality,
  doseScaleFactor = 1
}: DoseColoredOrganMeshProps) {
  const meshRef = useRef<THREE.Mesh>(null);

  // Generate geometry with vertex colors based on dose
  const { geometry, hasColors } = useMemo(() => {
    const [width, height, depth] = organData.dimensions;
    const positions: number[] = [];
    const colors: number[] = [];
    const indices: number[] = [];

    // Get actual voxel spacing from NIFTI data to maintain correct aspect ratio
    const voxelSpacing = organData.voxelSpacing || [1, 1, 1];
    console.log(`Building 3D mesh with voxel spacing: [${voxelSpacing.join(', ')}] mm`);

    const step = quality === 'high' ? 1 : 2;
    let vertexIndex = 0;
    let foundColors = false;
    let coloredVoxels = 0;
    let totalOrganVoxels = 0;
    
    for (let z = 0; z < depth; z += step) {
      for (let y = 0; y < height; y += step) {
        for (let x = 0; x < width; x += step) {
          const index = z * width * height + y * width + x;
          const organValue = organData.data[index];
          
          if (organValue > 0) {
            totalOrganVoxels++;
            // Get dose value at this position if available
            let doseValue = 0;
            if (doseData) {
              const [dw, dh, dd] = doseData.dimensions;
              // Map organ coordinates to dose coordinates (they should match, but handle potential mismatches)
              const dx = Math.min(Math.floor(x * dw / width), dw - 1);
              const dy = Math.min(Math.floor(y * dh / height), dh - 1);
              const dz = Math.min(Math.floor(z * dd / depth), dd - 1);
              const doseIndex = dz * dw * dh + dy * dw + dx;
              doseValue = doseData.data[doseIndex] * doseScaleFactor; // Apply scale factor for unit conversion
            }
            
            // Only render if dose is above threshold (or if no dose data)
            if (!doseData || doseValue >= doseThreshold) {
              // NIFTI to Three.js coordinate mapping (RAS+ orientation):
              // NIFTI: X (L→R), Y (P→A), Z (I→S)
              // Three.js: X (L→R), Y (D→U), Z (F→N)
              // Mapping: NIFTI_X → Three_X, NIFTI_Z → Three_Y, NIFTI_Y → Three_-Z (flip for correct orientation)
              const px = (x - width / 2) * voxelSpacing[0];
              const py = (z - depth / 2) * voxelSpacing[2];  // NIFTI Z (inf→sup) → Three.js Y (down→up)
              const pz = -(y - height / 2) * voxelSpacing[1]; // NIFTI Y (post→ant) → Three.js -Z (flipped)
              
              // Add cube vertices - map dimensions correctly
              const dx = voxelSpacing[0];
              const dy = voxelSpacing[2]; // NIFTI Z spacing for Three.js Y
              const dz = voxelSpacing[1]; // NIFTI Y spacing for Three.js Z
              
              const cubeVertices = [
                [px, py, pz],
                [px + dx, py, pz],
                [px + dx, py + dy, pz],
                [px, py + dy, pz],
                [px, py, pz + dz],
                [px + dx, py, pz + dz],
                [px + dx, py + dy, pz + dz],
                [px, py + dy, pz + dz],
              ];
              
              // Get color based on dose value
              let color: [number, number, number];
              if (doseData && doseValue >= 0) {
                color = applyColormap(doseValue, doseRange[0], doseRange[1], colormap);
                foundColors = true;
                coloredVoxels++;
              } else {
                // Default gray color if no dose data
                color = [0.5, 0.5, 0.5];
              }
              
              // Add vertices and colors for all 8 corners of the cube
              cubeVertices.forEach(v => {
                positions.push(...v);
                colors.push(...color);
              });
              
              // Add cube face indices
              const baseIndex = vertexIndex;
              const faceIndices = [
                [0, 1, 2], [0, 2, 3], // Front
                [4, 6, 5], [4, 7, 6], // Back
                [0, 4, 5], [0, 5, 1], // Bottom
                [2, 6, 7], [2, 7, 3], // Top
                [0, 3, 7], [0, 7, 4], // Left
                [1, 5, 6], [1, 6, 2], // Right
              ];
              
              faceIndices.forEach(face => {
                indices.push(baseIndex + face[0], baseIndex + face[1], baseIndex + face[2]);
              });
              
              vertexIndex += 8;
            }
          }
        }
      }
    }

    const geom = new THREE.BufferGeometry();
    geom.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
    geom.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
    geom.setIndex(indices);
    geom.computeVertexNormals();
    
    console.log(`3D Organ Rendering: ${totalOrganVoxels} organ voxels, ${coloredVoxels} colored voxels (with dose data)`);
    console.log(`Geometry bounds - vertices: ${positions.length / 3}, faces: ${indices.length / 3}`);
    
    return { geometry: geom, hasColors: foundColors };
  }, [organData, doseData, doseThreshold, colormap, doseRange, quality, doseScaleFactor]);

  useFrame(() => {
    if (meshRef.current) {
      meshRef.current.rotation.y += 0.001;
    }
  });

  return (
    <mesh ref={meshRef} geometry={geometry}>
      <meshPhongMaterial
        vertexColors={hasColors}
        opacity={opacity}
        transparent
        side={THREE.DoubleSide}
      />
    </mesh>
  );
}

// Component to render full body dose distribution as a point cloud
interface FullDoseVolumeMeshProps {
  doseData: NiftiData;
  doseThreshold: number;
  colormap: ColormapType;
  doseRange: [number, number];
  quality: 'standard' | 'high';
  opacity: number;
}

function FullDoseVolumeMesh({
  doseData,
  doseThreshold,
  colormap,
  doseRange,
  quality,
  opacity,
}: FullDoseVolumeMeshProps) {
  const pointsRef = useRef<THREE.Points>(null);

  // Generate point cloud from dose data
  const { geometry, pointCount } = useMemo(() => {
    const [width, height, depth] = doseData.dimensions;
    const positions: number[] = [];
    const colors: number[] = [];
    
    // Get voxel spacing
    const voxelSpacing = doseData.voxelSpacing || [1, 1, 1];
    const step = quality === 'high' ? 1 : 2;
    console.log(`Building full dose point cloud with spacing: [${voxelSpacing.join(', ')}] mm, quality: ${quality}, step: ${step}`);
    let points = 0;
    
    for (let z = 0; z < depth; z += step) {
      for (let y = 0; y < height; y += step) {
        for (let x = 0; x < width; x += step) {
          const index = z * width * height + y * width + x;
          const doseValue = doseData.data[index];
          
          // Only render voxels above threshold
          if (doseValue >= doseThreshold) {
            // NIFTI to Three.js coordinate mapping (same as organs)
            const px = (x - width / 2) * voxelSpacing[0];
            const py = (z - depth / 2) * voxelSpacing[2];
            const pz = -(y - height / 2) * voxelSpacing[1];
            
            positions.push(px, py, pz);
            
            // Apply colormap
            const [r, g, b] = applyColormap(doseValue, doseRange[0], doseRange[1], colormap);
            colors.push(r, g, b);
            
            points++;
          }
        }
      }
    }
    
    const geom = new THREE.BufferGeometry();
    geom.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
    geom.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
    
    console.log(`Full dose point cloud: ${points} points (threshold: ${doseThreshold} mGy)`);
    
    return { geometry: geom, pointCount: points };
  }, [doseData, doseThreshold, colormap, doseRange, quality]);

  useFrame(() => {
    if (pointsRef.current) {
      pointsRef.current.rotation.y += 0.001;
    }
  });

  // Constant point size for consistent visualization
  const pointSize = 2.5;

  return (
    <points ref={pointsRef} geometry={geometry}>
      <pointsMaterial
        size={pointSize}
        vertexColors
        transparent
        opacity={opacity}
        sizeAttenuation={true}
      />
    </points>
  );
}

// Color bar legend component
function ColorBarLegend({ 
  colormap, 
  doseRange 
}: { 
  colormap: ColormapType; 
  doseRange: [number, number];
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  
  useMemo(() => {
    if (!canvasRef.current) return;
    
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    const width = 30;
    const height = 200;
    canvas.width = width;
    canvas.height = height;
    
    // Draw gradient
    for (let i = 0; i < height; i++) {
      const value = doseRange[1] - (i / height) * (doseRange[1] - doseRange[0]);
      const [r, g, b] = applyColormap(value, doseRange[0], doseRange[1], colormap);
      ctx.fillStyle = `rgb(${Math.floor(r * 255)}, ${Math.floor(g * 255)}, ${Math.floor(b * 255)})`;
      ctx.fillRect(0, i, width, 1);
    }
  }, [colormap, doseRange]);
  
  return (
    <div className="flex items-center gap-2">
      <div className="flex flex-col justify-between h-[200px] text-xs">
<span>{doseRange[1].toFixed(1)} mGy</span>
          <span>{((doseRange[0] + doseRange[1]) / 2).toFixed(1)} mGy</span>
          <span>{doseRange[0].toFixed(1)} mGy</span>
      </div>
      <canvas ref={canvasRef} className="border rounded" />
    </div>
  );
}

export function VolumeRenderer3D({
  organMasks,
  doseData,
  showOrgans = true,
  showDose = true,
  doseThreshold = 0.5,
  initialDoseRange = [0, 5],
}: VolumeRenderer3DProps) {
  const [viewMode, setViewMode] = useState<ViewMode>('full-body');
  const [opacity, setOpacity] = useState(0.7);
  const [threshold, setThreshold] = useState(0.5); // Default threshold for full body mode
  const [quality, setQuality] = useState<'standard' | 'high'>('standard');
  const [colormap, setColormap] = useState<ColormapType>('rainbow');
  const [doseRange, setDoseRange] = useState<[number, number]>(initialDoseRange);
  const [doseScaleFactor, setDoseScaleFactor] = useState(1);
  const controlsRef = useRef<any>(null);
  
  // Track which organs are visible
  const [visibleOrgans, setVisibleOrgans] = useState<Map<string, boolean>>(new Map());

  // Initialize visible organs when organMasks changes
  useEffect(() => {
    if (organMasks && organMasks.size > 0) {
      const newVisibleOrgans = new Map<string, boolean>();
      organMasks.forEach((_, name) => {
        newVisibleOrgans.set(name, true); // All organs visible by default
      });
      setVisibleOrgans(newVisibleOrgans);
    }
  }, [organMasks]);

  // Update dose range when initialDoseRange changes
  useEffect(() => {
    setDoseRange(initialDoseRange);
    // Dose data is in Gy from NIFTI, no conversion needed
    setDoseScaleFactor(1);
    console.log(`3D Renderer: dose range [${initialDoseRange[0]}, ${initialDoseRange[1]}] Gy`);
  }, [initialDoseRange, doseData]);

  const handleReset = () => {
    if (controlsRef.current) {
      controlsRef.current.reset();
    }
  };
  
  const toggleOrganVisibility = (organName: string) => {
    setVisibleOrgans(prev => {
      const newMap = new Map(prev);
      newMap.set(organName, !prev.get(organName));
      return newMap;
    });
  };
  
  const showAllOrgans = () => {
    setVisibleOrgans(prev => {
      const newMap = new Map(prev);
      newMap.forEach((_, name) => newMap.set(name, true));
      return newMap;
    });
  };
  
  const hideAllOrgans = () => {
    setVisibleOrgans(prev => {
      const newMap = new Map(prev);
      newMap.forEach((_, name) => newMap.set(name, false));
      return newMap;
    });
  };

  const hasData = (organMasks && organMasks.size > 0) || doseData;
  const organNames = organMasks ? Array.from(organMasks.keys()).sort() : [];

  return (
    <Card className="p-4">
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Box className="h-4 w-4" />
            <span className="font-medium text-sm">
              3D Dose Visualization: {viewMode === 'full-body' ? 'Full Body' : 'Organs Only'}
            </span>
          </div>
          <div className="flex items-center gap-2">
            {doseData && (
              <div className="flex items-center gap-1 mr-2">
                <Button
                  variant={viewMode === 'full-body' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setViewMode('full-body')}
                  className="text-xs"
                >
                  Full Body
                </Button>
                <Button
                  variant={viewMode === 'organs-only' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setViewMode('organs-only')}
                  className="text-xs"
                >
                  Organs Only
                </Button>
              </div>
            )}
            <Button variant="outline" size="sm" onClick={handleReset}>
              <RotateCcw className="h-3 w-3 mr-1" />
              Reset View
            </Button>
          </div>
        </div>

        {/* Instructions */}
        {hasData && (
          <Alert>
            <Info className="h-4 w-4" />
            <AlertDescription>
              <div className="space-y-2 text-xs">
                <p><strong>View Mode:</strong></p>
                <ul className="list-disc list-inside space-y-1">
                  <li><strong>Full Body:</strong> View complete 3D dose distribution throughout the body</li>
                  <li><strong>Organs Only:</strong> View dose distribution within specific organs at risk</li>
                </ul>
                <p className="mt-2"><strong>Interaction:</strong></p>
                <ul className="list-disc list-inside space-y-1">
                  <li>Click + drag: Rotate view</li>
                  <li>Scroll: Zoom in/out</li>
                  <li>Dose threshold: Filter low-dose areas</li>
                  <li>Colormap: Change color scheme</li>
                </ul>
                <p className="mt-2"><strong>Color Legend:</strong> Colors represent radiation dose levels using the selected colormap.</p>
              </div>
            </AlertDescription>
          </Alert>
        )}

        {!hasData ? (
          <div className="h-[500px] flex items-center justify-center bg-muted rounded-lg">
            <p className="text-sm text-muted-foreground">
              Load overlays to enable 3D visualization
            </p>
          </div>
        ) : (
          <>
            <div className="flex gap-4">
              {/* 3D Canvas */}
              <div className="flex-1 h-[500px] bg-background rounded-lg border">
                <Canvas>
                  <PerspectiveCamera makeDefault position={[0, 200, 400]} />
                  <OrbitControls ref={controlsRef} enableDamping target={[0, 0, 0]} />
                  
                  <ambientLight intensity={0.6} />
                  <directionalLight position={[100, 200, 100]} intensity={1} />
                  <directionalLight position={[-100, -50, -100]} intensity={0.4} />
                  <hemisphereLight intensity={0.3} groundColor="#444444" />

                  {/* Conditional rendering based on view mode */}
                  {viewMode === 'full-body' && doseData && (
                    <FullDoseVolumeMesh
                      doseData={doseData}
                      doseThreshold={threshold}
                      colormap={colormap}
                      doseRange={doseRange}
                      quality={quality}
                      opacity={opacity}
                    />
                  )}

                  {viewMode === 'organs-only' && showOrgans && organMasks && Array.from(organMasks.entries())
                    .filter(([name]) => visibleOrgans.get(name) === true)
                    .map(([name, { data }]) => (
                      <DoseColoredOrganMesh
                        key={name}
                        organData={data}
                        doseData={showDose ? doseData : null}
                        opacity={opacity}
                        doseThreshold={threshold}
                        colormap={colormap}
                        doseRange={doseRange}
                        quality={quality}
                        doseScaleFactor={doseScaleFactor}
                      />
                    ))}

                  {/* Grid helper */}
                  <gridHelper args={[200, 20]} />
                </Canvas>
              </div>

              {/* Prominent Color bar legend */}
              {doseData && (
                <Card className="flex flex-col items-center justify-center p-4 border-2 border-primary/20">
                  <div className="text-center mb-3">
                    <h4 className="text-sm font-semibold">Dose Colormap</h4>
                    <p className="text-xs text-muted-foreground">{colormap.charAt(0).toUpperCase() + colormap.slice(1)}</p>
                  </div>
                  <ColorBarLegend colormap={colormap} doseRange={doseRange} />
                </Card>
              )}
            </div>
            
            {/* Organ visibility controls */}
            {viewMode === 'organs-only' && organNames.length > 0 && (
              <Card className="p-4">
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <h4 className="text-sm font-semibold">Visible Organs</h4>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm" onClick={showAllOrgans}>
                        Show All
                      </Button>
                      <Button variant="outline" size="sm" onClick={hideAllOrgans}>
                        Hide All
                      </Button>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-2 max-h-[200px] overflow-y-auto">
                    {organNames.map(name => (
                      <label key={name} className="flex items-center gap-2 text-xs cursor-pointer hover:bg-muted/50 p-2 rounded">
                        <input
                          type="checkbox"
                          checked={visibleOrgans.get(name) || false}
                          onChange={() => toggleOrganVisibility(name)}
                          className="h-4 w-4 rounded border-primary"
                        />
                        <span className="truncate">{name}</span>
                      </label>
                    ))}
                  </div>
                </div>
              </Card>
            )}

            {/* Controls */}
            <div className="space-y-3">
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span>{viewMode === 'full-body' ? 'Dose Cloud' : 'Organ'} Opacity</span>
                  <span className="font-medium">{Math.round(opacity * 100)}%</span>
                </div>
                <Slider
                  value={[opacity]}
                  onValueChange={(v) => setOpacity(v[0])}
                  min={0}
                  max={1}
                  step={0.1}
                />
              </div>

              {doseData && (
                <>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-xs">
                      <span>Dose Threshold (mGy)</span>
                      <span className="font-medium">{threshold.toFixed(2)}</span>
                    </div>
                    <Slider
                      value={[threshold]}
                      onValueChange={(v) => setThreshold(v[0])}
                      min={0}
                      max={doseRange[1]}
                      step={0.1}
                    />
                  </div>

                  <div className="space-y-2">
                    <div className="text-xs">Dose Range (mGy)</div>
                    <div className="flex gap-2">
                      <input
                        type="number"
                        value={doseRange[0]}
                        onChange={(e) => setDoseRange([parseFloat(e.target.value), doseRange[1]])}
                        className="w-20 px-2 py-1 text-xs border rounded"
                        step="0.1"
                      />
                      <span className="text-xs">to</span>
                      <input
                        type="number"
                        value={doseRange[1]}
                        onChange={(e) => setDoseRange([doseRange[0], parseFloat(e.target.value)])}
                        className="w-20 px-2 py-1 text-xs border rounded"
                        step="0.1"
                      />
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-xs">Colormap</span>
                    <div className="flex gap-2">
                      <Button
                        variant={colormap === 'rainbow' ? 'default' : 'outline'}
                        size="sm"
                        onClick={() => setColormap('rainbow')}
                      >
                      Heatmap
                      </Button>
                      <Button
                        variant={colormap === 'hot' ? 'default' : 'outline'}
                        size="sm"
                        onClick={() => setColormap('hot')}
                      >
                        Hot
                      </Button>
                      <Button
                        variant={colormap === 'jet' ? 'default' : 'outline'}
                        size="sm"
                        onClick={() => setColormap('jet')}
                      >
                        Jet
                      </Button>
                      <Button
                        variant={colormap === 'viridis' ? 'default' : 'outline'}
                        size="sm"
                        onClick={() => setColormap('viridis')}
                      >
                        Viridis
                      </Button>
                    </div>
                  </div>
                </>
              )}

              <div className="flex items-center justify-between">
                <span className="text-xs">Quality</span>
                <div className="flex gap-2">
                  <Button
                    variant={quality === 'standard' ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setQuality('standard')}
                  >
                    Standard
                  </Button>
                  <Button
                    variant={quality === 'high' ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setQuality('high')}
                  >
                    High
                  </Button>
                </div>
              </div>
            </div>
          </>
        )}
      </div>
    </Card>
  );
}