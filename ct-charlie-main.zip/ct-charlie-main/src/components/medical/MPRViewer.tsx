import { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { Card } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { AlertCircle, Layers2, Info } from 'lucide-react';
import { toast } from 'sonner';
import { VolumeData, ViewPlane, extractSlice, getSliceDimensions, getSliceCount } from '@/services/mprProcessor';
import { computeMIP } from '@/services/mipProcessor';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { useDebounce } from '@/hooks/useDebounce';

interface MPRViewerProps {
  volume: VolumeData | null;
  isLoading?: boolean;
  showMIP?: boolean;
}

interface ViewportState {
  plane: ViewPlane;
  currentSlice: number;
  windowWidth: number;
  windowCenter: number;
  zoom: number;
}

export function MPRViewer({ volume, isLoading = false, showMIP = false }: MPRViewerProps) {
  const [isMIP, setIsMIP] = useState(false); // Start in Slice mode for better performance
  const [slabThickness, setSlabThickness] = useState(10);
  const [windowWidth, setWindowWidth] = useState(400); // Default to soft tissue
  const [windowCenter, setWindowCenter] = useState(40);
  const canvasRefs = {
    axial: useRef<HTMLCanvasElement>(null),
    sagittal: useRef<HTMLCanvasElement>(null),
    coronal: useRef<HTMLCanvasElement>(null),
  };

  const [sliceIndices, setSliceIndices] = useState({
    axial: 0,
    sagittal: 0,
    coronal: 0,
  });

  // Debounce window settings to reduce re-renders during slider changes
  const debouncedWindowWidth = useDebounce(windowWidth, 50); // Faster response
  const debouncedWindowCenter = useDebounce(windowCenter, 50);

  // Slice cache to avoid recomputing
  const sliceCacheRef = useRef<Map<string, Float32Array>>(new Map());

  // Track which planes need re-rendering
  const needsRenderRef = useRef({ axial: true, sagittal: true, coronal: true });
  const renderRequestRef = useRef<number | null>(null);

  // Initialize slice indices when volume loads
  useEffect(() => {
    if (!volume) return;

    // Clear cache when volume changes
    sliceCacheRef.current.clear();

    const [width, height, depth] = volume.dimensions;
    setSliceIndices({
      axial: Math.floor(depth / 2),
      sagittal: Math.floor(width / 2),
      coronal: Math.floor(height / 2),
    });
  }, [volume]);

  // Optimized render function using requestAnimationFrame
  const renderPlane = useCallback((plane: ViewPlane) => {
    if (!volume) return;

    const canvas = canvasRefs[plane].current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d', { willReadFrequently: false });
    if (!ctx) return;

    const [width, height] = getSliceDimensions(volume, plane);
    
    // Only resize canvas if dimensions changed
    if (canvas.width !== width || canvas.height !== height) {
      canvas.width = width;
      canvas.height = height;
    }

    try {
      let slice: Float32Array;
      
      if (isMIP) {
        // MIP is expensive, don't cache
        slice = computeMIP(volume, plane, { 
          slabThickness: slabThickness === 0 ? getSliceCount(volume, plane) : slabThickness,
          centerSlice: sliceIndices[plane] 
        });
      } else {
        // Use cache for single slices
        const cacheKey = `${plane}-${sliceIndices[plane]}`;
        let cachedSlice = sliceCacheRef.current.get(cacheKey);
        
        if (!cachedSlice) {
          cachedSlice = extractSlice(volume, plane, sliceIndices[plane]);
          sliceCacheRef.current.set(cacheKey, cachedSlice);
          
          // Keep cache reasonable size (last 30 slices across all planes)
          if (sliceCacheRef.current.size > 30) {
            const firstKey = sliceCacheRef.current.keys().next().value;
            sliceCacheRef.current.delete(firstKey);
          }
        }
        
        slice = cachedSlice;
      }

      const imageData = ctx.createImageData(width, height);
      const data = imageData.data;
      
      // Convert to 8-bit with adjustable windowing (optimized loop)
      const minValue = debouncedWindowCenter - debouncedWindowWidth / 2;
      const maxValue = debouncedWindowCenter + debouncedWindowWidth / 2;
      const range = maxValue - minValue;

      for (let i = 0; i < slice.length; i++) {
        const value = slice[i];
        const normalized = Math.max(0, Math.min(1, (value - minValue) / range));
        const gray = (normalized * 255) | 0; // Bitwise OR for faster floor

        const pixelIndex = i << 2; // Faster multiplication by 4
        data[pixelIndex] = gray;
        data[pixelIndex + 1] = gray;
        data[pixelIndex + 2] = gray;
        data[pixelIndex + 3] = 255;
      }

      ctx.putImageData(imageData, 0, 0);
    } catch (err) {
      console.error(`Error rendering ${plane}:`, err);
    }
  }, [volume, sliceIndices, isMIP, slabThickness, debouncedWindowWidth, debouncedWindowCenter]);

  // Batch render using requestAnimationFrame for better performance
  const scheduleRender = useCallback(() => {
    if (renderRequestRef.current) return;

    renderRequestRef.current = requestAnimationFrame(() => {
      if (needsRenderRef.current.axial) renderPlane('axial');
      if (needsRenderRef.current.sagittal) renderPlane('sagittal');
      if (needsRenderRef.current.coronal) renderPlane('coronal');
      
      needsRenderRef.current = { axial: false, sagittal: false, coronal: false };
      renderRequestRef.current = null;
    });
  }, [renderPlane]);

  // Mark all planes for re-render when settings change
  useEffect(() => {
    if (!volume) return;
    
    needsRenderRef.current = { axial: true, sagittal: true, coronal: true };
    scheduleRender();
  }, [volume, sliceIndices, isMIP, slabThickness, debouncedWindowWidth, debouncedWindowCenter, scheduleRender]);

  // Mouse wheel handler for scrolling through slices - optimized
  const handleWheel = useCallback((plane: ViewPlane) => (e: WheelEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (!volume) return;

    // Allow scrolling even in MIP mode (will change center slice)
    const delta = e.deltaY > 0 ? 1 : -1;
    const maxSlice = getSliceCount(volume, plane) - 1;
    
    setSliceIndices(prev => {
      const newIndex = Math.max(0, Math.min(maxSlice, prev[plane] + delta));
      if (newIndex === prev[plane]) return prev; // No change, don't re-render
      
      // Mark only this plane for re-render
      needsRenderRef.current[plane] = true;
      scheduleRender();
      
      return {
        ...prev,
        [plane]: newIndex
      };
    });
  }, [volume, scheduleRender]);

  // Attach native wheel event listeners for better performance
  useEffect(() => {
    const axialCanvas = canvasRefs.axial.current;
    const sagittalCanvas = canvasRefs.sagittal.current;
    const coronalCanvas = canvasRefs.coronal.current;

    if (!axialCanvas || !sagittalCanvas || !coronalCanvas) return;

    const axialHandler = handleWheel('axial');
    const sagittalHandler = handleWheel('sagittal');
    const coronalHandler = handleWheel('coronal');

    axialCanvas.addEventListener('wheel', axialHandler, { passive: false });
    sagittalCanvas.addEventListener('wheel', sagittalHandler, { passive: false });
    coronalCanvas.addEventListener('wheel', coronalHandler, { passive: false });

    return () => {
      axialCanvas.removeEventListener('wheel', axialHandler);
      sagittalCanvas.removeEventListener('wheel', sagittalHandler);
      coronalCanvas.removeEventListener('wheel', coronalHandler);
    };
  }, [handleWheel]);

  if (isLoading) {
    return (
      <Card className="p-4">
        <Skeleton className="h-[600px] w-full" />
      </Card>
    );
  }

  if (!volume) {
    return (
      <Alert>
        <AlertCircle className="h-4 w-4" />
        <AlertDescription>
          No volume data available. Load DICOM images to enable MPR views.
        </AlertDescription>
      </Alert>
    );
  }

  return (
    <Card className="p-4">
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Layers2 className="h-4 w-4" />
            <span className="font-medium text-sm">Multi-Planar Reconstruction</span>
          </div>
        </div>

        {/* Instructions */}
        <Alert>
          <Info className="h-4 w-4" />
          <AlertDescription>
            <strong>Hover over any view and scroll</strong> with mouse wheel to navigate slices. Use window/level presets below for different tissue types.
          </AlertDescription>
        </Alert>

        {/* Controls */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs">Projection Mode</span>
            <div className="flex gap-2">
              <Button
                variant={!isMIP ? 'default' : 'outline'}
                size="sm"
                onClick={() => setIsMIP(false)}
              >
                Slice
              </Button>
              <Button
                variant={isMIP ? 'default' : 'outline'}
                size="sm"
                onClick={() => setIsMIP(true)}
              >
                MIP
              </Button>
            </div>
          </div>

          {isMIP && (
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span>MIP Mode</span>
                <div className="flex gap-2">
                  <Button
                    variant={slabThickness === 0 ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setSlabThickness(0)}
                  >
                    Full Volume
                  </Button>
                  <Button
                    variant={slabThickness > 0 ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setSlabThickness(10)}
                  >
                    Thick Slab
                  </Button>
                </div>
              </div>
              {slabThickness > 0 && (
                <>
                  <div className="flex items-center justify-between text-xs">
                    <span>Slab Thickness</span>
                    <span className="font-medium">{slabThickness} slices</span>
                  </div>
                  <Slider
                    value={[slabThickness]}
                    onValueChange={(v) => setSlabThickness(v[0])}
                    min={1}
                    max={50}
                    step={1}
                  />
                </>
              )}
            </div>
          )}

          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span>Window Width</span>
              <span className="font-medium">{windowWidth}</span>
            </div>
            <Slider
              value={[windowWidth]}
              onValueChange={(v) => setWindowWidth(v[0])}
              min={1}
              max={4000}
              step={10}
            />
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span>Window Center</span>
              <span className="font-medium">{windowCenter}</span>
            </div>
            <Slider
              value={[windowCenter]}
              onValueChange={(v) => setWindowCenter(v[0])}
              min={-1000}
              max={2000}
              step={10}
            />
          </div>

          <div className="flex gap-2 flex-wrap">
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                setWindowWidth(400);
                setWindowCenter(40);
              }}
            >
              Soft Tissue
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                setWindowWidth(1500);
                setWindowCenter(300);
              }}
            >
              Bone
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                setWindowWidth(1600);
                setWindowCenter(-600);
              }}
            >
              Lung
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                setWindowWidth(2000);
                setWindowCenter(0);
              }}
            >
              Full Range
            </Button>
          </div>
        </div>

        {/* Three-panel view */}
        <div className="grid grid-cols-3 gap-4">
          {/* Axial View */}
          <div className="space-y-2">
            <div className="text-xs font-medium text-center">
              Axial (Slice {sliceIndices.axial + 1}/{getSliceCount(volume, 'axial')})
            </div>
            <div className="border rounded-lg overflow-hidden bg-black">
              <canvas
                ref={canvasRefs.axial}
                className="w-full h-auto cursor-crosshair"
                style={{ touchAction: 'none' }}
              />
            </div>
          </div>

          {/* Sagittal View */}
          <div className="space-y-2">
            <div className="text-xs font-medium text-center">
              Sagittal (Slice {sliceIndices.sagittal + 1}/{getSliceCount(volume, 'sagittal')})
            </div>
            <div className="border rounded-lg overflow-hidden bg-black">
              <canvas
                ref={canvasRefs.sagittal}
                className="w-full h-auto cursor-crosshair"
                style={{ touchAction: 'none' }}
              />
            </div>
          </div>

          {/* Coronal View */}
          <div className="space-y-2">
            <div className="text-xs font-medium text-center">
              Coronal (Slice {sliceIndices.coronal + 1}/{getSliceCount(volume, 'coronal')})
            </div>
            <div className="border rounded-lg overflow-hidden bg-black">
              <canvas
                ref={canvasRefs.coronal}
                className="w-full h-auto cursor-crosshair"
                style={{ touchAction: 'none' }}
              />
            </div>
          </div>
        </div>
      </div>
    </Card>
  );
}
