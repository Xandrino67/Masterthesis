import { useState, useEffect, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Card } from '@/components/ui/card';
import { Play, Pause, SkipBack, SkipForward, RotateCcw } from 'lucide-react';

interface CineControlsProps {
  totalSlices: number;
  currentSlice: number;
  onSliceChange: (slice: number) => void;
  defaultFps?: number;
}

export function CineControls({
  totalSlices,
  currentSlice,
  onSliceChange,
  defaultFps = 10,
}: CineControlsProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [fps, setFps] = useState(defaultFps);
  const [loop, setLoop] = useState(true);

  // Cine playback effect
  useEffect(() => {
    if (!isPlaying) return;

    let currentSliceIndex = currentSlice;

    const interval = setInterval(() => {
      if (currentSliceIndex >= totalSlices - 1) {
        if (loop) {
          currentSliceIndex = 0;
        } else {
          setIsPlaying(false);
          return;
        }
      } else {
        currentSliceIndex++;
      }
      onSliceChange(currentSliceIndex);
    }, 1000 / fps);

    return () => clearInterval(interval);
  }, [isPlaying, fps, loop, totalSlices, currentSlice, onSliceChange]);

  const handlePlayPause = useCallback(() => {
    setIsPlaying((prev) => !prev);
  }, []);

  const handleStepBackward = useCallback(() => {
    setIsPlaying(false);
    onSliceChange(Math.max(0, currentSlice - 1));
  }, [currentSlice, onSliceChange]);

  const handleStepForward = useCallback(() => {
    setIsPlaying(false);
    onSliceChange(Math.min(totalSlices - 1, currentSlice + 1));
  }, [currentSlice, totalSlices, onSliceChange]);

  const handleReset = useCallback(() => {
    setIsPlaying(false);
    onSliceChange(0);
  }, [onSliceChange]);

  const handleFpsChange = useCallback((value: number[]) => {
    setFps(value[0]);
  }, []);

  return (
    <Card className="p-4">
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <span className="text-sm font-medium">Cine Mode</span>
          <span className="text-xs text-muted-foreground">
            {currentSlice + 1} / {totalSlices}
          </span>
        </div>

        {/* Playback Controls */}
        <div className="flex items-center justify-center gap-2">
          <Button
            variant="outline"
            size="icon"
            onClick={handleReset}
            title="Reset to first slice"
          >
            <RotateCcw className="h-4 w-4" />
          </Button>
          
          <Button
            variant="outline"
            size="icon"
            onClick={handleStepBackward}
            disabled={currentSlice === 0}
            title="Previous slice"
          >
            <SkipBack className="h-4 w-4" />
          </Button>

          <Button
            variant="default"
            size="icon"
            onClick={handlePlayPause}
            title={isPlaying ? 'Pause' : 'Play'}
          >
            {isPlaying ? (
              <Pause className="h-4 w-4" />
            ) : (
              <Play className="h-4 w-4" />
            )}
          </Button>

          <Button
            variant="outline"
            size="icon"
            onClick={handleStepForward}
            disabled={currentSlice === totalSlices - 1}
            title="Next slice"
          >
            <SkipForward className="h-4 w-4" />
          </Button>
        </div>

        {/* Speed Control */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span>Speed (FPS)</span>
            <span className="font-medium">{fps}</span>
          </div>
          <Slider
            value={[fps]}
            onValueChange={handleFpsChange}
            min={1}
            max={30}
            step={1}
            className="w-full"
          />
        </div>

        {/* Loop Toggle */}
        <div className="flex items-center justify-between">
          <span className="text-sm">Loop playback</span>
          <Button
            variant={loop ? 'default' : 'outline'}
            size="sm"
            onClick={() => setLoop(!loop)}
          >
            {loop ? 'On' : 'Off'}
          </Button>
        </div>
      </div>
    </Card>
  );
}
