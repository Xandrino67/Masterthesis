import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { DicomViewer } from './DicomViewer';
import { Maximize2, Minimize2, Link, Unlink } from 'lucide-react';

type FileType = 'dicom_dose' | 'dicom_other' | 'dicom_ct_fusie' | 'dicom_ct_wb';

interface SplitScreenViewerProps {
  studyId: string;
  availableFileTypes: FileType[];
}

// Helper to get readable labels
const getFileTypeLabel = (fileType: FileType): string => {
  switch(fileType) {
    case 'dicom_ct_fusie': return 'CT Fusie (1.25mm)';
    case 'dicom_ct_wb': return 'CT WB (3.0mm)';
    case 'dicom_dose': return 'Dose Distribution';
    case 'dicom_other': return 'CT Scan';
    default: return 'DICOM';
  }
};

export function SplitScreenViewer({
  studyId,
  availableFileTypes,
}: SplitScreenViewerProps) {
  // Intelligent default pairing: CT (anatomy) on left, Dose (distribution) on right if available
  const hasCT = availableFileTypes.find(t => t.startsWith('dicom_ct'));
  const hasDose = availableFileTypes.includes('dicom_dose');
  
  const defaultLeft = hasCT || availableFileTypes[0];
  const defaultRight = (hasCT && hasDose) 
    ? 'dicom_dose'  // CT left, dose right for comparison
    : availableFileTypes.find(t => t !== defaultLeft) || availableFileTypes[0];
  
  const [leftType, setLeftType] = useState<FileType>(defaultLeft);
  const [rightType, setRightType] = useState<FileType>(defaultRight);
  const [synchronized, setSynchronized] = useState(true);
  const [currentSlice, setCurrentSlice] = useState(0);
  const [layout, setLayout] = useState<'split' | 'left' | 'right'>('split');

  const handleSliceChange = (slice: number, side: 'left' | 'right') => {
    if (synchronized) {
      setCurrentSlice(slice);
    } else if (side === 'left') {
      setCurrentSlice(slice);
    }
    // If not synchronized and right side changes, ignore for left side
  };

  return (
    <Card className="p-4">
      <div className="space-y-4">
        {/* Controls */}
        <div className="flex items-center justify-between gap-4 flex-wrap">
          <div className="flex items-center gap-2">
            <span className="text-sm font-medium">Split Screen Comparison</span>
          </div>

          {/* Layout Controls */}
          <div className="flex items-center gap-2">
            <Button
              variant={layout === 'left' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setLayout('left')}
              title="Show left only"
            >
              <Minimize2 className="h-3 w-3 mr-1" />
              Left
            </Button>
            <Button
              variant={layout === 'split' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setLayout('split')}
              title="Show both"
            >
              <Maximize2 className="h-3 w-3 mr-1" />
              Split
            </Button>
            <Button
              variant={layout === 'right' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setLayout('right')}
              title="Show right only"
            >
              <Minimize2 className="h-3 w-3 mr-1" />
              Right
            </Button>
          </div>

          {/* Sync Control */}
          <Button
            variant={synchronized ? 'default' : 'outline'}
            size="sm"
            onClick={() => setSynchronized(!synchronized)}
            title={synchronized ? 'Unsync scrolling' : 'Sync scrolling'}
          >
            {synchronized ? (
              <>
                <Link className="h-3 w-3 mr-1" />
                Synced
              </>
            ) : (
              <>
                <Unlink className="h-3 w-3 mr-1" />
                Unsynced
              </>
            )}
          </Button>
        </div>

        {/* Series Selectors */}
        {layout !== 'right' && (
          <div className="flex items-center gap-2">
            <span className="text-xs font-medium">Links:</span>
            <div className="flex gap-1 flex-wrap">
              {availableFileTypes.map((type) => (
                <Button
                  key={type}
                  variant={leftType === type ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setLeftType(type)}
                >
                  {getFileTypeLabel(type)}
                </Button>
              ))}
            </div>
          </div>
        )}

        {layout !== 'left' && (
          <div className="flex items-center gap-2">
            <span className="text-xs font-medium">Rechts:</span>
            <div className="flex gap-1 flex-wrap">
              {availableFileTypes.map((type) => (
                <Button
                  key={type}
                  variant={rightType === type ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setRightType(type)}
                >
                  {getFileTypeLabel(type)}
                </Button>
              ))}
            </div>
          </div>
        )}

        {/* Viewers */}
        <div className={`grid gap-4 ${layout === 'split' ? 'grid-cols-2' : 'grid-cols-1'}`}>
          {layout !== 'right' && (
            <div className="border-r pr-4">
              <DicomViewer
                studyId={studyId}
                fileType={leftType}
                initialSlice={currentSlice}
                showControls={true}
                showOverlay={true}
              />
            </div>
          )}

          {layout !== 'left' && (
            <div>
              <DicomViewer
                studyId={studyId}
                fileType={rightType}
                initialSlice={synchronized ? currentSlice : 0}
                showControls={true}
                showOverlay={true}
              />
            </div>
          )}
        </div>

        {synchronized && (
          <div className="text-xs text-center text-muted-foreground">
            <p>Scroll synchronized: Slice {currentSlice + 1}</p>
          </div>
        )}
      </div>
    </Card>
  );
}
