import { Card } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Eye, EyeOff, Layers } from 'lucide-react';

export interface OrganConfig {
  name: string;
  color: string;
  visible: boolean;
  opacity: number;
}

export interface DoseConfig {
  visible: boolean;
  opacity: number;
  minDose: number;
  maxDose: number;
  colorScheme: 'hot' | 'jet' | 'viridis';
}

export interface CombinedViewConfig {
  enabled: boolean;
  showBoundaries: boolean;
  showDoseInside: boolean;
  highlightThreshold: number;
  doseOpacity: number;
}

interface OverlayControlsProps {
  organs: OrganConfig[];
  doseConfig: DoseConfig | null;
  onOrganToggle: (organName: string) => void;
  onOrganOpacityChange: (organName: string, opacity: number) => void;
  onDoseToggle: () => void;
  onDoseOpacityChange: (opacity: number) => void;
  onDoseRangeChange: (min: number, max: number) => void;
  onDoseColorSchemeChange: (scheme: 'hot' | 'jet' | 'viridis') => void;
  filterDoseByOrgans?: boolean;
  onFilterDoseByOrgansToggle?: (checked: boolean) => void;
}

export function OverlayControls({
  organs,
  doseConfig,
  onOrganToggle,
  onOrganOpacityChange,
  onDoseToggle,
  onDoseOpacityChange,
  onDoseRangeChange,
  onDoseColorSchemeChange,
  filterDoseByOrgans,
  onFilterDoseByOrgansToggle,
}: OverlayControlsProps) {
  return (
    <Card className="p-4">
      <h3 className="font-semibold mb-4">Overlay Controls</h3>

      {/* Dose Heat Map Controls */}
      {doseConfig && (
        <>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <Label htmlFor="dose-toggle" className="text-sm font-medium">
                Dose Heat Map
              </Label>
              <Switch
                id="dose-toggle"
                checked={doseConfig.visible}
                onCheckedChange={onDoseToggle}
              />
            </div>

            {doseConfig.visible && (
              <div className="space-y-4 pl-4">
                <div className="space-y-2">
                  <Label className="text-xs text-muted-foreground">Opacity</Label>
                  <Slider
                    value={[doseConfig.opacity]}
                    min={0}
                    max={1}
                    step={0.1}
                    onValueChange={(value) => onDoseOpacityChange(value[0])}
                  />
                </div>

                <div className="space-y-2">
                  <Label className="text-xs text-muted-foreground">Color Scheme</Label>
                  <Select
                    value={doseConfig.colorScheme}
                    onValueChange={(value: 'hot' | 'jet' | 'viridis') =>
                      onDoseColorSchemeChange(value)
                    }
                  >
                    <SelectTrigger className="h-8">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="hot">Hot (Black-Red-Yellow)</SelectItem>
                      <SelectItem value="jet">Jet (Blue-Green-Red)</SelectItem>
                      <SelectItem value="viridis">Viridis (Purple-Yellow)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label className="text-xs text-muted-foreground">
                    Min Dose: {doseConfig.minDose.toFixed(2)} mGy
                  </Label>
                  <Slider
                    value={[doseConfig.minDose]}
                    min={0}
                    max={doseConfig.maxDose}
                    step={0.01}
                    onValueChange={(value) =>
                      onDoseRangeChange(value[0], doseConfig.maxDose)
                    }
                  />
                </div>

                <div className="space-y-2">
                  <Label className="text-xs text-muted-foreground">
                    Max Dose: {doseConfig.maxDose.toFixed(2)} mGy
                  </Label>
                  <Slider
                    value={[doseConfig.maxDose]}
                    min={doseConfig.minDose}
                    max={10}
                    step={0.01}
                    onValueChange={(value) =>
                      onDoseRangeChange(doseConfig.minDose, value[0])
                    }
                  />
                </div>
              </div>
            )}
          </div>

          <Separator className="my-4" />
        </>
      )}

      {/* Filter Dose by Organs */}
      {onFilterDoseByOrgansToggle && (
        <div className="space-y-3 pb-3">
          <div className="flex items-center justify-between">
            <Label htmlFor="filter-dose">Filter Dose by Selected Organs</Label>
            <Switch
              id="filter-dose"
              checked={filterDoseByOrgans || false}
              onCheckedChange={onFilterDoseByOrgansToggle}
            />
          </div>
          <p className="text-xs text-muted-foreground">
            When enabled, dose is only shown inside selected organ masks
          </p>
          <Separator className="my-4" />
        </div>
      )}

      {/* Organ Overlays - Only show when filter is enabled */}
      {filterDoseByOrgans && organs.length > 0 && (
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <Label className="text-sm font-medium">Organ Masks</Label>
            <button
              onClick={() => {
                const allVisible = organs.every(o => o.visible);
                organs.forEach(o => onOrganToggle(o.name));
              }}
              className="text-xs text-primary hover:underline"
            >
              {organs.every(o => o.visible) ? 'Hide All' : 'Show All'}
            </button>
          </div>
          <ScrollArea className="h-[300px]">
            <div className="space-y-3">
              {organs.map((organ) => (
                <div key={organ.name} className="space-y-2 pb-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div
                        className="w-4 h-4 rounded border"
                        style={{ backgroundColor: organ.color }}
                      />
                      <Label htmlFor={`organ-${organ.name}`} className="text-xs">
                        {organ.name}
                      </Label>
                    </div>
                    <button
                      onClick={() => onOrganToggle(organ.name)}
                      className="p-1 hover:bg-accent rounded"
                    >
                      {organ.visible ? (
                        <Eye className="h-3 w-3" />
                      ) : (
                        <EyeOff className="h-3 w-3 opacity-50" />
                      )}
                    </button>
                  </div>
                  {organ.visible && (
                    <div className="pl-6">
                      <Slider
                        value={[organ.opacity]}
                        min={0}
                        max={1}
                        step={0.1}
                        onValueChange={(value) =>
                          onOrganOpacityChange(organ.name, value[0])
                        }
                      />
                    </div>
                  )}
                </div>
              ))}
            </div>
          </ScrollArea>
        </div>
      )}

      {!filterDoseByOrgans && organs.length > 0 && (
        <p className="text-xs text-muted-foreground mt-2">
          Enable "Filter Dose by Selected Organs" above to toggle individual organ overlays
        </p>
      )}
    </Card>
  );
}
