import { useEffect, useState } from "react";
import { Navigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Session } from "@supabase/supabase-js";
import { useSessionRefresh } from "@/hooks/useSessionRefresh";

interface ProtectedRouteProps {
  children: React.ReactNode;
}

const ProtectedRoute = ({ children }: ProtectedRouteProps) => {
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const [restoringSession, setRestoringSession] = useState(false);
  
  // Automatically refresh session to prevent expiration
  useSessionRefresh();

  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (_event, session) => {
        setSession(session);
        setLoading(false);
        setRestoringSession(false);
      }
    );

    // Attempt to restore session with retry logic
    const restoreSession = async (retryCount = 0): Promise<void> => {
      const MAX_RETRIES = 3;
      
      try {
        // First check if we have a session in localStorage
        const { data: { session: currentSession } } = await supabase.auth.getSession();
        
        if (currentSession) {
          // Session exists and is valid
          console.log('✅ Valid session found');
          setSession(currentSession);
          setLoading(false);
          return;
        }

        // No valid session, but check if we have session data in localStorage
        const storedSession = localStorage.getItem('sb-eqsqopszevmwasdahwyh-auth-token');
        
        if (storedSession && retryCount < MAX_RETRIES) {
          // Attempt to refresh the session
          console.log(`🔄 Attempting to refresh session (attempt ${retryCount + 1}/${MAX_RETRIES})...`);
          setRestoringSession(true);
          
          const { data: { session: refreshedSession }, error } = await supabase.auth.refreshSession();
          
          if (error) {
            console.error('Session refresh error:', error);
            
            // Retry after a short delay
            if (retryCount < MAX_RETRIES - 1) {
              await new Promise(resolve => setTimeout(resolve, 1000 * (retryCount + 1)));
              return restoreSession(retryCount + 1);
            }
          } else if (refreshedSession) {
            console.log('✅ Session restored successfully');
            setSession(refreshedSession);
            setLoading(false);
            setRestoringSession(false);
            return;
          }
        }
        
        // All attempts failed or no session to restore
        console.log('❌ No valid session found');
        setSession(null);
        setLoading(false);
        setRestoringSession(false);
      } catch (error) {
        console.error('Error restoring session:', error);
        
        if (retryCount < MAX_RETRIES - 1) {
          await new Promise(resolve => setTimeout(resolve, 1000 * (retryCount + 1)));
          return restoreSession(retryCount + 1);
        }
        
        setSession(null);
        setLoading(false);
        setRestoringSession(false);
      }
    };

    restoreSession();

    return () => subscription.unsubscribe();
  }, []);

  if (loading || restoringSession) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-background via-background to-primary/5">
        <div className="animate-pulse text-muted-foreground">
          {restoringSession ? 'Restoring session...' : 'Loading...'}
        </div>
      </div>
    );
  }

  if (!session) {
    return <Navigate to="/auth" replace />;
  }

  return <>{children}</>;
};

export default ProtectedRoute;
