import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { Plus, Heart, Pencil, Trash2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";

const OrgansTab = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    label: "",
    icrp_code: "",
    weight_factor: "",
  });

  const { data: organs, isLoading } = useQuery({
    queryKey: ["organs"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("organs")
        .select("*")
        .order("label");
      if (error) throw error;
      return data;
    },
  });

  const createMutation = useMutation({
    mutationFn: async (newOrgan: any) => {
      const organData = {
        ...newOrgan,
        weight_factor: newOrgan.weight_factor ? parseFloat(newOrgan.weight_factor) : null,
      };
      if (editingId) {
        const { error } = await supabase
          .from("organs")
          .update(organData)
          .eq("id", editingId);
        if (error) throw error;
      } else {
        const { error } = await supabase
          .from("organs")
          .insert([organData]);
        if (error) throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["organs"] });
      toast({ title: editingId ? "Organ updated successfully" : "Organ created successfully" });
      setIsDialogOpen(false);
      setEditingId(null);
      setFormData({ label: "", icrp_code: "", weight_factor: "" });
    },
    onError: (error: Error) => {
      toast({ variant: "destructive", title: "Error", description: error.message });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("organs").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["organs"] });
      toast({ title: "Organ deleted successfully" });
      setDeleteId(null);
    },
    onError: (error: Error) => {
      toast({ variant: "destructive", title: "Error", description: error.message });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createMutation.mutate(formData);
  };

  if (isLoading) {
    return <div className="text-center py-8 text-muted-foreground">Loading organs...</div>;
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-xl font-semibold">Organ Definitions</h2>
          <p className="text-sm text-muted-foreground">
            ICRP-103 organ weight factors for effective dose calculations
          </p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              Add Organ
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{editingId ? "Edit Organ" : "Add New Organ"}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="label">Organ Name *</Label>
                <Input
                  id="label"
                  value={formData.label}
                  onChange={(e) => setFormData({ ...formData, label: e.target.value })}
                  placeholder="Liver"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="icrp_code">ICRP Code</Label>
                <Input
                  id="icrp_code"
                  value={formData.icrp_code}
                  onChange={(e) => setFormData({ ...formData, icrp_code: e.target.value })}
                  placeholder="ICRP-103"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="weight_factor">Weight Factor</Label>
                <Input
                  id="weight_factor"
                  type="number"
                  step="0.01"
                  value={formData.weight_factor}
                  onChange={(e) => setFormData({ ...formData, weight_factor: e.target.value })}
                  placeholder="0.12"
                />
              </div>
              <Button type="submit" className="w-full" disabled={createMutation.isPending}>
                {createMutation.isPending ? (editingId ? "Updating..." : "Creating...") : (editingId ? "Update Organ" : "Create Organ")}
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {organs?.map((organ) => (
          <Card key={organ.id} className="p-4 hover:shadow-lg transition-shadow">
            <div className="flex items-start gap-3">
              <div className="p-2 bg-primary/10 rounded-lg">
                <Heart className="h-5 w-5 text-primary" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <h3 className="font-semibold truncate">{organ.label}</h3>
                  {organ.is_system_default && (
                    <Badge variant="secondary" className="text-xs">System</Badge>
                  )}
                </div>
                <div className="text-sm text-muted-foreground space-y-1">
                  {organ.icrp_code && <div>Code: {organ.icrp_code}</div>}
                  {organ.weight_factor && (
                    <div>Weight factor: {parseFloat(organ.weight_factor.toString()).toFixed(2)}</div>
                  )}
                </div>
              </div>
              {!organ.is_system_default && (
                <div className="flex gap-1">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8"
                    onClick={() => {
                      setEditingId(organ.id);
                      setFormData({
                        label: organ.label,
                        icrp_code: organ.icrp_code || "",
                        weight_factor: organ.weight_factor?.toString() || "",
                      });
                      setIsDialogOpen(true);
                    }}
                  >
                    <Pencil className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8 text-destructive"
                    onClick={() => setDeleteId(organ.id)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              )}
            </div>
          </Card>
        ))}
      </div>

      {organs?.length === 0 && (
        <Card className="p-12 text-center">
          <Heart className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
          <p className="text-muted-foreground">No organs yet. Add your first organ to get started.</p>
        </Card>
      )}

      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Organ</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={() => deleteId && deleteMutation.mutate(deleteId)} className="bg-destructive text-destructive-foreground">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default OrgansTab;
