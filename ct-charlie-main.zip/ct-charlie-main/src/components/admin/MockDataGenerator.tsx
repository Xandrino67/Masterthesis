import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { generateMockData } from "@/services/mockDataGenerator";
import { Beaker, Loader2 } from "lucide-react";

export function MockDataGenerator() {
  const { toast } = useToast();
  const [isGenerating, setIsGenerating] = useState(false);
  const [progress, setProgress] = useState(0);
  const [progressMessage, setProgressMessage] = useState("");
  
  const [params, setParams] = useState({
    numPatients: 20,
    minStudies: 2,
    maxStudies: 8,
    startDate: "2023-01-01",
    endDate: "2025-12-31",
  });

  const handleGenerate = async () => {
    setIsGenerating(true);
    setProgress(0);
    setProgressMessage("Starting mock data generation...");

    try {
      await generateMockData({
        numPatients: params.numPatients,
        studiesPerPatient: { min: params.minStudies, max: params.maxStudies },
        dateRange: {
          start: new Date(params.startDate),
          end: new Date(params.endDate),
        },
        onProgress: (pct, msg) => {
          setProgress(pct);
          setProgressMessage(msg);
        },
      });

      toast({
        title: "Mock Data Generated",
        description: `Successfully created ${params.numPatients} mock patients with longitudinal studies`,
      });
    } catch (error) {
      toast({
        title: "Generation Failed",
        description: error instanceof Error ? error.message : "Failed to generate mock data",
        variant: "destructive",
      });
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Beaker className="h-5 w-5" />
          Mock Data Generator
        </CardTitle>
        <CardDescription>
          Generate realistic synthetic patients with longitudinal studies and DVH analyses for testing
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="numPatients">Number of Patients</Label>
            <Input
              id="numPatients"
              type="number"
              min="1"
              max="100"
              value={params.numPatients}
              onChange={(e) => setParams({ ...params, numPatients: parseInt(e.target.value) })}
              disabled={isGenerating}
            />
          </div>

          <div className="space-y-2">
            <Label>Studies per Patient</Label>
            <div className="flex gap-2">
              <Input
                type="number"
                min="1"
                max="20"
                placeholder="Min"
                value={params.minStudies}
                onChange={(e) => setParams({ ...params, minStudies: parseInt(e.target.value) })}
                disabled={isGenerating}
              />
              <Input
                type="number"
                min="1"
                max="20"
                placeholder="Max"
                value={params.maxStudies}
                onChange={(e) => setParams({ ...params, maxStudies: parseInt(e.target.value) })}
                disabled={isGenerating}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="startDate">Start Date</Label>
            <Input
              id="startDate"
              type="date"
              value={params.startDate}
              onChange={(e) => setParams({ ...params, startDate: e.target.value })}
              disabled={isGenerating}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="endDate">End Date</Label>
            <Input
              id="endDate"
              type="date"
              value={params.endDate}
              onChange={(e) => setParams({ ...params, endDate: e.target.value })}
              disabled={isGenerating}
            />
          </div>
        </div>

        {isGenerating && (
          <div className="space-y-2">
            <Progress value={progress} />
            <p className="text-sm text-muted-foreground">{progressMessage}</p>
          </div>
        )}

        <Button
          onClick={handleGenerate}
          disabled={isGenerating}
          className="w-full"
          size="lg"
        >
          {isGenerating ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Generating...
            </>
          ) : (
            <>
              <Beaker className="mr-2 h-4 w-4" />
              Generate Mock Data
            </>
          )}
        </Button>

        <div className="bg-amber-50 dark:bg-amber-950 border border-amber-200 dark:border-amber-800 rounded-lg p-4">
          <h4 className="font-semibold text-amber-900 dark:text-amber-100 mb-2">
            ⚠️ Mock Data Characteristics
          </h4>
          <ul className="text-sm text-amber-800 dark:text-amber-200 space-y-1">
            <li>• All IDs prefixed with "MOCK-"</li>
            <li>• Realistic organ doses based on typical CT ranges</li>
            <li>• Longitudinal studies with temporal variation</li>
            <li>• Clearly marked throughout the application</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  );
}