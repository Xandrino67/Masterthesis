import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { StatsCard } from "@/components/ui/stats-card";
import { 
  Plus, 
  Search, 
  Filter,
  FileText,
  Calendar,
  User,
  Activity,
  TrendingUp,
  Beaker,
  Users
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import Navigation from "@/components/Navigation";

const Dashboard = () => {
  const navigate = useNavigate();
  const { toast } = useToast();

  const { data: studies, isLoading } = useQuery({
    queryKey: ["studies"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("studies")
        .select(`
          *,
          patient:patients(pseudonym_id),
          series(count),
          analysis_runs(results)
        `)
        .order("study_date", { ascending: false })
        .limit(10);
      if (error) throw error;
      return data;
    },
  });

  const { data: statsData } = useQuery({
    queryKey: ["dashboard-stats"],
    queryFn: async () => {
      const [
        studiesAll,
        studiesReal,
        studiesMock,
        patientsAll,
        patientsReal,
        patientsMock,
        analysesAll,
        analysesReal,
        analysesMock,
      ] = await Promise.all([
        supabase.from("studies").select("*", { count: "exact", head: true }),
        supabase.from("studies").select("*", { count: "exact", head: true }).eq("is_mock_data", false),
        supabase.from("studies").select("*", { count: "exact", head: true }).eq("is_mock_data", true),
        supabase.from("patients").select("*", { count: "exact", head: true }),
        supabase.from("patients").select("*", { count: "exact", head: true }).eq("is_mock_data", false),
        supabase.from("patients").select("*", { count: "exact", head: true }).eq("is_mock_data", true),
        supabase.from("analysis_runs").select("*", { count: "exact", head: true }),
        supabase.from("analysis_runs").select("*", { count: "exact", head: true }).eq("is_mock_data", false),
        supabase.from("analysis_runs").select("*", { count: "exact", head: true }).eq("is_mock_data", true),
      ]);

      return {
        totalStudies: studiesAll.count || 0,
        realStudies: studiesReal.count || 0,
        mockStudies: studiesMock.count || 0,
        totalPatients: patientsAll.count || 0,
        realPatients: patientsReal.count || 0,
        mockPatients: patientsMock.count || 0,
        totalAnalyses: analysesAll.count || 0,
        realAnalyses: analysesReal.count || 0,
        mockAnalyses: analysesMock.count || 0,
      };
    },
  });

  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <div className="container mx-auto px-6 py-8">
        {/* Stats Grid */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 mb-8">
          <StatsCard
            title="Total Patients"
            value={statsData?.totalPatients || 0}
            subtitle={`${statsData?.realPatients || 0} Real, ${statsData?.mockPatients || 0} Mock`}
            icon={Users}
          />
          
          <StatsCard
            title="Real Patients"
            value={statsData?.realPatients || 0}
            subtitle="Actual data"
            icon={User}
            variant="default"
          />
          
          <StatsCard
            title="Mock Patients"
            value={statsData?.mockPatients || 0}
            subtitle="Test data"
            icon={Beaker}
            variant="mock"
          />

          <StatsCard
            title="Total Studies"
            value={statsData?.totalStudies || 0}
            subtitle={`${statsData?.realStudies || 0} Real, ${statsData?.mockStudies || 0} Mock`}
            icon={FileText}
          />

          <StatsCard
            title="Total Analyses"
            value={statsData?.totalAnalyses || 0}
            subtitle={`${statsData?.realAnalyses || 0} Real, ${statsData?.mockAnalyses || 0} Mock`}
            icon={Activity}
          />

          <StatsCard
            title="Avg. Dose"
            value={
              studies && studies.length > 0
                ? `${(
                    studies.reduce((acc, study) => {
                      const completedRun = study.analysis_runs?.find((r: any) => 
                        r.results && typeof r.results === 'object' && 'effective_dose_mSv' in r.results
                      );
                      const results = completedRun?.results as any;
                      return acc + (results?.effective_dose_mSv ? parseFloat(results.effective_dose_mSv) : 0);
                    }, 0) / studies.length
                  ).toFixed(2)} mSv`
                : "0.00 mSv"
            }
            subtitle="Mean effective"
            icon={TrendingUp}
          />
        </div>

        {/* Studies Section */}
        <Card className="p-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-xl font-semibold mb-1">Recent Studies</h2>
              <p className="text-sm text-muted-foreground">
                Manage and analyze your dosimetry studies
              </p>
            </div>
            <div className="flex gap-2">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input 
                  placeholder="Search studies..." 
                  className="pl-9 w-64"
                />
              </div>
              <Button variant="outline" size="icon" onClick={() => toast({ title: "Filter feature coming soon" })}>
                <Filter className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {isLoading ? (
            <div className="text-center py-8 text-muted-foreground">Loading studies...</div>
          ) : studies && studies.length > 0 ? (
            <div className="space-y-3">
              {studies.map((study) => {
                const completedRun = study.analysis_runs?.find((r: any) => 
                  r.results && typeof r.results === 'object' && 'effective_dose_mSv' in r.results
                );
                const results = completedRun?.results as any;
                const effectiveDose = results?.effective_dose_mSv 
                  ? `${parseFloat(results.effective_dose_mSv).toFixed(2)} mSv`
                  : "—";

                return (
                  <div 
                    key={study.id}
                    className="p-4 border rounded-lg hover:bg-accent/5 transition-colors cursor-pointer"
                    onClick={() => navigate(`/study/${study.id}`)}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <h3 className="font-semibold">{study.study_id}</h3>
                          {(study as any).is_mock_data && (
                            <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">
                              🧪 MOCK
                            </Badge>
                          )}
                          <div className="flex gap-1">
                            {study.modality_set?.map((mod: string) => (
                              <Badge key={mod} variant="outline" className="text-xs">
                                {mod}
                              </Badge>
                            ))}
                          </div>
                        </div>
                        <div className="flex items-center gap-4 text-sm text-muted-foreground">
                          <div className="flex items-center gap-1">
                            <User className="h-3 w-3" />
                            {study.patient?.pseudonym_id || "Unknown"}
                          </div>
                          <div className="flex items-center gap-1">
                            <Calendar className="h-3 w-3" />
                            {new Date(study.study_date).toLocaleDateString()}
                          </div>
                          <div className="flex items-center gap-1">
                            <Activity className="h-3 w-3" />
                            {study.series?.[0]?.count || 0} series
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-sm text-muted-foreground mb-1">Effective Dose</p>
                        <p className="text-lg font-semibold text-primary">{effectiveDose}</p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="text-center py-12">
              <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground mb-4">No studies yet. Create your first study to get started.</p>
              <Button onClick={() => navigate("/upload")}>
                <Plus className="h-4 w-4 mr-2" />
                Create Study
              </Button>
            </div>
          )}

          <div className="mt-6 text-center">
            <Button variant="outline" onClick={() => navigate("/studies")}>View All Studies</Button>
          </div>
        </Card>
      </div>
    </div>
  );
};

export default Dashboard;
