import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Activity, Database, FileCheck, Layers, BarChart3, Shield, LogIn } from "lucide-react";
import { useNavigate } from "react-router-dom";
import charlieLogoWide from "@/assets/charlie-logo-wide.png";

const Index = () => {
  const navigate = useNavigate();

  const features = [
    {
      icon: Database,
      title: "Master Data Management",
      description: "Comprehensive patient, device, and protocol tracking with full audit trails"
    },
    {
      icon: FileCheck,
      title: "Data Validation",
      description: "Automatic alignment checks, unit conversion, and quality assurance for all inputs"
    },
    {
      icon: Layers,
      title: "Multi-Modality Support",
      description: "CT and CBCT dose analysis with cumulative calculations and organ segmentation"
    },
    {
      icon: Activity,
      title: "DVH Analysis",
      description: "Comprehensive dose-volume histograms with configurable metrics and statistical analysis"
    },
    {
      icon: BarChart3,
      title: "Effective Dose",
      description: "ICRP-103 compliant organ weighting and effective dose calculations with reports"
    },
    {
      icon: Shield,
      title: "Secure & Compliant",
      description: "Role-based access control, data provenance, and full reproducibility"
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="gradient-hero py-20 px-4 border-b">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center space-y-6">
            <div className="flex justify-center mb-6">
              <img src={charlieLogoWide} alt="Charlie - AI Powered Dose Analyzer" className="h-20 w-auto" />
            </div>
            
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-primary/10 rounded-full text-sm font-medium text-primary border border-primary/20">
              <Activity className="h-4 w-4" />
              AI Powered Medical Dosimetry
            </div>
            
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              AI-powered dose analyzer for CT and CBCT simulation analysis. 
              Intelligent organ dose calculations with comprehensive reports and full data provenance.
            </p>

            <div className="flex flex-wrap gap-4 justify-center pt-4">
              <Button 
                size="lg" 
                className="gradient-primary shadow-glow text-lg px-8 h-12"
                onClick={() => navigate('/auth')}
              >
                <LogIn className="mr-2 h-5 w-5" />
                Login / Sign Up
              </Button>
              <Button 
                size="lg" 
                variant="outline" 
                className="text-lg px-8 h-12"
                onClick={() => navigate('/dashboard')}
              >
                View Demo
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-20 px-4">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Comprehensive Dose Analysis</h2>
            <p className="text-muted-foreground text-lg">
              Everything you need for rigorous medical physics research
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, index) => (
              <Card key={index} className="p-6 hover:shadow-lg transition-shadow">
                <div className="flex items-start gap-4">
                  <div className="p-3 bg-primary/10 rounded-lg">
                    <feature.icon className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-semibold mb-2">{feature.title}</h3>
                    <p className="text-sm text-muted-foreground">{feature.description}</p>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Workflow Section */}
      <section className="py-20 px-4 bg-muted/30">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Streamlined Research Workflow</h2>
            <p className="text-muted-foreground text-lg">
              From data ingestion to publication-ready reports
            </p>
          </div>

          <div className="grid md:grid-cols-4 gap-6">
            {[
              { step: "01", title: "Upload Data", desc: "IMPACT-MC output + organ masks" },
              { step: "02", title: "Validate", desc: "Automatic QA and alignment checks" },
              { step: "03", title: "Analyze", desc: "DVH, statistics, cumulative doses" },
              { step: "04", title: "Report", desc: "Generate comprehensive PDF reports" }
            ].map((item) => (
              <div key={item.step} className="text-center">
                <div className="text-4xl font-bold text-primary/20 mb-3">{item.step}</div>
                <h3 className="font-semibold mb-2">{item.title}</h3>
                <p className="text-sm text-muted-foreground">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto max-w-4xl">
          <Card className="p-12 text-center gradient-primary text-white shadow-glow">
            <h2 className="text-3xl font-bold mb-4">Ready to start analyzing?</h2>
            <p className="text-lg mb-8 opacity-90">
              Join researchers using Charlie for AI-powered dosimetry analysis
            </p>
            <Button 
              size="lg" 
              variant="secondary"
              className="text-lg px-8 h-12"
              onClick={() => navigate('/dashboard')}
            >
              Start Your First Study
            </Button>
          </Card>
        </div>
      </section>
    </div>
  );
};

export default Index;
