import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  Folder as FolderIcon,
  CheckCircle2,
  AlertCircle,
  File,
  XCircle,
  FileArchive,
  Atom
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { useFolderUpload } from "@/hooks/useFolderUpload";
import Navigation from "@/components/Navigation";
import { Progress } from "@/components/ui/progress";
import { UploadProgressDialog } from "@/components/study/UploadProgressDialog";
import { NuclearMedicineInput } from "@/components/upload/NuclearMedicineInput";
import type { RadioTracer, NuclearMedicineOrganDose } from "@/services/nuclearMedicineDoseCoefficients";
import { mapIcrpToTotalSeg } from "@/services/organMergeConfig";

const Upload = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const folderUpload = useFolderUpload();
  const [selectedFolder, setSelectedFolder] = useState<string | null>(null);
  const [selectedZip, setSelectedZip] = useState<File | null>(null);
  const [uploadType, setUploadType] = useState<'folder' | 'zip'>('folder');
  const [fileCount, setFileCount] = useState(0);
  
  interface FileNode {
    path: string;
    name: string;
    size: number;
    file: File;
    relativePath: string;
    status: 'pending' | 'uploading' | 'success' | 'error' | 'skipped';
    skipReason?: string;
    fileType?: string;
    organName?: string | null;
  }
  
  const [pendingFiles, setPendingFiles] = useState<FileNode[] | null>(null);
  const [fileStats, setFileStats] = useState<{
    total: number;
    essential: number;
    ctOnly: number;
    totalSize: string;
  } | null>(null);
  const [uploadMode, setUploadMode] = useState<'essential' | 'all' | 'ct-only'>('all');
  const [showUploadDialog, setShowUploadDialog] = useState(false);
  const [formData, setFormData] = useState({
    study_id: `ST-${Date.now()}`,
    patient_id: "",
    study_date: new Date().toISOString().split('T')[0],
    modality: "CT" as "CT" | "CBCT" | "PET" | "SPECT",
    protocol_id: "",
    device_id: "",
  });
  const [uploadedStudyId, setUploadedStudyId] = useState<string | null>(null);
  const [nuclearMedicineResults, setNuclearMedicineResults] = useState<{
    tracer: RadioTracer;
    activityMBq: number;
    organDoses: NuclearMedicineOrganDose[];
    effectiveDose_mSv: number;
  } | null>(null);

  const isNuclearMedicine = formData.modality === 'PET' || formData.modality === 'SPECT';

  const { data: patients } = useQuery({
    queryKey: ["patients"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("patients")
        .select("*")
        .order("pseudonym_id");
      if (error) throw error;
      return data;
    },
  });

  const { data: protocols } = useQuery({
    queryKey: ["protocols"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("protocols")
        .select("*")
        .order("name");
      if (error) throw error;
      return data;
    },
  });

  const { data: devices } = useQuery({
    queryKey: ["devices"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("devices")
        .select("*")
        .order("device_id");
      if (error) throw error;
      return data;
    },
  });

  // Verify extraction helper function
  const verifyExtraction = async (studyId: string) => {
    const { data, error, count } = await supabase
      .from('extracted_files')
      .select('id', { count: 'exact' })
      .eq('study_id', studyId);
    
    return { 
      success: !error && (count || 0) > 0,
      fileCount: count || 0 
    };
  };

  // Nuclear medicine: combined calculate + create study
  const createNuclearMedicineStudyMutation = useMutation({
    mutationFn: async ({ studyData, nmResults }: {
      studyData: typeof formData;
      nmResults: NonNullable<typeof nuclearMedicineResults>;
    }) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("You must be logged in");

      const { modality, ...studyDataWithoutModality } = studyData;

      const { data, error } = await supabase
        .from("studies")
        .insert([{
          ...studyDataWithoutModality,
          modality_set: [modality],
          upload_mode: 'nuclear_medicine',
          created_by: user.id,
        }])
        .select()
        .maybeSingle();

      if (error) throw error;
      if (!data) throw new Error("Failed to create study");

      // Store dose results in analysis_runs
      const { error: analysisError } = await supabase
        .from("analysis_runs")
        .insert({
          study_id: data.id,
          run_id: `NM-${Date.now()}`,
          status: 'completed',
          started_at: new Date().toISOString(),
          finished_at: new Date().toISOString(),
          created_by: user.id,
          params: {
            method: 'nuclear_medicine_coefficients',
            tracer_id: nmResults.tracer.id,
            tracer_name: nmResults.tracer.name,
            radionuclide: nmResults.tracer.radionuclide,
            activity_mbq: nmResults.activityMBq,
            source: nmResults.tracer.source,
          },
          results: {
            effective_dose_mSv: nmResults.effectiveDose_mSv,
            organ_doses: Object.fromEntries(
              nmResults.organDoses.map(od => {
                const mappedName = mapIcrpToTotalSeg(od.organ_name);
                return [mappedName, {
                  organ_name: mappedName,
                  icrp_name: od.organ_name,
                  d_mean: od.dose_mGy,
                  coefficient: od.coefficient_mGy_per_MBq,
                  unit: 'mGy',
                  status: 'success',
                }];
              })
            ),
          },
        });

      if (analysisError) {
        console.error("Failed to store analysis results:", analysisError);
      }

      // Log audit action
      await supabase.from("audit_logs").insert({
        action: "study_created",
        resource_type: "study",
        resource_id: data.study_id,
        user_id: user.id,
        details: {
          patient_id: studyData.patient_id,
          modality: studyData.modality,
          method: 'nuclear_medicine_coefficients',
          tracer: nmResults.tracer.name,
          activity_mbq: nmResults.activityMBq,
        },
      });

      return data;
    },
    onSuccess: (data) => {
      toast({
        title: "Study created",
        description: `${formData.modality} study ${data.study_id} created with dose estimates`,
      });
      navigate(`/study/${data.id}`);
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "Error creating study",
        description: error.message,
      });
    },
  });

  const createStudyMutation = useMutation({
    mutationFn: async (studyData: typeof formData) => {
      // Final verification: check that extracted files exist
      const verification = await verifyExtraction(studyData.study_id);
      if (!verification.success) {
        throw new Error("No files found for this study. Please upload files first.");
      }

      // Study already exists, just fetch it and update metadata if needed
      const { modality, ...studyDataWithoutModality } = studyData;
      const { data, error } = await supabase
        .from("studies")
        .update({
          ...studyDataWithoutModality,
          modality_set: [modality],
        })
        .eq('study_id', studyData.study_id)
        .select()
        .maybeSingle();
      
      if (error) throw error;
      if (!data) {
        throw new Error(`Study ${studyData.study_id} not found. Files may not have been uploaded correctly.`);
      }
      
      // Log audit action
      await supabase.from("audit_logs").insert({
        action: "study_finalized",
        resource_type: "study",
        resource_id: data.study_id,
        details: {
          patient_id: studyData.patient_id,
          modality: studyData.modality,
          file_count: verification.fileCount,
        },
      });
      
      return data;
    },
    onSuccess: (data) => {
      toast({
        title: "Study created",
        description: `Study ${data.study_id} created with ${fileCount} files`,
      });
      navigate(`/study/${data.id}`);
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "Error creating study",
        description: error.message,
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.patient_id) {
      toast({
        variant: "destructive",
        title: "Validation error",
        description: "Please select a patient",
      });
      return;
    }

    if (isNuclearMedicine) {
      // NM studies are created via the NuclearMedicineInput button directly
      return;
    }

    if (!uploadedStudyId || fileCount === 0) {
      toast({
        variant: "destructive",
        title: "No files uploaded",
        description: "Please upload files before creating the study",
      });
      return;
    }

    createStudyMutation.mutate(formData);
  };

  const handleFolderSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    // Validate patient selection
    if (!formData.patient_id) {
      toast({
        variant: "destructive",
        title: "Validation error",
        description: "Please select a patient before selecting files",
      });
      return;
    }

    // Lock the study_id after first selection
    if (!uploadedStudyId) {
      setUploadedStudyId(formData.study_id);
    }

    // Get folder name from first file's path
    const firstFile = files[0] as any;
    const webkitPath = firstFile.webkitRelativePath || firstFile.name;
    const folderName = webkitPath.split('/')[0];
    setSelectedFolder(folderName);

    // Process ALL files (don't skip anything yet)
    const allFileNodes = folderUpload.processFolderStructure(files, false);
    
    // Validate folder structure
    const validation = folderUpload.validateFolderStructure(allFileNodes);
    
    if (!validation.isValid) {
      toast({
        variant: "destructive",
        title: "Invalid folder structure",
        description: validation.errors.join('. '),
        duration: 8000,
      });
      return;
    }
    
    if (validation.warnings.length > 0) {
      toast({
        title: "Folder structure warnings",
        description: validation.warnings.join('. '),
        duration: 8000,
      });
    }

    if (allFileNodes.length === 0) {
      toast({
        variant: "destructive",
        title: "No valid files found",
        description: "The selected folder doesn't contain any DICOM or NIfTI files",
      });
      return;
    }

    // Calculate statistics
    const essentialFiles = folderUpload.filterEssentialFiles(allFileNodes);
    const ctOnlyFiles = allFileNodes.filter(f => 
      f.fileType === 'dicom_ct_fusie' || f.fileType === 'dicom_ct_wb'
    );
    const totalSize = allFileNodes.reduce((sum, f) => sum + f.size, 0);
    const formatSize = (bytes: number) => {
      if (bytes < 1024) return bytes + ' B';
      if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
      if (bytes < 1024 * 1024 * 1024) return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
      return (bytes / (1024 * 1024 * 1024)).toFixed(2) + ' GB';
    };

    // Store files and stats for later upload
    setPendingFiles(allFileNodes);
    setFileStats({
      total: allFileNodes.length,
      essential: essentialFiles.length,
      ctOnly: ctOnlyFiles.length,
      totalSize: formatSize(totalSize)
    });

    toast({
      title: "Folder processed",
      description: `Found ${allFileNodes.length} files (${essentialFiles.length} essential). Choose an upload option below.`,
      duration: 6000,
    });
  };

  const handleUpload = async (mode: 'essential' | 'all' | 'ct-only') => {
    if (!pendingFiles) return;

    setUploadMode(mode);
    setShowUploadDialog(true);
    let filesToUpload = pendingFiles;

    if (mode === 'essential') {
      filesToUpload = folderUpload.filterEssentialFiles(pendingFiles);
    } else if (mode === 'ct-only') {
      filesToUpload = pendingFiles.filter(f => 
        f.fileType === 'dicom_ct_fusie' || f.fileType === 'dicom_ct_wb'
      );
    }

    // Create study record BEFORE uploading files
    try {
      const { modality, ...studyDataWithoutModality } = formData;
      const { error: studyError } = await supabase
        .from("studies")
        .insert([{
          ...studyDataWithoutModality,
          modality_set: [modality],
          upload_mode: mode, // Save the upload mode for re-upload purposes
        }]);
      
      if (studyError) throw studyError;
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error creating study",
        description: error.message,
      });
      return;
    }

    toast({
      title: "Uploading files",
      description: `Starting upload of ${filesToUpload.length} files (${mode} mode)`,
      duration: 5000,
    });

    // Upload files in batches
    const result = await folderUpload.uploadFilesInBatches(filesToUpload, formData.study_id);

    if (result.success) {
      setFileCount(result.uploadedCount);
      toast({
        title: "Upload complete",
        description: `Successfully uploaded ${result.uploadedCount} files`,
      });
    } else {
      setFileCount(result.uploadedCount);
      toast({
        variant: result.uploadedCount > 0 ? "default" : "destructive",
        title: result.uploadedCount > 0 ? "Upload partially completed" : "Upload failed",
        description: `${result.uploadedCount} successful, ${result.failedCount} failed`,
      });
    }
  };

  const uploadProgress = folderUpload.progress.totalFiles > 0 
    ? Math.round((folderUpload.progress.uploadedFiles / folderUpload.progress.totalFiles) * 100)
    : 0;

  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <div className="container mx-auto px-6 py-8 max-w-5xl">
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Main Upload Area */}
          <div className="lg:col-span-2 space-y-6">
            {/* Study Metadata */}
            <Card className="p-6">
              <h2 className="text-lg font-semibold mb-4">Study Information</h2>
              <form onSubmit={handleSubmit}>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                   <Label htmlFor="study_id">Study ID *</Label>
                    <Input
                      id="study_id"
                      value={formData.study_id}
                      onChange={(e) => {
                        if (uploadedStudyId && uploadedStudyId !== e.target.value) {
                          toast({
                            variant: "destructive",
                            title: "Warning",
                            description: `Files were uploaded for study ${uploadedStudyId}. Changing the ID requires re-uploading files.`,
                          });
                        }
                        setFormData({ ...formData, study_id: e.target.value })
                      }}
                      disabled={!!uploadedStudyId}
                      required
                      className={uploadedStudyId ? "bg-muted cursor-not-allowed" : ""}
                    />
                    {uploadedStudyId && (
                      <p className="text-xs text-muted-foreground mt-1">
                        Locked after file upload
                      </p>
                    )}
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="study_date">Study Date *</Label>
                    <Input
                      id="study_date"
                      type="date"
                      value={formData.study_date}
                      onChange={(e) => setFormData({ ...formData, study_date: e.target.value })}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="patient">Patient *</Label>
                    <Select
                      value={formData.patient_id}
                      onValueChange={(value) => setFormData({ ...formData, patient_id: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select patient" />
                      </SelectTrigger>
                      <SelectContent>
                        {patients?.map((patient) => (
                          <SelectItem key={patient.id} value={patient.id}>
                            {patient.pseudonym_id}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="modality">Modality *</Label>
                    <Select
                      value={formData.modality}
                      onValueChange={(value: "CT" | "CBCT" | "PET" | "SPECT") => {
                        setFormData({ ...formData, modality: value, protocol_id: "", device_id: "" });
                        setNuclearMedicineResults(null);
                      }}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="CT">CT</SelectItem>
                        <SelectItem value="CBCT">CBCT</SelectItem>
                        <SelectItem value="PET">PET</SelectItem>
                        <SelectItem value="SPECT">SPECT</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="protocol">Protocol</Label>
                    <Select
                      value={formData.protocol_id}
                      onValueChange={(value) => setFormData({ ...formData, protocol_id: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select protocol" />
                      </SelectTrigger>
                      <SelectContent>
                        {protocols?.filter(p => p.modality === formData.modality).map((protocol) => (
                          <SelectItem key={protocol.id} value={protocol.id}>
                            {protocol.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="device">Device</Label>
                    <Select
                      value={formData.device_id}
                      onValueChange={(value) => setFormData({ ...formData, device_id: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select device" />
                      </SelectTrigger>
                      <SelectContent>
                        {devices?.filter(d => d.modality === formData.modality).map((device) => (
                          <SelectItem key={device.id} value={device.id}>
                            {device.device_id} — {device.vendor} {device.model}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="mt-6">
                  {!isNuclearMedicine && fileCount > 0 && (
                    <div className="mb-3 p-3 bg-green-500/10 border border-green-500/20 rounded-lg">
                      <div className="flex items-center gap-2 text-green-600 dark:text-green-400">
                        <CheckCircle2 className="h-4 w-4" />
                        <p className="text-sm font-medium">
                          ✓ {fileCount.toLocaleString()} files uploaded and ready
                        </p>
                      </div>
                    </div>
                  )}
                  {!isNuclearMedicine && (
                    <Button
                      type="submit"
                      className="w-full"
                      disabled={createStudyMutation.isPending || !uploadedStudyId || fileCount === 0 || folderUpload.uploading}
                    >
                      {createStudyMutation.isPending 
                        ? "Creating Study..." 
                        : folderUpload.uploading
                        ? "Uploading Files..."
                        : fileCount > 0
                        ? "Create Study"
                        : "Select Folder First"}
                    </Button>
                  )}
                  {!isNuclearMedicine && !uploadedStudyId && (
                    <p className="text-xs text-muted-foreground text-center mt-2">
                      Select a folder to enable study creation
                    </p>
                  )}
                  {isNuclearMedicine && (
                    <p className="text-xs text-muted-foreground text-center mt-2">
                      Use the "Calculate &amp; Create Study" button below to create the study
                    </p>
                  )}
                </div>
              </form>
            </Card>

            {/* Conditional: Folder Upload (CT/CBCT) or Nuclear Medicine Input (PET/SPECT) */}
            {isNuclearMedicine ? (
              <NuclearMedicineInput
                modality={formData.modality as "PET" | "SPECT"}
                onCalculateAndCreate={(results) => {
                  setNuclearMedicineResults(results);
                  if (!formData.patient_id) {
                    toast({
                      variant: "destructive",
                      title: "Validation error",
                      description: "Please select a patient first",
                    });
                    return;
                  }
                  createNuclearMedicineStudyMutation.mutate({
                    studyData: formData,
                    nmResults: results,
                  });
                }}
                disabled={createNuclearMedicineStudyMutation.isPending}
                isCreating={createNuclearMedicineStudyMutation.isPending}
              />
            ) : (
            <Card className="p-6">
              <h2 className="text-lg font-semibold mb-4">Data Files</h2>
              
              {/* Info about upload options */}
              <div className="mb-4 p-3 bg-blue-500/10 border border-blue-500/20 rounded-lg">
                <div className="flex items-start gap-2 text-blue-600 dark:text-blue-400">
                  <AlertCircle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                  <div className="text-sm">
                    <p className="font-medium">Selective Upload Available</p>
                    <p className="text-xs mt-1">
                      After selecting your folder, you can choose to upload only essential files (CT images, dose data, organ masks) or all files. This saves time and storage for large datasets.
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="border-2 border-dashed rounded-lg p-8 text-center bg-muted/30">
                <input
                  type="file"
                  /* @ts-ignore */
                  webkitdirectory=""
                  directory=""
                  onChange={handleFolderSelect}
                  className="hidden"
                  id="folder-upload"
                  disabled={folderUpload.uploading || !!pendingFiles}
                />
                <label htmlFor="folder-upload" className={pendingFiles ? "" : "cursor-pointer"}>
                  <div className="flex flex-col items-center gap-4">
                    <div className="p-4 bg-muted rounded-full">
                      <FolderIcon className="h-8 w-8 text-muted-foreground" />
                    </div>
                    <div>
                      <p className="font-medium mb-1">
                        {pendingFiles ? "Folder Selected" : "Select Folder"}
                      </p>
                      <p className="text-sm text-muted-foreground mb-1">
                        {pendingFiles 
                          ? `${selectedFolder} ready for upload`
                          : "Choose a folder containing your study files"
                        }
                      </p>
                      <p className="text-xs text-muted-foreground">
                        DICOM (.dcm) • NIfTI (.nii, .nii.gz) • Metadata (.json)
                      </p>
                    </div>
                  </div>
                </label>
              </div>

              {/* File Statistics and Upload Buttons */}
              {fileStats && (
                <div className="mt-6 space-y-4">
                  <div className="grid grid-cols-2 gap-3">
                    <div className="p-4 bg-muted/50 border border-border rounded-lg">
                      <p className="text-xs text-muted-foreground mb-1">Total Files</p>
                      <p className="text-2xl font-bold">{fileStats.total.toLocaleString()}</p>
                      <p className="text-xs text-muted-foreground mt-1">{fileStats.totalSize}</p>
                    </div>
                    <div className="p-4 bg-primary/10 border border-primary/20 rounded-lg">
                      <p className="text-xs text-muted-foreground mb-1">Essential Files</p>
                      <p className="text-2xl font-bold text-primary">{fileStats.essential.toLocaleString()}</p>
                      <p className="text-xs text-muted-foreground mt-1">Recommended</p>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Button
                      onClick={() => handleUpload('essential')}
                      disabled={folderUpload.uploading}
                      className="w-full"
                      size="lg"
                    >
                      <CheckCircle2 className="h-5 w-5 mr-2" />
                      Upload Essential Files Only ({fileStats.essential} files)
                    </Button>
                    
                    <div className="grid grid-cols-2 gap-2">
                      <Button
                        onClick={() => handleUpload('all')}
                        disabled={folderUpload.uploading}
                        variant="outline"
                      >
                        <File className="h-4 w-4 mr-2" />
                        Upload All ({fileStats.total})
                      </Button>
                      
                      <Button
                        onClick={() => handleUpload('ct-only')}
                        disabled={folderUpload.uploading}
                        variant="outline"
                      >
                        <FileArchive className="h-4 w-4 mr-2" />
                        CT Only ({fileStats.ctOnly})
                      </Button>
                    </div>
                  </div>

                  <div className="p-3 bg-blue-500/10 border border-blue-500/20 rounded-lg">
                    <p className="text-xs text-blue-600 dark:text-blue-400">
                      <strong>Essential files include:</strong> CT_Beelden (CT images), DoseDistribution (dose data), and TotalSegmentator/segmentations (organ masks)
                    </p>
                  </div>
                </div>
              )}

              {folderUpload.uploading && (
                <div className="mt-4 space-y-3">
                  <div className="flex items-center gap-2 mb-1">
                    <div className="h-2 w-2 bg-green-500 rounded-full animate-pulse" />
                    <p className="text-xs font-medium text-green-600 dark:text-green-400">
                      Upload in progress
                    </p>
                  </div>
                  <Progress value={uploadProgress} className="h-3" />
                  <div className="flex justify-between items-center">
                    <p className="text-sm font-medium text-foreground">
                      {folderUpload.progress.uploadedFiles} / {folderUpload.progress.totalFiles} files ({uploadProgress}%)
                    </p>
                  </div>
                  {folderUpload.progress.currentFile && (
                    <p className="text-xs text-muted-foreground truncate">
                      Current: {folderUpload.progress.currentFile}
                    </p>
                  )}
                  {folderUpload.progress.failedFiles > 0 && (
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 text-destructive">
                        <XCircle className="h-4 w-4" />
                        <p className="text-xs font-medium">
                          {folderUpload.progress.failedFiles} file(s) failed
                        </p>
                      </div>
                      {folderUpload.progress.failedFileReasons.size > 0 && (
                        <div className="max-h-32 overflow-y-auto space-y-1 text-xs text-muted-foreground">
                          {Array.from(folderUpload.progress.failedFileReasons.entries()).slice(0, 5).map(([path, reason]) => (
                            <div key={path} className="border-l-2 border-destructive/30 pl-2">
                              <p className="font-mono text-[10px] truncate">{path}</p>
                              <p className="text-destructive/80">{reason.errorType}: {reason.error}</p>
                              <p className="text-[10px] text-muted-foreground">Size: {(reason.size / 1024 / 1024).toFixed(2)}MB</p>
                            </div>
                          ))}
                          {folderUpload.progress.failedFileReasons.size > 5 && (
                            <p className="text-center pt-1">
                              ...and {folderUpload.progress.failedFileReasons.size - 5} more
                            </p>
                          )}
                        </div>
                      )}
                    </div>
                  )}
                  <p className="text-xs text-amber-600 dark:text-amber-400">
                    ⚠️ Keep this page open until upload completes
                  </p>
                </div>
              )}

              <div className="mt-4 p-4 bg-muted/50 rounded-lg">
                <p className="text-sm font-medium mb-2">Accepted file formats:</p>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>• Dose files: DICOM (.dcm)</li>
                  <li>• Masks: NIfTI (.nii, .nii.gz)</li>
                  <li>• Metadata: .json, .txt</li>
                </ul>
              </div>
            </Card>
            )}
          </div>

          {/* Info Panel */}
          <div className="space-y-6">
            <Card className="p-6">
              <div className="flex items-center gap-2 mb-4">
                {isNuclearMedicine ? (
                  <Atom className="h-5 w-5 text-primary" />
                ) : (
                  <File className="h-5 w-5 text-primary" />
                )}
                <h2 className="text-lg font-semibold">
                  {isNuclearMedicine ? "Dose Estimation Info" : "Upload Info"}
                </h2>
              </div>
              
              <div className="space-y-3">
                {isNuclearMedicine ? (
                  <>
                    <div>
                      <p className="text-sm font-medium mb-1">Conversion Coefficients</p>
                      <p className="text-xs text-muted-foreground">
                        Organ doses are calculated using ICRP Publication 128 dose coefficients (mGy/MBq)
                      </p>
                    </div>
                    <div>
                      <p className="text-sm font-medium mb-1">No File Upload</p>
                      <p className="text-xs text-muted-foreground">
                        PET/SPECT studies only require radiotracer and administered activity input
                      </p>
                    </div>
                    <div>
                      <p className="text-sm font-medium mb-1">Standard Adult Model</p>
                      <p className="text-xs text-muted-foreground">
                        Coefficients are based on ICRP reference adult phantoms
                      </p>
                    </div>
                  </>
                ) : (
                  <>
                    <div>
                      <p className="text-sm font-medium mb-1">Folder Structure Preserved</p>
                      <p className="text-xs text-muted-foreground">
                        Your original folder hierarchy will be maintained in the system
                      </p>
                    </div>
                    <div>
                      <p className="text-sm font-medium mb-1">Parallel Uploads</p>
                      <p className="text-xs text-muted-foreground">
                        Multiple files uploaded simultaneously for faster processing
                      </p>
                    </div>
                    <div>
                      <p className="text-sm font-medium mb-1">Automatic Retry</p>
                      <p className="text-xs text-muted-foreground">
                        Failed uploads will be retried automatically
                      </p>
                    </div>
                  </>
                )}
              </div>
            </Card>

            <Card className="p-6 bg-primary/5 border-primary/20">
              <div className="flex items-start gap-2">
                <AlertCircle className="h-5 w-5 text-primary mt-0.5" />
                <div>
                  <p className="text-sm font-medium mb-1">Research Use Only</p>
                  <p className="text-xs text-muted-foreground">
                    This platform is for research purposes. Not approved for clinical decision-making.
                  </p>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </div>

      {/* Upload Progress Dialog */}
      <UploadProgressDialog 
        open={showUploadDialog}
        checking={folderUpload.checking}
        uploading={folderUpload.uploading}
        progress={folderUpload.progress}
        uploadMode={uploadMode}
        onClose={() => setShowUploadDialog(false)}
      />
    </div>
  );
};

export default Upload;
