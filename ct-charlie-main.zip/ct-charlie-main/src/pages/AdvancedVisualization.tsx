import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { DicomViewer } from '@/components/medical/DicomViewer';
import { MPRViewer } from '@/components/medical/MPRViewer';
import { VolumeRenderer3D } from '@/components/medical/VolumeRenderer3D';
import { CineControls } from '@/components/medical/CineControls';
import { SplitScreenViewer } from '@/components/medical/SplitScreenViewer';
import { ArrowLeft, Layers, Box, Grid3x3, Film, SplitSquareVertical, AlertCircle, Info } from 'lucide-react';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { toast } from 'sonner';
import { extractVolumeFromStack } from '@/services/mprProcessor';
import { loadDicomStack } from '@/services/dicomImageLoader';
import { loadOrganMasks, loadDoseDistribution } from '@/services/overlayLoader';
import { VolumeData } from '@/services/mprProcessor';
import { NiftiData } from '@/services/niftiLoader';
import { supabase } from '@/integrations/supabase/client';

type FileType = 'dicom_dose' | 'dicom_other' | 'dicom_ct_fusie' | 'dicom_ct_wb';

// Helper function to get human-readable labels for file types
const getFileTypeLabel = (fileType: FileType): string => {
  switch(fileType) {
    case 'dicom_ct_fusie': return 'CT Fusie (1.25mm)';
    case 'dicom_ct_wb': return 'CT Whole Body (3.0mm)';
    case 'dicom_dose': return 'Dose Distribution';
    case 'dicom_other': return 'CT Scan';
    default: return 'DICOM';
  }
};

// Helper function to get file type descriptions
const getFileTypeDescription = (fileType: FileType): string => {
  switch(fileType) {
    case 'dicom_ct_fusie': return 'High resolution anatomical scan (1.25mm) for image fusion';
    case 'dicom_ct_wb': return 'Whole body scan (3.0mm) with bone window reconstruction';
    case 'dicom_dose': return 'Monte Carlo simulation results - dose distribution';
    case 'dicom_other': return 'Standard CT scan images';
    default: return 'DICOM images';
  }
};

export default function AdvancedVisualization() {
  const { studyId } = useParams<{ studyId: string }>();
  const navigate = useNavigate();
  
  const [activeTab, setActiveTab] = useState('standard');
  const [volume, setVolume] = useState<VolumeData | null>(null);
  const [isLoadingVolume, setIsLoadingVolume] = useState(false);
  const [loadingProgress, setLoadingProgress] = useState<{ current: number; total: number } | null>(null);
  const [organMasks, setOrganMasks] = useState<Map<string, { data: NiftiData; color: string }>>(new Map());
  const [doseData, setDoseData] = useState<NiftiData | null>(null);
  const [doseRange, setDoseRange] = useState<[number, number]>([0, 5]);
  const [availableFileTypes, setAvailableFileTypes] = useState<FileType[]>([]);
  const [selectedFileType, setSelectedFileType] = useState<FileType | null>(null);
  const [isCheckingFiles, setIsCheckingFiles] = useState(true);
  const [studyTextId, setStudyTextId] = useState<string | null>(null);
  
  // Cine mode state
  const [currentSlice, setCurrentSlice] = useState(0);
  const [totalSlices, setTotalSlices] = useState(0);
  const [imageIds, setImageIds] = useState<string[]>([]);

  // First, get the text study_id from the UUID
  useEffect(() => {
    if (!studyId) return;

    const fetchStudyTextId = async () => {
      try {
        const { data: study, error } = await supabase
          .from('studies')
          .select('study_id')
          .eq('id', studyId)
          .single();

        if (error) throw error;
        if (!study) throw new Error('Study not found');

        setStudyTextId(study.study_id);
      } catch (err) {
        console.error('Error fetching study:', err);
        toast.error('Failed to load study information');
        setIsCheckingFiles(false);
      }
    };

    fetchStudyTextId();
  }, [studyId]);

  // Check what file types are available for this study
  useEffect(() => {
    if (!studyTextId) return;

    const checkAvailableFileTypes = async () => {
      setIsCheckingFiles(true);
      try {
        // Query distinct file types for this study using the text study_id
        const { data: files, error } = await supabase
          .from('extracted_files')
          .select('file_type')
          .eq('study_id', studyTextId)
          .like('file_type', 'dicom%');

        if (error) throw error;

        if (!files || files.length === 0) {
          setAvailableFileTypes([]);
          setSelectedFileType(null);
          setIsCheckingFiles(false);
          return;
        }

        // Get unique file types
        const uniqueTypes = Array.from(new Set(files.map(f => f.file_type as FileType)));
        setAvailableFileTypes(uniqueTypes);
        
        // Select preferred file type - prioritize anatomical CT scans over dose distribution
        const preferredType = 
          uniqueTypes.find(t => t === 'dicom_ct_fusie') ||  // First: high resolution CT
          uniqueTypes.find(t => t === 'dicom_ct_wb') ||     // Then: whole body CT
          uniqueTypes.find(t => t === 'dicom_other') ||     // Then: other DICOM
          uniqueTypes.find(t => t === 'dicom_dose') ||      // Last: dose distribution
          uniqueTypes[0];                                   // Fallback
        setSelectedFileType(preferredType);
        
        console.log(`Found ${uniqueTypes.length} file types for study ${studyTextId}:`, uniqueTypes);
      } catch (err) {
        console.error('Error checking file types:', err);
        setAvailableFileTypes([]);
        setSelectedFileType(null);
      } finally {
        setIsCheckingFiles(false);
      }
    };

    checkAvailableFileTypes();
  }, [studyTextId]);

  // Load DICOM stack for cine mode
  useEffect(() => {
    if (!studyTextId || activeTab !== 'cine' || !selectedFileType) return;

    const loadStack = async () => {
      try {
        const stack = await loadDicomStack(studyTextId, selectedFileType);
        setImageIds(stack.imageIds);
        setTotalSlices(stack.totalSlices);
        setCurrentSlice(0);
      } catch (err) {
        console.error('Error loading DICOM stack:', err);
        toast.error('Failed to load DICOM images');
      }
    };

    loadStack();
  }, [studyTextId, activeTab, selectedFileType]);

  // Load volume for MPR
  const handleLoadVolume = async () => {
    if (!studyTextId || !selectedFileType) return;
    
    setIsLoadingVolume(true);
    setLoadingProgress(null);
    try {
      toast.info('Loading volume data for MPR...');
      
      const stack = await loadDicomStack(studyTextId, selectedFileType);
      const volumeData = await extractVolumeFromStack(
        stack.imageIds,
        (current, total) => {
          setLoadingProgress({ current, total });
        }
      );
      
      setVolume(volumeData);
      setLoadingProgress(null);
      toast.success('Volume data loaded successfully');
    } catch (err) {
      console.error('Error loading volume:', err);
      toast.error('Failed to load volume data');
      setLoadingProgress(null);
    } finally {
      setIsLoadingVolume(false);
    }
  };

  // Load overlays for 3D rendering
  const handleLoad3DData = async () => {
    if (!studyTextId) return;
    
    try {
      toast.info('Loading 3D data...');
      
      // Load organ masks
      const masks = await loadOrganMasks(studyTextId);
      setOrganMasks(masks);
      
      // Load dose distribution
      const dose = await loadDoseDistribution(studyTextId);
      setDoseData(dose);
      
      // Auto-calculate dose range using mean + 2×stddev for clinical relevance
      if (dose) {
        // Collect all non-zero dose values
        const nonZeroValues: number[] = [];
        for (let i = 0; i < dose.data.length; i++) {
          const value = dose.data[i];
          if (value > 0) {
            nonZeroValues.push(value);
          }
        }
        
        if (nonZeroValues.length > 0) {
          // Calculate mean
          const sum = nonZeroValues.reduce((a, b) => a + b, 0);
          const mean = sum / nonZeroValues.length;
          
          // Calculate standard deviation
          const variance = nonZeroValues.reduce((sum, val) => 
            sum + Math.pow(val - mean, 2), 0) / nonZeroValues.length;
          const stdDev = Math.sqrt(variance);
          
          // Use mean ± 2 standard deviations (covers ~95% of data in normal distribution)
          // This focuses on clinically relevant dose range
          const minDose = Math.max(0, mean - 2 * stdDev); // Don't go below 0
          const maxDose = mean + 2 * stdDev;
          
          // Calculate additional statistics for validation
          const sortedValues = [...nonZeroValues].sort((a, b) => a - b);
          const minVal = sortedValues[0];
          const maxVal = sortedValues[sortedValues.length - 1];
          const median = sortedValues[Math.floor(sortedValues.length / 2)];
          
          setDoseRange([minDose, maxDose]);
          
          // Log dose statistics for validation
          console.log('=== Dose Statistics ===');
          console.log(`Non-zero voxels: ${nonZeroValues.length.toLocaleString()}`);
          console.log(`Mean: ${mean.toFixed(4)} Gy (${(mean * 1000).toFixed(1)} mGy)`);
          console.log(`Std Dev: ${stdDev.toFixed(4)} Gy (${(stdDev * 1000).toFixed(1)} mGy)`);
          console.log(`Median: ${median.toFixed(4)} Gy (${(median * 1000).toFixed(1)} mGy)`);
          console.log(`Absolute Range: ${minVal.toFixed(4)} - ${maxVal.toFixed(4)} Gy`);
          console.log(`Display Range (mean±2σ): ${minDose.toFixed(4)} - ${maxDose.toFixed(4)} Gy`);
          console.log(`Display Range (mGy): ${(minDose * 1000).toFixed(1)} - ${(maxDose * 1000).toFixed(1)} mGy`);
          console.log('=====================');
        }
      }
      
      toast.success(`Loaded ${masks.size} organ masks and dose distribution`);
    } catch (err) {
      console.error('Error loading 3D data:', err);
      toast.error('Failed to load 3D data');
    }
  };

  if (!studyId) {
    return (
      <div className="container mx-auto p-6">
        <Card className="p-6">
          <p className="text-center text-muted-foreground">No study selected</p>
        </Card>
      </div>
    );
  }

  if (isCheckingFiles) {
    return (
      <div className="container mx-auto p-6">
        <Card className="p-6">
          <div className="flex items-center justify-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            <span className="ml-3">Checking study files...</span>
          </div>
        </Card>
      </div>
    );
  }

  if (availableFileTypes.length === 0 && !isCheckingFiles) {
    return (
      <div className="container mx-auto p-6 space-y-6">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="sm" onClick={() => navigate('/studies')}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Studies
          </Button>
          <div>
            <h1 className="text-2xl font-bold">Advanced Visualization</h1>
            <p className="text-sm text-muted-foreground">Study ID: {studyId}</p>
          </div>
        </div>
        
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            No DICOM files found for this study. Please ensure the study has been properly uploaded and processed.
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => navigate('/studies')}
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Studies
          </Button>
          <div>
            <h1 className="text-2xl font-bold">Advanced Visualization</h1>
            <p className="text-sm text-muted-foreground">Study ID: {studyId}</p>
          </div>
        </div>
        
        {/* File Type Selector */}
        {selectedFileType && availableFileTypes.length > 1 && (
          <div className="flex items-center gap-2">
            <span className="text-sm font-medium">Viewing:</span>
            <Select value={selectedFileType} onValueChange={(value) => setSelectedFileType(value as FileType)}>
              <SelectTrigger className="w-[200px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {availableFileTypes.map(type => (
                  <SelectItem key={type} value={type}>
                    <div className="flex items-center gap-2">
                      {getFileTypeLabel(type)}
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Info className="h-3 w-3 text-muted-foreground" />
                          </TooltipTrigger>
                          <TooltipContent>
                            <p className="max-w-xs text-xs">{getFileTypeDescription(type)}</p>
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        )}
      </div>

      {/* Visualization Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid grid-cols-5 w-full">
          <TabsTrigger value="standard" className="flex items-center gap-2">
            <Layers className="h-4 w-4" />
            CT Viewer
          </TabsTrigger>
          <TabsTrigger value="mpr" className="flex items-center gap-2">
            <Grid3x3 className="h-4 w-4" />
            MPR (3 Planes)
          </TabsTrigger>
          <TabsTrigger value="3d" className="flex items-center gap-2">
            <Box className="h-4 w-4" />
            3D Volume
          </TabsTrigger>
          <TabsTrigger value="cine" className="flex items-center gap-2">
            <Film className="h-4 w-4" />
            Cine Mode
          </TabsTrigger>
          <TabsTrigger value="split" className="flex items-center gap-2">
            <SplitSquareVertical className="h-4 w-4" />
            Compare
          </TabsTrigger>
        </TabsList>

        {/* Standard Viewer */}
        <TabsContent value="standard">
          {selectedFileType && studyTextId ? (
            <div className="space-y-4">
              <Card className="p-4 bg-muted/50">
                <div className="flex items-center gap-2">
                  <Layers className="h-5 w-5 text-primary" />
                  <div className="flex-1">
                    <h3 className="font-semibold text-sm">CT Viewer</h3>
                    <p className="text-xs text-muted-foreground">
                      Standard 2D view of CT scans. Use mouse wheel to navigate through slices, click + drag to adjust window/level.
                    </p>
                  </div>
                  <Badge variant="outline">{getFileTypeLabel(selectedFileType)}</Badge>
                </div>
              </Card>
              <DicomViewer
                studyId={studyTextId}
                fileType={selectedFileType}
                showControls={true}
                showOverlay={true}
              />
            </div>
          ) : (
            <Card className="p-6">
              <Alert>
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>No DICOM files available</AlertDescription>
              </Alert>
            </Card>
          )}
        </TabsContent>

        {/* MPR Viewer */}
        <TabsContent value="mpr">
          <div className="space-y-4">
            <Card className="p-4 bg-muted/50">
              <div className="flex items-center gap-2">
                <Grid3x3 className="h-5 w-5 text-primary" />
                  <div className="flex-1">
                    <h3 className="font-semibold text-sm">Multi-Planar Reconstruction (MPR)</h3>
                    <p className="text-xs text-muted-foreground">
                      View CT data from 3 orthogonal planes simultaneously (axial, sagittal, coronal). Ideal for spatial understanding of anatomy.
                    </p>
                  </div>
              </div>
            </Card>
            
            {!volume && (
              <Card className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-medium">Multi-Planar Reconstruction</h3>
                    <p className="text-sm text-muted-foreground">
                      Load volume data to enable MPR view
                    </p>
                  </div>
                  <Button onClick={handleLoadVolume} disabled={isLoadingVolume}>
                    {isLoadingVolume ? 'Loading volume...' : 'Load Volume Data'}
                  </Button>
                </div>
              </Card>
            )}
            
            {/* Loading progress overlay */}
            {isLoadingVolume && loadingProgress && (
              <Card className="p-6 mb-4">
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Loading volume data...</span>
                    <span className="text-sm text-muted-foreground">
                      {loadingProgress.current}/{loadingProgress.total} slices ({Math.round((loadingProgress.current / loadingProgress.total) * 100)}%)
                    </span>
                  </div>
                  <div className="w-full bg-muted rounded-full h-2 overflow-hidden">
                    <div 
                      className="bg-primary h-full transition-all duration-300"
                      style={{ width: `${(loadingProgress.current / loadingProgress.total) * 100}%` }}
                    />
                  </div>
                </div>
              </Card>
            )}
            
            <MPRViewer
              volume={volume}
              isLoading={isLoadingVolume}
              showMIP={true}
            />
          </div>
        </TabsContent>

        {/* 3D Volume Rendering */}
        <TabsContent value="3d">
          <div className="space-y-4">
            <Card className="p-4 bg-muted/50">
              <div className="flex items-center gap-2">
                <Box className="h-5 w-5 text-primary" />
                  <div className="flex-1">
                    <h3 className="font-semibold text-sm">3D Volume Rendering</h3>
                    <p className="text-xs text-muted-foreground">
                      Interactive 3D visualization of organ segmentations and radiation dose distribution. Heatmap colors show dose from lowest (dark blue) to highest (red).
                    </p>
                    {doseRange[0] !== 0 || doseRange[1] !== 5 ? (
                      <p className="text-xs text-primary font-medium mt-1">
                        Dose range: {doseRange[0].toFixed(4)} - {doseRange[1].toFixed(4)} Gy 
                        ({(doseRange[0] * 1000).toFixed(1)} - {(doseRange[1] * 1000).toFixed(1)} mGy)
                      </p>
                    ) : null}
                  </div>
              </div>
            </Card>
            
            {organMasks.size === 0 && !doseData && (
              <Card className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-medium">3D Volume Rendering</h3>
                    <p className="text-sm text-muted-foreground">
                      Load organ masks and dose data for 3D visualization
                    </p>
                  </div>
                  <Button onClick={handleLoad3DData}>
                    Load 3D Data
                  </Button>
                </div>
              </Card>
            )}
            
            <VolumeRenderer3D
              organMasks={organMasks}
              doseData={doseData}
              showOrgans={true}
              showDose={true}
              doseThreshold={0.5}
              initialDoseRange={doseRange}
            />
          </div>
        </TabsContent>

        {/* Cine Mode */}
        <TabsContent value="cine">
          {selectedFileType && studyTextId ? (
            <div className="space-y-4">
              <Card className="p-4 bg-muted/50">
                <div className="flex items-center gap-2">
                  <Film className="h-5 w-5 text-primary" />
                  <div className="flex-1">
                    <h3 className="font-semibold text-sm">Cine Mode</h3>
                    <p className="text-xs text-muted-foreground">
                      Animation function for fast scrolling through all slices. Use play/pause to automatically scroll through images.
                    </p>
                  </div>
                </div>
              </Card>
              
              <div className="grid gap-4 lg:grid-cols-[1fr_300px]">
                <DicomViewer
                  studyId={studyTextId}
                  fileType={selectedFileType}
                  initialSlice={currentSlice}
                  showControls={true}
                  showOverlay={false}
                />
                
                {totalSlices > 0 && (
                  <CineControls
                    totalSlices={totalSlices}
                    currentSlice={currentSlice}
                    onSliceChange={setCurrentSlice}
                    defaultFps={10}
                  />
                )}
              </div>
            </div>
          ) : (
            <Card className="p-6">
              <Alert>
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>No DICOM files available</AlertDescription>
              </Alert>
            </Card>
          )}
        </TabsContent>

        {/* Split Screen */}
        <TabsContent value="split">
          {selectedFileType && availableFileTypes.length > 1 && studyTextId ? (
            <div className="space-y-4">
              <Card className="p-4 bg-muted/50">
                <div className="flex items-center gap-2">
                  <SplitSquareVertical className="h-5 w-5 text-primary" />
                  <div className="flex-1">
                    <h3 className="font-semibold text-sm">Compare</h3>
                    <p className="text-xs text-muted-foreground">
                      Compare different scan types side by side. Ideal for fusion images or different reconstructions.
                    </p>
                  </div>
                </div>
              </Card>
              
              <SplitScreenViewer
                studyId={studyTextId}
                availableFileTypes={availableFileTypes}
              />
            </div>
          ) : selectedFileType ? (
            <Card className="p-6">
              <Alert>
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  Split screen requires at least 2 different file types. Only {selectedFileType} is available.
                </AlertDescription>
              </Alert>
            </Card>
          ) : (
            <Card className="p-6">
              <Alert>
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>No DICOM files available</AlertDescription>
              </Alert>
            </Card>
          )}
        </TabsContent>
      </Tabs>

      {/* Info Card */}
      <Card className="p-4">
        <div className="space-y-2 text-sm">
          <h3 className="font-medium">Visualization Features</h3>
          <ul className="list-disc list-inside space-y-1 text-muted-foreground">
            <li><strong>CT Viewer:</strong> Anatomical CT images with overlay controls (standard view)</li>
            <li><strong>MPR (3 Planes):</strong> Multi-planar reconstruction with axial, sagittal and coronal cross-sections</li>
            <li><strong>3D Volume:</strong> Interactive 3D visualization of organ masks and dose clouds</li>
            <li><strong>Cine Mode:</strong> Automatic scrolling through slices with adjustable speed</li>
            <li><strong>Compare:</strong> Compare different scans side by side (e.g. CT anatomy vs. dose distribution)</li>
          </ul>
        </div>
      </Card>
    </div>
  );
}
