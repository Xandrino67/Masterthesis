import { useParams, useNavigate } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import Navigation from "@/components/Navigation";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { ArrowLeft, Calendar, User, Activity, FileText, BarChart3, Play, Download, Upload, Trash2, Eye } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useFolderUpload } from "@/hooks/useFolderUpload";
import DVHChart from "@/components/analysis/DVHChart";
import OrganStatsTable from "@/components/analysis/OrganStatsTable";
import EffectiveDoseCard from "@/components/analysis/EffectiveDoseCard";
import FileTree from "@/components/study/FileTree";
import CalculationButton from "@/components/analysis/CalculationButton";
import { DicomViewer } from "@/components/medical/DicomViewer";
import { UploadProgressDialog } from "@/components/study/UploadProgressDialog";
import { useState, useRef } from "react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

const StudyDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [newlyUploadedFiles, setNewlyUploadedFiles] = useState<string[]>([]);
  const [isDeleting, setIsDeleting] = useState(false);
  const [selectedCTFileType, setSelectedCTFileType] = useState<'dicom_ct_fusie' | 'dicom_ct_wb' | 'dicom_other' | 'dicom_dose'>('dicom_dose');
  const [availableCTFileTypes, setAvailableCTFileTypes] = useState<string[]>([]);
  const [showUploadDialog, setShowUploadDialog] = useState(false);
  
  const { uploading, checking, progress, processFolderStructure, uploadFilesInBatches, reuploadFilesForStudy, resetProgress } = useFolderUpload();

  const { data: study, isLoading } = useQuery({
    queryKey: ["study", id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("studies")
        .select(`
          *,
          patient:patients(*),
          protocol:protocols(*),
          institution:institutions(*),
          device:devices(*),
          physician:physicians(*),
          series(*),
          analysis_runs(*)
        `)
        .eq("id", id)
        .order("created_at", { referencedTable: "analysis_runs", ascending: false })
        .single();
      if (error) throw error;
      return data;
    },
    enabled: !!id,
  });

  const { data: organs } = useQuery({
    queryKey: ["organs"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("organs")
        .select("*")
        .not("weight_factor", "is", null)
        .order("label");
      if (error) throw error;
      return data;
    },
  });

  // Query available CT file types for this study
  const { data: availableFileTypes } = useQuery({
    queryKey: ["available-ct-types", study?.study_id],
    queryFn: async () => {
      if (!study?.study_id) return [];
      
      const { data, error } = await supabase
        .from("extracted_files")
        .select("file_type")
        .eq("study_id", study.study_id)
        .in("file_type", ["dicom_ct_fusie", "dicom_ct_wb", "dicom_other", "dicom_dose"]);
      
      if (error) throw error;
      
      // Get unique file types
      const uniqueTypes = [...new Set(data.map(f => f.file_type))];
      return uniqueTypes;
    },
    enabled: !!study?.study_id,
  });

  // Set the best available CT file type when available types are loaded
  useQuery({
    queryKey: ["set-best-ct-type", availableFileTypes],
    queryFn: () => {
      if (!availableFileTypes || availableFileTypes.length === 0) return null;
      
      setAvailableCTFileTypes(availableFileTypes);
      
      // Priority order: dicom_ct_fusie > dicom_ct_wb > dicom_other > dicom_dose
      const priority = ["dicom_ct_fusie", "dicom_ct_wb", "dicom_other", "dicom_dose"];
      
      for (const type of priority) {
        if (availableFileTypes.includes(type)) {
          setSelectedCTFileType(type as any);
          break;
        }
      }
      
      return null;
    },
    enabled: !!availableFileTypes,
  });

  const runAnalysisMutation = useMutation({
    mutationFn: async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) throw new Error("Not authenticated");

      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/analyze-dose`,
        {
          method: "POST",
          headers: {
            Authorization: `Bearer ${session.access_token}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            study_id: id,
            series_ids: study?.series?.map((s: any) => s.id) || [],
            method: "ct_cbct_cumulative",
            params: {
              dvh_bins: 0.1,
              organ_ids: organs?.map(o => o.id) || [],
            },
          }),
        }
      );

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || "Analysis failed");
      }

      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["study", id] });
      toast({
        title: "Analysis completed",
        description: "Dose statistics and DVH calculated successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "Analysis failed",
        description: error.message,
      });
    },
  });

  const generateReportMutation = useMutation({
    mutationFn: async (format: "json" | "html") => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) throw new Error("Not authenticated");

      const completedRun = study?.analysis_runs?.find((r: any) => r.status === "completed");
      if (!completedRun) throw new Error("No completed analysis to generate report from");

      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/generate-report`,
        {
          method: "POST",
          headers: {
            Authorization: `Bearer ${session.access_token}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            study_id: id,
            analysis_run_id: completedRun.id,
            format,
            include_sections: ["all"],
          }),
        }
      );

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || "Report generation failed");
      }

      return { format, data: await response.blob() };
    },
    onSuccess: ({ format, data }) => {
      const url = window.URL.createObjectURL(data);
      const a = document.createElement("a");
      a.href = url;
      a.download = `report-${study?.study_id}-${Date.now()}.${format === "json" ? "json" : "html"}`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);

      toast({
        title: "Report generated",
        description: `Report downloaded as ${format.toUpperCase()}`,
      });
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "Report generation failed",
        description: error.message,
      });
    },
  });

  const handleFolderUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0 || !study) return;

    try {
      setShowUploadDialog(true);
      
      // Use reuploadFilesForStudy to respect the upload mode
      const result = await reuploadFilesForStudy(files, study.study_id, study.upload_mode);
      
      queryClient.invalidateQueries({ queryKey: ["extracted-files-all", study.study_id] });
      
      // Clear newly uploaded files filter (reuploadFilesForStudy doesn't track individual paths)
      setNewlyUploadedFiles([]);

      // Show appropriate toast message based on results
      if (result.uploadedCount === 0 && result.skippedCount > 0) {
        toast({
          title: "No new files to upload",
          description: `All ${result.skippedCount} files already exist in this study`,
        });
      } else if (result.uploadedCount > 0 && result.failedCount === 0) {
        toast({
          title: "Upload complete",
          description: `${result.uploadedCount} files uploaded successfully${result.skippedCount > 0 ? `, ${result.skippedCount} already existed` : ''}`,
        });
      } else if (result.failedCount > 0) {
        toast({
          variant: result.uploadedCount > 0 ? "default" : "destructive",
          title: result.uploadedCount > 0 ? "Upload partially complete" : "Upload failed",
          description: `${result.uploadedCount} uploaded, ${result.skippedCount} skipped, ${result.failedCount} failed`,
        });
      }
    } catch (error) {
      console.error("Upload error:", error);
      toast({
        variant: "destructive",
        title: "Upload failed",
        description: error instanceof Error ? error.message : "Unknown error occurred",
      });
    }

    // Reset file input
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleDeleteAllFiles = async () => {
    if (!study) return;
    
    setIsDeleting(true);
    try {
      // Get all files for this study
      const { data: files, error: fetchError } = await supabase
        .from('extracted_files')
        .select('storage_path, storage_bucket')
        .eq('study_id', study.study_id);

      if (fetchError) throw fetchError;

      // Delete from storage
      if (files && files.length > 0) {
        const filePaths = files.map(f => f.storage_path);
        const { error: storageError } = await supabase.storage
          .from('dose-files')
          .remove(filePaths);

        if (storageError) {
          console.error('Storage deletion error:', storageError);
          // Continue anyway to clean up database records
        }
      }

      // Delete database records
      const { error: dbError } = await supabase
        .from('extracted_files')
        .delete()
        .eq('study_id', study.study_id);

      if (dbError) throw dbError;

      queryClient.invalidateQueries({ queryKey: ["extracted-files-all", study.study_id] });
      setNewlyUploadedFiles([]);

      toast({
        title: "All files deleted",
        description: `Successfully deleted ${files?.length || 0} files from this study`,
      });
    } catch (error) {
      console.error("Delete error:", error);
      toast({
        variant: "destructive",
        title: "Deletion failed",
        description: error instanceof Error ? error.message : "Failed to delete files",
      });
    } finally {
      setIsDeleting(false);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="container mx-auto px-6 py-8">
          <div className="text-center text-muted-foreground">Loading study...</div>
        </div>
      </div>
    );
  }

  if (!study) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="container mx-auto px-6 py-8">
          <div className="text-center">
            <p className="text-muted-foreground mb-4">Study not found</p>
            <Button onClick={() => navigate("/dashboard")}>Back to Dashboard</Button>
          </div>
        </div>
      </div>
    );
  }

  const isNuclearMedicine = study.upload_mode === 'nuclear_medicine';
  const latestCompletedRun = study.analysis_runs
    ?.filter((r: any) => r.status === 'completed')
    .sort((a: any, b: any) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())[0];

  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <div className="container mx-auto px-6 py-8">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Button variant="ghost" size="icon" onClick={() => navigate(study?.patient_id ? `/patient/${study.patient_id}` : "/studies")}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-2">
              <h1 className="text-3xl font-bold">{study.study_id}</h1>
              {study.modality_set?.map((mod: string) => (
                <Badge key={mod} variant="outline">{mod}</Badge>
              ))}
            </div>
            <div className="flex items-center gap-4 text-sm text-muted-foreground">
              {study.patient && (
                <div className="flex items-center gap-1">
                  <User className="h-4 w-4" />
                  {study.patient.pseudonym_id}
                </div>
              )}
              <div className="flex items-center gap-1">
                <Calendar className="h-4 w-4" />
                {new Date(study.study_date).toLocaleDateString()}
              </div>
              {study.institution && (
                <div>{study.institution.name}</div>
              )}
            </div>
          </div>
          <div className="flex gap-2">
            {!isNuclearMedicine && (
              <>
                <Button
                  variant="default"
                  onClick={() => navigate(`/visualization/${id}`)}
                >
                  <Eye className="mr-2 h-4 w-4" />
                  Advanced Visualization
                </Button>
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button 
                        variant="outline"
                        onClick={() => fileInputRef.current?.click()}
                        disabled={uploading || checking || isDeleting}
                      >
                        <Upload className="mr-2 h-4 w-4" />
                        Re-upload Files
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>Select the same folder to add any missing files</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
                
                <UploadProgressDialog 
                  open={showUploadDialog}
                  checking={checking}
                  uploading={uploading}
                  progress={progress}
                  onClose={() => setShowUploadDialog(false)}
                />
                <input
                  ref={fileInputRef}
                  type="file"
                  onChange={handleFolderUpload}
                  className="hidden"
                  {...({ webkitdirectory: "", directory: "" } as any)}
                  multiple
                />
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button 
                      variant="outline" 
                      disabled={uploading || checking || isDeleting}
                    >
                      <Trash2 className="mr-2 h-4 w-4" />
                      {isDeleting ? "Deleting..." : "Delete All Files"}
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Delete all files?</AlertDialogTitle>
                      <AlertDialogDescription>
                        This will permanently delete all files from this study. This action cannot be undone.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                      <AlertDialogAction onClick={handleDeleteAllFiles} className="bg-destructive hover:bg-destructive/90">
                        Delete All
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </>
            )}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline">
                  <Download className="mr-2 h-4 w-4" />
                  Export Report
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                <DropdownMenuItem
                  onClick={() => generateReportMutation.mutate("json")}
                  disabled={generateReportMutation.isPending || !study.analysis_runs?.some((r: any) => r.status === "completed")}
                >
                  Download JSON
                </DropdownMenuItem>
                <DropdownMenuItem
                  onClick={() => generateReportMutation.mutate("html")}
                  disabled={generateReportMutation.isPending || !study.analysis_runs?.some((r: any) => r.status === "completed")}
                >
                  Download HTML Report
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>

        {/* Study Information Cards */}
        <div className={`grid ${isNuclearMedicine ? 'md:grid-cols-2' : 'md:grid-cols-3'} gap-6 mb-8`}>
          <Card className="p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-2 bg-primary/10 rounded-lg">
                <Activity className="h-5 w-5 text-primary" />
              </div>
              <h3 className="font-semibold">Protocol</h3>
            </div>
            {study.protocol ? (
              <div className="space-y-1 text-sm">
                <p className="font-medium">{study.protocol.name}</p>
                {study.protocol.kvp && <p className="text-muted-foreground">kVp: {study.protocol.kvp}</p>}
                {study.protocol.mas && <p className="text-muted-foreground">mAs: {study.protocol.mas}</p>}
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">No protocol specified</p>
            )}
          </Card>

          <Card className="p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-2 bg-primary/10 rounded-lg">
                <FileText className="h-5 w-5 text-primary" />
              </div>
              <h3 className="font-semibold">Device</h3>
            </div>
            {study.device ? (
              <div className="space-y-1 text-sm">
                <p className="font-medium">{study.device.device_id}</p>
                <p className="text-muted-foreground">{study.device.vendor} {study.device.model}</p>
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">No device specified</p>
            )}
          </Card>

          {!isNuclearMedicine && (
            <Card className="p-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="p-2 bg-primary/10 rounded-lg">
                  <BarChart3 className="h-5 w-5 text-primary" />
                </div>
                <h3 className="font-semibold">Series</h3>
              </div>
              <p className="text-3xl font-bold">{study.series?.length || 0}</p>
              <p className="text-sm text-muted-foreground mt-1">
                {study.series?.filter((s: any) => s.series_type === 'Dose').length || 0} dose, {" "}
                {study.series?.filter((s: any) => s.series_type === 'Mask').length || 0} mask
              </p>
            </Card>
          )}
        </div>

        {/* Nuclear Medicine: simplified view */}
        {isNuclearMedicine ? (
          <div className="space-y-6">
            {/* Study Details */}
            <Card className="p-6">
              <h3 className="font-semibold mb-4">Study Details</h3>
              <div className="grid md:grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-muted-foreground">Study ID:</span>
                  <p className="font-medium">{study.study_id}</p>
                </div>
                <div>
                  <span className="text-muted-foreground">Study Date:</span>
                  <p className="font-medium">{new Date(study.study_date).toLocaleDateString()}</p>
                </div>
                {latestCompletedRun?.params && (
                  <>
                    <div>
                      <span className="text-muted-foreground">Radiotracer:</span>
                      <p className="font-medium">{(latestCompletedRun.params as any).tracer_name}</p>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Radionuclide:</span>
                      <p className="font-medium">{(latestCompletedRun.params as any).radionuclide}</p>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Administered Activity:</span>
                      <p className="font-medium">{(latestCompletedRun.params as any).activity_mbq} MBq</p>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Method:</span>
                      <p className="font-medium">ICRP 128 Dose Coefficients</p>
                    </div>
                  </>
                )}
                {study.indication && (
                  <div className="md:col-span-2">
                    <span className="text-muted-foreground">Indication:</span>
                    <p className="font-medium">{study.indication}</p>
                  </div>
                )}
              </div>
            </Card>

            {/* Effective Dose */}
            {latestCompletedRun?.results && (
              <EffectiveDoseCard
                effectiveDose={(() => {
                  const r = latestCompletedRun.results as any;
                  return r.effective_dose_mSv ?? r.effective_dose_msv ?? 0;
                })()}
                method="ICRP 128 Dose Coefficients"
                organCount={(() => {
                  const r = latestCompletedRun.results as any;
                  const od = r.organ_doses;
                  return Array.isArray(od) ? od.length : Object.keys(od || {}).length;
                })()}
              />
            )}

            {/* Organ Doses */}
            {latestCompletedRun?.results && typeof latestCompletedRun.results === 'object' && 'organ_doses' in (latestCompletedRun.results as any) && (
              <OrganStatsTable
                stats={(() => {
                  const results = latestCompletedRun.results as any;
                  const organDoses = results.organ_doses;
                  if (Array.isArray(organDoses)) {
                    return organDoses.map((od: any, i: number) => ({
                      organ_id: (od.organ_name || `organ-${i}`).toLowerCase(),
                      label: od.organ_name || `Organ ${i + 1}`,
                      volume_ml: 0,
                      d_mean: od.d_mean || od.dose_mGy || 0,
                      d_min: 0,
                      d_max: 0,
                      d_median: 0,
                      d_p5: 0,
                      d_p95: 0,
                    }));
                  }
                  return Object.entries(organDoses).map(([organ, data]: [string, any]) => ({
                    organ_id: organ.toLowerCase(),
                    label: organ,
                    volume_ml: 0,
                    d_mean: data.d_mean || 0,
                    d_min: 0,
                    d_max: 0,
                    d_median: 0,
                    d_p5: 0,
                    d_p95: 0,
                  }));
                })()}
                title="Organ Absorbed Doses (ICRP 128)"
              />
            )}
          </div>
        ) : (
        /* CT/CBCT: full tabbed view */
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList>
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="files">Files</TabsTrigger>
            <TabsTrigger value="series">Series</TabsTrigger>
            <TabsTrigger value="analysis">Analysis Runs</TabsTrigger>
            <TabsTrigger value="dvh">DVH</TabsTrigger>
            <TabsTrigger value="ct-viewer">CT Viewer</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-4">
            <Card className="p-6">
              <h3 className="font-semibold mb-4">Study Details</h3>
              <div className="grid md:grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-muted-foreground">Study ID:</span>
                  <p className="font-medium">{study.study_id}</p>
                </div>
                <div>
                  <span className="text-muted-foreground">Study Date:</span>
                  <p className="font-medium">{new Date(study.study_date).toLocaleDateString()}</p>
                </div>
                {study.indication && (
                  <div className="md:col-span-2">
                    <span className="text-muted-foreground">Indication:</span>
                    <p className="font-medium">{study.indication}</p>
                  </div>
                )}
              </div>
            </Card>
          </TabsContent>

          <TabsContent value="files" className="space-y-4">
            <FileTree 
              studyId={study.study_id}
              initialFilter={newlyUploadedFiles.length > 0 ? { uploadedPaths: newlyUploadedFiles } : undefined}
            />
          </TabsContent>

          <TabsContent value="series" className="space-y-4">
            {study.series && study.series.length > 0 ? (
              <div className="grid gap-4">
                {study.series.map((series: any) => (
                  <Card key={series.id} className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <h4 className="font-semibold">{series.series_id}</h4>
                          <Badge variant="outline">{series.series_type}</Badge>
                        </div>
                        {series.grid_size && (
                          <p className="text-sm text-muted-foreground">
                            Grid: {JSON.stringify(series.grid_size)}
                          </p>
                        )}
                      </div>
                      {series.unit && (
                        <Badge variant="secondary">{series.unit}</Badge>
                      )}
                    </div>
                  </Card>
                ))}
              </div>
            ) : (
              <Card className="p-12 text-center">
                <p className="text-muted-foreground">No series data available</p>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="analysis" className="space-y-4">
            <Card className="p-6">
              <div className="space-y-4">
                <div>
                  <h3 className="text-lg font-semibold mb-2">Calculate Organ Doses</h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    Analyze DICOM dose distribution files and organ masks to calculate absolute organ doses.
                  </p>
                </div>
                <CalculationButton 
                  studyId={study.id}
                  latestRun={latestCompletedRun}
                  onCalculationComplete={() => {
                    queryClient.invalidateQueries({ queryKey: ["study", id] });
                  }}
                />
              </div>
            </Card>

            {study.analysis_runs && study.analysis_runs.length > 0 ? (
              <div className="space-y-6">
                {(() => {
                  if (!latestCompletedRun) {
                    return (
                      <Card className="p-12 text-center">
                        <BarChart3 className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                        <p className="text-muted-foreground">No completed analysis runs yet. Use the button above to start.</p>
                      </Card>
                    );
                  }

                  return (
                    <div key={latestCompletedRun.id} className="space-y-4">
                      <Card className="p-4">
                        <div className="flex items-center justify-between">
                          <div>
                            <div className="flex items-center gap-2 mb-1">
                              <h4 className="font-semibold">{latestCompletedRun.run_id}</h4>
                              <Badge variant="default">Completed</Badge>
                            </div>
                            {latestCompletedRun.finished_at && (
                              <p className="text-sm text-muted-foreground">
                                {new Date(latestCompletedRun.finished_at).toLocaleString()}
                              </p>
                            )}
                            {latestCompletedRun.results && typeof latestCompletedRun.results === 'object' && 'mean_mAs' in latestCompletedRun.results && (
                              <p className="text-sm text-muted-foreground">
                                Mean mAs: {(latestCompletedRun.results as any).mean_mAs.toFixed(2)}
                              </p>
                            )}
                          </div>
                        </div>
                      </Card>

                      {latestCompletedRun.results && typeof latestCompletedRun.results === 'object' && 'organ_doses' in latestCompletedRun.results && (
                        <OrganStatsTable 
                          stats={Object.entries((latestCompletedRun.results as any).organ_doses).map(([organ, data]: [string, any]) => ({
                            organ_id: organ.toLowerCase(),
                            label: organ,
                            volume_ml: data.volume_ml || 0,
                            d_mean: data.d_mean || 0,
                            d_min: data.d_min || 0,
                            d_max: data.d_max || 0,
                            d_median: data.d_median || 0,
                            d_p5: data.d_p5 || 0,
                            d_p95: data.d_p95 || 0,
                          }))}
                          title={`Results - ${latestCompletedRun.run_id}`}
                        />
                      )}
                    </div>
                  );
                })()}
              </div>
            ) : (
              <Card className="p-12 text-center">
                <BarChart3 className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-muted-foreground">No analysis runs yet. Use the button above to start.</p>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="dvh" className="space-y-4">
            {(() => {
              const dvhRun = study.analysis_runs
                ?.filter((run: any) => {
                  if (run.status !== "completed" || !run.results || typeof run.results !== 'object') return false;
                  const results = run.results as any;
                  return results.organ_doses && Object.values(results.organ_doses).some((organ: any) => organ.dvh_cumulative?.length > 0);
                })
                .sort((a: any, b: any) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())[0];

              if (!dvhRun) {
                return (
                  <Card className="p-12 text-center">
                    <BarChart3 className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                    <p className="text-muted-foreground">Run an analysis to generate DVH</p>
                  </Card>
                );
              }

              const results = dvhRun.results as any;
              const dvhData = Object.entries(results.organ_doses)
                .filter(([_, organ]: [string, any]) => organ.dvh_cumulative?.length > 0)
                .map(([organName, organ]: [string, any]) => ({
                  organ_id: organName.toLowerCase(),
                  label: organName,
                  dvh_cumulative: organ.dvh_cumulative
                }));

              return (
                <DVHChart
                  key={dvhRun.id}
                  data={dvhData}
                  title={`DVH - ${dvhRun.run_id}`}
                />
              );
            })()}
          </TabsContent>

          <TabsContent value="ct-viewer" className="space-y-4">
            {availableCTFileTypes.length > 1 && (
              <Card className="p-4 mb-4">
                <div className="flex items-center gap-4">
                  <label className="text-sm font-medium">CT Image Type:</label>
                  <div className="flex gap-2">
                    {availableCTFileTypes.map((type) => (
                      <Button
                        key={type}
                        variant={selectedCTFileType === type ? "default" : "outline"}
                        size="sm"
                        onClick={() => setSelectedCTFileType(type as any)}
                      >
                        {type === 'dicom_ct_fusie' ? 'CT Fusion' :
                         type === 'dicom_ct_wb' ? 'CT Whole Body' :
                         type === 'dicom_other' ? 'CT Other' : 'Dose Distribution'}
                      </Button>
                    ))}
                  </div>
                </div>
              </Card>
            )}
            <DicomViewer 
              key={`${study.study_id}-${selectedCTFileType}`}
              studyId={study.study_id}
              fileType={selectedCTFileType}
              showControls={true}
              showOverlay={true}
            />
          </TabsContent>
        </Tabs>
        )}
      </div>
    </div>
  );
};

export default StudyDetail;
