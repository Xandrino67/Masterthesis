import { useState, useRef, useMemo } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { 
  Search, 
  Filter,
  FileText,
  Calendar,
  User,
  Activity,
  Plus,
  X,
  ChevronDown,
  ChevronRight,
  FolderTree,
  Trash2,
  Upload,
  XCircle,
  Users,
  ExternalLink
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import Navigation from "@/components/Navigation";
import FileTree from "@/components/study/FileTree";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { toast } from "sonner";
import { useFolderUpload } from "@/hooks/useFolderUpload";
import { getStudyEffectiveDose as getStudyEffectiveDoseUtil } from "@/services/effectiveDoseUtils";

interface PatientGroup {
  patientId: string;
  pseudonymId: string;
  studies: any[];
  dateRange: string;
  totalDose: number | null;
}

const Studies = () => {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const folderUpload = useFolderUpload();
  const ctImageInputRef = useRef<HTMLInputElement>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [modalityFilter, setModalityFilter] = useState<string>("all");
  const [patientFilter, setPatientFilter] = useState<string>("all");
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");
  const [showFilters, setShowFilters] = useState(false);
  const [expandedPatients, setExpandedPatients] = useState<Set<string>>(new Set());
  const [expandedStudies, setExpandedStudies] = useState<Set<string>>(new Set());
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [studyToDelete, setStudyToDelete] = useState<{ id: string; studyId: string } | null>(null);
  const [uploadingCtForStudy, setUploadingCtForStudy] = useState<string | null>(null);
  const [reuploadingStudy, setReuploadingStudy] = useState<{ id: string; mode: string | null } | null>(null);
  const reuploadInputRef = useRef<HTMLInputElement>(null);

  const togglePatientExpansion = (patientId: string) => {
    setExpandedPatients(prev => {
      const newSet = new Set(prev);
      if (newSet.has(patientId)) {
        newSet.delete(patientId);
      } else {
        newSet.add(patientId);
      }
      return newSet;
    });
  };

  const toggleStudyExpansion = (studyId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setExpandedStudies(prev => {
      const newSet = new Set(prev);
      if (newSet.has(studyId)) {
        newSet.delete(studyId);
      } else {
        newSet.add(studyId);
      }
      return newSet;
    });
  };

  const deleteStudyMutation = useMutation({
    mutationFn: async ({ id, studyId }: { id: string; studyId: string }) => {
      console.log('Starting deletion for study:', { id, studyId });
      
      try {
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) {
          throw new Error('You must be logged in to delete studies');
        }

        console.log('Fetching extracted files...');
        const { data: files, error: filesError } = await supabase
          .from('extracted_files')
          .select('storage_bucket, storage_path, id')
          .eq('study_id', studyId);

        if (filesError) {
          console.error('Error fetching files:', filesError);
          throw new Error(`Failed to fetch files: ${filesError.message}`);
        }
        
        console.log(`Found ${files?.length || 0} files to delete`);

        if (files && files.length > 0) {
          const buckets = [...new Set(files.map(f => f.storage_bucket))];
          for (const bucket of buckets) {
            const bucketFiles = files
              .filter(f => f.storage_bucket === bucket)
              .map(f => f.storage_path);
            
            const { error: storageError } = await supabase.storage
              .from(bucket)
              .remove(bucketFiles);
            
            if (storageError) {
              console.warn(`Storage deletion warning for ${bucket}:`, storageError);
            }
          }
        }

        const deletedFilesCount = files?.length || 0;
        const { error: extractedFilesError } = await supabase
          .from('extracted_files')
          .delete()
          .eq('study_id', studyId);

        if (extractedFilesError) {
          throw new Error(`Failed to delete extracted files: ${extractedFilesError.message}`);
        }

        const { error: cohortStudiesError } = await supabase
          .from('cohort_studies')
          .delete()
          .eq('study_id', id);
        if (cohortStudiesError) throw new Error(`Failed to delete cohort associations: ${cohortStudiesError.message}`);

        const { error: analysisError } = await supabase
          .from('analysis_runs')
          .delete()
          .eq('study_id', id);
        if (analysisError) throw new Error(`Failed to delete analysis runs: ${analysisError.message}`);

        const { error: seriesError } = await supabase
          .from('series')
          .delete()
          .eq('study_id', id);
        if (seriesError) throw new Error(`Failed to delete series: ${seriesError.message}`);

        const { error: studyError } = await supabase
          .from('studies')
          .delete()
          .eq('id', id);
        if (studyError) throw new Error(`Failed to delete study: ${studyError.message}`);

        const { data: studyCheck } = await supabase
          .from('studies')
          .select('id')
          .eq('id', id)
          .maybeSingle();

        if (studyCheck) {
          throw new Error('Study deletion verification failed - study still exists in database');
        }

        return { id, studyId, deletedFilesCount: deletedFilesCount || 0 };
      } catch (error) {
        console.error('Deletion failed:', error);
        throw error;
      }
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['all-studies'], exact: false });
      toast.success(
        `Study ${data.studyId} deleted successfully`,
        { description: `Removed ${data.deletedFilesCount} files from the database` }
      );
      setDeleteDialogOpen(false);
      setStudyToDelete(null);
    },
    onError: (error: any) => {
      toast.error('Failed to delete study', {
        description: error?.message || 'Please check your permissions and try again.'
      });
    },
  });

  const handleDeleteClick = (id: string, studyId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setStudyToDelete({ id, studyId });
    setDeleteDialogOpen(true);
  };

  const confirmDelete = () => {
    if (studyToDelete) {
      deleteStudyMutation.mutate(studyToDelete);
    }
  };

  const handleCtImageUpload = (studyId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setUploadingCtForStudy(studyId);
    ctImageInputRef.current?.click();
  };

  const handleCtFolderSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0 || !uploadingCtForStudy) {
      setUploadingCtForStudy(null);
      return;
    }

    try {
      toast.info(`Starting upload of CT images...`);
      const result = await folderUpload.uploadCtImagesOnly(files, uploadingCtForStudy);
      
      if (result.success) {
        toast.success(`${result.uploadedCount} CT images uploaded successfully! (${result.skippedCount} were already uploaded)`);
        queryClient.invalidateQueries({ queryKey: ['all-studies'] });
      } else if (result.error) {
        toast.error(result.error);
      } else {
        toast.warning(`Upload completed: ${result.uploadedCount} succeeded, ${result.failedCount} failed, ${result.skippedCount} skipped`);
        queryClient.invalidateQueries({ queryKey: ['all-studies'] });
      }
    } catch (error: any) {
      toast.error(error.message || 'Failed to upload CT images');
    } finally {
      setUploadingCtForStudy(null);
      if (ctImageInputRef.current) ctImageInputRef.current.value = '';
    }
  };

  const handleReuploadFiles = (studyId: string, uploadMode: string | null, e: React.MouseEvent) => {
    e.stopPropagation();
    setReuploadingStudy({ id: studyId, mode: uploadMode });
    reuploadInputRef.current?.click();
  };

  const handleReuploadFolderSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0 || !reuploadingStudy) {
      setReuploadingStudy(null);
      return;
    }

    try {
      const modeText = reuploadingStudy.mode || 'essential';
      toast.info(`Starting re-upload in ${modeText} mode...`);
      const result = await folderUpload.reuploadFilesForStudy(files, reuploadingStudy.id, reuploadingStudy.mode);
      
      if (result.success) {
        toast.success(`${result.uploadedCount} files uploaded successfully! (${result.skippedCount} were already uploaded)`);
        queryClient.invalidateQueries({ queryKey: ['all-studies'] });
      } else if (result.error) {
        toast.error(result.error);
      } else {
        toast.warning(`Upload completed: ${result.uploadedCount} succeeded, ${result.failedCount} failed, ${result.skippedCount} skipped`);
        queryClient.invalidateQueries({ queryKey: ['all-studies'] });
      }
    } catch (error: any) {
      toast.error(error.message || 'Failed to re-upload files');
    } finally {
      setReuploadingStudy(null);
      if (reuploadInputRef.current) reuploadInputRef.current.value = '';
    }
  };

  const { data: studies, isLoading, error, refetch } = useQuery({
    queryKey: ["all-studies", searchQuery, modalityFilter, patientFilter, dateFrom, dateTo],
    queryFn: async () => {
      let query = supabase
        .from("studies")
        .select(`
          *,
          patient:patients(id, pseudonym_id, sex, birth_year),
          series(count),
          analysis_runs(results, status, finished_at),
          upload_mode
        `)
        .order("study_date", { ascending: false});

      if (searchQuery) {
        query = query.ilike("study_id", `%${searchQuery}%`);
      }
      if (modalityFilter && modalityFilter !== "all") {
        query = query.contains("modality_set", [modalityFilter]);
      }
      if (patientFilter && patientFilter !== "all") {
        query = query.eq("patient_id", patientFilter);
      }
      if (dateFrom) {
        query = query.gte("study_date", dateFrom);
      }
      if (dateTo) {
        query = query.lte("study_date", dateTo);
      }

      const { data, error } = await query;
      if (error) throw error;
      return data;
    },
    staleTime: 0,
    refetchOnMount: true,
    retry: 1,
  });

  const { data: patients } = useQuery({
    queryKey: ["patients"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("patients")
        .select("*")
        .order("pseudonym_id");
      if (error) throw error;
      return data;
    },
  });

  // Group studies by patient
  const patientGroups: PatientGroup[] = useMemo(() => {
    if (!studies) return [];

    const groups: Record<string, any[]> = {};
    for (const study of studies) {
      const pid = study.patient_id;
      if (!groups[pid]) groups[pid] = [];
      groups[pid].push(study);
    }

    return Object.entries(groups).map(([patientId, patientStudies]) => {
      // Sort by date descending
      patientStudies.sort((a, b) => new Date(b.study_date).getTime() - new Date(a.study_date).getTime());
      
      const pseudonymId = patientStudies[0]?.patient?.pseudonym_id || "Unknown";
      const dates = patientStudies.map(s => new Date(s.study_date));
      const minDate = new Date(Math.min(...dates.map(d => d.getTime())));
      const maxDate = new Date(Math.max(...dates.map(d => d.getTime())));
      const dateRange = minDate.getFullYear() === maxDate.getFullYear()
        ? `${minDate.getFullYear()}`
        : `${minDate.getFullYear()}–${maxDate.getFullYear()}`;

      // Sum effective doses (with fallback to organ-dose computation)
      let totalDose: number | null = null;
      for (const s of patientStudies) {
        const dose = getStudyEffectiveDoseUtil(s);
        if (dose !== null) {
          totalDose = (totalDose || 0) + dose;
        }
      }

      return {
        patientId,
        pseudonymId,
        studies: patientStudies,
        dateRange,
        totalDose,
      };
    }).sort((a, b) => a.pseudonymId.localeCompare(b.pseudonymId));
  }, [studies]);

  const clearFilters = () => {
    setSearchQuery("");
    setModalityFilter("all");
    setPatientFilter("all");
    setDateFrom("");
    setDateTo("");
  };

  const hasActiveFilters = searchQuery || modalityFilter !== "all" || patientFilter !== "all" || dateFrom || dateTo;

  const getStudyEffectiveDose = (study: any) => {
    const dose = getStudyEffectiveDoseUtil(study);
    return dose !== null ? `${dose.toFixed(2)} mSv` : "—";
  };

  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <div className="container mx-auto px-6 py-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-3xl font-bold mb-2">Patient Studies</h1>
            <p className="text-muted-foreground">
              Browse studies grouped by patient
            </p>
          </div>
          <Button onClick={() => navigate("/upload")}>
            <Plus className="h-4 w-4 mr-2" />
            New Study
          </Button>
        </div>

        {/* Search and Filter Bar */}
        <Card className="p-4 mb-6">
          <div className="flex flex-col gap-4">
            <div className="flex gap-2">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input 
                  placeholder="Search by Study ID..." 
                  className="pl-9"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <Button 
                variant={showFilters ? "default" : "outline"} 
                onClick={() => setShowFilters(!showFilters)}
              >
                <Filter className="h-4 w-4 mr-2" />
                Filters
                {hasActiveFilters && (
                  <Badge variant="secondary" className="ml-2 h-5 px-1.5">
                    {[searchQuery, modalityFilter !== "all", patientFilter !== "all", dateFrom, dateTo].filter(Boolean).length}
                  </Badge>
                )}
              </Button>
              {hasActiveFilters && (
                <Button variant="ghost" onClick={clearFilters}>
                  <X className="h-4 w-4 mr-2" />
                  Clear
                </Button>
              )}
            </div>

            {showFilters && (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 pt-4 border-t">
                <div className="space-y-2">
                  <Label>Modality</Label>
                  <Select value={modalityFilter} onValueChange={setModalityFilter}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Modalities</SelectItem>
                      <SelectItem value="CT">CT</SelectItem>
                      <SelectItem value="CBCT">CBCT</SelectItem>
                      <SelectItem value="PET">PET</SelectItem>
                      <SelectItem value="SPECT">SPECT</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Patient</Label>
                  <Select value={patientFilter} onValueChange={setPatientFilter}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Patients</SelectItem>
                      {patients?.map((patient) => (
                        <SelectItem key={patient.id} value={patient.id}>
                          {patient.pseudonym_id}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Date From</Label>
                  <Input 
                    type="date" 
                    value={dateFrom}
                    onChange={(e) => setDateFrom(e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Date To</Label>
                  <Input 
                    type="date" 
                    value={dateTo}
                    onChange={(e) => setDateTo(e.target.value)}
                  />
                </div>
              </div>
            )}
          </div>
        </Card>

        {/* Results - Patient Grouped View */}
        <Card className="p-6">
          {isLoading ? (
            <div className="text-center py-12 text-muted-foreground">
              Loading studies...
            </div>
          ) : error ? (
            <div className="text-center py-12">
              <div className="text-destructive mb-4">Failed to load studies</div>
              <Button onClick={() => refetch()} variant="outline">
                Try Again
              </Button>
            </div>
          ) : patientGroups.length > 0 ? (
            <>
              <div className="mb-4 text-sm text-muted-foreground">
                Showing {patientGroups.length} {patientGroups.length === 1 ? "patient" : "patients"} with {studies?.length || 0} {(studies?.length || 0) === 1 ? "study" : "studies"}
              </div>
              <div className="space-y-3">
                {patientGroups.map((group) => {
                  const isPatientExpanded = expandedPatients.has(group.patientId);

                  return (
                    <div key={group.patientId} className="border rounded-lg overflow-hidden">
                      {/* Patient Header Row */}
                      <div 
                        className="p-4 hover:bg-accent/5 transition-colors cursor-pointer"
                        onClick={() => togglePatientExpansion(group.patientId)}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            {isPatientExpanded ? (
                              <ChevronDown className="h-5 w-5 text-muted-foreground" />
                            ) : (
                              <ChevronRight className="h-5 w-5 text-muted-foreground" />
                            )}
                            <Users className="h-5 w-5 text-primary" />
                            <div>
                              <h3 className="font-semibold text-lg">{group.pseudonymId}</h3>
                              <div className="flex items-center gap-3 text-sm text-muted-foreground">
                                <span>{group.studies.length} {group.studies.length === 1 ? "study" : "studies"}</span>
                                <span>•</span>
                                <span>{group.dateRange}</span>
                                {group.studies[0]?.patient?.sex && (
                                  <>
                                    <span>•</span>
                                    <span>{group.studies[0].patient.sex}</span>
                                  </>
                                )}
                                {group.studies[0]?.patient?.birth_year && (
                                  <>
                                    <span>•</span>
                                    <span>Born {group.studies[0].patient.birth_year}</span>
                                  </>
                                )}
                              </div>
                            </div>
                          </div>
                          <div className="flex items-center gap-4">
                            <div className="text-right mr-4">
                              <p className="text-xs text-muted-foreground">Cumulative Dose</p>
                              <p className="text-lg font-semibold text-primary">
                                {group.totalDose !== null ? `${group.totalDose.toFixed(2)} mSv` : "—"}
                              </p>
                            </div>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={(e) => {
                                e.stopPropagation();
                                navigate(`/patient/${group.patientId}`);
                              }}
                            >
                              <ExternalLink className="h-3 w-3 mr-1" />
                              Patient Overview
                            </Button>
                          </div>
                        </div>
                      </div>

                      {/* Expanded Studies List */}
                      {isPatientExpanded && (
                        <div className="border-t bg-muted/10">
                          {group.studies.map((study) => {
                            const effectiveDose = getStudyEffectiveDose(study);
                            const isFileExpanded = expandedStudies.has(study.id);

                            return (
                              <div key={study.id} className="border-b last:border-b-0">
                                <div 
                                  className="p-3 pl-14 hover:bg-accent/5 transition-colors cursor-pointer"
                                  onClick={() => navigate(`/study/${study.id}`)}
                                >
                                  <div className="flex items-center justify-between">
                                    <div className="flex-1">
                                      <div className="flex items-center gap-3 mb-1">
                                        <h4 className="font-medium text-sm">{study.study_id}</h4>
                                        <div className="flex gap-1">
                                          {study.modality_set?.map((mod: string) => (
                                            <Badge key={mod} variant="outline" className="text-xs">
                                              {mod}
                                            </Badge>
                                          ))}
                                        </div>
                                      </div>
                                      <div className="flex items-center gap-4 text-xs text-muted-foreground">
                                        <div className="flex items-center gap-1">
                                          <Calendar className="h-3 w-3" />
                                          {new Date(study.study_date).toLocaleDateString()}
                                        </div>
                                        <div className="flex items-center gap-1">
                                          <Activity className="h-3 w-3" />
                                          {study.series?.[0]?.count || 0} series
                                        </div>
                                        <button
                                          onClick={(e) => toggleStudyExpansion(study.id, e)}
                                          className="flex items-center gap-1 text-primary hover:text-primary/80"
                                        >
                                          <FolderTree className="h-3 w-3" />
                                          <span className="text-xs">Files</span>
                                          {isFileExpanded ? <ChevronDown className="h-3 w-3" /> : <ChevronRight className="h-3 w-3" />}
                                        </button>
                                        <button
                                          onClick={(e) => handleCtImageUpload(study.study_id, e)}
                                          className="flex items-center gap-1 text-blue-600 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300"
                                          disabled={folderUpload.uploading}
                                        >
                                          <Upload className="h-3 w-3" />
                                          <span className="text-xs">Upload CT</span>
                                        </button>
                                        <button
                                          onClick={(e) => handleReuploadFiles(study.study_id, study.upload_mode, e)}
                                          className="flex items-center gap-1 text-green-600 hover:text-green-700 dark:text-green-400 dark:hover:text-green-300"
                                          disabled={folderUpload.uploading}
                                        >
                                          <Upload className="h-3 w-3" />
                                          <span className="text-xs">Re-upload</span>
                                        </button>
                                        <button
                                          onClick={(e) => handleDeleteClick(study.id, study.study_id, e)}
                                          className="flex items-center gap-1 text-destructive hover:text-destructive/80"
                                          disabled={deleteStudyMutation.isPending}
                                        >
                                          <Trash2 className="h-3 w-3" />
                                          <span className="text-xs">Delete</span>
                                        </button>
                                      </div>
                                    </div>
                                    <div className="text-right">
                                      <p className="text-xs text-muted-foreground">Effective Dose</p>
                                      <p className="text-sm font-semibold text-primary">{effectiveDose}</p>
                                    </div>
                                  </div>
                                </div>
                                {isFileExpanded && (
                                  <div className="border-t bg-muted/20 p-4 pl-14">
                                    <FileTree studyId={study.study_id} />
                                  </div>
                                )}
                              </div>
                            );
                          })}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>

              {/* CT Upload Progress Indicator */}
              {folderUpload.uploading && uploadingCtForStudy && (
                <Card className="p-6 mt-6 border-blue-500/50 bg-blue-500/5">
                  <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                    <div className="h-2 w-2 bg-green-500 rounded-full animate-pulse" />
                    Uploading CT Images for Study {uploadingCtForStudy}
                  </h3>
                  <div className="space-y-3">
                    <Progress 
                      value={folderUpload.progress.totalFiles > 0 
                        ? Math.round((folderUpload.progress.uploadedFiles / folderUpload.progress.totalFiles) * 100)
                        : 0
                      } 
                      className="h-3" 
                    />
                    <div className="flex justify-between items-center">
                      <p className="text-sm font-medium">
                        {folderUpload.progress.uploadedFiles} / {folderUpload.progress.totalFiles} files (
                        {folderUpload.progress.totalFiles > 0 
                          ? Math.round((folderUpload.progress.uploadedFiles / folderUpload.progress.totalFiles) * 100)
                          : 0
                        }%)
                      </p>
                      {folderUpload.progress.skippedFiles > 0 && (
                        <p className="text-xs text-muted-foreground">
                          {folderUpload.progress.skippedFiles} already uploaded
                        </p>
                      )}
                    </div>
                    {folderUpload.progress.currentFile && (
                      <p className="text-xs text-muted-foreground truncate">
                        Current: {folderUpload.progress.currentFile}
                      </p>
                    )}
                    {folderUpload.progress.failedFiles > 0 && (
                      <div className="space-y-2">
                        <div className="flex items-center gap-2 text-destructive">
                          <XCircle className="h-4 w-4" />
                          <p className="text-xs font-medium">
                            {folderUpload.progress.failedFiles} file(s) failed
                          </p>
                        </div>
                        {folderUpload.progress.failedFileReasons.size > 0 && (
                          <div className="max-h-32 overflow-y-auto space-y-1 text-xs text-muted-foreground">
                            {Array.from(folderUpload.progress.failedFileReasons.entries()).slice(0, 5).map(([path, reason]) => (
                              <div key={path} className="border-l-2 border-destructive/30 pl-2">
                                <p className="font-mono text-[10px] truncate">{path}</p>
                                <p className="text-destructive/80">{reason.errorType}: {reason.error}</p>
                                <p className="text-[10px] text-muted-foreground">Size: {(reason.size / 1024 / 1024).toFixed(2)}MB</p>
                              </div>
                            ))}
                            {folderUpload.progress.failedFileReasons.size > 5 && (
                              <p className="text-center pt-1">
                                ...and {folderUpload.progress.failedFileReasons.size - 5} more
                              </p>
                            )}
                          </div>
                        )}
                      </div>
                    )}
                    <p className="text-xs text-amber-600 dark:text-amber-400">
                      ⚠️ Keep this page open until upload completes
                    </p>
                  </div>
                </Card>
              )}
            </>
          ) : (
            <div className="text-center py-12">
              <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground mb-2">
                {hasActiveFilters ? "No studies match your filters" : "No studies found"}
              </p>
              {hasActiveFilters && (
                <Button variant="outline" onClick={clearFilters}>
                  Clear Filters
                </Button>
              )}
            </div>
          )}
        </Card>
      </div>

      {/* Hidden file input for CT images */}
      <input
        ref={ctImageInputRef}
        type="file"
        /* @ts-ignore */
        webkitdirectory=""
        directory=""
        multiple
        className="hidden"
        onChange={handleCtFolderSelect}
      />

      {/* Hidden file input for re-upload */}
      <input
        ref={reuploadInputRef}
        type="file"
        /* @ts-ignore */
        webkitdirectory=""
        directory=""
        multiple
        className="hidden"
        onChange={handleReuploadFolderSelect}
      />

      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Study</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete study <strong>{studyToDelete?.studyId}</strong>?
              <br /><br />
              This will permanently delete:
              <ul className="list-disc ml-6 mt-2">
                <li>The study record</li>
                <li>All associated series</li>
                <li>All analysis runs</li>
                <li>All extracted files</li>
                <li>All uploaded files from storage</li>
              </ul>
              <br />
              <strong className="text-destructive">This action cannot be undone.</strong>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleteStudyMutation.isPending}>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={confirmDelete}
              disabled={deleteStudyMutation.isPending}
              className="bg-destructive hover:bg-destructive/90"
            >
              {deleteStudyMutation.isPending ? "Deleting..." : "Delete Study"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default Studies;
