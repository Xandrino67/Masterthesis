import { useParams, useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import Navigation from "@/components/Navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { StatsCard } from "@/components/ui/stats-card";
import { ArrowLeft, Calendar, User, Activity, FileText, TrendingUp } from "lucide-react";
import { useMemo } from "react";
import { normalizeOrganName } from "@/services/organMergeConfig";
import { getEffectiveDoseFromResults } from "@/services/effectiveDoseUtils";
import CumulativeOrganDoseTable, { type OrganDoseEntry } from "@/components/patient/CumulativeOrganDoseTable";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts";

const PatientDetail = () => {
  const { patientId } = useParams();
  const navigate = useNavigate();

  const { data: patient, isLoading } = useQuery({
    queryKey: ["patient-detail", patientId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("patients")
        .select("*, studies(*, analysis_runs(results, status, finished_at))")
        .eq("id", patientId)
        .single();
      if (error) throw error;

      // Sort studies by date
      if (data?.studies) {
        data.studies.sort((a: any, b: any) => 
          new Date(a.study_date).getTime() - new Date(b.study_date).getTime()
        );
      }
      return data;
    },
    enabled: !!patientId,
  });

  // Compute cumulative dose data
  const { organDoseEntries, timelineData, totalEffectiveDose, studiesWithDose } = useMemo(() => {
    if (!patient?.studies) return { organDoseEntries: [] as OrganDoseEntry[], timelineData: [], totalEffectiveDose: 0, studiesWithDose: 0 };

    // Track per-part contributions: normalized → { originalName → cumulative dose }
    const partsMap: Record<string, Record<string, number>> = {};
    let totalEffectiveDose = 0;
    let studiesWithDose = 0;
    const timelineData: Array<{ date: string; cumulativeDose: number; studyDose: number; studyId: string }> = [];

    const addOrganDose = (originalName: string, dose: number) => {
      const normalized = normalizeOrganName(originalName);
      if (!partsMap[normalized]) partsMap[normalized] = {};
      partsMap[normalized][originalName] = (partsMap[normalized][originalName] || 0) + dose;
    };

    for (const study of patient.studies as any[]) {
      const latestRun = study.analysis_runs
        ?.filter((r: any) => r.status === 'completed')
        .sort((a: any, b: any) => new Date(b.finished_at).getTime() - new Date(a.finished_at).getTime())[0];

      let studyDose = 0;
      if (latestRun?.results && typeof latestRun.results === 'object') {
        const results = latestRun.results as any;
        const effectiveDose = getEffectiveDoseFromResults(results);
        if (effectiveDose !== null) {
          studyDose = effectiveDose;
          totalEffectiveDose += studyDose;
          studiesWithDose++;
        }

        if (results.organ_doses) {
          if (Array.isArray(results.organ_doses)) {
            for (const od of results.organ_doses) {
              if (od?.organ_name && od?.d_mean) {
                addOrganDose(od.organ_name, od.d_mean);
              }
            }
          } else if (typeof results.organ_doses === 'object') {
            for (const [organ, data] of Object.entries(results.organ_doses as Record<string, any>)) {
              if (data?.d_mean) {
                addOrganDose(organ, data.d_mean);
              }
            }
          }
        }
      }

      timelineData.push({
        date: new Date(study.study_date).toLocaleDateString(),
        cumulativeDose: totalEffectiveDose,
        studyDose,
        studyId: study.study_id,
      });
    }

    // Convert partsMap into OrganDoseEntry[]
    const organDoseEntries: OrganDoseEntry[] = Object.entries(partsMap).map(([organ, partsDoses]) => {
      const parts = Object.entries(partsDoses).map(([name, dose]) => ({ name, dose }));
      const totalDose = parts.reduce((s, p) => s + p.dose, 0);
      return { organ, totalDose, parts };
    });

    return { organDoseEntries, timelineData, totalEffectiveDose, studiesWithDose };
  }, [patient]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="container mx-auto px-6 py-8">
          <div className="text-center text-muted-foreground">Loading patient data...</div>
        </div>
      </div>
    );
  }

  if (!patient) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="container mx-auto px-6 py-8">
          <div className="text-center">
            <p className="text-muted-foreground mb-4">Patient not found</p>
            <Button onClick={() => navigate("/studies")}>Back to Studies</Button>
          </div>
        </div>
      </div>
    );
  }

  const studies = (patient.studies || []) as any[];
  const dateRange = studies.length > 0
    ? `${new Date(studies[0].study_date).toLocaleDateString()} – ${new Date(studies[studies.length - 1].study_date).toLocaleDateString()}`
    : "—";

  // organDoseEntries are already computed in useMemo above

  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <div className="container mx-auto px-6 py-8">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Button variant="ghost" size="icon" onClick={() => navigate("/studies")}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div>
            <h1 className="text-3xl font-bold">{patient.pseudonym_id}</h1>
            <div className="flex items-center gap-4 text-sm text-muted-foreground mt-1">
              {patient.sex && <span>{patient.sex}</span>}
              {patient.birth_year && <span>Born {patient.birth_year}</span>}
              <span>{studies.length} {studies.length === 1 ? "study" : "studies"}</span>
            </div>
          </div>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <StatsCard
            title="Total Studies"
            value={studies.length}
            subtitle={`${studiesWithDose} with dose analysis`}
            icon={FileText}
          />
          <StatsCard
            title="Cumulative Effective Dose"
            value={studiesWithDose > 0 ? `${totalEffectiveDose.toFixed(2)} mSv` : "—"}
            subtitle={studiesWithDose > 0 ? `Across ${studiesWithDose} analyzed studies` : "No analyses completed"}
            icon={Activity}
          />
          <StatsCard
            title="Imaging Period"
            value={dateRange}
            icon={Calendar}
          />
        </div>

        {/* Cumulative Dose Over Time Chart */}
        {timelineData.length > 0 && studiesWithDose > 0 && (
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5" />
                Cumulative Effective Dose Over Time
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={timelineData}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                    <XAxis 
                      dataKey="date" 
                      className="text-xs fill-muted-foreground"
                      tick={{ fontSize: 12 }}
                    />
                    <YAxis 
                      className="text-xs fill-muted-foreground"
                      tick={{ fontSize: 12 }}
                      label={{ value: 'mSv', angle: -90, position: 'insideLeft', className: 'fill-muted-foreground' }}
                    />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: 'hsl(var(--background))', 
                        border: '1px solid hsl(var(--border))',
                        borderRadius: '8px'
                      }}
                      formatter={(value: number, name: string) => [
                        `${value.toFixed(2)} mSv`,
                        name === 'cumulativeDose' ? 'Cumulative' : 'This Study'
                      ]}
                    />
                    <Legend />
                    <Line
                      type="monotone"
                      dataKey="cumulativeDose"
                      stroke="hsl(var(--primary))"
                      strokeWidth={2}
                      dot={{ r: 4, fill: 'hsl(var(--primary))' }}
                      name="Cumulative Dose"
                    />
                    <Line
                      type="monotone"
                      dataKey="studyDose"
                      stroke="hsl(var(--muted-foreground))"
                      strokeWidth={1}
                      strokeDasharray="4 4"
                      dot={{ r: 3 }}
                      name="Per-Study Dose"
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Studies Timeline Table */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Studies Timeline</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Study ID</TableHead>
                  <TableHead>Modality</TableHead>
                  <TableHead>Effective Dose</TableHead>
                  <TableHead>Analysis Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {studies.map((study: any) => {
                  const latestRun = study.analysis_runs
                    ?.filter((r: any) => r.status === 'completed')
                    .sort((a: any, b: any) => new Date(b.finished_at).getTime() - new Date(a.finished_at).getTime())[0];
                  const results = latestRun?.results as any;
                  const doseValue = getEffectiveDoseFromResults(results);
                  const dose = doseValue !== null
                    ? `${doseValue.toFixed(2)} mSv`
                    : "—";
                  const hasAnalysis = study.analysis_runs?.some((r: any) => r.status === 'completed');

                  return (
                    <TableRow 
                      key={study.id} 
                      className="cursor-pointer hover:bg-accent/5"
                      onClick={() => navigate(`/study/${study.id}`)}
                    >
                      <TableCell>{new Date(study.study_date).toLocaleDateString()}</TableCell>
                      <TableCell className="font-mono text-sm">{study.study_id}</TableCell>
                      <TableCell>
                        <div className="flex gap-1">
                          {study.modality_set?.map((mod: string) => (
                            <Badge key={mod} variant="outline" className="text-xs">{mod}</Badge>
                          ))}
                        </div>
                      </TableCell>
                      <TableCell className="font-semibold">{dose}</TableCell>
                      <TableCell>
                        <Badge variant={hasAnalysis ? "default" : "secondary"}>
                          {hasAnalysis ? "Completed" : "Pending"}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        {/* Cumulative Organ Dose Table */}
        {organDoseEntries.length > 0 && (
          <CumulativeOrganDoseTable entries={organDoseEntries} />
        )}
      </div>
    </div>
  );
};

export default PatientDetail;
