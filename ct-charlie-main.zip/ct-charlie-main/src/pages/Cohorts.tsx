import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import Navigation from "@/components/Navigation";
import { Loader2, Plus, Users, Trash2, BarChart3 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { CohortStudySelector } from "@/components/cohorts/CohortStudySelector";

export default function Cohorts() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [selectorOpen, setSelectorOpen] = useState(false);
  const [selectedCohortId, setSelectedCohortId] = useState<string | null>(null);
  const [selectedCohortName, setSelectedCohortName] = useState("");
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    include_mock_data: false,
  });

  // Fetch cohorts with study counts
  const { data: cohorts, isLoading } = useQuery({
    queryKey: ["cohorts"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("cohorts")
        .select(`
          *,
          cohort_studies(study_id)
        `)
        .order("created_at", { ascending: false });

      if (error) throw error;
      return data.map(cohort => ({
        ...cohort,
        study_count: cohort.cohort_studies?.length || 0
      }));
    },
  });

  // Create cohort mutation
  const createCohortMutation = useMutation({
    mutationFn: async (cohortData: typeof formData) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Not authenticated");

      const { data, error } = await supabase
        .from("cohorts")
        .insert({
          ...cohortData,
          created_by: user.id,
        })
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["cohorts"] });
      toast({ title: "Cohort created successfully" });
      setIsDialogOpen(false);
      setFormData({ name: "", description: "", include_mock_data: false });
    },
    onError: (error) => {
      toast({
        title: "Failed to create cohort",
        description: error instanceof Error ? error.message : "Unknown error",
        variant: "destructive",
      });
    },
  });

  // Delete cohort mutation
  const deleteCohortMutation = useMutation({
    mutationFn: async (cohortId: string) => {
      const { error } = await supabase
        .from("cohorts")
        .delete()
        .eq("id", cohortId);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["cohorts"] });
      toast({ title: "Cohort deleted successfully" });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createCohortMutation.mutate(formData);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="container mx-auto px-4 py-8 flex items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin" />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <div className="container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-3xl font-bold">Patient Cohorts</h1>
            <p className="text-muted-foreground mt-1">
              Create and manage subsets of patients and studies for analysis
            </p>
          </div>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                New Cohort
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create New Cohort</DialogTitle>
                <DialogDescription>
                  Define a new patient cohort for analysis
                </DialogDescription>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Cohort Name</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="Q4 2024 Chest CTs"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    placeholder="Describe the purpose of this cohort..."
                    rows={3}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <Label htmlFor="include_mock">Include Mock Data</Label>
                  <Switch
                    id="include_mock"
                    checked={formData.include_mock_data}
                    onCheckedChange={(checked) => 
                      setFormData({ ...formData, include_mock_data: checked })
                    }
                  />
                </div>

                <Button type="submit" className="w-full" disabled={createCohortMutation.isPending}>
                  {createCohortMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Creating...
                    </>
                  ) : (
                    "Create Cohort"
                  )}
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        <div className="grid gap-4">
          {cohorts?.map((cohort) => (
            <Card key={cohort.id}>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="space-y-1">
                    <CardTitle className="flex items-center gap-2">
                      <Users className="h-5 w-5" />
                      {cohort.name}
                      {cohort.include_mock_data && (
                        <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">
                          Includes Mock
                        </Badge>
                      )}
                    </CardTitle>
                    {cohort.description && (
                      <CardDescription>{cohort.description}</CardDescription>
                    )}
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        setSelectedCohortId(cohort.id);
                        setSelectedCohortName(cohort.name);
                        setSelectorOpen(true);
                      }}
                    >
                      <Users className="h-4 w-4 mr-2" />
                      Manage Studies
                    </Button>
                    <Button
                      size="sm"
                      onClick={() => navigate(`/cohorts/${cohort.id}/analysis`)}
                      disabled={cohort.study_count === 0}
                    >
                      <BarChart3 className="h-4 w-4 mr-2" />
                      Analyze
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => deleteCohortMutation.mutate(cohort.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between text-sm text-muted-foreground">
                  <span>Created {new Date(cohort.created_at).toLocaleDateString()}</span>
                  <span className="font-medium">{cohort.study_count} studies</span>
                </div>
              </CardContent>
            </Card>
          ))}

          {cohorts?.length === 0 && (
            <Card>
              <CardContent className="py-12 text-center">
                <Users className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <p className="text-muted-foreground">
                  No cohorts yet. Create your first cohort to start analyzing patient subsets.
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      {/* Study Selector Dialog */}
      {selectedCohortId && (
        <CohortStudySelector
          cohortId={selectedCohortId}
          cohortName={selectedCohortName}
          open={selectorOpen}
          onOpenChange={setSelectorOpen}
        />
      )}
    </div>
  );
}