import { useParams, useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Loader2 } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { SummaryCards } from "@/components/cohorts/analysis/SummaryCards";
import { OrganDoseTable } from "@/components/cohorts/analysis/OrganDoseTable";
import { EffectiveDoseDistribution } from "@/components/cohorts/analysis/EffectiveDoseDistribution";
import { OrganDoseBoxPlots } from "@/components/cohorts/analysis/OrganDoseBoxPlots";
import { DVHComparison } from "@/components/cohorts/analysis/DVHComparison";
import { TemporalAnalysis } from "@/components/cohorts/analysis/TemporalAnalysis";
import { StatisticalTests } from "@/components/cohorts/analysis/StatisticalTests";
import { ExportDialog } from "@/components/cohorts/analysis/ExportDialog";
import { calculateDescriptiveStats, detectOutliers, OrganDoseData } from "@/services/cohortStatistics";
import { aggregateDVHCurves, DVHCurve } from "@/services/dvhAnalysis";
import { useMemo } from "react";
import { format } from "date-fns";

export default function CohortAnalysis() {
  const { id } = useParams();
  const navigate = useNavigate();

  const { data: cohort, isLoading: cohortLoading } = useQuery({
    queryKey: ['cohort', id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('cohorts')
        .select('*')
        .eq('id', id)
        .single();
      if (error) throw error;
      return data;
    }
  });

  const { data: analysisData, isLoading: analysisLoading } = useQuery({
    queryKey: ['cohort-analysis', id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('cohort_studies')
        .select(`
          study_id,
          studies!inner(
            id,
            study_id,
            study_date,
            is_mock_data,
            patient_id,
            patients!inner(
              pseudonym_id,
              sex,
              birth_year
            ),
            analysis_runs!inner(
              id,
              results,
              created_at,
              status
            )
          )
        `)
        .eq('cohort_id', id);
      
      if (error) throw error;
      return data;
    },
    enabled: !!id
  });

  const processedData = useMemo(() => {
    if (!analysisData) return null;

    const organDoseMap = new Map<string, OrganDoseData>();
    const effectiveDoses: number[] = [];
    const temporalData: any[] = [];
    const dvhCurves: DVHCurve[] = [];
    let totalPatients = new Set();
    let hasMockData = false;
    let minDate = new Date();
    let maxDate = new Date(0);
    let totalAge = 0;
    let ageCount = 0;

    analysisData.forEach((item: any) => {
      const study = item.studies;
      const patient = study.patients;
      const analysisRuns = study.analysis_runs || [];

      totalPatients.add(study.patient_id);
      if (study.is_mock_data) hasMockData = true;

      const studyDate = new Date(study.study_date);
      if (studyDate < minDate) minDate = studyDate;
      if (studyDate > maxDate) maxDate = studyDate;

      if (patient.birth_year && study.study_date) {
        const age = new Date(study.study_date).getFullYear() - patient.birth_year;
        totalAge += age;
        ageCount++;
      }

      analysisRuns.forEach((run: any) => {
        if (run.status !== 'completed' || !run.results) return;

        const results = run.results;
        
        // Calculate effective dose from organ doses if not present
        let effectiveDose = results.effective_dose?.value;
        
        if (!effectiveDose && results.organ_doses) {
          // Tissue weighting factors (ICRP 103)
          const tissueWeights: Record<string, number> = {
            'Lungs': 0.12,
            'Stomach': 0.12,
            'Colon': 0.12,
            'Liver': 0.04,
            'Esophagus': 0.04,
            'Thyroid': 0.04,
            'Skin': 0.01,
            'Bone Surface': 0.01,
            'Brain': 0.01,
            'Salivary Glands': 0.01,
            'Red Bone Marrow': 0.12,
            'Gonads': 0.08,
            'Bladder': 0.04,
            'Breast': 0.12,
            'Kidneys': 0.04,
            'Heart': 0.04,
            'Ribs': 0.01 // Using bone surface weight
          };
          
          effectiveDose = 0;
          const organDosesArray = Array.isArray(results.organ_doses) 
            ? results.organ_doses 
            : Object.values(results.organ_doses);
            
          organDosesArray.forEach((organ: any) => {
            const organName = organ.organ_name || organ.label;
            const weight = tissueWeights[organName] || 0;
            const doseMsv = (organ.d_mean || 0) * 1000; // Convert Gy to mSv
            effectiveDose! += weight * doseMsv;
          });
          
          console.log('Calculated effective dose:', effectiveDose, 'mSv');
        }
        
        if (effectiveDose && effectiveDose > 0) {
          effectiveDoses.push(effectiveDose);
          temporalData.push({
            date: study.study_date,
            effectiveDose: effectiveDose,
            studyId: study.study_id,
            patientId: patient.pseudonym_id
          });
        }

        if (results.organ_doses) {
          // Handle both array and object formats
          const organDosesArray = Array.isArray(results.organ_doses) 
            ? results.organ_doses 
            : Object.values(results.organ_doses);
            
          organDosesArray.forEach((organ: any) => {
            const key = organ.organ_name || organ.organ_id;
            const label = organ.organ_name || organ.label;
            
            if (!organDoseMap.has(key)) {
              organDoseMap.set(key, {
                organ_id: key,
                label: label,
                doses: [],
                volumes: []
              });
            }
            organDoseMap.get(key)!.doses.push(organ.d_mean);
            organDoseMap.get(key)!.volumes.push(organ.volume || organ.volume_ml);

            // Convert DVH array to DVHPoint[] format
            if (organ.dvh && Array.isArray(organ.dvh)) {
              const minDose = organ.d_min || 0;
              const maxDose = organ.d_max || 100;
              const numPoints = organ.dvh.length;
              
              const dvhPoints = organ.dvh.map((volume: number, index: number) => {
                const dose = minDose + (index * (maxDose - minDose) / (numPoints - 1));
                // DVH values are already in decimal format (0-1), convert to percentage (0-100)
                const volumePercent = typeof volume === 'number' && volume <= 1 ? volume * 100 : volume;
                return {
                  dose: dose,
                  volume: volumePercent
                };
              });
              
              console.log(`DVH for ${label}, first 3 points:`, dvhPoints.slice(0, 3));
              
              dvhCurves.push({
                organId: key,
                organLabel: label,
                studyId: study.study_id,
                points: dvhPoints
              });
            }
          });
        }
      });
    });

    const organData = Array.from(organDoseMap.values());
    const organStats = organData.map(organ => ({
      organLabel: organ.label,
      ...calculateDescriptiveStats(organ.doses)
    }));

    const allOutliers: any[] = [];
    organData.forEach(organ => {
      const outliers = detectOutliers(organ.doses, 2);
      outliers.forEach(o => {
        allOutliers.push({
          ...o,
          organ: organ.label
        });
      });
    });

    const aggregateDVHs = Array.from(
      dvhCurves.reduce((map, curve) => {
        if (!map.has(curve.organLabel)) {
          map.set(curve.organLabel, []);
        }
        map.get(curve.organLabel)!.push(curve);
        return map;
      }, new Map<string, DVHCurve[]>())
    ).map(([_, curves]) => aggregateDVHCurves(curves)).filter(Boolean) as any[];

    console.log('Processed data summary:', {
      totalStudies: analysisData.length,
      effectiveDosesCount: effectiveDoses.length,
      effectiveDoses: effectiveDoses,
      organStatsCount: organStats.length,
      aggregateDVHsCount: aggregateDVHs.length
    });

    return {
      summary: {
        totalPatients: totalPatients.size,
        totalStudies: analysisData.length,
        dateRange: {
          start: format(minDate, 'MMM yyyy'),
          end: format(maxDate, 'MMM yyyy')
        },
        meanAge: ageCount > 0 ? totalAge / ageCount : 0,
        meanEffectiveDose: effectiveDoses.length > 0 
          ? effectiveDoses.reduce((a, b) => a + b, 0) / effectiveDoses.length 
          : 0,
        sdEffectiveDose: effectiveDoses.length > 1
          ? Math.sqrt(effectiveDoses.reduce((sum, d) => {
              const mean = effectiveDoses.reduce((a, b) => a + b, 0) / effectiveDoses.length;
              return sum + Math.pow(d - mean, 2);
            }, 0) / (effectiveDoses.length - 1))
          : 0,
        hasMockData
      },
      organStats,
      organData,
      effectiveDoses,
      temporalData,
      aggregateDVHs,
      outliers: allOutliers
    };
  }, [analysisData]);

  if (cohortLoading || analysisLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!cohort) {
    return (
      <div className="container mx-auto py-8 text-center">
        <p className="text-muted-foreground mb-4">Cohort not found</p>
        <Button onClick={() => navigate('/cohorts')}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Cohorts
        </Button>
      </div>
    );
  }

  if (!processedData || processedData.summary.totalStudies === 0) {
    return (
      <div className="container mx-auto py-8">
        <div className="flex items-center gap-4 mb-6">
          <Button variant="ghost" size="icon" onClick={() => navigate('/cohorts')}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div>
            <h1 className="text-3xl font-bold">{cohort.name}</h1>
            {cohort.description && (
              <p className="text-muted-foreground">{cohort.description}</p>
            )}
          </div>
        </div>
        <div className="text-center py-12">
          <p className="text-muted-foreground mb-4">
            No analysis data available for this cohort yet. Please ensure studies have completed dose calculations.
          </p>
          <Button onClick={() => navigate('/cohorts')}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Cohorts
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8 space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => navigate('/cohorts')}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div>
            <h1 className="text-3xl font-bold">{cohort.name}</h1>
            {cohort.description && (
              <p className="text-muted-foreground">{cohort.description}</p>
            )}
          </div>
        </div>
        <ExportDialog
          cohortName={cohort.name}
          summary={processedData.summary}
          organStats={processedData.organStats}
        />
      </div>

      <SummaryCards {...processedData.summary} />

      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="dvh">DVH Analysis</TabsTrigger>
          <TabsTrigger value="temporal">Temporal</TabsTrigger>
          <TabsTrigger value="advanced">Advanced</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <OrganDoseTable organStats={processedData.organStats} />
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <EffectiveDoseDistribution doses={processedData.effectiveDoses} />
            <OrganDoseBoxPlots organStats={processedData.organStats} />
          </div>
        </TabsContent>

        <TabsContent value="dvh">
          <DVHComparison aggregateDVHs={processedData.aggregateDVHs} />
        </TabsContent>

        <TabsContent value="temporal">
          <TemporalAnalysis data={processedData.temporalData} />
        </TabsContent>

        <TabsContent value="advanced">
          <StatisticalTests 
            organData={processedData.organData}
            outliers={processedData.outliers}
          />
        </TabsContent>
      </Tabs>
    </div>
  );
}
