import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import Navigation from "@/components/Navigation";
import InstitutionsTab from "@/components/master-data/InstitutionsTab";
import DevicesTab from "@/components/master-data/DevicesTab";
import ProtocolsTab from "@/components/master-data/ProtocolsTab";
import PatientsTab from "@/components/master-data/PatientsTab";
import PhysiciansTab from "@/components/master-data/PhysiciansTab";
import OrgansTab from "@/components/master-data/OrgansTab";
import { Database, Microscope, Users, Stethoscope, FileText, Heart } from "lucide-react";

const MasterData = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <div className="container mx-auto px-6 py-8">
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 bg-primary/10 rounded-lg">
              <Database className="h-6 w-6 text-primary" />
            </div>
            <h1 className="text-3xl font-bold">Master Data Management</h1>
          </div>
          <p className="text-muted-foreground">
            Manage institutions, devices, protocols, patients, and organ definitions
          </p>
        </div>

        <Tabs defaultValue="institutions" className="space-y-6">
          <TabsList className="grid w-full grid-cols-6 lg:w-auto">
            <TabsTrigger value="institutions" className="gap-2">
              <Microscope className="h-4 w-4" />
              <span className="hidden sm:inline">Institutions</span>
            </TabsTrigger>
            <TabsTrigger value="devices" className="gap-2">
              <Microscope className="h-4 w-4" />
              <span className="hidden sm:inline">Devices</span>
            </TabsTrigger>
            <TabsTrigger value="protocols" className="gap-2">
              <FileText className="h-4 w-4" />
              <span className="hidden sm:inline">Protocols</span>
            </TabsTrigger>
            <TabsTrigger value="patients" className="gap-2">
              <Users className="h-4 w-4" />
              <span className="hidden sm:inline">Patients</span>
            </TabsTrigger>
            <TabsTrigger value="physicians" className="gap-2">
              <Stethoscope className="h-4 w-4" />
              <span className="hidden sm:inline">Physicians</span>
            </TabsTrigger>
            <TabsTrigger value="organs" className="gap-2">
              <Heart className="h-4 w-4" />
              <span className="hidden sm:inline">Organs</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="institutions" className="space-y-4">
            <InstitutionsTab />
          </TabsContent>

          <TabsContent value="devices" className="space-y-4">
            <DevicesTab />
          </TabsContent>

          <TabsContent value="protocols" className="space-y-4">
            <ProtocolsTab />
          </TabsContent>

          <TabsContent value="patients" className="space-y-4">
            <PatientsTab />
          </TabsContent>

          <TabsContent value="physicians" className="space-y-4">
            <PhysiciansTab />
          </TabsContent>

          <TabsContent value="organs" className="space-y-4">
            <OrgansTab />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default MasterData;
