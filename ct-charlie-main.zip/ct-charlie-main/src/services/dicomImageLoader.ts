import cornerstone from 'cornerstone-core';
import cornerstoneWADOImageLoader from 'cornerstone-wado-image-loader';
import dicomParser from 'dicom-parser';
import { supabase } from '@/integrations/supabase/client';
import { dicomCache } from './dicomCache';

// Initialize Cornerstone WADO Image Loader
cornerstoneWADOImageLoader.external.cornerstone = cornerstone;
cornerstoneWADOImageLoader.external.dicomParser = dicomParser;

cornerstoneWADOImageLoader.configure({
  useWebWorkers: true,
  decodeConfig: {
    convertFloatPixelDataToInt: false,
  },
});

interface DicomFile {
  id: string;
  storage_path: string;
  original_path: string;
  file_type: string;
}

interface DicomStack {
  imageIds: string[];
  currentImageIdIndex: number;
  totalSlices: number;
}

// LRU Cache for signed URLs
const urlCache = new Map<string, { url: string; expiry: number }>();
const MAX_CACHE_SIZE = 100;

/**
 * Check if a file exists in storage
 */
async function fileExistsInStorage(storagePath: string): Promise<boolean> {
  try {
    const { data, error } = await supabase.storage
      .from('dose-files')
      .list(storagePath.substring(0, storagePath.lastIndexOf('/')), {
        limit: 1,
        search: storagePath.substring(storagePath.lastIndexOf('/') + 1)
      });
    
    if (error) return false;
    return data && data.length > 0;
  } catch {
    return false;
  }
}

/**
 * Get signed URL for a storage path with caching and retry logic
 */
async function getSignedUrl(storagePath: string, retryCount = 0): Promise<string> {
  const now = Date.now();
  const MAX_RETRIES = 3;
  const RETRY_DELAY = 1000; // 1 second
  
  // Check cache
  const cached = urlCache.get(storagePath);
  if (cached && cached.expiry > now) {
    return cached.url;
  }
  
  try {
    // Generate new signed URL (1 hour expiry)
    const { data, error } = await supabase.storage
      .from('dose-files')
      .createSignedUrl(storagePath, 3600);
    
    if (error) {
      // Retry on 502 errors or network issues
      if (retryCount < MAX_RETRIES) {
        await new Promise(resolve => setTimeout(resolve, RETRY_DELAY * (retryCount + 1)));
        return getSignedUrl(storagePath, retryCount + 1);
      }
      
      throw new Error(`Failed to generate signed URL after ${MAX_RETRIES + 1} attempts: ${error.message || 'Unknown error'}`);
    }
    
    if (!data || !data.signedUrl) {
      throw new Error(`No signed URL returned for ${storagePath}`);
    }
    
    // Cache the URL
    urlCache.set(storagePath, {
      url: data.signedUrl,
      expiry: now + 3500000, // 58 minutes (slightly less than 1 hour)
    });
    
    // Cleanup old cache entries
    if (urlCache.size > MAX_CACHE_SIZE) {
      const firstKey = urlCache.keys().next().value;
      if (firstKey) urlCache.delete(firstKey);
    }
    
    return data.signedUrl;
  } catch (error) {
    // Retry on network errors
    if (retryCount < MAX_RETRIES && error instanceof Error && 
        (error.message.includes('502') || error.message.includes('network') || 
         error.message.includes('timeout') || error.message.includes('pattern'))) {
      await new Promise(resolve => setTimeout(resolve, RETRY_DELAY * (retryCount + 1)));
      return getSignedUrl(storagePath, retryCount + 1);
    }
    
    throw error;
  }
}

/**
 * Custom image loader that checks cache first and returns proper Cornerstone image
 */
async function loadCachedImage(storagePath: string): Promise<ArrayBuffer> {
  // Check cache first
  const cached = await dicomCache.get(storagePath);
  if (cached) {
    return cached;
  }

  // Not in cache, download from Supabase
  const signedUrl = await getSignedUrl(storagePath);
  const response = await fetch(signedUrl);
  if (!response.ok) {
    throw new Error(`Failed to download image: ${response.statusText}`);
  }

  const arrayBuffer = await response.arrayBuffer();
  return arrayBuffer;
}

/**
 * Register custom image loader with Cornerstone that uses cache
 * Uses wadouri: protocol to leverage existing WADO loader
 */
function registerCacheAwareLoader() {
  const originalWadouriLoader = cornerstoneWADOImageLoader.wadouri.loadImage;
  
  // Wrap the original WADO loader to check cache first
  cornerstoneWADOImageLoader.wadouri.loadImage = function(imageId: string, options?: any) {
    const storagePath = imageId.replace(/^wadouri:.*\/storage\/v1\/object\/sign\//, '')
      .split('?')[0]; // Remove signed URL params
    
    // Check if we have this in cache
    return dicomCache.get(storagePath).then(cachedBuffer => {
      if (cachedBuffer) {
        // Create a blob URL from cached data
        const blob = new Blob([cachedBuffer], { type: 'application/dicom' });
        const blobUrl = URL.createObjectURL(blob);
        const cachedImageId = `wadouri:${blobUrl}`;
        
        // Load using the original loader with the blob URL
        return originalWadouriLoader.call(this, cachedImageId, options).then((image: any) => {
          // Clean up blob URL after loading
          URL.revokeObjectURL(blobUrl);
          // Return image with original imageId
          return { ...image, imageId };
        });
      } else {
        // Not in cache, use original loader
        return originalWadouriLoader.call(this, imageId, options);
      }
    }).catch(() => {
      // If cache check fails, use original loader
      return originalWadouriLoader.call(this, imageId, options);
    });
  };
}

// Register on module load
registerCacheAwareLoader();

/**
 * Load DICOM image stack from Supabase Storage with progressive loading and caching
 */
// Store files metadata for lazy loading
let filesCache: Map<string, DicomFile[]> = new Map();

/**
 * Load DICOM image stack with lazy URL generation and file validation
 */
export async function loadDicomStack(
  studyId: string,
  fileType: 'dicom_dose' | 'dicom_other' | 'dicom_ct_fusie' | 'dicom_ct_wb' = 'dicom_dose',
  onProgress?: (loaded: number, total: number) => void
): Promise<DicomStack> {
  try {
    // Initialize cache
    await dicomCache.init();
    
    // Set memory limit for Cornerstone cache dynamically based on device memory
    const deviceMemory = (navigator as any).deviceMemory || 4; // Default to 4GB if not available
    const maxCacheSize = deviceMemory >= 8 ? 384 * 1024 * 1024 : 256 * 1024 * 1024; // 384MB for high-end, 256MB otherwise
    cornerstone.imageCache.setMaximumSizeBytes(maxCacheSize);
    console.log(`Set Cornerstone cache limit to ${maxCacheSize / (1024 * 1024)}MB based on device memory`);

    // Query extracted_files table for DICOM files
    const { data: files, error } = await supabase
      .from('extracted_files')
      .select('id, storage_path, original_path, file_type')
      .eq('study_id', studyId)
      .eq('file_type', fileType)
      .order('original_path', { ascending: true });
    
    if (error) {
      throw new Error(`Failed to fetch DICOM files: ${error.message}`);
    }
    
    if (!files || files.length === 0) {
      throw new Error(`No ${fileType} files found for study ${studyId}`);
    }
    
    console.log(`Found ${files.length} DICOM file records in database for study ${studyId}`);
    
    // Validate that files actually exist in storage (batch validation for first 10)
    const validFiles: DicomFile[] = [];
    const missingFiles: DicomFile[] = [];
    const samplesToCheck = Math.min(10, files.length);
    
    console.log(`Validating ${samplesToCheck} sample files in storage...`);
    
    for (let i = 0; i < samplesToCheck; i++) {
      const file = files[i];
      try {
        // Try to generate signed URL - this will fail if file doesn't exist
        await getSignedUrl(file.storage_path);
        validFiles.push(file as DicomFile);
      } catch (err) {
        console.warn(`File missing in storage: ${file.storage_path}`);
        missingFiles.push(file as DicomFile);
      }
    }
    
    // If all sampled files are missing, throw error
    if (validFiles.length === 0) {
      throw new Error(
        `⚠️ Geen van de DICOM bestanden kon worden gevonden in storage.\n\n` +
        `Dit betekent dat de ZIP extractie niet correct is verlopen. ` +
        `Upload de ZIP opnieuw via de Upload pagina.`
      );
    }
    
    // If some files are missing, warn but continue with available ones
    if (missingFiles.length > 0) {
      const estimatedMissing = Math.round((missingFiles.length / samplesToCheck) * files.length);
      console.warn(`⚠️ Estimated ${estimatedMissing} of ${files.length} files missing from storage`);
      
      // Import toast dynamically to show warning
      import('sonner').then(({ toast }) => {
        toast.warning(
          `${estimatedMissing} van ${files.length} bestanden ontbreken in storage. ` +
          `Deze slices kunnen niet worden geladen.`,
          { duration: 5000 }
        );
      });
    }
    
    // Assume remaining unchecked files follow the same pattern
    const filesToUse = files as DicomFile[];
    
    // Store files for lazy loading
    const cacheKey = `${studyId}-${fileType}`;
    filesCache.set(cacheKey, filesToUse);
    
    // Only generate URL and load the first VALID image immediately
    const firstValidFile = validFiles[0];
    const firstSignedUrl = await getSignedUrl(firstValidFile.storage_path);
    const firstImageId = `wadouri:${firstSignedUrl}`;
    
    // Pre-load first image
    await cornerstone.loadImage(firstImageId);
    onProgress?.(1, filesToUse.length);
    
    // Create imageIds array with lazy loader function
    const imageIds = filesToUse.map((file, index) => {
      // Use actual first valid file for index 0
      if (file.storage_path === firstValidFile.storage_path) return firstImageId;
      // Return a placeholder that will be resolved when needed
      return `lazy:${studyId}:${fileType}:${index}`;
    });
    
    return {
      imageIds,
      currentImageIdIndex: 0,
      totalSlices: filesToUse.length,
    };
  } catch (error) {
    console.error('Error loading DICOM stack:', error);
    throw error;
  }
}

/**
 * Resolve lazy image ID to actual signed URL with error handling for missing files
 */
export async function resolveLazyImageId(imageId: string): Promise<string> {
  if (!imageId.startsWith('lazy:')) {
    return imageId;
  }
  
  const [, studyId, fileType, indexStr] = imageId.split(':');
  const index = parseInt(indexStr, 10);
  const cacheKey = `${studyId}-${fileType}`;
  
  const files = filesCache.get(cacheKey);
  if (!files || !files[index]) {
    throw new Error(`Slice ${index}: Bestand niet gevonden in database`);
  }
  
  try {
    const signedUrl = await getSignedUrl(files[index].storage_path);
    return `wadouri:${signedUrl}`;
  } catch (error) {
    // Provide helpful error message
    const err = error instanceof Error ? error : new Error('Unknown error');
    throw new Error(
      `Slice ${index}: Bestand ontbreekt in storage (${files[index].storage_path}). ` +
      `Dit bestand moet opnieuw worden geüpload.`
    );
  }
}

/**
 * Pre-load adjacent slices for smooth navigation
 */
export async function preloadAdjacentSlices(
  imageIds: string[],
  currentIndex: number,
  range: number = 2 // Small window for responsive scrolling
): Promise<void> {
  const start = Math.max(0, currentIndex - range);
  const end = Math.min(imageIds.length - 1, currentIndex + range);
  
  const promises: Promise<any>[] = [];
  
  for (let i = start; i <= end; i++) {
    if (i !== currentIndex && imageIds[i]) {
      promises.push(
        (async () => {
          try {
            // Resolve lazy image ID first
            const resolvedId = await resolveLazyImageId(imageIds[i]);
            await cornerstone.loadImage(resolvedId);
          } catch (err) {
            console.warn(`Failed to preload slice ${i}:`, err);
          }
        })()
      );
    }
  }
  
  await Promise.allSettled(promises);
}

/**
 * Clear image cache to free memory
 */
export function clearImageCache(): void {
  cornerstone.imageCache.purgeCache();
  urlCache.clear();
}
