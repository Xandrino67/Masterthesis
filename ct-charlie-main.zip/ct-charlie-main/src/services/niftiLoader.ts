import * as nifti from 'nifti-reader-js';
import * as pako from 'pako';

export interface NiftiData {
  data: Float32Array | Int16Array;
  dimensions: number[];
  voxelSpacing: number[];
  header?: any; // Full NIFTI header for orientation info
}

/**
 * Merge multiple NIfTI organ masks into a single unified mask
 * All masks must have identical dimensions and voxel spacing
 * The output mask will have value 1 for any voxel where ANY input mask has value > 0
 */
export function mergeNiftiMasks(masks: NiftiData[], organName: string): NiftiData {
  if (masks.length === 0) {
    throw new Error(`No masks provided for merging (${organName})`);
  }
  
  if (masks.length === 1) {
    console.log(`Single mask for ${organName}, no merging needed`);
    return masks[0];
  }
  
  console.log(`Merging ${masks.length} masks for ${organName}`);
  
  // Use first mask as template
  const template = masks[0];
  const dimensions = template.dimensions;
  const voxelSpacing = template.voxelSpacing;
  const header = template.header;
  
  // Validate all masks have same dimensions
  for (let i = 1; i < masks.length; i++) {
    const mask = masks[i];
    if (
      mask.dimensions[0] !== dimensions[0] ||
      mask.dimensions[1] !== dimensions[1] ||
      mask.dimensions[2] !== dimensions[2]
    ) {
      throw new Error(
        `Dimension mismatch in masks for ${organName}: ` +
        `[${dimensions.join(',')}] vs [${mask.dimensions.join(',')}]`
      );
    }
  }
  
  // Create output array (Int16 for masks)
  const totalVoxels = dimensions[0] * dimensions[1] * dimensions[2];
  const mergedData = new Int16Array(totalVoxels);
  
  // Merge: union of all masks (OR operation)
  for (let i = 0; i < totalVoxels; i++) {
    let hasValue = false;
    
    for (const mask of masks) {
      if (mask.data[i] > 0) {
        hasValue = true;
        break;
      }
    }
    
    mergedData[i] = hasValue ? 1 : 0;
  }
  
  const nonZeroCount = mergedData.filter(v => v > 0).length;
  console.log(`Merged ${organName}: ${nonZeroCount} non-zero voxels out of ${totalVoxels}`);
  
  return {
    data: mergedData,
    dimensions,
    voxelSpacing,
    header
  };
}

/**
 * Load NIfTI file (.nii or .nii.gz) and return 3D array data
 * Handles both compressed and uncompressed formats
 */
export async function loadNiftiFile(file: ArrayBuffer, isCompressed: boolean = false): Promise<NiftiData> {
  try {
    let data: ArrayBuffer = file;

    // Decompress if .nii.gz
    if (isCompressed) {
      console.log('Decompressing .nii.gz file...');
      const compressed = new Uint8Array(file);
      const decompressed = pako.inflate(compressed);
      data = decompressed.buffer;
    }

    // Parse NIfTI header
    if (!nifti.isNIFTI(data)) {
      throw new Error('Invalid NIfTI file format');
    }

    const header = nifti.readHeader(data);
    if (!header) {
      throw new Error('Failed to read NIfTI header');
    }

    // Read image data
    const imageData = nifti.readImage(header, data);
    if (!imageData) {
      throw new Error('Failed to read NIfTI image data');
    }

    // Get dimensions [x, y, z]
    const dimensions = [header.dims[1], header.dims[2], header.dims[3]];
    
    // Get voxel spacing
    const voxelSpacing = [header.pixDims[1], header.pixDims[2], header.pixDims[3]];

    // Convert to appropriate typed array based on data type
    let typedData: Float32Array | Int16Array;
    
    // Calculate expected number of voxels from dimensions
    const expectedVoxels = dimensions[0] * dimensions[1] * dimensions[2];
    
    console.log(`NIfTI data type code: ${header.datatypeCode}, data buffer size: ${imageData.byteLength} bytes, expected voxels: ${expectedVoxels}`);
    
    if (header.datatypeCode === nifti.NIFTI1.TYPE_FLOAT32) {
      typedData = new Float32Array(imageData);
    } else if (header.datatypeCode === nifti.NIFTI1.TYPE_INT16) {
      typedData = new Int16Array(imageData);
    } else if (header.datatypeCode === nifti.NIFTI1.TYPE_UINT8 || header.datatypeCode === nifti.NIFTI1.TYPE_INT8) {
      // Organ masks are often stored as UINT8 (1 byte per voxel)
      // Convert to Int16Array for compatibility with calculations
      const uint8Data = new Uint8Array(imageData);
      typedData = new Int16Array(uint8Data);
      console.log(`Converted UINT8/INT8 (${uint8Data.length} values) to Int16Array`);
    } else {
      // For other data types, try to infer from byte length
      const bytesPerVoxel = imageData.byteLength / expectedVoxels;
      console.log(`Unknown data type, inferring from byte length: ${bytesPerVoxel} bytes per voxel`);
      
      if (bytesPerVoxel === 4) {
        typedData = new Float32Array(imageData);
      } else if (bytesPerVoxel === 2) {
        typedData = new Int16Array(imageData);
      } else if (bytesPerVoxel === 1) {
        // 1 byte per voxel - convert UINT8 to Int16Array
        const uint8Data = new Uint8Array(imageData);
        typedData = new Int16Array(uint8Data);
      } else {
        // Default fallback
        typedData = new Float32Array(imageData);
      }
    }

    console.log(`Loaded NIfTI: dimensions [${dimensions.join(', ')}], voxels: ${typedData.length}, expected: ${expectedVoxels}`);
    console.log(`NIFTI orientation - qform_code: ${header.qform_code}, sform_code: ${header.sform_code}`);

    return {
      data: typedData,
      dimensions,
      voxelSpacing,
      header, // Include full header for orientation transformations
    };
  } catch (error) {
    console.error('NIfTI loading error:', error);
    throw new Error(`Failed to load NIfTI file: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}

/**
 * Convert NIfTI data to Int16 for organ masks
 * Matches Matlab: organ = int16(organ);
 */
export function convertToInt16(data: Float32Array | Int16Array): Int16Array {
  if (data instanceof Int16Array) {
    return data;
  }
  return new Int16Array(data);
}
