import * as ss from 'simple-statistics';

export interface OrganDoseData {
  organ_id: string;
  label: string;
  doses: number[];
  volumes: number[];
}

export interface DescriptiveStats {
  mean: number;
  median: number;
  sd: number;
  min: number;
  max: number;
  q1: number;
  q3: number;
  iqr: number;
  cv: number; // Coefficient of variation (%)
  n: number;
}

export interface OutlierInfo {
  studyId: string;
  value: number;
  zScore: number;
  organ: string;
}

export interface CorrelationPair {
  organ1: string;
  organ2: string;
  correlation: number;
}

export function calculateDescriptiveStats(values: number[]): DescriptiveStats {
  if (values.length === 0) {
    return {
      mean: 0,
      median: 0,
      sd: 0,
      min: 0,
      max: 0,
      q1: 0,
      q3: 0,
      iqr: 0,
      cv: 0,
      n: 0
    };
  }

  const sorted = [...values].sort((a, b) => a - b);
  const mean = ss.mean(values);
  const median = ss.median(sorted);
  const sd = values.length > 1 ? ss.standardDeviation(values) : 0;
  const min = ss.min(values);
  const max = ss.max(values);
  const q1 = ss.quantile(sorted, 0.25);
  const q3 = ss.quantile(sorted, 0.75);
  const iqr = q3 - q1;
  const cv = mean !== 0 ? (sd / mean) * 100 : 0;

  return {
    mean,
    median,
    sd,
    min,
    max,
    q1,
    q3,
    iqr,
    cv,
    n: values.length
  };
}

export function calculatePercentile(values: number[], percentile: number): number {
  if (values.length === 0) return 0;
  const sorted = [...values].sort((a, b) => a - b);
  return ss.quantile(sorted, percentile / 100);
}

export function detectOutliers(values: number[], threshold: number = 2): OutlierInfo[] {
  if (values.length < 3) return [];
  
  const mean = ss.mean(values);
  const sd = ss.standardDeviation(values);
  
  const outliers: OutlierInfo[] = [];
  values.forEach((value, index) => {
    const zScore = (value - mean) / sd;
    if (Math.abs(zScore) > threshold) {
      outliers.push({
        studyId: `study-${index}`,
        value,
        zScore,
        organ: 'unknown'
      });
    }
  });
  
  return outliers;
}

export function calculateCorrelationMatrix(organData: OrganDoseData[]): number[][] {
  const n = organData.length;
  const matrix: number[][] = Array(n).fill(0).map(() => Array(n).fill(0));
  
  for (let i = 0; i < n; i++) {
    for (let j = 0; j < n; j++) {
      if (i === j) {
        matrix[i][j] = 1;
      } else if (organData[i].doses.length > 0 && organData[j].doses.length > 0) {
        try {
          matrix[i][j] = ss.sampleCorrelation(organData[i].doses, organData[j].doses);
        } catch (e) {
          matrix[i][j] = 0;
        }
      }
    }
  }
  
  return matrix;
}

export function performMannWhitneyU(group1: number[], group2: number[]): { 
  uStatistic: number; 
  pValue: number;
  significant: boolean;
} {
  // Simple implementation - in production, use a proper statistical library
  const n1 = group1.length;
  const n2 = group2.length;
  
  const combined = [
    ...group1.map(v => ({ value: v, group: 1 })),
    ...group2.map(v => ({ value: v, group: 2 }))
  ].sort((a, b) => a.value - b.value);
  
  let rank = 1;
  let r1 = 0;
  
  for (let i = 0; i < combined.length; i++) {
    const ties = combined.filter(c => c.value === combined[i].value).length;
    const avgRank = rank + (ties - 1) / 2;
    
    if (combined[i].group === 1) {
      r1 += avgRank;
    }
    
    rank += ties;
    i += ties - 1;
  }
  
  const u1 = r1 - (n1 * (n1 + 1)) / 2;
  const u2 = n1 * n2 - u1;
  const uStatistic = Math.min(u1, u2);
  
  // Simplified p-value calculation (normal approximation)
  const meanU = (n1 * n2) / 2;
  const sdU = Math.sqrt((n1 * n2 * (n1 + n2 + 1)) / 12);
  const z = Math.abs((uStatistic - meanU) / sdU);
  const pValue = 2 * (1 - normalCDF(z));
  
  return {
    uStatistic,
    pValue,
    significant: pValue < 0.05
  };
}

function normalCDF(z: number): number {
  return (1 + erf(z / Math.sqrt(2))) / 2;
}

function erf(x: number): number {
  // Approximation of error function
  const sign = x >= 0 ? 1 : -1;
  x = Math.abs(x);
  
  const a1 = 0.254829592;
  const a2 = -0.284496736;
  const a3 = 1.421413741;
  const a4 = -1.453152027;
  const a5 = 1.061405429;
  const p = 0.3275911;
  
  const t = 1.0 / (1.0 + p * x);
  const y = 1.0 - (((((a5 * t + a4) * t) + a3) * t + a2) * t + a1) * t * Math.exp(-x * x);
  
  return sign * y;
}

export function calculateMovingAverage(values: number[], windowSize: number): number[] {
  const result: number[] = [];
  
  for (let i = 0; i < values.length; i++) {
    const start = Math.max(0, i - Math.floor(windowSize / 2));
    const end = Math.min(values.length, i + Math.ceil(windowSize / 2));
    const window = values.slice(start, end);
    result.push(ss.mean(window));
  }
  
  return result;
}

export function calculateTrendLine(xValues: number[], yValues: number[]): { 
  slope: number; 
  intercept: number;
  rSquared: number;
  predictions: number[];
} {
  if (xValues.length < 2 || xValues.length !== yValues.length) {
    return { slope: 0, intercept: 0, rSquared: 0, predictions: [] };
  }
  
  const points: [number, number][] = xValues.map((x, i) => [x, yValues[i]]);
  const result = ss.linearRegression(points);
  const predictions = xValues.map(x => result.m * x + result.b);
  
  const yMean = ss.mean(yValues);
  const ssTotal = yValues.reduce((sum, y) => sum + Math.pow(y - yMean, 2), 0);
  const ssResidual = yValues.reduce((sum, y, i) => sum + Math.pow(y - predictions[i], 2), 0);
  const rSquared = ssTotal !== 0 ? 1 - (ssResidual / ssTotal) : 0;
  
  return {
    slope: result.m,
    intercept: result.b,
    rSquared,
    predictions
  };
}

export function categorizeRisk(effectiveDose: number): 'low' | 'medium' | 'high' {
  if (effectiveDose < 3) return 'low';
  if (effectiveDose <= 10) return 'medium';
  return 'high';
}

export function calculateLifetimeRisk(effectiveDose: number): number {
  // ICRP-103: approximately 5.5% per Sv for whole population
  return effectiveDose * 0.0055;
}
