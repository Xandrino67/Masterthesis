import { supabase } from "@/integrations/supabase/client";
import { parseDicomFile, calculateMeanMAs, DicomMetadata } from "./dicomParser";
import { loadNiftiFile, convertToInt16, NiftiData, mergeNiftiMasks } from "./niftiLoader";
import { 
  multiplyArrays, 
  meanNonZero, 
  dimensionsMatch, 
  calculateVolume,
  calculateStatistics,
  calculateDVH
} from "./arrayOperations";
import { ORGAN_MERGE_MAPPINGS, getOrganFromPath, getIndividualOrganFromPath } from "./organMergeConfig";
import { resolveStudyId } from "./studyIdResolver";

/**
 * Conversion constant from Matlab
 * Formula: 0.00001 × 21.88406 = 0.0002188406
 */
const CONVERSION_FACTOR = 0.00001 * 21.88406;

/**
 * Organ file mappings (matching Matlab script)
 */
export const ORGAN_MAPPINGS = {
  'Liver': ['liver.nii', 'lever.nii'],
  'Esophagus': ['esophagus.nii', 'slokdarm.nii'],
  'Kidneys': ['nieren.nii', 'kidneys.nii'],
  'Vertebrae': ['wervel.nii', 'vertebrae.nii'],
  'Ribs': ['ribben.nii', 'ribs.nii'],
  'Heart': ['hart.nii', 'heart.nii'],
  'Lungs': ['longen.nii', 'lungs.nii']
};

export interface OrganDoseResult {
  organ_name: string;
  d_mean: number;
  d_min: number;
  d_max: number;
  d_median: number;
  d_p5: number;
  d_p95: number;
  volume_ml: number;
  unit: string;
  relative_dose: number;
  dvh_cumulative?: number[][]; // [dose, volume%] pairs for cumulative DVH
  status: 'success' | 'dimension_mismatch' | 'file_not_found' | 'error';
  error_message?: string;
}

export interface CalculationProgress {
  stage: string;
  current: number;
  total: number;
  message: string;
}

/**
 * Download file from Supabase storage as ArrayBuffer with retry logic and detailed error reporting
 */
async function downloadFile(bucket: string, path: string, maxRetries: number = 3): Promise<ArrayBuffer> {
  let lastError: any = null;
  
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      // Verify authentication
      const { data: { user }, error: authError } = await supabase.auth.getUser();
      
      if (authError || !user) {
        throw new Error(`Authentication required. User: ${user?.id || 'not authenticated'}`);
      }
      
      console.log(`[Download attempt ${attempt}/${maxRetries}] Bucket: ${bucket}, Path: ${path}, User: ${user.id}`);
      
      // Attempt download
      const { data, error } = await supabase.storage
        .from(bucket)
        .download(path);

      if (error) {
        lastError = error;
        
        // Create detailed error object
        const errorDetails = {
          attempt,
          bucket,
          path,
          userId: user.id,
          errorObject: error,
          errorString: JSON.stringify(error, null, 2),
          timestamp: new Date().toISOString()
        };
        
        console.error(`Download attempt ${attempt} failed:`, errorDetails);
        
        // If this isn't the last attempt, wait before retrying
        if (attempt < maxRetries) {
          const delayMs = 1000 * attempt; // Exponential backoff: 1s, 2s, 3s
          console.log(`Retrying in ${delayMs}ms...`);
          await new Promise(resolve => setTimeout(resolve, delayMs));
          continue;
        }
        
        // Last attempt failed, throw detailed error
        throw new Error(`Failed to download file after ${maxRetries} attempts: ${JSON.stringify(errorDetails, null, 2)}`);
      }

      // Success!
      console.log(`[Download success] ${path} (${data.size} bytes)`);
      return await data.arrayBuffer();
      
    } catch (error) {
      lastError = error;
      
      if (attempt === maxRetries) {
        // Re-throw the error on last attempt
        throw error;
      }
      
      // Log and retry
      console.error(`Attempt ${attempt} exception:`, error);
      const delayMs = 1000 * attempt;
      await new Promise(resolve => setTimeout(resolve, delayMs));
    }
  }
  
  // Should never reach here, but just in case
  throw new Error(`Download failed after ${maxRetries} attempts: ${lastError}`);
}

/**
 * Main dose calculation function
 * Replicates the exact Matlab workflow from OrgaandosisV5-3.m
 */
export async function calculateOrganDoses(
  studyId: string,
  onProgress?: (progress: CalculationProgress) => void,
  useOldMethod: boolean = false,
  calculateAllOrgans: boolean = false
): Promise<{
  meanmAs: number;
  metadata: {
    patient_sex?: string;
    device_model?: string;
    num_dicom_files: number;
    num_organs_processed: number;
  };
  organ_doses: OrganDoseResult[];
}> {
  
  // Step 0: Resolve study_id - handle both UUID (from studies.id) and text (studies.study_id)
  onProgress?.({ stage: 'init', current: 0, total: 100, message: 'Initializing calculation...' });
  
  const actualStudyId = await resolveStudyId(studyId);
  console.log(`Using study_id for file queries: ${actualStudyId}`);
  
  // Step 1: Get all DICOM dose files
  onProgress?.({ stage: 'dicom', current: 0, total: 100, message: 'Loading DICOM files...' });
  
  const { data: dicomFiles, error: dicomError } = await supabase
    .from('extracted_files')
    .select('*')
    .eq('study_id', actualStudyId)
    .eq('file_type', 'dicom_dose')
    .order('original_path');

  if (dicomError) {
    throw new Error(`Failed to fetch DICOM files: ${dicomError.message}`);
  }

  if (!dicomFiles || dicomFiles.length === 0) {
    throw new Error('No DICOM files found for this study');
  }

  // Step 2: Parse DICOM metadata from all files
  onProgress?.({ stage: 'dicom', current: 10, total: 100, message: `Parsing DICOM files (0/${dicomFiles.length})...` });
  
  const metadataArray: DicomMetadata[] = [];
  
  // Process files in parallel batches for much faster execution
  const BATCH_SIZE = 10;
  
  for (let i = 0; i < dicomFiles.length; i += BATCH_SIZE) {
    const batch = dicomFiles.slice(i, i + BATCH_SIZE);
    
    try {
      // Download and parse all files in batch concurrently
      const batchResults = await Promise.all(
        batch.map(async (file) => {
          const arrayBuffer = await downloadFile(file.storage_bucket, file.storage_path);
          return parseDicomFile(arrayBuffer);
        })
      );
      
      metadataArray.push(...batchResults);
      
      // Update progress after each batch
      const processed = i + batch.length;
      onProgress?.({ 
        stage: 'dicom', 
        current: 10 + (processed / dicomFiles.length) * 20, 
        total: 100, 
        message: `Parsing DICOM files (${processed}/${dicomFiles.length})...` 
      });
    } catch (error) {
      console.error(`Failed to parse DICOM batch starting at index ${i}:`, error);
      throw error;
    }
  }

  // Step 3: Calculate mean mAs (matches Matlab: meanmAs = mean(mA .* (exposureTime / 1000)))
  onProgress?.({ stage: 'calculation', current: 30, total: 100, message: 'Calculating mean mAs...' });
  const meanmAs = calculateMeanMAs(metadataArray);

  // Step 4: Load dose distribution NIfTI file
  onProgress?.({ stage: 'dose', current: 35, total: 100, message: 'Loading dose distribution...' });
  
  const { data: doseFiles, error: doseError } = await supabase
    .from('extracted_files')
    .select('*')
    .eq('study_id', actualStudyId)
    .eq('file_type', 'nifti_dose')
    .limit(1);

  if (doseError || !doseFiles || doseFiles.length === 0) {
    throw new Error(
      'No dose distribution NIfTI file found. ' +
      'Please ensure DICOM files have been converted to NIfTI format (.nii or .nii.gz) ' +
      'and are located in the DoseDistribution_WB_CT_NM folder.'
    );
  }

  const doseArrayBuffer = await downloadFile(
    doseFiles[0].storage_bucket,
    doseFiles[0].storage_path
  );
  
  const isCompressed = doseFiles[0].storage_path.endsWith('.gz');
  const doseData = await loadNiftiFile(doseArrayBuffer, isCompressed);

  // Step 5: Fetch organ mask files
  onProgress?.({ stage: 'organs', current: 40, total: 100, message: 'Fetching organ masks...' });

  // Declare organResults before branching to either method
  let organResults: OrganDoseResult[] = [];

  if (useOldMethod) {
    console.log('⚠️ Using OLD METHOD (full-volume Niftis) for comparison');
    
    // OLD METHOD: Keep existing logic
    const { data: allOrganFiles, error: organError } = await supabase
    .from('extracted_files')
    .select('*')
    .eq('study_id', actualStudyId)
    .eq('file_type', 'nifti_mask');

  if (organError) {
    throw new Error(`Failed to fetch organ mask files: ${organError.message}`);
  }

  // Build lookup map by organ_name for fast access
  const organFileMap = new Map<string, typeof allOrganFiles[0]>();
  allOrganFiles?.forEach(file => {
    if (file.organ_name) {
      organFileMap.set(file.organ_name, file);
    }
  });

  console.log(`Found ${allOrganFiles?.length || 0} organ mask files`);
  console.log('Organ file map:', Array.from(organFileMap.keys()));

  // Step 6: Process each organ
  onProgress?.({ stage: 'organs', current: 42, total: 100, message: `Processing organs (0/${Object.keys(ORGAN_MAPPINGS).length})...` });

  const organs = Object.keys(ORGAN_MAPPINGS);

  for (let i = 0; i < organs.length; i++) {
    const organName = organs[i];
    const possibleFilenames = ORGAN_MAPPINGS[organName as keyof typeof ORGAN_MAPPINGS];
    
    onProgress?.({ 
      stage: 'organs', 
      current: 42 + ((i + 1) / organs.length) * 53, 
      total: 100, 
      message: `Processing ${organName} (${i + 1}/${organs.length})...` 
    });

    try {
      // Find organ mask file using organ_name lookup first
      let organFile = organFileMap.get(organName);
      
      // Fallback: search by filename patterns if organ_name not set
      // PRIORITIZE full-volume .nii files over compressed .nii.gz files
      if (!organFile) {
        // First, try to find uncompressed .nii files (full-volume masks)
        organFile = allOrganFiles?.find(f => 
          f.original_path.endsWith('.nii') &&
          !f.original_path.endsWith('.nii.gz') &&
          possibleFilenames.some(name => 
            f.original_path.toLowerCase().includes(name.toLowerCase())
          )
        );
        
        // Fallback: if no .nii found, try .nii.gz (but these will likely have dimension mismatches)
        if (!organFile) {
          organFile = allOrganFiles?.find(f => 
            possibleFilenames.some(name => 
              f.original_path.toLowerCase().includes(name.toLowerCase())
            )
          );
        }
      }

      if (!organFile) {
        console.warn(`Organ mask not found for ${organName}`);
        organResults.push({
          organ_name: organName,
          d_mean: 0,
          d_min: 0,
          d_max: 0,
          d_median: 0,
          d_p5: 0,
          d_p95: 0,
          volume_ml: 0,
          unit: 'mGy',
          relative_dose: 0,
          status: 'file_not_found',
          error_message: 'Organ mask file not found'
        });
        continue;
      }

      // Diagnostic logging
      console.log(`Processing ${organName}:`);
      console.log(`  - File: ${organFile.original_path}`);
      console.log(`  - Size: ${organFile.file_size} bytes (${(organFile.file_size / 1024 / 1024).toFixed(2)} MB)`);
      console.log(`  - Compressed: ${organFile.storage_path.endsWith('.gz') ? 'Yes' : 'No'}`);
      
      // Load organ mask
      const organArrayBuffer = await downloadFile(
        organFile.storage_bucket,
        organFile.storage_path
      );
      
      const organIsCompressed = organFile.storage_path.endsWith('.gz');
      const organData = await loadNiftiFile(organArrayBuffer, organIsCompressed);

      // Log dimensions
      console.log(`  - Organ dimensions: ${organData.dimensions.join('×')} = ${organData.dimensions.reduce((a, b) => a * b, 1)} voxels`);
      console.log(`  - Dose dimensions: ${doseData.dimensions.join('×')} = ${doseData.dimensions.reduce((a, b) => a * b, 1)} voxels`);

      // Convert to int16 (matches Matlab: organ = int16(organ))
      const organInt16 = convertToInt16(organData.data);

      // Check dimensions match (matches Matlab: isequal(size(dosedistribution), size(organ)))
      if (!dimensionsMatch(doseData.dimensions, organData.dimensions)) {
        console.warn(`❌ Dimension mismatch for ${organName}: dose ${doseData.dimensions.join('×')} vs organ ${organData.dimensions.join('×')}`);
        organResults.push({
          organ_name: organName,
          d_mean: 0,
          d_min: 0,
          d_max: 0,
          d_median: 0,
          d_p5: 0,
          d_p95: 0,
          volume_ml: 0,
          unit: 'mGy',
          relative_dose: 0,
          status: 'dimension_mismatch',
          error_message: `Dimension mismatch: dose [${doseData.dimensions.join(', ')}] vs organ [${organData.dimensions.join(', ')}]`
        });
        continue;
      }

      // Element-wise multiplication (matches Matlab: dosedistribution .* organ)
      const maskedDose = multiplyArrays(doseData.data, organInt16, doseData.dimensions);

      // Calculate relative dose (matches Matlab: relDose = mean(nonzeros(dosedistribution .* organ)))
      const relDose = meanNonZero(maskedDose);

      // Calculate absolute dose (matches Matlab: absDose = 0.00001 * relDose * 21.88406 * meanmAs)
      // Result is in mGy (matching Matlab output)
      const absDose = CONVERSION_FACTOR * relDose * meanmAs;

      // Calculate volume
      const volumeMl = calculateVolume(organInt16, organData.voxelSpacing);

      // Calculate additional statistics
      const stats = calculateStatistics(maskedDose);

      // Convert statistics to absolute dose in mGy (matching Matlab output)
      const statsAbs = {
        d_min: CONVERSION_FACTOR * stats.min * meanmAs,
        d_max: CONVERSION_FACTOR * stats.max * meanmAs,
        d_median: CONVERSION_FACTOR * stats.median * meanmAs,
        d_p5: CONVERSION_FACTOR * stats.p5 * meanmAs,
        d_p95: CONVERSION_FACTOR * stats.p95 * meanmAs,
      };

      // Calculate DVH with relative dose units (bin width = 0.1)
      const dvhRelative = calculateDVH(maskedDose, organInt16, 0.1, 200);
      
      // Convert DVH doses from relative to absolute units (mGy)
      const dvhAbsolute = dvhRelative.map(([dose, volumePercent]) => [
        CONVERSION_FACTOR * dose * meanmAs,
        volumePercent
      ]);

      organResults.push({
        organ_name: organName,
        d_mean: absDose,
        ...statsAbs,
        volume_ml: volumeMl,
        unit: 'mGy',
        relative_dose: relDose,
        dvh_cumulative: dvhAbsolute,
        status: 'success'
      });

      console.log(`${organName}: ${absDose.toFixed(3)} mGy (volume: ${volumeMl.toFixed(1)} ml)`);

    } catch (error) {
      console.error(`Error processing ${organName}:`, error);
      organResults.push({
        organ_name: organName,
        d_mean: 0,
        d_min: 0,
        d_max: 0,
        d_median: 0,
        d_p5: 0,
        d_p95: 0,
        volume_ml: 0,
        unit: 'mGy',
        relative_dose: 0,
        status: 'error',
        error_message: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  }
  } else {
    // NEW METHOD: Use TotalSegmentator segmentations with merging
    console.log('✅ Using NEW METHOD (TotalSegmentator segmentations)');
    
    // Fetch ALL files from segmentations folder
    const { data: allSegmentationFiles, error: segError } = await supabase
      .from('extracted_files')
      .select('*')
      .eq('study_id', actualStudyId)
      .eq('file_type', 'nifti_mask')
      .like('storage_path', '%TotalSegmentator/segmentations%');

    if (segError) {
      throw new Error(`Failed to fetch segmentation files: ${segError.message}`);
    }

    console.log(`Found ${allSegmentationFiles?.length || 0} segmentation files`);
    console.log(`Calculate all organs: ${calculateAllOrgans}`);

    // Group files by target organ
    const organFileGroups = new Map<string, typeof allSegmentationFiles>();
    
    for (const file of allSegmentationFiles || []) {
      const mergedOrganName = getOrganFromPath(file.storage_path);
      
      if (mergedOrganName) {
        // This file belongs to a merged organ group
        if (!organFileGroups.has(mergedOrganName)) {
          organFileGroups.set(mergedOrganName, []);
        }
        organFileGroups.get(mergedOrganName)!.push(file);
      } else if (calculateAllOrgans) {
        // In "all organs" mode, treat unmatched files as individual organs
        const individualName = getIndividualOrganFromPath(file.storage_path);
        if (!organFileGroups.has(individualName)) {
          organFileGroups.set(individualName, []);
        }
        organFileGroups.get(individualName)!.push(file);
      }
    }

    console.log('Organ groups:', Array.from(organFileGroups.keys()));

    // Step 6: Process each organ
    onProgress?.({ 
      stage: 'organs', 
      current: 42, 
      total: 100, 
      message: `Processing organs (0/${organFileGroups.size})...` 
    });

    const organNames = Array.from(organFileGroups.keys());

    for (let i = 0; i < organNames.length; i++) {
      const organName = organNames[i];
      const files = organFileGroups.get(organName)!;
      
      onProgress?.({ 
        stage: 'organs', 
        current: 42 + ((i + 1) / organNames.length) * 53, 
        total: 100, 
        message: `Processing ${organName} (${i + 1}/${organNames.length})...` 
      });

      try {
        console.log(`Processing ${organName} from ${files.length} file(s)`);

        // Load all component masks
        const loadedMasks: NiftiData[] = [];
        
        for (const file of files) {
          try {
            const arrayBuffer = await downloadFile(
              file.storage_bucket,
              file.storage_path
            );
            
            const isCompressed = file.storage_path.endsWith('.gz');
            const maskData = await loadNiftiFile(arrayBuffer, isCompressed);
            loadedMasks.push(maskData);
            
            console.log(`  - Loaded ${file.original_path} (${maskData.dimensions.join('×')})`);
          } catch (error) {
            console.error(`  - Failed to load ${file.original_path}:`, error);
          }
        }

        if (loadedMasks.length === 0) {
          throw new Error(`No valid masks loaded for ${organName}`);
        }

        // Merge masks
        const organData = mergeNiftiMasks(loadedMasks, organName);

        // Convert to int16
        const organInt16 = convertToInt16(organData.data);

        // Check dimensions match
        if (!dimensionsMatch(doseData.dimensions, organData.dimensions)) {
          console.warn(
            `❌ Dimension mismatch for ${organName}: ` +
            `dose ${doseData.dimensions.join('×')} vs organ ${organData.dimensions.join('×')}`
          );
          organResults.push({
            organ_name: organName,
            d_mean: 0,
            d_min: 0,
            d_max: 0,
            d_median: 0,
            d_p5: 0,
            d_p95: 0,
            volume_ml: 0,
            unit: 'mGy',
            relative_dose: 0,
            status: 'dimension_mismatch',
            error_message: `Dimension mismatch: dose [${doseData.dimensions.join(', ')}] vs organ [${organData.dimensions.join(', ')}]`
          });
          continue;
        }

        // Element-wise multiplication
        const maskedDose = multiplyArrays(doseData.data, organInt16, doseData.dimensions);

        // Calculate relative dose
        const relDose = meanNonZero(maskedDose);

        // Calculate absolute dose (mGy)
        const absDose = CONVERSION_FACTOR * relDose * meanmAs;

        // Calculate volume
        const volumeMl = calculateVolume(organInt16, organData.voxelSpacing);

        // Calculate additional statistics
        const stats = calculateStatistics(maskedDose);

        // Convert statistics to absolute dose
        const statsAbs = {
          d_min: CONVERSION_FACTOR * stats.min * meanmAs,
          d_max: CONVERSION_FACTOR * stats.max * meanmAs,
          d_median: CONVERSION_FACTOR * stats.median * meanmAs,
          d_p5: CONVERSION_FACTOR * stats.p5 * meanmAs,
          d_p95: CONVERSION_FACTOR * stats.p95 * meanmAs,
        };

        // Calculate DVH
        const dvhRelative = calculateDVH(maskedDose, organInt16, 0.1, 200);
        const dvhAbsolute = dvhRelative.map(([dose, volumePercent]) => [
          CONVERSION_FACTOR * dose * meanmAs,
          volumePercent
        ]);

        organResults.push({
          organ_name: organName,
          d_mean: absDose,
          ...statsAbs,
          volume_ml: volumeMl,
          unit: 'mGy',
          relative_dose: relDose,
          dvh_cumulative: dvhAbsolute,
          status: 'success'
        });

        console.log(`✅ ${organName}: ${absDose.toFixed(3)} mGy (volume: ${volumeMl.toFixed(1)} ml)`);

      } catch (error) {
        console.error(`Error processing ${organName}:`, error);
        organResults.push({
          organ_name: organName,
          d_mean: 0,
          d_min: 0,
          d_max: 0,
          d_median: 0,
          d_p5: 0,
          d_p95: 0,
          volume_ml: 0,
          unit: 'mGy',
          relative_dose: 0,
          status: 'error',
          error_message: error instanceof Error ? error.message : 'Unknown error'
        });
      }
    }
  }

  onProgress?.({ stage: 'complete', current: 100, total: 100, message: 'Calculation complete!' });

  return {
    meanmAs,
    metadata: {
      patient_sex: metadataArray[0]?.patientSex,
      device_model: metadataArray[0]?.manufacturerModelName,
      num_dicom_files: dicomFiles.length,
      num_organs_processed: organResults.filter(r => r.status === 'success').length
    },
    organ_doses: organResults
  };
}
