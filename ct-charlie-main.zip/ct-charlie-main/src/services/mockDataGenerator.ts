import { supabase } from "@/integrations/supabase/client";

// Organ-specific realistic dose ranges (in Gy)
const organBaseRanges = {
  Lungs: { min: 0.015, mean: 0.021, max: 0.045, volume: 4500 },
  Heart: { min: 0.018, mean: 0.023, max: 0.040, volume: 750 },
  Liver: { min: 0.020, mean: 0.028, max: 0.050, volume: 1500 },
  Kidneys: { min: 0.019, mean: 0.025, max: 0.042, volume: 300 },
  Ribs: { min: 0.030, mean: 0.046, max: 0.085, volume: 800 },
  Vertebrae: { min: 0.028, mean: 0.040, max: 0.070, volume: 600 },
  Esophagus: { min: 0.012, mean: 0.018, max: 0.032, volume: 150 },
};

type OrganName = keyof typeof organBaseRanges;

interface MockDataParams {
  numPatients: number;
  studiesPerPatient: { min: number; max: number };
  dateRange: { start: Date; end: Date };
  onProgress?: (progress: number, message: string) => void;
}

// Generate realistic DVH histogram (100 bins)
function generateDVH(mean: number, min: number, max: number): number[] {
  const dvh: number[] = [];
  const numBins = 100;
  
  for (let i = 0; i < numBins; i++) {
    const doseLevel = min + (max - min) * (i / numBins);
    // Gamma distribution-like shape for realistic DVH
    const x = (doseLevel - min) / (mean - min);
    const volume = Math.exp(-2 * x) * (1 + Math.random() * 0.1);
    dvh.push(Math.max(0, Math.min(1, volume)));
  }
  
  return dvh;
}

// Generate realistic organ dose with proper statistics
function generateOrganDose(organName: OrganName, variation: number = 1.0) {
  const base = organBaseRanges[organName];
  
  // Apply variation (±30% for different scans)
  const variationFactor = 0.7 + Math.random() * 0.6 * variation;
  
  const mean = base.mean * variationFactor;
  const min = base.min * variationFactor * 0.8;
  const max = base.max * variationFactor * 1.2;
  
  // Generate percentiles with proper ordering
  const d_p5 = min + (mean - min) * 0.3;
  const d_median = mean * 0.95;
  const d_p95 = mean + (max - mean) * 0.6;
  
  const volume = base.volume * (0.95 + Math.random() * 0.1);
  
  return {
    organ_name: organName,
    d_mean: mean,
    d_min: min,
    d_max: max,
    d_median,
    d_p5,
    d_p95,
    volume,
    unit: "Gy",
    dvh: generateDVH(mean, min, max),
  };
}

export async function generateMockData(params: MockDataParams) {
  const { numPatients, studiesPerPatient, dateRange, onProgress } = params;
  
  let totalProgress = 0;
  const totalSteps = numPatients * ((studiesPerPatient.min + studiesPerPatient.max) / 2);
  
  const updateProgress = (message: string) => {
    totalProgress++;
    const percentage = Math.round((totalProgress / totalSteps) * 100);
    onProgress?.(percentage, message);
  };

  try {
    // Get current user
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error("User must be authenticated");

    // Get existing devices and protocols for linking
    const { data: devices } = await supabase.from("devices").select("id").limit(10);
    const { data: protocols } = await supabase.from("protocols").select("id").limit(10);
    const { data: institutions } = await supabase.from("institutions").select("id").limit(5);

    const deviceIds = devices?.map(d => d.id) || [];
    const protocolIds = protocols?.map(p => p.id) || [];
    const institutionIds = institutions?.map(i => i.id) || [];

    for (let p = 0; p < numPatients; p++) {
      // Create mock patient
      const patientData = {
        pseudonym_id: `MOCK-PT-${String(p + 1).padStart(4, "0")}`,
        birth_year: 1940 + Math.floor(Math.random() * 60),
        sex: Math.random() > 0.5 ? "M" : "F",
        is_mock_data: true,
        created_by: user.id,
      };

      const { data: patient, error: patientError } = await supabase
        .from("patients")
        .insert(patientData)
        .select()
        .single();

      if (patientError || !patient) {
        console.error("Failed to create patient:", patientError);
        continue;
      }

      updateProgress(`Created patient ${patientData.pseudonym_id}`);

      // Generate studies for this patient
      const numStudies = 
        studiesPerPatient.min + 
        Math.floor(Math.random() * (studiesPerPatient.max - studiesPerPatient.min + 1));

      for (let s = 0; s < numStudies; s++) {
        // Random date within range
        const timeRange = dateRange.end.getTime() - dateRange.start.getTime();
        const studyTime = dateRange.start.getTime() + Math.random() * timeRange;
        const studyDate = new Date(studyTime).toISOString().split("T")[0];

        const studyData = {
          study_id: `MOCK-ST-${patientData.pseudonym_id}-${studyDate}`,
          patient_id: patient.id,
          study_date: studyDate,
          device_id: deviceIds.length > 0 ? deviceIds[Math.floor(Math.random() * deviceIds.length)] : null,
          protocol_id: protocolIds.length > 0 ? protocolIds[Math.floor(Math.random() * protocolIds.length)] : null,
          institution_id: institutionIds.length > 0 ? institutionIds[Math.floor(Math.random() * institutionIds.length)] : null,
          modality_set: ["CT" as const],
          is_mock_data: true,
          created_by: user.id,
        };

        const { data: study, error: studyError } = await supabase
          .from("studies")
          .insert([studyData])
          .select()
          .single();

        if (studyError || !study) {
          console.error("Failed to create study:", studyError);
          continue;
        }

        // Generate realistic analysis results
        const mean_mAs = 150 + Math.random() * 40;
        const organResults: any = {};

        Object.keys(organBaseRanges).forEach((organName) => {
          organResults[organName] = generateOrganDose(
            organName as OrganName,
            0.8 + Math.random() * 0.4
          );
        });

        const analysisData = {
          study_id: study.id,
          run_id: `MOCK-RUN-${study.study_id}`,
          status: "completed" as const,
          started_at: new Date().toISOString(),
          finished_at: new Date().toISOString(),
          results: {
            mean_mAs,
            metadata: {
              studyId: study.study_id,
              patientId: patientData.pseudonym_id,
            },
            organ_doses: organResults,
          },
          is_mock_data: true,
          created_by: user.id,
        };

        await supabase.from("analysis_runs").insert([analysisData]);

        updateProgress(`Created study ${studyData.study_id} with analysis`);
      }
    }

    onProgress?.(100, "Mock data generation complete!");
    return { success: true, patientsCreated: numPatients };
  } catch (error) {
    console.error("Error generating mock data:", error);
    throw error;
  }
}