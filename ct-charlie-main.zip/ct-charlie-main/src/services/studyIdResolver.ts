/**
 * Study ID Resolver
 * Resolves study UUIDs to folder names for file queries
 */

import { supabase } from '@/integrations/supabase/client';

/**
 * Resolve a study UUID to its folder name (study_id)
 * If the input is already a folder name (not a UUID), return it as-is
 */
export async function resolveStudyId(studyIdOrUuid: string): Promise<string> {
  // Check if it's a UUID format (contains hyphens and is 36 chars)
  const isUuid = studyIdOrUuid.includes('-') && studyIdOrUuid.length === 36;
  
  if (!isUuid) {
    // Already a folder name
    return studyIdOrUuid;
  }
  
  // Look up the study_id (folder name) from the studies table
  const { data, error } = await supabase
    .from('studies')
    .select('study_id')
    .eq('id', studyIdOrUuid)
    .single();
  
  if (error || !data) {
    console.warn(`Could not resolve UUID ${studyIdOrUuid} to study_id, using UUID as fallback`);
    return studyIdOrUuid;
  }
  
  console.log(`Resolved UUID ${studyIdOrUuid} -> study_id: ${data.study_id}`);
  return data.study_id;
}
