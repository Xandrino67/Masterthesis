/**
 * Configuration for merging multi-part organs from TotalSegmentator
 * Maps unified organ names to their component file patterns
 */

export const ORGAN_MERGE_MAPPINGS: Record<string, string[]> = {
  'Lungs': [
    'lung_lower_lobe_left',
    'lung_lower_lobe_right', 
    'lung_middle_lobe_right',
    'lung_upper_lobe_left',
    'lung_upper_lobe_right'
  ],
  'Heart': [
    'heart_atrium_left',
    'heart_atrium_right',
    'heart_myocardium',
    'heart_ventricle_left',
    'heart_ventricle_right'
  ],
  'Ribs': [
    'rib_left_1', 'rib_left_2', 'rib_left_3', 'rib_left_4', 'rib_left_5',
    'rib_left_6', 'rib_left_7', 'rib_left_8', 'rib_left_9', 'rib_left_10',
    'rib_left_11', 'rib_left_12',
    'rib_right_1', 'rib_right_2', 'rib_right_3', 'rib_right_4', 'rib_right_5',
    'rib_right_6', 'rib_right_7', 'rib_right_8', 'rib_right_9', 'rib_right_10',
    'rib_right_11', 'rib_right_12'
  ],
  'Kidneys': [
    'kidney_left',
    'kidney_right'
  ],
  'Adrenal Glands': [
    'adrenal_gland_left',
    'adrenal_gland_right'
  ],
  'Vertebrae': [
    'vertebrae_C1', 'vertebrae_C2', 'vertebrae_C3', 'vertebrae_C4', 'vertebrae_C5',
    'vertebrae_C6', 'vertebrae_C7', 'vertebrae_T1', 'vertebrae_T2', 'vertebrae_T3',
    'vertebrae_T4', 'vertebrae_T5', 'vertebrae_T6', 'vertebrae_T7', 'vertebrae_T8',
    'vertebrae_T9', 'vertebrae_T10', 'vertebrae_T11', 'vertebrae_T12', 'vertebrae_L1',
    'vertebrae_L2', 'vertebrae_L3', 'vertebrae_L4', 'vertebrae_L5'
  ],
  'Liver': ['liver'],
  'Esophagus': ['esophagus'],
  'Autochthon': ['autochthon_left', 'autochthon_right'],
  'Gluteus Maximus': ['gluteus_maximus_left', 'gluteus_maximus_right'],
  'Gluteus Medius': ['gluteus_medius_left', 'gluteus_medius_right'],
  'Gluteus Minimus': ['gluteus_minimus_left', 'gluteus_minimus_right'],
  'Iliopsoas': ['iliopsoas_left', 'iliopsoas_right'],
  'Iliac Arteries': ['iliac_artery_left', 'iliac_artery_right'],
  'Iliac Veins': ['iliac_vena_left', 'iliac_vena_right'],
  'Femurs': ['femur_left', 'femur_right'],
  'Hips': ['hip_left', 'hip_right'],
  'Humeri': ['humerus_left', 'humerus_right'],
  'Clavicles': ['clavicula_left', 'clavicula_right'],
  'Scapulae': ['scapula_left', 'scapula_right'],
};

/**
 * Mapping from ICRP Publication 128 organ names to TotalSegmentator
 * merged organ names used in CT dose analysis.
 *
 * Organs without a direct TotalSegmentator equivalent keep their ICRP name
 * so they still appear in the cumulative table (just won't merge with CT data).
 */
export const ICRP_TO_TOTALSEG_MAP: Record<string, string> = {
  // Direct / quasi-direct matches (ICRP "wall" → TotalSeg whole organ)
  'Heart wall':                'Heart',
  'Kidneys':                   'Kidneys',
  'Liver':                     'Liver',
  'Lungs':                     'Lungs',
  'Oesophagus':                'Esophagus',
  'Gallbladder wall':          'Gallbladder',
  'Stomach wall':              'Stomach',
  'Urinary bladder wall':      'Urinary Bladder',
  'Small intestine wall':      'Small Bowel',       // TotalSeg: small_bowel.nii.gz
  'Colon wall':                'Colon',
  'Upper large intestine wall':'Colon',              // no separate segment
  'Lower large intestine wall':'Colon',              // no separate segment
  'Adrenals':                  'Adrenal Glands',     // merge of adrenal_gland_left/right
  'Spleen':                    'Spleen',
  'Pancreas':                  'Pancreas',
  'Brain':                     'Brain',
  'Thyroid':                   'Thyroid',
  'Thymus':                    'Thymus',
  // Organs without a direct TotalSeg equivalent keep their ICRP name
  'Ovaries':                   'Ovaries',
  'Testes':                    'Testes',
  'Uterus':                    'Uterus',
  'Breast':                    'Breast',
  'Skin':                      'Skin',
  'Red marrow':                'Red Marrow',
  'Bone surfaces':             'Bone Surfaces',
  'Muscles':                   'Muscles',
  'Remaining organs':          'Remaining Organs',
};

/**
 * Map an ICRP organ name to the corresponding TotalSegmentator name.
 * Falls back to the original name if no mapping exists.
 */
export function mapIcrpToTotalSeg(icrpName: string): string {
  return ICRP_TO_TOTALSEG_MAP[icrpName] ?? icrpName;
}

/**
 * Build a reverse lookup: individual TotalSeg Title-Case name → merged group name.
 * e.g. "Adrenal Gland Left" → "Adrenal Glands", "Kidney Right" → "Kidneys"
 */
const INDIVIDUAL_TO_MERGED: Record<string, string> = (() => {
  const map: Record<string, string> = {};
  for (const [groupName, patterns] of Object.entries(ORGAN_MERGE_MAPPINGS)) {
    for (const pattern of patterns) {
      // Convert snake_case pattern to Title Case (same logic as getIndividualOrganFromPath)
      const titleCase = pattern
        .split('_')
        .map(w => w.charAt(0).toUpperCase() + w.slice(1))
        .join(' ');
      map[titleCase] = groupName;
    }
  }
  return map;
})();

/**
 * Normalize any organ name to its canonical form:
 * 1. Try ICRP → TotalSeg mapping (e.g. "Heart wall" → "Heart")
 * 2. Try individual → merged group (e.g. "Adrenal Gland Left" → "Adrenal Glands")
 * 3. Fall back to the original name
 */
export function normalizeOrganName(name: string): string {
  // First try ICRP mapping
  const icrpMapped = ICRP_TO_TOTALSEG_MAP[name];
  if (icrpMapped) return icrpMapped;
  // Then try individual-to-merged
  const merged = INDIVIDUAL_TO_MERGED[name];
  if (merged) return merged;
  return name;
}

/**
 * Extract unified organ name from a file path
 * Returns null if the path doesn't match any known organ pattern
 */
export function getOrganFromPath(path: string): string | null {
  const lowerPath = path.toLowerCase();
  
  for (const [organName, patterns] of Object.entries(ORGAN_MERGE_MAPPINGS)) {
    for (const pattern of patterns) {
      if (lowerPath.includes(pattern.toLowerCase())) {
        return organName;
      }
    }
  }
  
  return null;
}

/**
 * Extract organ name from a segmentation file path for "all organs" mode.
 * Returns the filename without extension as the organ label.
 * e.g. "path/to/spleen.nii.gz" -> "Spleen"
 */
export function getIndividualOrganFromPath(path: string): string {
  const filename = path.split('/').pop() || path;
  const name = filename.replace(/\.nii(\.gz)?$/i, '');
  // Convert snake_case to Title Case
  return name
    .split('_')
    .map(word => word.charAt(0).toUpperCase() + word.slice(1))
    .join(' ');
}
