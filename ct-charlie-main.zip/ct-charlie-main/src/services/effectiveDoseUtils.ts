import { normalizeOrganName } from "@/services/organMergeConfig";

const ICRP103_WEIGHT_FACTORS: Record<string, number> = {
  Lungs: 0.12,
  Colon: 0.12,
  Stomach: 0.12,
  Esophagus: 0.12,
  Oesophagus: 0.12,
  Liver: 0.04,
  Kidneys: 0.04,
  Heart: 0.04,
  "Urinary Bladder": 0.04,
  "Small Bowel": 0.04,
  Spleen: 0.04,
  Pancreas: 0.04,
  "Adrenal Glands": 0.04,
  Adrenals: 0.04,
  Brain: 0.01,
};

export const toFiniteNumber = (value: unknown): number | null => {
  if (value === null || value === undefined) return null;
  const parsed = typeof value === "number" ? value : parseFloat(String(value));
  return Number.isFinite(parsed) ? parsed : null;
};

export const computeEffectiveDoseFromOrganDoses = (organDoses: unknown): number | null => {
  if (!organDoses) return null;

  const normalizedDoses: Record<string, number> = {};

  const addDose = (organName: string | undefined, doseValue: unknown) => {
    if (!organName) return;
    const dose = toFiniteNumber(doseValue);
    if (dose === null) return;
    const normalizedName = normalizeOrganName(organName);
    normalizedDoses[normalizedName] = (normalizedDoses[normalizedName] || 0) + dose;
  };

  if (Array.isArray(organDoses)) {
    for (const organDose of organDoses as any[]) {
      addDose(organDose?.organ_name, organDose?.d_mean);
    }
  } else if (typeof organDoses === "object") {
    for (const [organName, organData] of Object.entries(organDoses as Record<string, any>)) {
      addDose(organName, organData?.d_mean);
    }
  }

  let effectiveDose = 0;
  let hasWeightedOrgan = false;

  for (const [organName, dose] of Object.entries(normalizedDoses)) {
    const weight = ICRP103_WEIGHT_FACTORS[organName];
    if (weight !== undefined) {
      effectiveDose += weight * dose;
      hasWeightedOrgan = true;
    }
  }

  return hasWeightedOrgan ? effectiveDose : null;
};

/** Get effective dose from analysis results, with fallback to organ-dose computation */
export const getEffectiveDoseFromResults = (results: any): number | null => {
  const storedDose = toFiniteNumber(results?.effective_dose_mSv ?? results?.effective_dose_msv);
  if (storedDose !== null) return storedDose;
  return computeEffectiveDoseFromOrganDoses(results?.organ_doses);
};

/** Get effective dose for the latest completed run of a study */
export const getStudyEffectiveDose = (study: any): number | null => {
  const completedRuns = study.analysis_runs?.filter((r: any) => r.status === 'completed');
  if (!completedRuns?.length) return null;
  const latestRun = completedRuns.sort(
    (a: any, b: any) => new Date(b.finished_at).getTime() - new Date(a.finished_at).getTime()
  )[0];
  return getEffectiveDoseFromResults(latestRun?.results);
};
