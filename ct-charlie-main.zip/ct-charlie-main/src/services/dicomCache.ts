/**
 * IndexedDB Cache for DICOM Images
 * Provides persistent storage for offline viewing and fast access
 */

import { openDB, DBSchema, IDBPDatabase } from 'idb';

interface DicomCacheDB extends DBSchema {
  images: {
    key: string;
    value: {
      imageId: string;
      arrayBuffer: ArrayBuffer;
      timestamp: number;
      studyId: string;
      seriesNumber?: number;
      fileType?: string;
    };
    indexes: {
      'studyId': string;
      'timestamp': number;
      'fileType': string;
    };
  };
  overlays: {
    key: string;
    value: {
      cacheKey: string;
      arrayBuffer: ArrayBuffer;
      timestamp: number;
      studyId: string;
      fileType: 'organ_mask' | 'dose';
      organName?: string;
    };
    indexes: {
      'studyId': string;
      'timestamp': number;
    };
  };
  metadata: {
    key: string;
    value: {
      studyId: string;
      totalImages: number;
      cachedImages: number;
      lastAccessed: number;
    };
  };
}

class DicomCacheService {
  private db: IDBPDatabase<DicomCacheDB> | null = null;
  private memoryCache: Map<string, ArrayBuffer> = new Map();
  private readonly MAX_MEMORY_CACHE_SIZE = 150; // Keep 150 images in memory for smoother scrolling
  private readonly DB_NAME = 'dicom-cache';
  private readonly DB_VERSION = 2; // Incremented for overlay support
  private initPromise: Promise<void> | null = null;
  private readonly DEFAULT_MAX_CACHE_PERCENT = 50; // Use 50% of available storage by default

  async init(): Promise<void> {
    // If already initializing, wait for that to complete
    if (this.initPromise) return this.initPromise;
    
    // If already initialized and connection is healthy, return
    if (this.db && await this.isConnectionHealthy()) return;

    // Start initialization
    this.initPromise = this.doInit();
    
    try {
      await this.initPromise;
    } finally {
      this.initPromise = null;
    }
  }

  private async isConnectionHealthy(): Promise<boolean> {
    if (!this.db) return false;
    
    try {
      // Try a simple operation to check if connection is alive
      const tx = this.db.transaction('images', 'readonly');
      await tx.done;
      return true;
    } catch {
      // Connection is dead
      this.db = null;
      return false;
    }
  }

  private async doInit(): Promise<void> {
    this.db = await openDB<DicomCacheDB>(this.DB_NAME, this.DB_VERSION, {
      upgrade(db, oldVersion) {
        // Create images store
        if (!db.objectStoreNames.contains('images')) {
          const imageStore = db.createObjectStore('images', { keyPath: 'imageId' });
          imageStore.createIndex('studyId', 'studyId', { unique: false });
          imageStore.createIndex('timestamp', 'timestamp', { unique: false });
          imageStore.createIndex('fileType', 'fileType', { unique: false });
        } else if (oldVersion < 2) {
          // Upgrade existing images store to add fileType index
          const tx = (db as any).transaction;
          const imageStore = tx.objectStore('images');
          if (!imageStore.indexNames.contains('fileType')) {
            imageStore.createIndex('fileType', 'fileType', { unique: false });
          }
        }

        // Create overlays store
        if (!db.objectStoreNames.contains('overlays')) {
          const overlayStore = db.createObjectStore('overlays', { keyPath: 'cacheKey' });
          overlayStore.createIndex('studyId', 'studyId', { unique: false });
          overlayStore.createIndex('timestamp', 'timestamp', { unique: false });
        }

        // Create metadata store
        if (!db.objectStoreNames.contains('metadata')) {
          db.createObjectStore('metadata', { keyPath: 'studyId' });
        }
      },
    });
  }

  /**
   * Get cached image from memory or IndexedDB using storage path
   */
  async get(storagePath: string): Promise<ArrayBuffer | null> {
    // Check memory cache first
    if (this.memoryCache.has(storagePath)) {
      return this.memoryCache.get(storagePath)!;
    }

    // Ensure DB is initialized
    await this.init();
    if (!this.db) return null;
    
    try {
      const cached = await this.db.get('images', storagePath);
      if (cached) {
        // Add to memory cache for faster subsequent access
        this.addToMemoryCache(storagePath, cached.arrayBuffer);
        return cached.arrayBuffer;
      }
    } catch (error) {
      console.warn('Error reading from cache, reinitializing:', error);
      this.db = null;
      await this.init();
    }

    return null;
  }

  /**
   * Store image in both memory and IndexedDB using stable storage path
   */
  async set(
    storagePath: string,
    arrayBuffer: ArrayBuffer,
    studyId: string,
    seriesNumber?: number,
    fileType?: string
  ): Promise<void> {
    // Validate arrayBuffer
    if (!arrayBuffer || !(arrayBuffer instanceof ArrayBuffer) || arrayBuffer.byteLength === 0) {
      console.warn('Invalid arrayBuffer provided to cache.set:', storagePath);
      return;
    }

    // Add to memory cache
    this.addToMemoryCache(storagePath, arrayBuffer);

    // Ensure DB is initialized
    await this.init();
    if (!this.db) return;

    try {
      await this.db.put('images', {
        imageId: storagePath,
        arrayBuffer,
        timestamp: Date.now(),
        studyId,
        seriesNumber,
        fileType,
      });

      // Update metadata
      await this.updateMetadata(studyId);
    } catch (error) {
      console.warn('Error writing to cache, reinitializing:', error);
      this.db = null;
      // Don't retry immediately to avoid infinite loops
    }
  }

  /**
   * Batch set multiple images
   */
  async setMany(
    images: Array<{
      imageId: string;
      arrayBuffer: ArrayBuffer;
      studyId: string;
      seriesNumber?: number;
      fileType?: string;
    }>
  ): Promise<void> {
    await this.init();
    if (!this.db) return;

    try {
      const tx = this.db.transaction('images', 'readwrite');
      
      await Promise.all([
        ...images.map(img => {
          this.addToMemoryCache(img.imageId, img.arrayBuffer);
          return tx.store.put({
            imageId: img.imageId,
            arrayBuffer: img.arrayBuffer,
            timestamp: Date.now(),
            studyId: img.studyId,
            seriesNumber: img.seriesNumber,
            fileType: img.fileType,
          });
        }),
        tx.done,
      ]);

      if (images.length > 0) {
        await this.updateMetadata(images[0].studyId);
      }
    } catch (error) {
      console.warn('Error batch writing to cache:', error);
      this.db = null;
    }
  }

  /**
   * Check if image exists in cache using storage path
   */
  async has(storagePath: string): Promise<boolean> {
    if (this.memoryCache.has(storagePath)) return true;
    
    if (!this.db) await this.init();
    
    try {
      const count = await this.db!.count('images', storagePath);
      return count > 0;
    } catch {
      return false;
    }
  }

  /**
   * Get all cached images for a study
   */
  async getStudyImages(studyId: string): Promise<string[]> {
    if (!this.db) await this.init();

    try {
      const images = await this.db!.getAllFromIndex('images', 'studyId', studyId);
      return images.map(img => img.imageId);
    } catch {
      return [];
    }
  }

  /**
   * Clear cache for a specific study
   */
  async clearStudy(studyId: string): Promise<void> {
    if (!this.db) await this.init();

    const tx = this.db!.transaction('images', 'readwrite');
    const index = tx.store.index('studyId');
    
    let cursor = await index.openCursor(studyId);
    while (cursor) {
      const imageId = cursor.value.imageId;
      this.memoryCache.delete(imageId);
      await cursor.delete();
      cursor = await cursor.continue();
    }

    await tx.done;
    await this.db!.delete('metadata', studyId);
  }

  /**
   * Clear entire cache
   */
  async clearAll(): Promise<void> {
    this.memoryCache.clear();
    
    if (!this.db) await this.init();
    
    await this.db!.clear('images');
    await this.db!.clear('metadata');
  }

  /**
   * Get cache statistics
   */
  async getStats(studyId?: string): Promise<{
    totalSize: number;
    imageCount: number;
    uniqueImages: number;
    studies: number;
    byFileType?: Record<string, { count: number; size: number }>;
  }> {
    await this.init();
    if (!this.db) {
      return { totalSize: 0, imageCount: 0, uniqueImages: 0, studies: 0 };
    }

    try {
      let images;
      if (studyId) {
        images = await this.db.getAllFromIndex('images', 'studyId', studyId);
      } else {
        images = await this.db.getAll('images');
      }

      const totalSize = images.reduce((sum, img) => {
        if (img.arrayBuffer && img.arrayBuffer.byteLength) {
          return sum + img.arrayBuffer.byteLength;
        }
        return sum;
      }, 0);
      
      // Since imageId is now the storage path, all entries should be unique
      const uniqueImageIds = new Set(images.map(img => img.imageId));
      
      const studies = new Set(images.map(img => img.studyId)).size;

      // Calculate per-file-type breakdown if studyId is provided
      const byFileType: Record<string, { count: number; size: number }> = {};
      if (studyId) {
        for (const img of images) {
          const fileType = img.fileType || 'unknown';
          if (!byFileType[fileType]) {
            byFileType[fileType] = { count: 0, size: 0 };
          }
          byFileType[fileType].count++;
          byFileType[fileType].size += img.arrayBuffer?.byteLength || 0;
        }
      }

      return {
        totalSize,
        imageCount: images.length,
        uniqueImages: uniqueImageIds.size,
        studies,
        byFileType: studyId ? byFileType : undefined,
      };
    } catch (error) {
      console.error('Error getting cache stats:', error);
      return { totalSize: 0, imageCount: 0, uniqueImages: 0, studies: 0 };
    }
  }

  /**
   * Prune old cache entries based on LRU
   */
  async pruneOldEntries(maxSizeMB: number = 500): Promise<void> {
    if (!this.db) await this.init();

    const stats = await this.getStats();
    const maxSizeBytes = maxSizeMB * 1024 * 1024;

    if (stats.totalSize <= maxSizeBytes) return;

    // Get all images sorted by timestamp
    const images = await this.db!.getAllFromIndex('images', 'timestamp');
    
    let currentSize = stats.totalSize;
    const tx = this.db!.transaction('images', 'readwrite');

    for (const img of images) {
      if (currentSize <= maxSizeBytes * 0.8) break; // Remove until 80% of max

      await tx.store.delete(img.imageId);
      this.memoryCache.delete(img.imageId);
      currentSize -= img.arrayBuffer.byteLength;
    }

    await tx.done;
  }

  private addToMemoryCache(imageId: string, arrayBuffer: ArrayBuffer): void {
    // Remove oldest if cache is full
    if (this.memoryCache.size >= this.MAX_MEMORY_CACHE_SIZE) {
      const firstKey = this.memoryCache.keys().next().value;
      if (firstKey) this.memoryCache.delete(firstKey);
    }

    this.memoryCache.set(imageId, arrayBuffer);
  }

  private async updateMetadata(studyId: string): Promise<void> {
    try {
      await this.init();
      if (!this.db) return;

      const images = await this.db.getAllFromIndex('images', 'studyId', studyId);
      
      await this.db.put('metadata', {
        studyId,
        totalImages: images.length,
        cachedImages: images.length,
        lastAccessed: Date.now(),
      });
    } catch (error) {
      console.warn('Error updating metadata:', error);
    }
  }

  /**
   * Get cached overlay from IndexedDB
   */
  async getOverlay(
    studyId: string,
    fileType: 'organ_mask' | 'dose',
    organName?: string
  ): Promise<ArrayBuffer | null> {
    await this.init();
    if (!this.db) return null;

    const cacheKey = this.buildOverlayCacheKey(studyId, fileType, organName);
    
    try {
      const cached = await this.db.get('overlays', cacheKey);
      if (cached) {
        return cached.arrayBuffer;
      }
    } catch (error) {
      console.warn('Error reading overlay from cache:', error);
    }

    return null;
  }

  /**
   * Store overlay in IndexedDB
   */
  async setOverlay(
    studyId: string,
    fileType: 'organ_mask' | 'dose',
    arrayBuffer: ArrayBuffer,
    organName?: string
  ): Promise<void> {
    if (!arrayBuffer || !(arrayBuffer instanceof ArrayBuffer) || arrayBuffer.byteLength === 0) {
      console.warn('Invalid arrayBuffer provided to overlay cache.set');
      return;
    }

    await this.init();
    if (!this.db) return;

    const cacheKey = this.buildOverlayCacheKey(studyId, fileType, organName);

    try {
      await this.db.put('overlays', {
        cacheKey,
        arrayBuffer,
        timestamp: Date.now(),
        studyId,
        fileType,
        organName,
      });
    } catch (error) {
      console.warn('Error writing overlay to cache:', error);
    }
  }

  /**
   * Get all cached overlays for a study
   */
  async getStudyOverlays(studyId: string): Promise<string[]> {
    await this.init();
    if (!this.db) return [];

    try {
      const overlays = await this.db.getAllFromIndex('overlays', 'studyId', studyId);
      return overlays.map(o => o.cacheKey);
    } catch {
      return [];
    }
  }

  /**
   * Clear all overlays for a specific study
   */
  async clearStudyOverlays(studyId: string): Promise<void> {
    await this.init();
    if (!this.db) return;

    try {
      const tx = this.db.transaction('overlays', 'readwrite');
      const index = tx.store.index('studyId');
      
      let cursor = await index.openCursor(studyId);
      while (cursor) {
        await cursor.delete();
        cursor = await cursor.continue();
      }

      await tx.done;
    } catch (error) {
      console.warn('Error clearing study overlays:', error);
    }
  }

  /**
   * Get overlay cache statistics
   */
  async getOverlayStats(studyId?: string): Promise<{
    totalSize: number;
    overlayCount: number;
  }> {
    await this.init();
    if (!this.db) {
      return { totalSize: 0, overlayCount: 0 };
    }

    try {
      let overlays;
      if (studyId) {
        overlays = await this.db.getAllFromIndex('overlays', 'studyId', studyId);
      } else {
        overlays = await this.db.getAll('overlays');
      }

      const totalSize = overlays.reduce((sum, overlay) => {
        if (overlay.arrayBuffer && overlay.arrayBuffer.byteLength) {
          return sum + overlay.arrayBuffer.byteLength;
        }
        return sum;
      }, 0);

      return {
        totalSize,
        overlayCount: overlays.length,
      };
    } catch (error) {
      console.error('Error getting overlay cache stats:', error);
      return { totalSize: 0, overlayCount: 0 };
    }
  }

  private buildOverlayCacheKey(
    studyId: string,
    fileType: 'organ_mask' | 'dose',
    organName?: string
  ): string {
    return organName 
      ? `${studyId}_${fileType}_${organName}`
      : `${studyId}_${fileType}`;
  }

  /**
   * Get storage quota information
   */
  async getStorageQuota(): Promise<{
    usage: number;
    quota: number;
    percentUsed: number;
    available: number;
  }> {
    if (!navigator.storage || !navigator.storage.estimate) {
      // Fallback for browsers that don't support StorageManager API
      return { usage: 0, quota: 0, percentUsed: 0, available: 0 };
    }

    try {
      const estimate = await navigator.storage.estimate();
      const usage = estimate.usage || 0;
      const quota = estimate.quota || 0;
      const percentUsed = quota > 0 ? (usage / quota) * 100 : 0;
      const available = quota - usage;

      return { usage, quota, percentUsed, available };
    } catch (error) {
      console.warn('Failed to get storage quota:', error);
      return { usage: 0, quota: 0, percentUsed: 0, available: 0 };
    }
  }

  /**
   * Get recommended max cache size based on available storage
   */
  async getRecommendedMaxCacheSize(): Promise<number> {
    const { quota } = await this.getStorageQuota();
    const maxCacheMB = Math.floor((quota * this.DEFAULT_MAX_CACHE_PERCENT / 100) / (1024 * 1024));
    return Math.max(100, Math.min(maxCacheMB, 1000)); // Between 100MB and 1GB
  }

  /**
   * Check if automatic pruning is needed
   */
  async shouldPrune(): Promise<boolean> {
    const { percentUsed } = await this.getStorageQuota();
    return percentUsed > 80; // Prune when over 80% of quota is used
  }

  /**
   * Auto-prune cache if needed based on storage quota
   */
  async autoPrune(): Promise<void> {
    if (await this.shouldPrune()) {
      const maxSize = await this.getRecommendedMaxCacheSize();
      console.log(`Auto-pruning cache to ${maxSize}MB due to storage pressure`);
      await this.pruneOldEntries(maxSize);
    }
  }

  /**
   * Clear all cache data (images + overlays)
   */
  async clearAllCache(): Promise<void> {
    this.memoryCache.clear();
    
    if (!this.db) await this.init();
    
    await this.db!.clear('images');
    await this.db!.clear('overlays');
    await this.db!.clear('metadata');
  }

  /**
   * Get comprehensive cache health status
   */
  async getCacheHealth(): Promise<{
    isHealthy: boolean;
    canWrite: boolean;
    canRead: boolean;
    storageAvailable: boolean;
    lastCheck: number;
  }> {
    const lastCheck = Date.now();
    let isHealthy = true;
    let canWrite = true;
    let canRead = true;
    let storageAvailable = true;

    try {
      // Check if we can initialize
      await this.init();
      
      if (!this.db) {
        isHealthy = false;
        canWrite = false;
        canRead = false;
      } else {
        // Test read operation
        try {
          await this.db.count('images');
        } catch {
          canRead = false;
          isHealthy = false;
        }

        // Test write operation
        try {
          const testKey = '__health_check__';
          await this.db.put('images', {
            imageId: testKey,
            arrayBuffer: new ArrayBuffer(1),
            timestamp: Date.now(),
            studyId: 'test',
          });
          await this.db.delete('images', testKey);
        } catch {
          canWrite = false;
          isHealthy = false;
        }
      }

      // Check storage availability
      const { quota } = await this.getStorageQuota();
      storageAvailable = quota > 0;

    } catch (error) {
      console.error('Cache health check failed:', error);
      isHealthy = false;
    }

    return { isHealthy, canWrite, canRead, storageAvailable, lastCheck };
  }
}

// Export singleton instance
export const dicomCache = new DicomCacheService();
