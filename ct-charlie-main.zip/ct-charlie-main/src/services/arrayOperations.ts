/**
 * 3D Array Operations for Dose Calculations
 * Implements element-wise operations matching Matlab functionality
 */

/**
 * Check if two arrays have matching dimensions
 * Matches Matlab: isequal(size(dosedistribution), size(organ))
 */
export function dimensionsMatch(
  dims1: number[],
  dims2: number[]
): boolean {
  if (dims1.length !== dims2.length) return false;
  return dims1.every((dim, i) => dim === dims2[i]);
}

/**
 * Element-wise multiplication of two 3D arrays
 * Matches Matlab: dosedistribution .* organ
 * 
 * @param array1 - Dose distribution (Float32Array)
 * @param array2 - Organ mask (Int16Array)
 * @param dimensions - [x, y, z] dimensions
 * @returns Result array
 */
export function multiplyArrays(
  array1: Float32Array | Int16Array,
  array2: Float32Array | Int16Array,
  dimensions: number[]
): Float32Array {
  const totalVoxels = dimensions[0] * dimensions[1] * dimensions[2];
  
  if (array1.length !== totalVoxels || array2.length !== totalVoxels) {
    throw new Error(`Array size mismatch: expected ${totalVoxels} voxels`);
  }

  const result = new Float32Array(totalVoxels);
  
  for (let i = 0; i < totalVoxels; i++) {
    result[i] = array1[i] * array2[i];
  }

  return result;
}

/**
 * Calculate mean of non-zero values
 * Matches Matlab: mean(nonzeros(dosedistribution .* organ))
 * 
 * @param array - Input array
 * @returns Mean of non-zero values
 */
export function meanNonZero(array: Float32Array | Int16Array): number {
  let sum = 0;
  let count = 0;

  for (let i = 0; i < array.length; i++) {
    if (array[i] !== 0) {
      sum += array[i];
      count++;
    }
  }

  if (count === 0) {
    return 0;
  }

  return sum / count;
}

/**
 * Calculate volume from binary mask
 * Volume (ml) = number of voxels × voxel volume (mm³) / 1000
 * 
 * @param mask - Binary organ mask
 * @param voxelSpacing - [x, y, z] voxel spacing in mm
 * @returns Volume in ml
 */
export function calculateVolume(
  mask: Float32Array | Int16Array,
  voxelSpacing: number[]
): number {
  let voxelCount = 0;

  for (let i = 0; i < mask.length; i++) {
    if (mask[i] !== 0) {
      voxelCount++;
    }
  }

  // Calculate voxel volume in mm³
  const voxelVolume = voxelSpacing[0] * voxelSpacing[1] * voxelSpacing[2];
  
  // Convert to ml (1 ml = 1000 mm³)
  const volumeMl = (voxelCount * voxelVolume) / 1000;

  return volumeMl;
}

/**
 * Calculate statistics for an array
 * 
 * @param array - Input array
 * @returns Statistics object with min, max, median, percentiles
 */
export function calculateStatistics(array: Float32Array | Int16Array): {
  min: number;
  max: number;
  median: number;
  p5: number;
  p95: number;
} {
  // Get non-zero values
  const nonZeroValues: number[] = [];
  for (let i = 0; i < array.length; i++) {
    if (array[i] !== 0) {
      nonZeroValues.push(array[i]);
    }
  }

  if (nonZeroValues.length === 0) {
    return { min: 0, max: 0, median: 0, p5: 0, p95: 0 };
  }

  // Sort for percentile calculations
  nonZeroValues.sort((a, b) => a - b);

  const min = nonZeroValues[0];
  const max = nonZeroValues[nonZeroValues.length - 1];
  const median = nonZeroValues[Math.floor(nonZeroValues.length / 2)];
  const p5 = nonZeroValues[Math.floor(nonZeroValues.length * 0.05)];
  const p95 = nonZeroValues[Math.floor(nonZeroValues.length * 0.95)];

  return { min, max, median, p5, p95 };
}

/**
 * Calculate Dose-Volume Histogram (DVH)
 * Returns cumulative DVH: percentage of organ volume receiving at least dose D
 * 
 * @param maskedDose - Dose array after element-wise multiplication with organ mask
 * @param organMask - Binary organ mask to count total organ voxels
 * @param binWidth - Dose bin width (default: 0.1 for relative dose units)
 * @param maxBins - Maximum number of bins to prevent excessive data (default: 200)
 * @returns Array of [dose, volume%] pairs representing cumulative DVH
 */
export function calculateDVH(
  maskedDose: Float32Array | Int16Array,
  organMask: Float32Array | Int16Array,
  binWidth: number = 0.1,
  maxBins: number = 200
): number[][] {
  // Extract non-zero dose values (voxels within the organ)
  const nonZeroDoses: number[] = [];
  let organVoxelCount = 0;

  for (let i = 0; i < maskedDose.length; i++) {
    if (organMask[i] !== 0) {
      organVoxelCount++;
      if (maskedDose[i] !== 0) {
        nonZeroDoses.push(maskedDose[i]);
      }
    }
  }

  // Edge case: empty organ or no dose
  if (organVoxelCount === 0 || nonZeroDoses.length === 0) {
    return [[0, 0]];
  }

  // Determine dose range WITHOUT spread operator (avoids stack overflow for large arrays)
  let minDose = nonZeroDoses[0];
  let maxDose = nonZeroDoses[0];
  for (let i = 1; i < nonZeroDoses.length; i++) {
    if (nonZeroDoses[i] < minDose) minDose = nonZeroDoses[i];
    if (nonZeroDoses[i] > maxDose) maxDose = nonZeroDoses[i];
  }

  // Create dose bins
  const numBins = Math.min(
    Math.ceil((maxDose - minDose) / binWidth) + 1,
    maxBins
  );
  const effectiveBinWidth = (maxDose - minDose) / (numBins - 1);

  // Create histogram: count voxels in each dose bin
  const histogram = new Array(numBins).fill(0);
  
  for (const dose of nonZeroDoses) {
    const binIndex = Math.min(
      Math.floor((dose - minDose) / effectiveBinWidth),
      numBins - 1
    );
    histogram[binIndex]++;
  }

  // Calculate cumulative DVH (from max dose to min dose)
  // cumulative_volume_percent(d_i) = (voxels with dose >= d_i / total organ voxels) × 100
  const dvh: number[][] = [];
  let cumulativeVoxels = 0;

  for (let i = numBins - 1; i >= 0; i--) {
    cumulativeVoxels += histogram[i];
    const doseValue = minDose + i * effectiveBinWidth;
    const volumePercent = (cumulativeVoxels / organVoxelCount) * 100;
    dvh.unshift([doseValue, volumePercent]);
  }

  // Ensure DVH starts at 0 dose with 100% volume (or appropriate percentage)
  // Add a point at dose=0 if not already present
  if (dvh.length > 0 && dvh[0][0] > 0) {
    dvh.unshift([0, (organVoxelCount / organVoxelCount) * 100]);
  }

  return dvh;
}
