import * as XLSX from 'xlsx';
import { OrganDoseResult } from './doseCalculation';

/**
 * Export dose calculation results to Excel
 * Matches Matlab output format: Patient | Organ | Dose (mGy) | Unit | meanmAs
 */
export function exportToExcel(
  studyId: string,
  meanmAs: number,
  organResults: OrganDoseResult[]
): void {
  try {
    console.log('exportToExcel called with:', { studyId, meanmAs, organResults });
    
    // Prepare data rows (matching Matlab format, with actual unit from results)
    const rows = organResults.map(result => {
      const row = {
        'Patient': studyId,
        'Organ': result.organ_name,
        'Dose': result.status === 'success' ? Number(result.d_mean).toFixed(6) : 'N/A',
        'Unit': result.unit, // Use actual unit (Gy or mGy)
        'meanmAs': Number(meanmAs).toFixed(6),
        'Volume (ml)': Number(result.volume_ml).toFixed(2),
        'Status': result.status
      };
      console.log('Created row:', row);
      return row;
    });

    console.log('All rows:', rows);

    // Validate rows
    if (!rows || rows.length === 0) {
      throw new Error('No data to export');
    }
    console.log('Validated rows, count:', rows.length);

    // Create worksheet
    const worksheet = XLSX.utils.json_to_sheet(rows);
    console.log('Worksheet created, keys:', Object.keys(worksheet).slice(0, 10));

    // Set column widths
    worksheet['!cols'] = [
      { wch: 30 }, // Patient
      { wch: 15 }, // Organ
      { wch: 15 }, // Dose
      { wch: 10 }, // Unit
      { wch: 15 }, // meanmAs
      { wch: 15 }, // Volume (ml)
      { wch: 20 }, // Status
    ];

    // Create workbook
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Organ Doses');
    console.log('Workbook created, SheetNames:', workbook.SheetNames);
    console.log('Workbook Sheets:', Object.keys(workbook.Sheets));

    // Generate filename
    const timestamp = new Date().toISOString().split('T')[0];
    const filename = `Organdosissen_${studyId}_${timestamp}.xlsx`;
    console.log('Attempting to download file:', filename);

    // Try to write file with error handling
    try {
      const wbout = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
      console.log('File buffer created, size:', wbout.byteLength, 'bytes');
      
      // Create blob with proper Excel MIME type
      const blob = new Blob([wbout], { 
        type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' 
      });
      console.log('Blob created, size:', blob.size, 'bytes');
      
      // Create download link with better browser compatibility
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = filename;
      link.style.display = 'none';
      
      // Trigger download
      document.body.appendChild(link);
      setTimeout(() => {
        link.click();
        console.log('Download click triggered');
        
        // Cleanup after a delay to ensure download starts
        setTimeout(() => {
          document.body.removeChild(link);
          URL.revokeObjectURL(url);
          console.log('Cleanup completed');
        }, 100);
      }, 0);
      
      console.log('File download initiated successfully');
    } catch (writeError) {
      console.error('Error during file write:', writeError);
      throw new Error(`File write failed: ${writeError instanceof Error ? writeError.message : 'Unknown error'}`);
    }
  } catch (error) {
    console.error('Export error in exportToExcel:', error);
    throw error;
  }
}

/**
 * Export detailed results with statistics to Excel
 */
export function exportDetailedToExcel(
  studyId: string,
  meanmAs: number,
  organResults: OrganDoseResult[]
): void {
  try {
    console.log('exportDetailedToExcel called with:', { studyId, meanmAs, organResults });
    
    // Prepare detailed data rows (unit-agnostic)
    const rows = organResults.map(result => ({
      'Patient': studyId,
      'Organ': result.organ_name,
      'Mean Dose': result.status === 'success' ? result.d_mean.toFixed(6) : 'N/A',
      'Min Dose': result.status === 'success' ? result.d_min.toFixed(6) : 'N/A',
      'Max Dose': result.status === 'success' ? result.d_max.toFixed(6) : 'N/A',
      'Median Dose': result.status === 'success' ? result.d_median.toFixed(6) : 'N/A',
      'P5': result.status === 'success' ? result.d_p5.toFixed(6) : 'N/A',
      'P95': result.status === 'success' ? result.d_p95.toFixed(6) : 'N/A',
      'Volume (ml)': result.volume_ml.toFixed(2),
      'Unit': result.unit, // Actual unit (Gy or mGy)
      'meanmAs': meanmAs.toFixed(6),
      'Relative Dose': result.relative_dose.toFixed(6),
      'Status': result.status,
      'Error': result.error_message || ''
    }));

    // Validate rows
    if (!rows || rows.length === 0) {
      throw new Error('No data to export');
    }
    console.log('Validated detailed rows, count:', rows.length);

    // Create worksheet
    const worksheet = XLSX.utils.json_to_sheet(rows);
    console.log('Detailed worksheet created');

    // Set column widths
    worksheet['!cols'] = [
      { wch: 30 }, // Patient
      { wch: 15 }, // Organ
      { wch: 18 }, // Mean Dose
      { wch: 18 }, // Min Dose
      { wch: 18 }, // Max Dose
      { wch: 18 }, // Median Dose
      { wch: 15 }, // P5
      { wch: 15 }, // P95
      { wch: 15 }, // Volume
      { wch: 10 }, // Unit
      { wch: 15 }, // meanmAs
      { wch: 18 }, // Relative Dose
      { wch: 20 }, // Status
      { wch: 40 }, // Error
    ];

    // Create workbook
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Detailed Results');
    console.log('Detailed workbook created');

    // Generate filename
    const timestamp = new Date().toISOString().split('T')[0];
    const filename = `Detailed_Organdosissen_${studyId}_${timestamp}.xlsx`;
    console.log('Attempting to download detailed file:', filename);

    // Try to write file with error handling
    try {
      const wbout = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
      console.log('Detailed file buffer created, size:', wbout.byteLength, 'bytes');
      
      // Create blob with proper Excel MIME type
      const blob = new Blob([wbout], { 
        type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' 
      });
      console.log('Detailed blob created, size:', blob.size, 'bytes');
      
      // Create download link with better browser compatibility
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = filename;
      link.style.display = 'none';
      
      // Trigger download
      document.body.appendChild(link);
      setTimeout(() => {
        link.click();
        console.log('Detailed download click triggered');
        
        // Cleanup after a delay to ensure download starts
        setTimeout(() => {
          document.body.removeChild(link);
          URL.revokeObjectURL(url);
          console.log('Detailed cleanup completed');
        }, 100);
      }, 0);
      
      console.log('Detailed file download initiated successfully');
    } catch (writeError) {
      console.error('Error during detailed file write:', writeError);
      throw new Error(`Detailed file write failed: ${writeError instanceof Error ? writeError.message : 'Unknown error'}`);
    }
  } catch (error) {
    console.error('Export error in exportDetailedToExcel:', error);
    throw error;
  }
}
