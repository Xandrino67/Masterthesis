/**
 * Overlay Loader Service
 * Loads organ masks and dose distributions for overlay rendering
 */

import { supabase } from '@/integrations/supabase/client';
import { loadNiftiFile, NiftiData, mergeNiftiMasks } from './niftiLoader';
import { dicomCache } from './dicomCache';
import { getOrganFromPath } from './organMergeConfig';
import { resolveStudyId } from './studyIdResolver';

export interface OrganMaskFile {
  organName: string;
  storagePath: string;
  color: string;
}

/**
 * Download file from Supabase storage with caching support
 */
async function downloadFile(
  bucket: string,
  path: string,
  studyId: string,
  fileType: 'organ_mask' | 'dose',
  organName?: string,
  useCache: boolean = true
): Promise<ArrayBuffer> {
  // Build unique cache key per component file to avoid collisions
  const cacheKey = organName ? `${organName}::${path}` : undefined;
  
  // Try cache first if enabled
  if (useCache && cacheKey) {
    const cached = await dicomCache.getOverlay(studyId, fileType, cacheKey);
    if (cached) {
      console.log(`Loaded ${fileType} from cache:`, cacheKey);
      return cached;
    }
  }

  // Download from Supabase Storage
  const { data, error } = await supabase.storage.from(bucket).download(path);

  if (error) {
    throw new Error(`Failed to download file from ${bucket}/${path}: ${error.message}`);
  }

  const arrayBuffer = await data.arrayBuffer();

  // Cache the downloaded file with unique key
  if (useCache && arrayBuffer && cacheKey) {
    await dicomCache.setOverlay(studyId, fileType, arrayBuffer, cacheKey);
    console.log(`Cached ${fileType}:`, cacheKey);
  }

  return arrayBuffer;
}

/**
 * Load all organ masks for a study from TotalSegmentator segmentations
 */
export async function loadOrganMasks(
  studyId: string,
  onProgress?: (current: number, total: number) => void
): Promise<Map<string, { data: NiftiData; color: string }>> {
  console.log('Loading organ masks (segmentation-based) for study:', studyId);

  // Clear old overlay cache to remove stale entries with incorrect keys
  await dicomCache.clearStudyOverlays(studyId);
  console.log('Cleared old overlay cache for study');

  // Resolve UUID to folder name
  const actualStudyId = await resolveStudyId(studyId);
  console.log('Using study_id for file queries:', actualStudyId);

  // Fetch mask files ONLY from segmentations folder
  const { data: maskFiles, error: maskError } = await supabase
    .from('extracted_files')
    .select('organ_name, storage_path, storage_bucket, original_path')
    .eq('study_id', actualStudyId)
    .eq('file_type', 'nifti_mask')
    .like('storage_path', '%TotalSegmentator/segmentations%');

  if (maskError) {
    throw new Error(`Failed to fetch organ masks: ${maskError.message}`);
  }

  if (!maskFiles || maskFiles.length === 0) {
    console.warn('No organ masks found in segmentations folder');
    return new Map();
  }

  console.log(`Found ${maskFiles.length} segmentation files`);

  // Group files by target organ
  const organFileGroups = new Map<string, typeof maskFiles>();
  
  for (const file of maskFiles) {
    const organName = getOrganFromPath(file.storage_path);
    if (organName) {
      if (!organFileGroups.has(organName)) {
        organFileGroups.set(organName, []);
      }
      organFileGroups.get(organName)!.push(file);
    }
  }

  console.log(`Grouped into ${organFileGroups.size} organs:`, Array.from(organFileGroups.keys()));

  // Fetch organ colors
  const organNames = Array.from(organFileGroups.keys());
  const { data: organs, error: organsError } = await supabase
    .from('organs')
    .select('label, color')
    .in('label', organNames);

  if (organsError) {
    console.warn('Failed to fetch organ colors:', organsError);
  }

  const organColorMap = new Map(
    organs?.map(o => [o.label, o.color || '#ff0000']) || []
  );

  // Load and merge each organ
  const organMasks = new Map<string, { data: NiftiData; color: string }>();
  const totalOrgans = organFileGroups.size;
  let processedOrgans = 0;

  for (const [organName, files] of organFileGroups) {
    processedOrgans++;
    onProgress?.(processedOrgans, totalOrgans);

    try {
      console.log(`Loading ${organName} from ${files.length} file(s)`);

      // Load all component masks for this organ
      const loadedMasks: NiftiData[] = [];
      
      for (const file of files) {
        try {
          const isCompressed = file.storage_path.endsWith('.gz');
          const arrayBuffer = await downloadFile(
            file.storage_bucket,
            file.storage_path,
            studyId,
            'organ_mask',
            organName  // Use unified organ name for caching
          );
          const niftiData = await loadNiftiFile(arrayBuffer, isCompressed);
          loadedMasks.push(niftiData);
          
          console.log(`  - Loaded ${file.original_path}`);
        } catch (error) {
          console.error(`  - Failed to load ${file.original_path}:`, error);
        }
      }

      if (loadedMasks.length === 0) {
        throw new Error(`No valid masks loaded for ${organName}`);
      }

      // Merge all component masks into one unified mask
      const mergedMask = mergeNiftiMasks(loadedMasks, organName);
      
      const color = organColorMap.get(organName) || '#ff0000';
      
      organMasks.set(organName, {
        data: mergedMask,
        color,
      });

      console.log(`✅ Merged mask for ${organName} complete`);
      
    } catch (error) {
      console.error(`Failed to load/merge masks for ${organName}:`, error);
    }
  }

  console.log(`Loaded ${organMasks.size} merged organ masks`);
  return organMasks;
}

/**
 * Load dose distribution for a study
 */
export async function loadDoseDistribution(studyId: string): Promise<NiftiData | null> {
  console.log('Loading dose distribution for study:', studyId);

  // Resolve UUID to folder name
  const actualStudyId = await resolveStudyId(studyId);

  // Fetch dose distribution file
  const { data: doseFiles, error: doseError } = await supabase
    .from('extracted_files')
    .select('storage_path, storage_bucket')
    .eq('study_id', actualStudyId)
    .eq('file_type', 'nifti_dose')
    .limit(1);

  if (doseError) {
    throw new Error(`Failed to fetch dose distribution: ${doseError.message}`);
  }

  if (!doseFiles || doseFiles.length === 0) {
    console.warn('No dose distribution found for study');
    return null;
  }

  const file = doseFiles[0];
  const isCompressed = file.storage_path.endsWith('.gz');
  const arrayBuffer = await downloadFile(
    file.storage_bucket,
    file.storage_path,
    studyId,
    'dose'
  );
  const niftiData = await loadNiftiFile(arrayBuffer, isCompressed);

  console.log('Loaded dose distribution');
  return niftiData;
}

/**
 * Find dose range using percentiles for better visualization
 * Returns 5th and 95th percentiles as min/max to avoid outliers
 */
export function getDoseRange(doseData: NiftiData): { min: number; max: number } {
  // Collect all positive dose values
  const positiveValues: number[] = [];
  
  for (let i = 0; i < doseData.data.length; i++) {
    const value = doseData.data[i];
    if (value > 0) {
      positiveValues.push(value);
    }
  }

  if (positiveValues.length === 0) {
    return { min: 0, max: 1 };
  }

  // Sort values for percentile calculation
  positiveValues.sort((a, b) => a - b);

  // Calculate 5th and 95th percentiles
  const p5Index = Math.floor(positiveValues.length * 0.05);
  const p95Index = Math.floor(positiveValues.length * 0.95);

  const min = positiveValues[p5Index];
  const max = positiveValues[p95Index];

  // Ensure valid range
  return {
    min: min || 0,
    max: max > min ? max : min + 1,
  };
}
