/**
 * Nuclear Medicine Dose Coefficients
 *
 * Age-dependent organ absorbed dose coefficients (mGy/MBq) for radiotracers
 * commonly used in lymphoma imaging.
 *
 * All values from ICRP Publication 128 (2015), Annex C.
 * Age groups: Adult, 15 years, 10 years, 5 years, 1 year.
 *
 * Cross-checked against printed ICRP 128 tables (screenshots + text) on 2026-02-28.
 * All 10 tracers verified against ICRP 128 reference file:
 *   C.31 (FDG), C.39 (FLT), C.43 (Ga-67), C.81 (MIBI), C.99 (In-111 HIG),
 *   C.101 (In-111 MAb), C.103 (In-111 Octreotide), C.119 (I-123 MAb),
 *   C.121 (I-131 MAb), C.127 (Tl-201).
 */

export type AgeGroup = 'Adult' | '15 years' | '10 years' | '5 years' | '1 year';

export const AGE_GROUPS: AgeGroup[] = ['Adult', '15 years', '10 years', '5 years', '1 year'];

export interface RadioTracer {
  id: string;
  name: string;
  radionuclide: string;
  halfLife: string;
  modality: 'PET' | 'SPECT';
  /** Default administered activity in MBq (adult) */
  defaultActivityMBq: number;
  /** ICRP 128 table reference */
  icrpTable: string;
  source: string;
  /** Whether this is a therapeutic agent */
  isTherapeutic: boolean;
  /** Age-dependent organ dose coefficients in mGy/MBq */
  organCoefficients: Record<string, Record<AgeGroup, number>>;
  /** Age-dependent effective dose coefficient in mSv/MBq */
  effectiveDoseCoefficient: Record<AgeGroup, number>;
}

export interface NuclearMedicineOrganDose {
  organ_name: string;
  dose_mGy: number;
  coefficient_mGy_per_MBq: number;
}

/**
 * 10 tracers for lymphoma imaging from ICRP Publication 128
 */
export const RADIOTRACERS: RadioTracer[] = [
  // ─── 1. F-18 FDG (Table C.31) — VERIFIED against ICRP 128 screenshot ───
  {
    id: 'f18-fdg',
    name: 'F-18 FDG',
    radionuclide: 'F-18',
    halfLife: '1.83 h',
    modality: 'PET',
    defaultActivityMBq: 370,
    icrpTable: 'Table C.31',
    source: 'ICRP Publication 128, Table C.31',
    isTherapeutic: false,
    effectiveDoseCoefficient: { 'Adult': 1.9e-2, '15 years': 2.4e-2, '10 years': 3.7e-2, '5 years': 5.6e-2, '1 year': 9.5e-2 },
    organCoefficients: {
      'Adrenals':              { 'Adult': 1.2e-2, '15 years': 1.6e-2, '10 years': 2.4e-2, '5 years': 3.9e-2, '1 year': 7.1e-2 },
      'Bone surfaces':         { 'Adult': 1.1e-2, '15 years': 1.4e-2, '10 years': 2.2e-2, '5 years': 3.4e-2, '1 year': 6.4e-2 },
      'Brain':                 { 'Adult': 3.8e-2, '15 years': 3.9e-2, '10 years': 4.1e-2, '5 years': 4.6e-2, '1 year': 6.3e-2 },
      'Breast':                { 'Adult': 8.8e-3, '15 years': 1.1e-2, '10 years': 1.8e-2, '5 years': 2.9e-2, '1 year': 5.6e-2 },
      'Gallbladder wall':      { 'Adult': 1.3e-2, '15 years': 1.6e-2, '10 years': 2.4e-2, '5 years': 3.7e-2, '1 year': 7.0e-2 },
      'Stomach wall':          { 'Adult': 1.1e-2, '15 years': 1.4e-2, '10 years': 2.2e-2, '5 years': 3.5e-2, '1 year': 6.7e-2 },
      'Small intestine wall':  { 'Adult': 1.2e-2, '15 years': 1.6e-2, '10 years': 2.5e-2, '5 years': 4.0e-2, '1 year': 7.3e-2 },
      'Colon wall':            { 'Adult': 1.3e-2, '15 years': 1.6e-2, '10 years': 2.5e-2, '5 years': 3.9e-2, '1 year': 7.0e-2 },
      'Heart wall':            { 'Adult': 6.7e-2, '15 years': 8.7e-2, '10 years': 1.3e-1, '5 years': 2.1e-1, '1 year': 3.8e-1 },
      'Kidneys':               { 'Adult': 1.7e-2, '15 years': 2.1e-2, '10 years': 2.9e-2, '5 years': 4.5e-2, '1 year': 7.8e-2 },
      'Liver':                 { 'Adult': 2.1e-2, '15 years': 2.8e-2, '10 years': 4.2e-2, '5 years': 6.3e-2, '1 year': 1.2e-1 },
      'Lungs':                 { 'Adult': 2.0e-2, '15 years': 2.9e-2, '10 years': 4.1e-2, '5 years': 6.2e-2, '1 year': 1.2e-1 },
      'Muscles':               { 'Adult': 1.0e-2, '15 years': 1.3e-2, '10 years': 2.0e-2, '5 years': 3.3e-2, '1 year': 6.2e-2 },
      'Oesophagus':            { 'Adult': 1.2e-2, '15 years': 1.5e-2, '10 years': 2.2e-2, '5 years': 3.5e-2, '1 year': 6.6e-2 },
      'Ovaries':               { 'Adult': 1.4e-2, '15 years': 1.8e-2, '10 years': 2.7e-2, '5 years': 4.3e-2, '1 year': 7.6e-2 },
      'Pancreas':              { 'Adult': 1.3e-2, '15 years': 1.6e-2, '10 years': 2.6e-2, '5 years': 4.0e-2, '1 year': 7.6e-2 },
      'Red marrow':            { 'Adult': 1.1e-2, '15 years': 1.4e-2, '10 years': 2.1e-2, '5 years': 3.2e-2, '1 year': 5.9e-2 },
      'Skin':                  { 'Adult': 7.8e-3, '15 years': 9.6e-3, '10 years': 1.5e-2, '5 years': 2.6e-2, '1 year': 5.0e-2 },
      'Spleen':                { 'Adult': 1.1e-2, '15 years': 1.4e-2, '10 years': 2.1e-2, '5 years': 3.5e-2, '1 year': 6.6e-2 },
      'Testes':                { 'Adult': 1.1e-2, '15 years': 1.4e-2, '10 years': 2.4e-2, '5 years': 3.7e-2, '1 year': 6.6e-2 },
      'Thymus':                { 'Adult': 1.2e-2, '15 years': 1.5e-2, '10 years': 2.2e-2, '5 years': 3.5e-2, '1 year': 6.6e-2 },
      'Thyroid':               { 'Adult': 1.0e-2, '15 years': 1.3e-2, '10 years': 2.1e-2, '5 years': 3.4e-2, '1 year': 6.5e-2 },
      'Urinary bladder wall':  { 'Adult': 1.3e-1, '15 years': 1.6e-1, '10 years': 2.5e-1, '5 years': 3.4e-1, '1 year': 4.7e-1 },
      'Uterus':                { 'Adult': 1.8e-2, '15 years': 2.2e-2, '10 years': 3.6e-2, '5 years': 5.4e-2, '1 year': 9.0e-2 },
      'Remaining organs':      { 'Adult': 1.2e-2, '15 years': 1.5e-2, '10 years': 2.4e-2, '5 years': 3.8e-2, '1 year': 6.4e-2 },
    },
  },
  // ─── 2. F-18 FLT (Table C.39) — VERIFIED against ICRP 128 screenshot ───
  {
    id: 'f18-flt',
    name: 'F-18 FLT',
    radionuclide: 'F-18',
    halfLife: '1.83 h',
    modality: 'PET',
    defaultActivityMBq: 370,
    icrpTable: 'Table C.39',
    source: 'ICRP Publication 128, Table C.39',
    isTherapeutic: false,
    effectiveDoseCoefficient: { 'Adult': 1.5e-2, '15 years': 1.9e-2, '10 years': 2.9e-2, '5 years': 4.6e-2, '1 year': 8.8e-2 },
    organCoefficients: {
      'Adrenals':              { 'Adult': 1.6e-2, '15 years': 1.9e-2, '10 years': 2.9e-2, '5 years': 4.4e-2, '1 year': 7.7e-2 },
      'Bone surfaces':         { 'Adult': 1.9e-2, '15 years': 2.4e-2, '10 years': 3.7e-2, '5 years': 6.1e-2, '1 year': 1.3e-1 },
      'Brain':                 { 'Adult': 8.2e-3, '15 years': 1.0e-2, '10 years': 1.7e-2, '5 years': 2.8e-2, '1 year': 5.2e-2 },
      'Breast':                { 'Adult': 8.2e-3, '15 years': 1.0e-2, '10 years': 1.6e-2, '5 years': 2.5e-2, '1 year': 4.9e-2 },
      'Gallbladder wall':      { 'Adult': 1.8e-2, '15 years': 2.1e-2, '10 years': 3.0e-2, '5 years': 4.6e-2, '1 year': 8.5e-2 },
      'Stomach wall':          { 'Adult': 1.2e-2, '15 years': 1.4e-2, '10 years': 2.2e-2, '5 years': 3.5e-2, '1 year': 6.6e-2 },
      'Small intestine wall':  { 'Adult': 1.3e-2, '15 years': 1.6e-2, '10 years': 2.5e-2, '5 years': 3.8e-2, '1 year': 6.9e-2 },
      'Colon wall':            { 'Adult': 1.2e-2, '15 years': 1.5e-2, '10 years': 2.3e-2, '5 years': 3.6e-2, '1 year': 6.5e-2 },
      'Heart wall':            { 'Adult': 1.2e-2, '15 years': 1.5e-2, '10 years': 2.4e-2, '5 years': 3.6e-2, '1 year': 6.5e-2 },
      'Kidneys':               { 'Adult': 4.3e-2, '15 years': 5.1e-2, '10 years': 7.2e-2, '5 years': 1.1e-1, '1 year': 1.9e-1 },
      'Liver':                 { 'Adult': 4.8e-2, '15 years': 6.3e-2, '10 years': 9.4e-2, '5 years': 1.4e-1, '1 year': 2.6e-1 },
      'Lungs':                 { 'Adult': 1.1e-2, '15 years': 1.4e-2, '10 years': 2.1e-2, '5 years': 3.2e-2, '1 year': 6.0e-2 },
      'Muscles':               { 'Adult': 9.8e-3, '15 years': 1.2e-2, '10 years': 1.9e-2, '5 years': 3.0e-2, '1 year': 5.6e-2 },
      'Oesophagus':            { 'Adult': 9.8e-3, '15 years': 1.3e-2, '10 years': 1.9e-2, '5 years': 3.0e-2, '1 year': 5.6e-2 },
      'Ovaries':               { 'Adult': 1.2e-2, '15 years': 1.5e-2, '10 years': 2.4e-2, '5 years': 3.6e-2, '1 year': 6.6e-2 },
      'Pancreas':              { 'Adult': 1.5e-2, '15 years': 1.9e-2, '10 years': 2.9e-2, '5 years': 4.4e-2, '1 year': 7.9e-2 },
      'Red marrow':            { 'Adult': 2.6e-2, '15 years': 3.0e-2, '10 years': 4.8e-2, '5 years': 8.6e-2, '1 year': 1.9e-1 },
      'Skin':                  { 'Adult': 7.5e-3, '15 years': 9.2e-3, '10 years': 1.5e-2, '5 years': 2.4e-2, '1 year': 4.6e-2 },
      'Spleen':                { 'Adult': 2.2e-2, '15 years': 3.1e-2, '10 years': 4.7e-2, '5 years': 7.3e-2, '1 year': 1.3e-1 },
      'Testes':                { 'Adult': 8.8e-3, '15 years': 1.1e-2, '10 years': 1.7e-2, '5 years': 2.7e-2, '1 year': 5.2e-2 },
      'Thymus':                { 'Adult': 9.8e-3, '15 years': 1.3e-2, '10 years': 1.9e-2, '5 years': 3.0e-2, '1 year': 5.6e-2 },
      'Thyroid':               { 'Adult': 9.4e-3, '15 years': 1.2e-2, '10 years': 1.9e-2, '5 years': 3.1e-2, '1 year': 5.8e-2 },
      'Urinary bladder wall':  { 'Adult': 2.3e-2, '15 years': 2.8e-2, '10 years': 4.2e-2, '5 years': 6.2e-2, '1 year': 9.2e-2 },
      'Uterus':                { 'Adult': 1.2e-2, '15 years': 1.5e-2, '10 years': 2.4e-2, '5 years': 3.7e-2, '1 year': 6.6e-2 },
      'Remaining organs':      { 'Adult': 1.0e-2, '15 years': 1.3e-2, '10 years': 2.0e-2, '5 years': 3.3e-2, '1 year': 6.0e-2 },
    },
  },
  // ─── 3. Ga-67 Citrate (Table C.43) — VERIFIED against ICRP 128 screenshot ───
  {
    id: 'ga67-citrate',
    name: 'Ga-67 Citrate',
    radionuclide: 'Ga-67',
    halfLife: '3.26 d',
    modality: 'SPECT',
    defaultActivityMBq: 150,
    icrpTable: 'Table C.43',
    source: 'ICRP Publication 128, Table C.43',
    isTherapeutic: false,
    effectiveDoseCoefficient: { 'Adult': 1.0e-1, '15 years': 1.3e-1, '10 years': 2.0e-1, '5 years': 3.3e-1, '1 year': 6.4e-1 },
    organCoefficients: {
      'Adrenals':              { 'Adult': 1.3e-1, '15 years': 1.8e-1, '10 years': 2.6e-1, '5 years': 3.6e-1, '1 year': 5.7e-1 },
      'Bone surfaces':         { 'Adult': 6.3e-1, '15 years': 8.1e-1, '10 years': 1.3e+0, '5 years': 2.2e+0, '1 year': 5.2e+0 },
      'Brain':                 { 'Adult': 5.7e-2, '15 years': 7.2e-2, '10 years': 1.2e-1, '5 years': 1.9e-1, '1 year': 3.4e-1 },
      'Breast':                { 'Adult': 4.7e-2, '15 years': 6.1e-2, '10 years': 9.3e-2, '5 years': 1.5e-1, '1 year': 2.9e-1 },
      'Gallbladder wall':      { 'Adult': 8.2e-2, '15 years': 1.1e-1, '10 years': 1.7e-1, '5 years': 2.5e-1, '1 year': 3.8e-1 },
      'Stomach wall':          { 'Adult': 6.9e-2, '15 years': 9.0e-2, '10 years': 1.4e-1, '5 years': 2.1e-1, '1 year': 3.9e-1 },
      'Small intestine wall':  { 'Adult': 5.9e-2, '15 years': 7.4e-2, '10 years': 1.1e-1, '5 years': 1.6e-1, '1 year': 2.8e-1 },
      'Colon wall':            { 'Adult': 1.6e-1, '15 years': 2.0e-1, '10 years': 3.3e-1, '5 years': 5.4e-1, '1 year': 1.0e+0 },
      'Heart wall':            { 'Adult': 6.9e-2, '15 years': 8.9e-2, '10 years': 1.4e-1, '5 years': 2.1e-1, '1 year': 3.8e-1 },
      'Kidneys':               { 'Adult': 1.2e-1, '15 years': 1.4e-1, '10 years': 2.0e-1, '5 years': 2.9e-1, '1 year': 5.1e-1 },
      'Liver':                 { 'Adult': 1.2e-1, '15 years': 1.5e-1, '10 years': 2.3e-1, '5 years': 3.3e-1, '1 year': 6.1e-1 },
      'Lungs':                 { 'Adult': 6.3e-2, '15 years': 8.3e-2, '10 years': 1.3e-1, '5 years': 1.9e-1, '1 year': 3.6e-1 },
      'Muscles':               { 'Adult': 6.0e-2, '15 years': 7.6e-2, '10 years': 1.2e-1, '5 years': 1.8e-1, '1 year': 3.5e-1 },
      'Oesophagus':            { 'Adult': 6.1e-2, '15 years': 7.9e-2, '10 years': 1.2e-1, '5 years': 1.9e-1, '1 year': 3.5e-1 },
      'Ovaries':               { 'Adult': 8.2e-2, '15 years': 1.1e-1, '10 years': 1.6e-1, '5 years': 2.4e-1, '1 year': 4.5e-1 },
      'Pancreas':              { 'Adult': 8.1e-2, '15 years': 1.0e-1, '10 years': 1.6e-1, '5 years': 2.4e-1, '1 year': 4.3e-1 },
      'Red marrow':            { 'Adult': 2.1e-1, '15 years': 2.3e-1, '10 years': 3.8e-1, '5 years': 7.1e-1, '1 year': 1.5e+0 },
      'Skin':                  { 'Adult': 4.5e-2, '15 years': 5.7e-2, '10 years': 9.2e-2, '5 years': 1.5e-1, '1 year': 2.9e-1 },
      'Spleen':                { 'Adult': 1.4e-1, '15 years': 2.0e-1, '10 years': 3.1e-1, '5 years': 4.8e-1, '1 year': 8.6e-1 },
      'Testes':                { 'Adult': 5.6e-2, '15 years': 7.2e-2, '10 years': 1.1e-1, '5 years': 1.8e-1, '1 year': 3.3e-1 },
      'Thymus':                { 'Adult': 6.1e-2, '15 years': 7.9e-2, '10 years': 1.2e-1, '5 years': 1.9e-1, '1 year': 3.5e-1 },
      'Thyroid':               { 'Adult': 6.2e-2, '15 years': 8.0e-2, '10 years': 1.3e-1, '5 years': 2.0e-1, '1 year': 3.8e-1 },
      'Urinary bladder wall':  { 'Adult': 8.1e-2, '15 years': 1.1e-1, '10 years': 1.5e-1, '5 years': 2.0e-1, '1 year': 3.7e-1 },
      'Uterus':                { 'Adult': 7.6e-2, '15 years': 9.7e-2, '10 years': 1.5e-1, '5 years': 2.3e-1, '1 year': 4.2e-1 },
      'Remaining organs':      { 'Adult': 6.1e-2, '15 years': 7.8e-2, '10 years': 1.2e-1, '5 years': 1.9e-1, '1 year': 3.5e-1 },
    },
  },
  // ─── 4. Tl-201 Ion (Table C.127) — VERIFIED against ICRP 128 screenshot ───
  {
    id: 'tl201-ion',
    name: 'Tl-201 Ion',
    radionuclide: 'Tl-201',
    halfLife: '3.05 d',
    modality: 'SPECT',
    defaultActivityMBq: 111,
    icrpTable: 'Table C.127',
    source: 'ICRP Publication 128, Table C.127',
    isTherapeutic: false,
    effectiveDoseCoefficient: { 'Adult': 1.4e-1, '15 years': 2.0e-1, '10 years': 5.6e-1, '5 years': 7.9e-1, '1 year': 1.3e+0 },
    organCoefficients: {
      'Adrenals':              { 'Adult': 5.7e-2, '15 years': 7.0e-2, '10 years': 1.0e-1, '5 years': 1.5e-1, '1 year': 2.7e-1 },
      'Bone surfaces':         { 'Adult': 3.8e-1, '15 years': 3.9e-1, '10 years': 6.9e-1, '5 years': 1.2e+0, '1 year': 1.9e+0 },
      'Brain':                 { 'Adult': 2.2e-2, '15 years': 2.4e-2, '10 years': 3.6e-2, '5 years': 5.4e-2, '1 year': 1.0e-1 },
      'Breast':                { 'Adult': 2.4e-2, '15 years': 2.7e-2, '10 years': 4.4e-2, '5 years': 6.6e-2, '1 year': 1.3e-1 },
      'Gallbladder wall':      { 'Adult': 6.5e-2, '15 years': 8.1e-2, '10 years': 1.3e-1, '5 years': 1.9e-1, '1 year': 3.1e-1 },
      'Stomach wall':          { 'Adult': 1.1e-1, '15 years': 1.5e-1, '10 years': 2.2e-1, '5 years': 3.5e-1, '1 year': 7.3e-1 },
      'Small intestine wall':  { 'Adult': 1.4e-1, '15 years': 1.8e-1, '10 years': 3.1e-1, '5 years': 5.0e-1, '1 year': 9.4e-1 },
      'Colon wall':            { 'Adult': 2.5e-1, '15 years': 3.2e-1, '10 years': 5.5e-1, '5 years': 9.2e-1, '1 year': 1.8e+0 },
      'Heart wall':            { 'Adult': 1.9e-1, '15 years': 2.4e-1, '10 years': 3.8e-1, '5 years': 6.0e-1, '1 year': 1.1e+0 },
      'Kidneys':               { 'Adult': 4.8e-1, '15 years': 5.8e-1, '10 years': 8.2e-1, '5 years': 1.2e+0, '1 year': 2.2e+0 },
      'Liver':                 { 'Adult': 1.5e-1, '15 years': 2.0e-1, '10 years': 3.1e-1, '5 years': 4.5e-1, '1 year': 8.4e-1 },
      'Lungs':                 { 'Adult': 1.1e-1, '15 years': 1.6e-1, '10 years': 2.3e-1, '5 years': 3.6e-1, '1 year': 6.9e-1 },
      'Muscles':               { 'Adult': 5.2e-2, '15 years': 8.2e-2, '10 years': 1.6e-1, '5 years': 4.5e-1, '1 year': 7.6e-1 },
      'Oesophagus':            { 'Adult': 3.6e-2, '15 years': 4.2e-2, '10 years': 6.0e-2, '5 years': 9.0e-2, '1 year': 1.6e-1 },
      'Ovaries':               { 'Adult': 1.2e-1, '15 years': 1.2e-1, '10 years': 2.9e-1, '5 years': 4.9e-1, '1 year': 1.1e+0 },
      'Pancreas':              { 'Adult': 5.7e-2, '15 years': 7.0e-2, '10 years': 1.1e-1, '5 years': 1.6e-1, '1 year': 2.8e-1 },
      'Red marrow':            { 'Adult': 1.1e-1, '15 years': 1.3e-1, '10 years': 2.2e-1, '5 years': 4.5e-1, '1 year': 1.1e+0 },
      'Skin':                  { 'Adult': 2.1e-2, '15 years': 2.4e-2, '10 years': 3.8e-2, '5 years': 5.8e-2, '1 year': 1.1e-1 },
      'Spleen':                { 'Adult': 1.2e-1, '15 years': 1.7e-1, '10 years': 2.6e-1, '5 years': 4.1e-1, '1 year': 7.4e-1 },
      'Testes':                { 'Adult': 1.8e-1, '15 years': 4.1e-1, '10 years': 3.1e+0, '5 years': 3.6e+0, '1 year': 4.9e+0 },
      'Thymus':                { 'Adult': 3.6e-2, '15 years': 4.2e-2, '10 years': 6.0e-2, '5 years': 9.0e-2, '1 year': 1.6e-1 },
      'Thyroid':               { 'Adult': 2.2e-1, '15 years': 3.5e-1, '10 years': 5.4e-1, '5 years': 1.2e+0, '1 year': 2.3e+0 },
      'Urinary bladder wall':  { 'Adult': 3.9e-2, '15 years': 5.4e-2, '10 years': 7.9e-2, '5 years': 1.2e-1, '1 year': 2.2e-1 },
      'Uterus':                { 'Adult': 5.0e-2, '15 years': 6.2e-2, '10 years': 9.9e-2, '5 years': 1.5e-1, '1 year': 2.7e-1 },
      'Remaining organs':      { 'Adult': 5.4e-2, '15 years': 8.2e-2, '10 years': 1.6e-1, '5 years': 3.4e-1, '1 year': 5.5e-1 },
    },
  },
  // ─── 5. Tc-99m MIBI (Sestamibi) resting (Table C.81) — VERIFIED against ICRP 128 screenshot ───
  {
    id: 'tc99m-mibi',
    name: 'Tc-99m MIBI (Sestamibi)',
    radionuclide: 'Tc-99m',
    halfLife: '6.01 h',
    modality: 'SPECT',
    defaultActivityMBq: 740,
    icrpTable: 'Table C.81',
    source: 'ICRP Publication 128, Table C.81 (resting)',
    isTherapeutic: false,
    effectiveDoseCoefficient: { 'Adult': 9.0e-3, '15 years': 1.2e-2, '10 years': 1.8e-2, '5 years': 2.8e-2, '1 year': 5.3e-2 },
    organCoefficients: {
      'Adrenals':              { 'Adult': 7.5e-3, '15 years': 9.9e-3, '10 years': 1.5e-2, '5 years': 2.2e-2, '1 year': 3.8e-2 },
      'Bone surfaces':         { 'Adult': 8.2e-3, '15 years': 1.0e-2, '10 years': 1.6e-2, '5 years': 2.1e-2, '1 year': 3.8e-2 },
      'Brain':                 { 'Adult': 5.2e-3, '15 years': 7.1e-3, '10 years': 1.1e-2, '5 years': 1.6e-2, '1 year': 2.7e-2 },
      'Breast':                { 'Adult': 3.8e-3, '15 years': 5.3e-3, '10 years': 7.1e-3, '5 years': 1.1e-2, '1 year': 2.0e-2 },
      'Gallbladder wall':      { 'Adult': 3.9e-2, '15 years': 4.5e-2, '10 years': 5.8e-2, '5 years': 1.0e-1, '1 year': 3.2e-1 },
      'Stomach wall':          { 'Adult': 6.5e-3, '15 years': 9.0e-3, '10 years': 1.5e-2, '5 years': 2.1e-2, '1 year': 3.5e-2 },
      'Small intestine wall':  { 'Adult': 1.5e-2, '15 years': 1.8e-2, '10 years': 2.9e-2, '5 years': 4.5e-2, '1 year': 8.0e-2 },
      'Colon wall':            { 'Adult': 2.4e-2, '15 years': 3.1e-2, '10 years': 5.0e-2, '5 years': 7.9e-2, '1 year': 1.5e-1 },
      'Heart wall':            { 'Adult': 6.3e-3, '15 years': 8.2e-3, '10 years': 1.2e-2, '5 years': 1.8e-2, '1 year': 3.0e-2 },
      'Kidneys':               { 'Adult': 3.6e-2, '15 years': 4.3e-2, '10 years': 5.9e-2, '5 years': 8.5e-2, '1 year': 1.5e-1 },
      'Liver':                 { 'Adult': 1.1e-2, '15 years': 1.4e-2, '10 years': 2.1e-2, '5 years': 3.0e-2, '1 year': 5.2e-2 },
      'Lungs':                 { 'Adult': 4.6e-3, '15 years': 6.4e-3, '10 years': 9.7e-3, '5 years': 1.4e-2, '1 year': 2.5e-2 },
      'Muscles':               { 'Adult': 2.9e-3, '15 years': 3.7e-3, '10 years': 5.4e-3, '5 years': 7.6e-3, '1 year': 1.4e-2 },
      'Oesophagus':            { 'Adult': 4.1e-3, '15 years': 5.7e-3, '10 years': 8.6e-3, '5 years': 1.3e-2, '1 year': 2.3e-2 },
      'Ovaries':               { 'Adult': 9.1e-3, '15 years': 1.2e-2, '10 years': 1.8e-2, '5 years': 2.5e-2, '1 year': 4.5e-2 },
      'Pancreas':              { 'Adult': 7.7e-3, '15 years': 1.0e-2, '10 years': 1.6e-2, '5 years': 2.4e-2, '1 year': 3.9e-2 },
      'Red marrow':            { 'Adult': 5.5e-3, '15 years': 7.1e-3, '10 years': 1.1e-2, '5 years': 3.0e-2, '1 year': 4.4e-2 },
      'Salivary glands':       { 'Adult': 1.4e-2, '15 years': 1.7e-2, '10 years': 2.2e-2, '5 years': 1.5e-2, '1 year': 2.6e-2 },
      'Skin':                  { 'Adult': 3.1e-3, '15 years': 4.1e-3, '10 years': 6.4e-3, '5 years': 9.8e-3, '1 year': 1.9e-2 },
      'Spleen':                { 'Adult': 6.5e-3, '15 years': 8.6e-3, '10 years': 1.4e-2, '5 years': 2.0e-2, '1 year': 3.4e-2 },
      'Testes':                { 'Adult': 3.8e-3, '15 years': 5.0e-3, '10 years': 7.5e-3, '5 years': 1.1e-2, '1 year': 2.1e-2 },
      'Thymus':                { 'Adult': 4.1e-3, '15 years': 5.7e-3, '10 years': 8.6e-3, '5 years': 1.3e-2, '1 year': 2.3e-2 },
      'Thyroid':               { 'Adult': 5.3e-3, '15 years': 7.9e-3, '10 years': 1.2e-2, '5 years': 2.4e-2, '1 year': 4.5e-2 },
      'Urinary bladder wall':  { 'Adult': 1.1e-2, '15 years': 1.4e-2, '10 years': 1.9e-2, '5 years': 2.3e-2, '1 year': 4.1e-2 },
      'Uterus':                { 'Adult': 7.8e-3, '15 years': 1.0e-2, '10 years': 1.5e-2, '5 years': 2.2e-2, '1 year': 3.8e-2 },
      'Remaining organs':      { 'Adult': 3.1e-3, '15 years': 3.9e-3, '10 years': 6.0e-3, '5 years': 8.8e-3, '1 year': 1.6e-2 },
    },
  },
  // ─── 6. In-111 Human Immunoglobulin (Table C.99) — VERIFIED against ICRP 128 reference file ───
  {
    id: 'in111-hig',
    name: 'In-111 Human Immunoglobulin',
    radionuclide: 'In-111',
    halfLife: '67.9 h',
    modality: 'SPECT',
    defaultActivityMBq: 74,
    icrpTable: 'Table C.99',
    source: 'ICRP Publication 128, Table C.99',
    isTherapeutic: false,
    effectiveDoseCoefficient: { 'Adult': 1.7e-1, '15 years': 2.2e-1, '10 years': 4.1e-1, '5 years': 5.8e-1, '1 year': 9.9e-1 },
    organCoefficients: {
      'Adrenals':              { 'Adult': 2.1e-1, '15 years': 2.5e-1, '10 years': 3.8e-1, '5 years': 5.8e-1, '1 year': 1.0e+0 },
      'Bone surfaces':         { 'Adult': 1.8e-1, '15 years': 2.3e-1, '10 years': 3.5e-1, '5 years': 5.5e-1, '1 year': 1.1e+0 },
      'Brain':                 { 'Adult': 9.8e-2, '15 years': 1.2e-1, '10 years': 2.0e-1, '5 years': 3.3e-1, '1 year': 5.8e-1 },
      'Breast':                { 'Adult': 9.1e-2, '15 years': 1.1e-1, '10 years': 1.7e-1, '5 years': 2.7e-1, '1 year': 5.0e-1 },
      'Gallbladder wall':      { 'Adult': 2.1e-1, '15 years': 2.6e-1, '10 years': 3.9e-1, '5 years': 5.8e-1, '1 year': 8.8e-1 },
      'Stomach wall':          { 'Adult': 1.5e-1, '15 years': 1.9e-1, '10 years': 2.9e-1, '5 years': 4.4e-1, '1 year': 7.6e-1 },
      'Small intestine wall':  { 'Adult': 1.4e-1, '15 years': 1.7e-1, '10 years': 2.7e-1, '5 years': 4.2e-1, '1 year': 7.4e-1 },
      'Colon wall':            { 'Adult': 1.4e-1, '15 years': 1.7e-1, '10 years': 2.6e-1, '5 years': 4.1e-1, '1 year': 7.0e-1 },
      'Heart wall':            { 'Adult': 2.9e-1, '15 years': 3.6e-1, '10 years': 5.4e-1, '5 years': 8.1e-1, '1 year': 1.4e+0 },
      'Kidneys':               { 'Adult': 2.3e-1, '15 years': 2.8e-1, '10 years': 4.2e-1, '5 years': 6.4e-1, '1 year': 1.1e+0 },
      'Liver':                 { 'Adult': 3.9e-1, '15 years': 5.0e-1, '10 years': 7.5e-1, '5 years': 1.1e+0, '1 year': 1.9e+0 },
      'Lungs':                 { 'Adult': 2.3e-1, '15 years': 2.9e-1, '10 years': 4.5e-1, '5 years': 6.9e-1, '1 year': 1.3e+0 },
      'Muscles':               { 'Adult': 1.1e-1, '15 years': 1.3e-1, '10 years': 2.0e-1, '5 years': 3.1e-1, '1 year': 5.8e-1 },
      'Oesophagus':            { 'Adult': 1.4e-1, '15 years': 1.7e-1, '10 years': 2.4e-1, '5 years': 3.7e-1, '1 year': 6.5e-1 },
      'Ovaries':               { 'Adult': 1.3e-1, '15 years': 1.7e-1, '10 years': 2.5e-1, '5 years': 3.8e-1, '1 year': 6.9e-1 },
      'Pancreas':              { 'Adult': 2.0e-1, '15 years': 2.5e-1, '10 years': 3.8e-1, '5 years': 5.8e-1, '1 year': 1.0e+0 },
      'Red marrow':            { 'Adult': 1.3e-1, '15 years': 1.6e-1, '10 years': 2.5e-1, '5 years': 3.7e-1, '1 year': 6.7e-1 },
      'Skin':                  { 'Adult': 7.0e-2, '15 years': 8.3e-2, '10 years': 1.3e-1, '5 years': 2.1e-1, '1 year': 3.9e-1 },
      'Spleen':                { 'Adult': 6.0e-1, '15 years': 8.1e-1, '10 years': 1.2e+0, '5 years': 1.9e+0, '1 year': 3.3e+0 },
      'Testes':                { 'Adult': 1.3e-1, '15 years': 2.2e-1, '10 years': 1.1e+0, '5 years': 1.3e+0, '1 year': 1.8e+0 },
      'Thymus':                { 'Adult': 1.4e-1, '15 years': 1.7e-1, '10 years': 2.4e-1, '5 years': 3.7e-1, '1 year': 6.5e-1 },
      'Thyroid':               { 'Adult': 1.3e-1, '15 years': 1.6e-1, '10 years': 2.5e-1, '5 years': 4.1e-1, '1 year': 7.6e-1 },
      'Urinary bladder wall':  { 'Adult': 1.3e-1, '15 years': 1.8e-1, '10 years': 2.4e-1, '5 years': 3.3e-1, '1 year': 5.8e-1 },
      'Uterus':                { 'Adult': 1.3e-1, '15 years': 1.7e-1, '10 years': 2.6e-1, '5 years': 3.9e-1, '1 year': 6.9e-1 },
      'Remaining organs':      { 'Adult': 1.1e-1, '15 years': 1.4e-1, '10 years': 2.1e-1, '5 years': 3.4e-1, '1 year': 6.1e-1 },
    },
  },
  // ─── 7. In-111 Monoclonal Antibodies (Table C.101) — VERIFIED against ICRP 128 text file ───
  {
    id: 'in111-mab',
    name: 'In-111 Monoclonal Antibodies',
    radionuclide: 'In-111',
    halfLife: '67.9 h',
    modality: 'SPECT',
    defaultActivityMBq: 185,
    icrpTable: 'Table C.101',
    source: 'ICRP Publication 128, Table C.101 (intact antibody)',
    isTherapeutic: false,
    effectiveDoseCoefficient: { 'Adult': 2.2e-1, '15 years': 2.7e-1, '10 years': 4.1e-1, '5 years': 6.4e-1, '1 year': 1.2e+0 },
    organCoefficients: {
      'Adrenals':              { 'Adult': 3.1e-1, '15 years': 3.7e-1, '10 years': 5.3e-1, '5 years': 7.2e-1, '1 year': 1.2e+0 },
      'Bone surfaces':         { 'Adult': 3.2e-1, '15 years': 3.6e-1, '10 years': 5.7e-1, '5 years': 9.4e-1, '1 year': 1.6e+0 },
      'Brain':                 { 'Adult': 5.7e-2, '15 years': 7.3e-2, '10 years': 1.1e-1, '5 years': 1.8e-1, '1 year': 3.3e-1 },
      'Breast':                { 'Adult': 6.9e-2, '15 years': 8.5e-2, '10 years': 1.4e-1, '5 years': 2.1e-1, '1 year': 3.8e-1 },
      'Gallbladder wall':      { 'Adult': 3.8e-1, '15 years': 4.3e-1, '10 years': 6.0e-1, '5 years': 9.2e-1, '1 year': 1.6e+0 },
      'Stomach wall':          { 'Adult': 1.6e-1, '15 years': 2.0e-1, '10 years': 3.1e-1, '5 years': 4.8e-1, '1 year': 8.3e-1 },
      'Small intestine wall':  { 'Adult': 1.5e-1, '15 years': 1.8e-1, '10 years': 2.8e-1, '5 years': 4.3e-1, '1 year': 7.1e-1 },
      'Colon wall':            { 'Adult': 1.4e-1, '15 years': 1.7e-1, '10 years': 2.7e-1, '5 years': 4.2e-1, '1 year': 6.9e-1 },
      'Heart wall':            { 'Adult': 1.6e-1, '15 years': 2.0e-1, '10 years': 2.9e-1, '5 years': 4.1e-1, '1 year': 7.3e-1 },
      'Kidneys':               { 'Adult': 8.0e-1, '15 years': 9.5e-1, '10 years': 1.3e+0, '5 years': 1.9e+0, '1 year': 3.1e+0 },
      'Liver':                 { 'Adult': 1.1e+0, '15 years': 1.4e+0, '10 years': 2.0e+0, '5 years': 2.8e+0, '1 year': 4.8e+0 },
      'Lungs':                 { 'Adult': 1.4e-1, '15 years': 1.8e-1, '10 years': 2.6e-1, '5 years': 3.8e-1, '1 year': 6.7e-1 },
      'Muscles':               { 'Adult': 9.6e-2, '15 years': 1.2e-1, '10 years': 1.8e-1, '5 years': 2.6e-1, '1 year': 4.8e-1 },
      'Oesophagus':            { 'Adult': 8.6e-2, '15 years': 1.0e-1, '10 years': 1.5e-1, '5 years': 2.2e-1, '1 year': 3.8e-1 },
      'Ovaries':               { 'Adult': 1.2e-1, '15 years': 1.5e-1, '10 years': 2.2e-1, '5 years': 3.3e-1, '1 year': 5.5e-1 },
      'Pancreas':              { 'Adult': 2.9e-1, '15 years': 3.5e-1, '10 years': 5.3e-1, '5 years': 8.0e-1, '1 year': 1.3e+0 },
      'Red marrow':            { 'Adult': 4.1e-1, '15 years': 4.6e-1, '10 years': 6.9e-1, '5 years': 1.2e+0, '1 year': 2.8e+0 },
      'Skin':                  { 'Adult': 5.4e-2, '15 years': 6.5e-2, '10 years': 1.0e-1, '5 years': 1.6e-1, '1 year': 3.1e-1 },
      'Spleen':                { 'Adult': 1.1e+0, '15 years': 1.5e+0, '10 years': 2.2e+0, '5 years': 3.4e+0, '1 year': 5.9e+0 },
      'Testes':                { 'Adult': 4.8e-2, '15 years': 6.2e-2, '10 years': 9.5e-2, '5 years': 1.5e-1, '1 year': 2.7e-1 },
      'Thymus':                { 'Adult': 8.6e-2, '15 years': 1.0e-1, '10 years': 1.5e-1, '5 years': 2.2e-1, '1 year': 3.8e-1 },
      'Thyroid':               { 'Adult': 6.6e-2, '15 years': 8.2e-2, '10 years': 1.2e-1, '5 years': 2.0e-1, '1 year': 3.6e-1 },
      'Urinary bladder wall':  { 'Adult': 7.8e-2, '15 years': 9.9e-2, '10 years': 1.6e-1, '5 years': 2.4e-1, '1 year': 4.1e-1 },
      'Uterus':                { 'Adult': 1.1e-1, '15 years': 1.3e-1, '10 years': 2.0e-1, '5 years': 3.0e-1, '1 year': 5.0e-1 },
      'Remaining organs':      { 'Adult': 1.0e-1, '15 years': 1.3e-1, '10 years': 2.0e-1, '5 years': 3.0e-1, '1 year': 5.1e-1 },
    },
  },
  // ─── 8. I-123 Monoclonal Antibodies (Table C.119) — VERIFIED against ICRP 128 screenshot ───
  {
    id: 'i123-mab',
    name: 'I-123 Monoclonal Antibodies',
    radionuclide: 'I-123',
    halfLife: '13.2 h',
    modality: 'SPECT',
    defaultActivityMBq: 185,
    icrpTable: 'Table C.119',
    source: 'ICRP Publication 128, Table C.119 (intact antibody)',
    isTherapeutic: false,
    effectiveDoseCoefficient: { 'Adult': 2.6e-2, '15 years': 3.3e-2, '10 years': 5.1e-2, '5 years': 8.0e-2, '1 year': 1.5e-1 },
    organCoefficients: {
      'Adrenals':              { 'Adult': 2.7e-2, '15 years': 3.4e-2, '10 years': 5.0e-2, '5 years': 6.9e-2, '1 year': 1.1e-1 },
      'Bone surfaces':         { 'Adult': 3.2e-2, '15 years': 3.7e-2, '10 years': 6.0e-2, '5 years': 1.0e-1, '1 year': 1.8e-1 },
      'Brain':                 { 'Adult': 4.5e-3, '15 years': 5.8e-3, '10 years': 9.0e-3, '5 years': 1.5e-2, '1 year': 2.8e-2 },
      'Breast':                { 'Adult': 6.0e-3, '15 years': 7.4e-3, '10 years': 1.2e-2, '5 years': 1.9e-2, '1 year': 3.7e-2 },
      'Gallbladder wall':      { 'Adult': 4.0e-2, '15 years': 4.8e-2, '10 years': 6.7e-2, '5 years': 1.0e-1, '1 year': 1.9e-1 },
      'Stomach wall':          { 'Adult': 1.5e-2, '15 years': 1.9e-2, '10 years': 3.2e-2, '5 years': 5.1e-2, '1 year': 9.2e-2 },
      'Small intestine wall':  { 'Adult': 1.2e-2, '15 years': 1.5e-2, '10 years': 2.4e-2, '5 years': 3.9e-2, '1 year': 6.9e-2 },
      'Colon wall':            { 'Adult': 1.2e-2, '15 years': 1.4e-2, '10 years': 2.4e-2, '5 years': 4.0e-2, '1 year': 6.8e-2 },
      'Heart wall':            { 'Adult': 1.4e-2, '15 years': 1.8e-2, '10 years': 2.8e-2, '5 years': 4.2e-2, '1 year': 7.7e-2 },
      'Kidneys':               { 'Adult': 5.9e-2, '15 years': 7.2e-2, '10 years': 1.0e-1, '5 years': 1.5e-1, '1 year': 2.5e-1 },
      'Liver':                 { 'Adult': 1.5e-1, '15 years': 1.9e-1, '10 years': 2.9e-1, '5 years': 4.0e-1, '1 year': 7.3e-1 },
      'Lungs':                 { 'Adult': 1.4e-2, '15 years': 1.8e-2, '10 years': 2.7e-2, '5 years': 4.0e-2, '1 year': 7.2e-2 },
      'Muscles':               { 'Adult': 8.5e-3, '15 years': 1.1e-2, '10 years': 1.6e-2, '5 years': 2.4e-2, '1 year': 4.5e-2 },
      'Oesophagus':            { 'Adult': 6.9e-3, '15 years': 8.6e-3, '10 years': 1.3e-2, '5 years': 2.0e-2, '1 year': 3.5e-2 },
      'Ovaries':               { 'Adult': 9.4e-3, '15 years': 1.2e-2, '10 years': 1.9e-2, '5 years': 2.9e-2, '1 year': 5.0e-2 },
      'Pancreas':              { 'Adult': 3.0e-2, '15 years': 3.7e-2, '10 years': 5.8e-2, '5 years': 8.9e-2, '1 year': 1.5e-1 },
      'Red marrow':            { 'Adult': 3.7e-2, '15 years': 4.2e-2, '10 years': 6.7e-2, '5 years': 1.3e-1, '1 year': 3.0e-1 },
      'Skin':                  { 'Adult': 4.7e-3, '15 years': 5.7e-3, '10 years': 9.1e-3, '5 years': 1.5e-2, '1 year': 2.8e-2 },
      'Spleen':                { 'Adult': 2.0e-1, '15 years': 2.9e-1, '10 years': 4.4e-1, '5 years': 6.7e-1, '1 year': 1.2e+0 },
      'Testes':                { 'Adult': 4.3e-3, '15 years': 5.6e-3, '10 years': 9.0e-3, '5 years': 1.4e-2, '1 year': 2.6e-2 },
      'Thymus':                { 'Adult': 6.9e-3, '15 years': 8.6e-3, '10 years': 1.3e-2, '5 years': 2.0e-2, '1 year': 3.5e-2 },
      'Thyroid':               { 'Adult': 5.1e-3, '15 years': 6.5e-3, '10 years': 1.0e-2, '5 years': 1.7e-2, '1 year': 3.1e-2 },
      'Urinary bladder wall':  { 'Adult': 2.4e-2, '15 years': 3.1e-2, '10 years': 4.6e-2, '5 years': 6.3e-2, '1 year': 8.6e-2 },
      'Uterus':                { 'Adult': 9.3e-3, '15 years': 1.2e-2, '10 years': 1.9e-2, '5 years': 2.9e-2, '1 year': 5.0e-2 },
      'Remaining organs':      { 'Adult': 9.0e-3, '15 years': 1.1e-2, '10 years': 1.7e-2, '5 years': 2.6e-2, '1 year': 4.6e-2 },
    },
  },
  // ─── 9. I-131 Monoclonal Antibodies (Table C.121) — VERIFIED against ICRP 128 screenshot ───
  {
    id: 'i131-mab',
    name: 'I-131 Monoclonal Antibodies',
    radionuclide: 'I-131',
    halfLife: '8.04 d',
    modality: 'SPECT',
    defaultActivityMBq: 370,
    icrpTable: 'Table C.121',
    source: 'ICRP Publication 128, Table C.121 (intact antibody)',
    isTherapeutic: true,
    effectiveDoseCoefficient: { 'Adult': 4.2e-1, '15 years': 5.5e-1, '10 years': 8.6e-1, '5 years': 1.4e+0, '1 year': 2.7e+0 },
    organCoefficients: {
      'Adrenals':              { 'Adult': 2.6e-1, '15 years': 3.2e-1, '10 years': 4.7e-1, '5 years': 6.6e-1, '1 year': 1.1e+0 },
      'Bone surfaces':         { 'Adult': 4.5e-1, '15 years': 4.7e-1, '10 years': 8.1e-1, '5 years': 1.4e+0, '1 year': 2.3e+0 },
      'Brain':                 { 'Adult': 6.2e-2, '15 years': 7.9e-2, '10 years': 1.3e-1, '5 years': 2.1e-1, '1 year': 4.1e-1 },
      'Breast':                { 'Adult': 8.2e-2, '15 years': 1.0e-1, '10 years': 1.7e-1, '5 years': 2.7e-1, '1 year': 5.2e-1 },
      'Gallbladder wall':      { 'Adult': 3.5e-1, '15 years': 3.9e-1, '10 years': 5.4e-1, '5 years': 8.5e-1, '1 year': 1.6e+0 },
      'Stomach wall':          { 'Adult': 1.6e-1, '15 years': 2.0e-1, '10 years': 3.1e-1, '5 years': 5.0e-1, '1 year': 9.3e-1 },
      'Small intestine wall':  { 'Adult': 1.3e-1, '15 years': 1.7e-1, '10 years': 2.7e-1, '5 years': 4.3e-1, '1 year': 7.5e-1 },
      'Colon wall':            { 'Adult': 1.3e-1, '15 years': 1.6e-1, '10 years': 2.6e-1, '5 years': 4.1e-1, '1 year': 7.3e-1 },
      'Heart wall':            { 'Adult': 1.5e-1, '15 years': 1.9e-1, '10 years': 3.0e-1, '5 years': 4.4e-1, '1 year': 7.9e-1 },
      'Kidneys':               { 'Adult': 1.0e+0, '15 years': 1.2e+0, '10 years': 1.7e+0, '5 years': 2.5e+0, '1 year': 4.4e+0 },
      'Liver':                 { 'Adult': 2.4e+0, '15 years': 3.2e+0, '10 years': 4.9e+0, '5 years': 7.3e+0, '1 year': 1.4e+1 },
      'Lungs':                 { 'Adult': 1.4e-1, '15 years': 1.8e-1, '10 years': 2.6e-1, '5 years': 3.9e-1, '1 year': 7.2e-1 },
      'Muscles':               { 'Adult': 9.8e-2, '15 years': 1.2e-1, '10 years': 1.9e-1, '5 years': 3.0e-1, '1 year': 5.6e-1 },
      'Oesophagus':            { 'Adult': 8.8e-2, '15 years': 1.1e-1, '10 years': 1.7e-1, '5 years': 2.6e-1, '1 year': 4.9e-1 },
      'Ovaries':               { 'Adult': 1.1e-1, '15 years': 1.4e-1, '10 years': 2.2e-1, '5 years': 3.4e-1, '1 year': 6.1e-1 },
      'Pancreas':              { 'Adult': 2.7e-1, '15 years': 3.3e-1, '10 years': 5.1e-1, '5 years': 7.8e-1, '1 year': 1.3e+0 },
      'Red marrow':            { 'Adult': 7.4e-1, '15 years': 8.2e-1, '10 years': 1.4e+0, '5 years': 2.7e+0, '1 year': 6.6e+0 },
      'Skin':                  { 'Adult': 6.8e-2, '15 years': 8.5e-2, '10 years': 1.4e-1, '5 years': 2.2e-1, '1 year': 4.3e-1 },
      'Spleen':                { 'Adult': 4.0e+0, '15 years': 5.8e+0, '10 years': 9.0e+0, '5 years': 1.4e+1, '1 year': 2.6e+1 },
      'Testes':                { 'Adult': 6.4e-2, '15 years': 8.3e-2, '10 years': 1.4e-1, '5 years': 2.2e-1, '1 year': 4.1e-1 },
      'Thymus':                { 'Adult': 8.8e-2, '15 years': 1.1e-1, '10 years': 1.7e-1, '5 years': 2.6e-1, '1 year': 4.9e-1 },
      'Thyroid':               { 'Adult': 7.0e-2, '15 years': 8.9e-2, '10 years': 1.4e-1, '5 years': 2.3e-1, '1 year': 4.5e-1 },
      'Urinary bladder wall':  { 'Adult': 5.0e-1, '15 years': 6.4e-1, '10 years': 9.8e-1, '5 years': 1.3e+0, '1 year': 1.8e+0 },
      'Uterus':                { 'Adult': 1.1e-1, '15 years': 1.4e-1, '10 years': 2.2e-1, '5 years': 3.5e-1, '1 year': 6.1e-1 },
      'Remaining organs':      { 'Adult': 1.1e-1, '15 years': 1.4e-1, '10 years': 2.2e-1, '5 years': 3.5e-1, '1 year': 6.2e-1 },
    },
  },
  // ─── 10. In-111 Octreotide (Table C.103) — VERIFIED against ICRP 128 reference file ───
  {
    id: 'in111-octreotide',
    name: 'In-111 Octreotide',
    radionuclide: 'In-111',
    halfLife: '67.9 h',
    modality: 'SPECT',
    defaultActivityMBq: 111,
    icrpTable: 'Table C.103',
    source: 'ICRP Publication 128, Table C.103',
    isTherapeutic: false,
    effectiveDoseCoefficient: { 'Adult': 5.4e-2, '15 years': 7.1e-2, '10 years': 1.0e-1, '5 years': 1.6e-1, '1 year': 2.8e-1 },
    organCoefficients: {
      'Adrenals':              { 'Adult': 5.8e-2, '15 years': 7.5e-2, '10 years': 1.2e-1, '5 years': 1.7e-1, '1 year': 3.0e-1 },
      'Bone surfaces':         { 'Adult': 2.7e-2, '15 years': 3.4e-2, '10 years': 5.0e-2, '5 years': 7.6e-2, '1 year': 1.5e-1 },
      'Brain':                 { 'Adult': 9.6e-3, '15 years': 1.2e-2, '10 years': 2.0e-2, '5 years': 3.3e-2, '1 year': 5.8e-2 },
      'Breast':                { 'Adult': 1.2e-2, '15 years': 1.5e-2, '10 years': 2.3e-2, '5 years': 3.7e-2, '1 year': 6.8e-2 },
      'Gallbladder wall':      { 'Adult': 5.2e-2, '15 years': 6.3e-2, '10 years': 9.2e-2, '5 years': 1.4e-1, '1 year': 2.2e-1 },
      'Stomach wall':          { 'Adult': 4.3e-2, '15 years': 5.0e-2, '10 years': 7.8e-2, '5 years': 1.1e-1, '1 year': 1.8e-1 },
      'Small intestine wall':  { 'Adult': 2.9e-2, '15 years': 3.8e-2, '10 years': 5.9e-2, '5 years': 9.1e-2, '1 year': 1.6e-1 },
      'Colon wall':            { 'Adult': 2.9e-2, '15 years': 3.6e-2, '10 years': 5.5e-2, '5 years': 8.9e-2, '1 year': 1.5e-1 },
      'Heart wall':            { 'Adult': 2.5e-2, '15 years': 3.2e-2, '10 years': 4.9e-2, '5 years': 7.1e-2, '1 year': 1.3e-1 },
      'Kidneys':               { 'Adult': 4.1e-1, '15 years': 4.9e-1, '10 years': 6.7e-1, '5 years': 9.6e-1, '1 year': 1.6e+0 },
      'Liver':                 { 'Adult': 1.0e-1, '15 years': 1.3e-1, '10 years': 2.0e-1, '5 years': 2.7e-1, '1 year': 4.8e-1 },
      'Lungs':                 { 'Adult': 2.3e-2, '15 years': 3.0e-2, '10 years': 4.4e-2, '5 years': 6.8e-2, '1 year': 1.2e-1 },
      'Muscles':               { 'Adult': 2.0e-2, '15 years': 2.6e-2, '10 years': 3.8e-2, '5 years': 5.7e-2, '1 year': 1.1e-1 },
      'Oesophagus':            { 'Adult': 1.4e-2, '15 years': 1.9e-2, '10 years': 2.8e-2, '5 years': 4.4e-2, '1 year': 7.8e-2 },
      'Ovaries':               { 'Adult': 2.7e-2, '15 years': 3.5e-2, '10 years': 5.1e-2, '5 years': 8.1e-2, '1 year': 1.4e-1 },
      'Pancreas':              { 'Adult': 7.2e-2, '15 years': 8.8e-2, '10 years': 1.3e-1, '5 years': 2.0e-1, '1 year': 3.2e-1 },
      'Red marrow':            { 'Adult': 2.2e-2, '15 years': 2.7e-2, '10 years': 3.9e-2, '5 years': 5.3e-2, '1 year': 8.7e-2 },
      'Skin':                  { 'Adult': 1.1e-2, '15 years': 1.3e-2, '10 years': 2.1e-2, '5 years': 3.3e-2, '1 year': 6.2e-2 },
      'Spleen':                { 'Adult': 5.7e-1, '15 years': 7.9e-1, '10 years': 1.2e+0, '5 years': 1.8e+0, '1 year': 3.1e+0 },
      'Testes':                { 'Adult': 1.7e-2, '15 years': 2.3e-2, '10 years': 3.5e-2, '5 years': 5.5e-2, '1 year': 1.0e-1 },
      'Thymus':                { 'Adult': 1.4e-2, '15 years': 1.9e-2, '10 years': 2.8e-2, '5 years': 4.4e-2, '1 year': 7.8e-2 },
      'Thyroid':               { 'Adult': 7.6e-2, '15 years': 1.2e-1, '10 years': 1.8e-1, '5 years': 3.7e-1, '1 year': 6.9e-1 },
      'Urinary bladder wall':  { 'Adult': 2.0e-1, '15 years': 2.5e-1, '10 years': 3.1e-1, '5 years': 4.6e-1, '1 year': 8.2e-1 },
      'Uterus':                { 'Adult': 3.9e-2, '15 years': 4.9e-2, '10 years': 7.1e-2, '5 years': 1.1e-1, '1 year': 1.9e-1 },
      'Remaining organs':      { 'Adult': 2.3e-2, '15 years': 2.8e-2, '10 years': 4.2e-2, '5 years': 6.3e-2, '1 year': 1.1e-1 },
    },
  },
];

/**
 * Get tracers applicable to a given modality
 */
export function getTracersForModality(modality: 'PET' | 'SPECT'): RadioTracer[] {
  return RADIOTRACERS.filter(t => t.modality === modality);
}

/**
 * Calculate organ doses from administered activity for a given age group
 */
export function calculateNuclearMedicineDoses(
  tracer: RadioTracer,
  activityMBq: number,
  ageGroup: AgeGroup = 'Adult'
): {
  organDoses: NuclearMedicineOrganDose[];
  effectiveDose_mSv: number;
} {
  const organDoses = Object.entries(tracer.organCoefficients).map(
    ([organ, coefficients]) => ({
      organ_name: organ,
      dose_mGy: coefficients[ageGroup] * activityMBq,
      coefficient_mGy_per_MBq: coefficients[ageGroup],
    })
  );

  organDoses.sort((a, b) => b.dose_mGy - a.dose_mGy);

  return {
    organDoses,
    effectiveDose_mSv: tracer.effectiveDoseCoefficient[ageGroup] * activityMBq,
  };
}
