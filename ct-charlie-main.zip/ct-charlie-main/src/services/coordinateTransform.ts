// Coordinate transformation utilities for NIfTI ↔ DICOM alignment

export interface DicomOrientation {
  // Direction cosines for rows and columns in LPS space
  rowCosines: [number, number, number];
  columnCosines: [number, number, number];
  // Image position (patient) of the top-left pixel of the current slice in LPS
  imagePositionPatient: [number, number, number];
  // Pixel spacing [rowSpacing (mm), columnSpacing (mm)]
  pixelSpacing: [number, number];
}

// Build a 4x4 affine matrix that maps NIfTI voxel indices [i,j,k,1] → LPS patient coords [x,y,z,1]
// Uses sform if available; falls back to simple spacing-based matrix (approximation)
export function buildNiftiVoxelToLPS(header: any, voxelSpacing: [number, number, number]): number[][] {
  // Try sform (preferred)
  if (header && header.sform_code > 0 && header.srow_x && header.srow_y && header.srow_z) {
    // srow_* are in RAS by convention for most tools → convert to LPS by flipping X and Y
    const M_RAS = [
      [header.srow_x[0], header.srow_x[1], header.srow_x[2], header.srow_x[3]],
      [header.srow_y[0], header.srow_y[1], header.srow_y[2], header.srow_y[3]],
      [header.srow_z[0], header.srow_z[1], header.srow_z[2], header.srow_z[3]],
      [0, 0, 0, 1],
    ];
    const F = [
      [-1, 0, 0, 0],
      [0, -1, 0, 0],
      [0, 0, 1, 0],
      [0, 0, 0, 1],
    ];
    return multiply4x4(F, M_RAS);
  }

  // Fallback: assume voxel indices map to LPS with spacing along i→X, j→Y, k→Z (no rotation),
  // and approximate RAS→LPS by flipping X and Y if header present
  const flipXY = header ? -1 : 1;
  const M = [
    [flipXY * voxelSpacing[0], 0, 0, 0],
    [0, flipXY * voxelSpacing[1], 0, 0],
    [0, 0, voxelSpacing[2], 0],
    [0, 0, 0, 1],
  ];
  return M;
}

export function invert4x4(m: number[][]): number[][] {
  // Compute inverse of a 4x4 matrix (naive explicit algorithm)
  const inv = new Array(4).fill(0).map(() => new Array(4).fill(0));
  const a = m.flat();
  const invOut = new Array(16).fill(0);

  invOut[0] = a[5]  * a[10] * a[15] - 
              a[5]  * a[11] * a[14] - 
              a[9]  * a[6]  * a[15] + 
              a[9]  * a[7]  * a[14] + 
              a[13] * a[6]  * a[11] - 
              a[13] * a[7]  * a[10];

  invOut[4] = -a[4]  * a[10] * a[15] + 
               a[4]  * a[11] * a[14] + 
               a[8]  * a[6]  * a[15] - 
               a[8]  * a[7]  * a[14] - 
               a[12] * a[6]  * a[11] + 
               a[12] * a[7]  * a[10];

  invOut[8] = a[4]  * a[9] * a[15] - 
              a[4]  * a[11] * a[13] - 
              a[8]  * a[5] * a[15] + 
              a[8]  * a[7] * a[13] + 
              a[12] * a[5] * a[11] - 
              a[12] * a[7] * a[9];

  invOut[12] = -a[4]  * a[9] * a[14] + 
                a[4]  * a[10] * a[13] + 
                a[8]  * a[5] * a[14] - 
                a[8]  * a[6] * a[13] - 
                a[12] * a[5] * a[10] + 
                a[12] * a[6] * a[9];

  invOut[1] = -a[1]  * a[10] * a[15] + 
               a[1]  * a[11] * a[14] + 
               a[9]  * a[2] * a[15] - 
               a[9]  * a[3] * a[14] - 
               a[13] * a[2] * a[11] + 
               a[13] * a[3] * a[10];

  invOut[5] = a[0]  * a[10] * a[15] - 
              a[0]  * a[11] * a[14] - 
              a[8]  * a[2] * a[15] + 
              a[8]  * a[3] * a[14] + 
              a[12] * a[2] * a[11] - 
              a[12] * a[3] * a[10];

  invOut[9] = -a[0]  * a[9] * a[15] + 
               a[0]  * a[11] * a[13] + 
               a[8]  * a[1] * a[15] - 
               a[8]  * a[3] * a[13] - 
               a[12] * a[1] * a[11] + 
               a[12] * a[3] * a[9];

  invOut[13] = a[0]  * a[9] * a[14] - 
               a[0]  * a[10] * a[13] - 
               a[8]  * a[1] * a[14] + 
               a[8]  * a[2] * a[13] + 
               a[12] * a[1] * a[10] - 
               a[12] * a[2] * a[9];

  invOut[2] = a[1]  * a[6] * a[15] - 
              a[1]  * a[7] * a[14] - 
              a[5]  * a[2] * a[15] + 
              a[5]  * a[3] * a[14] + 
              a[13] * a[2] * a[7] - 
              a[13] * a[3] * a[6];

  invOut[6] = -a[0]  * a[6] * a[15] + 
               a[0]  * a[7] * a[14] + 
               a[4]  * a[2] * a[15] - 
               a[4]  * a[3] * a[14] - 
               a[12] * a[2] * a[7] + 
               a[12] * a[3] * a[6];

  invOut[10] = a[0]  * a[5] * a[15] - 
               a[0]  * a[7] * a[13] - 
               a[4]  * a[1] * a[15] + 
               a[4]  * a[3] * a[13] + 
               a[12] * a[1] * a[7] - 
               a[12] * a[3] * a[5];

  invOut[14] = -a[0]  * a[5] * a[14] + 
                a[0]  * a[6] * a[13] + 
                a[4]  * a[1] * a[14] - 
                a[4]  * a[2] * a[13] - 
                a[12] * a[1] * a[6] + 
                a[12] * a[2] * a[5];

  invOut[3] = -a[1] * a[6] * a[11] + 
               a[1] * a[7] * a[10] + 
               a[5] * a[2] * a[11] - 
               a[5] * a[3] * a[10] - 
               a[9] * a[2] * a[7] + 
               a[9] * a[3] * a[6];

  invOut[7] = a[0] * a[6] * a[11] - 
              a[0] * a[7] * a[10] - 
              a[4] * a[2] * a[11] + 
              a[4] * a[3] * a[10] + 
              a[8] * a[2] * a[7] - 
              a[8] * a[3] * a[6];

  invOut[11] = -a[0] * a[5] * a[11] + 
                a[0] * a[7] * a[9] + 
                a[4] * a[1] * a[11] - 
                a[4] * a[3] * a[9] - 
                a[8] * a[1] * a[7] + 
                a[8] * a[3] * a[5];

  invOut[15] = a[0] * a[5] * a[10] - 
               a[0] * a[6] * a[9] - 
               a[4] * a[1] * a[10] + 
               a[4] * a[2] * a[9] + 
               a[8] * a[1] * a[6] - 
               a[8] * a[2] * a[5];

  let det = a[0] * invOut[0] + a[1] * invOut[4] + a[2] * invOut[8] + a[3] * invOut[12];
  if (det === 0) return identity4();
  det = 1.0 / det;

  for (let i = 0; i < 16; i++) invOut[i] *= det;

  // Convert back to 4x4 array
  for (let r = 0; r < 4; r++) {
    for (let c = 0; c < 4; c++) {
      inv[r][c] = invOut[r * 4 + c];
    }
  }
  return inv;
}

export function multiply4x4(a: number[][], b: number[][]): number[][] {
  const out = identity4();
  for (let r = 0; r < 4; r++) {
    for (let c = 0; c < 4; c++) {
      out[r][c] = a[r][0] * b[0][c] + a[r][1] * b[1][c] + a[r][2] * b[2][c] + a[r][3] * b[3][c];
    }
  }
  return out;
}

export function identity4(): number[][] {
  return [
    [1, 0, 0, 0],
    [0, 1, 0, 0],
    [0, 0, 1, 0],
    [0, 0, 0, 1],
  ];
}

export function addVec3(a: [number, number, number], b: [number, number, number]): [number, number, number] {
  return [a[0] + b[0], a[1] + b[1], a[2] + b[2]];
}

export function scaleVec3(v: [number, number, number], s: number): [number, number, number] {
  return [v[0] * s, v[1] * s, v[2] * s];
}

// Precompute basis for patient coordinates of pixel (x,y):
// P(x,y) = P0 + x * dPdx + y * dPdy
export function computePatientBasis(orientation: DicomOrientation): {
  P0: [number, number, number];
  dPdx: [number, number, number];
  dPdy: [number, number, number];
} {
  const P0 = orientation.imagePositionPatient;
  const row = orientation.rowCosines;
  const col = orientation.columnCosines;
  const [rowSpacing, colSpacing] = orientation.pixelSpacing; // DICOM: [row, col]

  const dPdy = [row[0] * rowSpacing, row[1] * rowSpacing, row[2] * rowSpacing] as [number, number, number];
  const dPdx = [col[0] * colSpacing, col[1] * colSpacing, col[2] * colSpacing] as [number, number, number];

  return { P0, dPdx, dPdy };
}

export function mapPatientToVoxel(P: [number, number, number], invM: number[][]): [number, number, number] {
  const x = P[0], y = P[1], z = P[2];
  const i = invM[0][0] * x + invM[0][1] * y + invM[0][2] * z + invM[0][3];
  const j = invM[1][0] * x + invM[1][1] * y + invM[1][2] * z + invM[1][3];
  const k = invM[2][0] * x + invM[2][1] * y + invM[2][2] * z + invM[2][3];
  return [i, j, k];
}
