/**
 * Overlay Renderer Service
 * Handles rendering of organ masks and dose heat maps on top of DICOM images
 */

import { NiftiData } from './niftiLoader';
import { DicomOrientation, buildNiftiVoxelToLPS, invert4x4, computePatientBasis, addVec3, scaleVec3, mapPatientToVoxel } from './coordinateTransform';

export interface OverlayConfig {
  opacity: number;
  color: string;
  visible: boolean;
}

export interface OrganOverlay {
  organName: string;
  data: NiftiData;
  config: OverlayConfig;
}

export interface DoseOverlay {
  data: NiftiData;
  config: {
    visible: boolean;
    opacity: number;
    minDose: number;
    maxDose: number;
    colorScheme: 'hot' | 'jet' | 'viridis';
  };
}

export interface CombinedViewConfig {
  enabled: boolean;
  showBoundaries: boolean;
  showDoseInside: boolean;
  highlightThreshold: number; // Dose value in Gy (e.g., 0.002 = 2 mGy)
  boundaryThickness: number;
  doseOpacity: number;
}

/**
 * Transform NIfTI coordinates to DICOM coordinates
 * NIfTI typically uses RAS+ (Right-Anterior-Superior) or varies by qform/sform
 * DICOM uses LPS (Left-Posterior-Superior) for patient coordinates
 * This function handles the coordinate transformation between the two systems
 */
function transformNiftiToDicom(
  x: number,
  y: number,
  z: number,
  width: number,
  height: number,
  depth: number,
  header?: any
): { x: number; y: number; z: number } {
  // DICOM typically has origin at top-left with:
  // - X increasing left to right
  // - Y increasing top to bottom
  // - Z increasing through slices
  
  // NIfTI coordinate system depends on qform/sform codes
  // For most medical imaging, we need to flip both X and Y axes
  // and potentially reverse the Z axis depending on slice ordering
  
  // Apply standard transformation: flip X and Y to account for orientation difference
  const transformedX = width - 1 - x;
  const transformedY = height - 1 - y;
  
  // Z-axis: Check if we need to reverse slice ordering
  // Some NIfTI files store slices in reverse order compared to DICOM
  let transformedZ = z;
  
  // If header indicates reversed orientation (common with certain scanners)
  if (header && (header.qform_code > 0 || header.sform_code > 0)) {
    // For RAS+ to LPS conversion, Z might need flipping depending on acquisition
    // This is a common case for CT data where NIfTI stores inferior->superior
    // but DICOM displays superior->inferior
    transformedZ = depth - 1 - z;
  }
  
  return { x: transformedX, y: transformedY, z: transformedZ };
}

// Helper: check if NIfTI header provides a valid affine (sform)
function hasValidNiftiAffine(header: any | undefined): boolean {
  return !!(header && header.sform_code > 0 && header.srow_x && header.srow_y && header.srow_z);
}

/**
 * Parse hex color to RGB
 */
function hexToRgb(hex: string): { r: number; g: number; b: number } {
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  return result ? {
    r: parseInt(result[1], 16),
    g: parseInt(result[2], 16),
    b: parseInt(result[3], 16),
  } : { r: 255, g: 0, b: 0 };
}

/**
 * Get color for dose value based on color scheme
 * Exported for use in DoseLegend component
 */
export function getDoseColor(
  value: number,
  minDose: number,
  maxDose: number,
  scheme: 'hot' | 'jet' | 'viridis'
): { r: number; g: number; b: number } {
  const normalized = Math.max(0, Math.min(1, (value - minDose) / (maxDose - minDose)));
  
  switch (scheme) {
    case 'hot':
      // Hot: Black -> Red -> Yellow -> White
      if (normalized < 0.33) {
        const t = normalized / 0.33;
        return { r: Math.round(255 * t), g: 0, b: 0 };
      } else if (normalized < 0.66) {
        const t = (normalized - 0.33) / 0.33;
        return { r: 255, g: Math.round(255 * t), b: 0 };
      } else {
        const t = (normalized - 0.66) / 0.34;
        return { r: 255, g: 255, b: Math.round(255 * t) };
      }
    
    case 'jet':
      // Jet: Blue -> Cyan -> Green -> Yellow -> Red
      if (normalized < 0.25) {
        const t = normalized / 0.25;
        return { r: 0, g: 0, b: Math.round(128 + 127 * t) };
      } else if (normalized < 0.5) {
        const t = (normalized - 0.25) / 0.25;
        return { r: 0, g: Math.round(255 * t), b: 255 };
      } else if (normalized < 0.75) {
        const t = (normalized - 0.5) / 0.25;
        return { r: Math.round(255 * t), g: 255, b: Math.round(255 * (1 - t)) };
      } else {
        const t = (normalized - 0.75) / 0.25;
        return { r: 255, g: Math.round(255 * (1 - t)), b: 0 };
      }
    
    case 'viridis':
      // Simplified viridis: Purple -> Blue -> Green -> Yellow
      if (normalized < 0.33) {
        const t = normalized / 0.33;
        return {
          r: Math.round(68 + (48 - 68) * t),
          g: Math.round(1 + (86 - 1) * t),
          b: Math.round(84 + (141 - 84) * t),
        };
      } else if (normalized < 0.66) {
        const t = (normalized - 0.33) / 0.33;
        return {
          r: Math.round(48 + (53 - 48) * t),
          g: Math.round(86 + (183 - 86) * t),
          b: Math.round(141 + (121 - 141) * t),
        };
      } else {
        const t = (normalized - 0.66) / 0.34;
        return {
          r: Math.round(53 + (254 - 53) * t),
          g: Math.round(183 + (231 - 183) * t),
          b: Math.round(121 + (36 - 121) * t),
        };
      }
  }
}

/**
 * Render organ mask overlay on canvas
 */
export function renderOrganOverlay(
  canvas: HTMLCanvasElement,
  overlay: OrganOverlay,
  sliceIndex: number,
  dicom?: DicomOrientation
): void {
  if (!overlay.config.visible) return;

  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  const { data, dimensions } = overlay.data;
  const [width, height, depth] = dimensions;

  // Check if slice is in range
  if (sliceIndex < 0 || sliceIndex >= depth) return;

  // Create image data for this slice
  const imageData = ctx.createImageData(width, height);
  const pixels = imageData.data;
  const rgb = hexToRgb(overlay.config.color);

  // If DICOM orientation is provided, use affine mapping for precise alignment
  if (dicom && hasValidNiftiAffine(overlay.data.header)) {
    const vs = (overlay.data.voxelSpacing as [number, number, number] | undefined) ?? [1, 1, 1];
    const M = buildNiftiVoxelToLPS(overlay.data.header, vs);
    const invM = invert4x4(M);
    const basis = computePatientBasis(dicom);

    for (let y = 0; y < height; y++) {
      // Compute starting patient point for this row
      const Py = addVec3(basis.P0, scaleVec3(basis.dPdy, y as unknown as number));
      let P = Py as [number, number, number];

      for (let x = 0; x < width; x++) {
        // Patient point for this pixel
        if (x > 0) {
          P = addVec3(P, basis.dPdx) as [number, number, number];
        }
        const [vi, vj, vk] = mapPatientToVoxel(P, invM);
        const ii = Math.round(vi);
        const jj = Math.round(vj);
        const kk = Math.round(vk);

        if (ii >= 0 && ii < width && jj >= 0 && jj < height && kk >= 0 && kk < depth) {
          const index = kk * width * height + jj * width + ii;
          const value = data[index];
          if (value > 0) {
            const pixelIndex = (y * width + x) * 4;
            pixels[pixelIndex] = rgb.r;
            pixels[pixelIndex + 1] = rgb.g;
            pixels[pixelIndex + 2] = rgb.b;
            pixels[pixelIndex + 3] = Math.round(overlay.config.opacity * 255);
          }
        }
      }
    }
  } else {
    // Fallback: Apply same Y-flip and Z-reversal as dose overlay
    const reversedSliceIndex = depth - 1 - sliceIndex;
    
    if (reversedSliceIndex < 0 || reversedSliceIndex >= depth) return;
    
    const sliceOffset = reversedSliceIndex * width * height;

    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        // Apply Y-flip only (same as dose)
        const rotatedX = x;
        const rotatedY = height - 1 - y;
        const index = sliceOffset + rotatedY * width + rotatedX;
        const value = data[index];
        if (value > 0) {
          const pixelIndex = (y * width + x) * 4;
          pixels[pixelIndex] = rgb.r;
          pixels[pixelIndex + 1] = rgb.g;
          pixels[pixelIndex + 2] = rgb.b;
          pixels[pixelIndex + 3] = Math.round(overlay.config.opacity * 255);
        }
      }
    }
  }

  ctx.putImageData(imageData, 0, 0);
}

/**
 * Render dose heat map overlay on canvas
 */
export function renderDoseOverlay(
  canvas: HTMLCanvasElement,
  overlay: DoseOverlay,
  sliceIndex: number,
  dicom?: DicomOrientation
): void {
  if (!overlay.config.visible) return;

  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  const { data, dimensions } = overlay.data;
  const [width, height, depth] = dimensions;

  // Reverse Z-axis: DICOM slices go from head to toe, NIfTI dose might be reversed
  const reversedSliceIndex = depth - 1 - sliceIndex;

  // Check if slice is in range
  if (reversedSliceIndex < 0 || reversedSliceIndex >= depth) return;

  // Create image data for this slice
  const imageData = ctx.createImageData(width, height);
  const pixels = imageData.data;
  const { minDose, maxDose, colorScheme, opacity } = overlay.config;

  // Validate dose range to prevent white/gray rendering
  if (maxDose <= minDose || maxDose - minDose < 0.001) {
    console.warn('Invalid dose range, skipping render:', { minDose, maxDose });
    ctx.putImageData(imageData, 0, 0);
    return;
  }

  if (dicom && hasValidNiftiAffine(overlay.data.header)) {
    const vs = (overlay.data.voxelSpacing as [number, number, number] | undefined) ?? [1, 1, 1];
    const M = buildNiftiVoxelToLPS(overlay.data.header, vs);
    const invM = invert4x4(M);
    const basis = computePatientBasis(dicom);

    // Render with Y-flip only (no X-flip to fix sagittal mirror)
    for (let y = height - 1; y >= 0; y--) {
      const Py = addVec3(basis.P0, scaleVec3(basis.dPdy, y as unknown as number));
      let P = Py as [number, number, number];

      for (let x = 0; x < width; x++) {
        if (x > 0) {
          P = addVec3(P, basis.dPdx) as [number, number, number];
        }
        const [vi, vj, vk] = mapPatientToVoxel(P, invM);
        const ii = Math.round(vi);
        const jj = Math.round(vj);
        const kk = Math.round(vk);
        if (ii >= 0 && ii < width && jj >= 0 && jj < height && kk >= 0 && kk < depth) {
          const index = kk * width * height + jj * width + ii;
          const doseValue = data[index];
          if (doseValue > minDose) {
            const color = getDoseColor(doseValue, minDose, maxDose, colorScheme);
            // Map position to canvas with Y-flip only
            const canvasY = height - 1 - y;
            const canvasX = x;
            const pixelIndex = (canvasY * width + canvasX) * 4;
            pixels[pixelIndex] = color.r;
            pixels[pixelIndex + 1] = color.g;
            pixels[pixelIndex + 2] = color.b;
            pixels[pixelIndex + 3] = Math.round(opacity * 255);
          }
        }
      }
    }
  } else {
    // Fallback: simple direct mapping with 180-degree rotation and Z-reversal
    if (reversedSliceIndex < 0 || reversedSliceIndex >= depth) {
      ctx.putImageData(imageData, 0, 0);
      return;
    }
    
    const sliceOffset = reversedSliceIndex * width * height;

    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        // Apply Y-flip only (no X-flip to fix sagittal mirror)
        const rotatedX = x;
        const rotatedY = height - 1 - y;
        const index = sliceOffset + rotatedY * width + rotatedX;
        const doseValue = data[index];

        if (doseValue > minDose) {
          const color = getDoseColor(doseValue, minDose, maxDose, colorScheme);
          const pixelIndex = (y * width + x) * 4;
          pixels[pixelIndex] = color.r;
          pixels[pixelIndex + 1] = color.g;
          pixels[pixelIndex + 2] = color.b;
          pixels[pixelIndex + 3] = Math.round(opacity * 255);
        }
      }
    }
  }

  ctx.putImageData(imageData, 0, 0);
}

/**
 * Detect organ boundaries from mask data
 */
function detectBoundary(
  data: Float32Array | Int16Array,
  width: number,
  height: number,
  sliceOffset: number,
  x: number,
  y: number
): boolean {
  const index = sliceOffset + y * width + x;
  const value = data[index];
  
  if (value === 0) return false;
  
  // Check 4-connected neighbors
  const neighbors = [
    { dx: -1, dy: 0 },
    { dx: 1, dy: 0 },
    { dx: 0, dy: -1 },
    { dx: 0, dy: 1 },
  ];
  
  for (const { dx, dy } of neighbors) {
    const nx = x + dx;
    const ny = y + dy;
    
    if (nx < 0 || nx >= width || ny < 0 || ny >= height) return true;
    
    const neighborIndex = sliceOffset + ny * width + nx;
    if (data[neighborIndex] === 0) return true;
  }
  
  return false;
}

/**
 * Render combined organ + dose overlay
 */
export function renderCombinedOverlay(
  canvas: HTMLCanvasElement,
  organOverlays: OrganOverlay[],
  doseOverlay: DoseOverlay | null,
  sliceIndex: number,
  config: CombinedViewConfig,
  dicom?: DicomOrientation
): void {
  if (!config.enabled) return;
  
  const ctx = canvas.getContext('2d');
  if (!ctx) return;
  
  const width = canvas.width;
  const height = canvas.height;
  
  // Create image data for this slice
  const imageData = ctx.createImageData(width, height);
  const pixels = imageData.data;
  
  // If DICOM orientation provided, use unified affine mapping for organ and dose
  if (
    dicom &&
    organOverlays.every(o => hasValidNiftiAffine(o.data.header)) &&
    (!doseOverlay || hasValidNiftiAffine(doseOverlay.data.header))
  ) {
    // Precompute NIfTI voxel→LPS and its inverse for each dataset
    const organTransforms = organOverlays.map(o => {
      const vs = (o.data.voxelSpacing as [number, number, number] | undefined) ?? [1, 1, 1];
      return {
        invM: invert4x4(buildNiftiVoxelToLPS(o.data.header, vs)),
        data: o.data,
        color: hexToRgb(o.config.color),
        opacity: o.config.opacity,
        visible: o.config.visible,
      };
    });

    const doseTransform = doseOverlay && doseOverlay.config.visible ? (() => {
      const vs = (doseOverlay.data.voxelSpacing as [number, number, number] | undefined) ?? [1, 1, 1];
      return {
        invM: invert4x4(buildNiftiVoxelToLPS(doseOverlay.data.header, vs)),
        data: doseOverlay.data,
        config: doseOverlay.config,
      };
    })() : null;

    const basis = computePatientBasis(dicom);

    for (let y = 0; y < height; y++) {
      const Py = addVec3(basis.P0, scaleVec3(basis.dPdy, y as unknown as number));
      let P = Py as [number, number, number];

      for (let x = 0; x < width; x++) {
        if (x > 0) {
          P = addVec3(P, basis.dPdx) as [number, number, number];
        }
        const pixelIndex = (y * width + x) * 4;

        // For each organ overlay, check boundary and/or fill
        for (let idx = 0; idx < organOverlays.length; idx++) {
          const overlay = organOverlays[idx];
          if (!overlay.config.visible) continue;
          const { invM, data: organData, color } = organTransforms[idx];
          const [w, h, d] = organData.dimensions;
          const [vi, vj, vk] = mapPatientToVoxel(P, invM);
          const ii = Math.round(vi);
          const jj = Math.round(vj);
          const kk = Math.round(vk);
          if (ii >= 0 && ii < w && jj >= 0 && jj < h && kk >= 0 && kk < d) {
            const index = kk * w * h + jj * w + ii;
            const maskValue = organData.data[index];
            if (maskValue > 0) {
              // Boundary detection in organ voxel space
              const isBoundary = detectBoundary(organData.data, w, h, kk * w * h, ii, jj);
              if (config.showBoundaries && isBoundary) {
                pixels[pixelIndex] = color.r;
                pixels[pixelIndex + 1] = color.g;
                pixels[pixelIndex + 2] = color.b;
                pixels[pixelIndex + 3] = Math.round(overlay.config.opacity * 255);
              }

              // Dose blending inside organ
              if (config.showDoseInside && doseTransform) {
                const { data: doseData, config: dcfg, invM: invDose } = doseTransform;
                const [dw, dh, dd] = doseData.dimensions;
                const [dvi, dvj, dvk] = mapPatientToVoxel(P, invDose);
                const di = Math.round(dvi);
                const dj = Math.round(dvj);
                const dk = Math.round(dvk);
                if (di >= 0 && di < dw && dj >= 0 && dj < dh && dk >= 0 && dk < dd) {
                  const dIndex = dk * dw * dh + dj * dw + di;
                  const doseValue = doseData.data[dIndex];
                  if (doseValue > dcfg.minDose) {
                    const doseColor = getDoseColor(doseValue, dcfg.minDose, dcfg.maxDose, dcfg.colorScheme);
                    const alpha = config.doseOpacity;
                    const existingAlpha = pixels[pixelIndex + 3] / 255;
                    if (existingAlpha > 0) {
                      pixels[pixelIndex] = Math.round(pixels[pixelIndex] * (1 - alpha) + doseColor.r * alpha);
                      pixels[pixelIndex + 1] = Math.round(pixels[pixelIndex + 1] * (1 - alpha) + doseColor.g * alpha);
                      pixels[pixelIndex + 2] = Math.round(pixels[pixelIndex + 2] * (1 - alpha) + doseColor.b * alpha);
                      pixels[pixelIndex + 3] = Math.round(Math.max(existingAlpha, alpha) * 255);
                    } else {
                      pixels[pixelIndex] = doseColor.r;
                      pixels[pixelIndex + 1] = doseColor.g;
                      pixels[pixelIndex + 2] = doseColor.b;
                      pixels[pixelIndex + 3] = Math.round(alpha * 255);
                    }

                    if (doseValue >= config.highlightThreshold) {
                      pixels[pixelIndex] = 255;
                      pixels[pixelIndex + 1] = 255;
                      pixels[pixelIndex + 2] = 0;
                      pixels[pixelIndex + 3] = Math.round(Math.min(config.doseOpacity * 1.5, 1) * 255);
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  } else {
    // Fallback: Apply same Y-flip and Z-reversal as dose for both organs and dose
    for (const overlay of organOverlays) {
      if (!overlay.config.visible) continue;
      
      const { data, dimensions } = overlay.data;
      const [maskWidth, maskHeight, depth] = dimensions;
      
      // Apply Z-reversal
      const reversedSliceIndex = depth - 1 - sliceIndex;
      if (reversedSliceIndex < 0 || reversedSliceIndex >= depth) continue;
      
      const sliceOffset = reversedSliceIndex * maskWidth * maskHeight;
      const rgb = hexToRgb(overlay.config.color);
      
      for (let y = 0; y < maskHeight && y < height; y++) {
        for (let x = 0; x < maskWidth && x < width; x++) {
          // Apply Y-flip only (same as dose)
          const rotatedX = x;
          const rotatedY = height - 1 - y;
          const maskIndex = sliceOffset + rotatedY * maskWidth + rotatedX;
          const maskValue = data[maskIndex];
          
          if (maskValue === 0) continue;
          
          const pixelIndex = (y * width + x) * 4;
          const isBoundary = detectBoundary(data, maskWidth, maskHeight, sliceOffset, rotatedX, rotatedY);
          
          if (config.showBoundaries && isBoundary) {
            pixels[pixelIndex] = rgb.r;
            pixels[pixelIndex + 1] = rgb.g;
            pixels[pixelIndex + 2] = rgb.b;
            pixels[pixelIndex + 3] = Math.round(overlay.config.opacity * 255);
          }
          
          if (config.showDoseInside && doseOverlay && doseOverlay.config.visible) {
            const { data: doseData, dimensions: doseDimensions } = doseOverlay.data;
            const [doseWidth, doseHeight, doseDepth] = doseDimensions;
            
            // Apply same Z-reversal to dose
            const doseReversedSliceIndex = doseDepth - 1 - sliceIndex;
            if (doseReversedSliceIndex >= 0 && doseReversedSliceIndex < doseDepth && x < doseWidth && y < doseHeight) {
              const doseSliceOffset = doseReversedSliceIndex * doseWidth * doseHeight;
              const doseIndex = doseSliceOffset + rotatedY * doseWidth + rotatedX;
              const doseValue = doseData[doseIndex];
              
              if (doseValue > doseOverlay.config.minDose) {
                const doseColor = getDoseColor(
                  doseValue,
                  doseOverlay.config.minDose,
                  doseOverlay.config.maxDose,
                  doseOverlay.config.colorScheme
                );
                
                const alpha = config.doseOpacity;
                const existingAlpha = pixels[pixelIndex + 3] / 255;
                
                if (existingAlpha > 0) {
                  pixels[pixelIndex] = Math.round(pixels[pixelIndex] * (1 - alpha) + doseColor.r * alpha);
                  pixels[pixelIndex + 1] = Math.round(pixels[pixelIndex + 1] * (1 - alpha) + doseColor.g * alpha);
                  pixels[pixelIndex + 2] = Math.round(pixels[pixelIndex + 2] * (1 - alpha) + doseColor.b * alpha);
                  pixels[pixelIndex + 3] = Math.round(Math.max(existingAlpha, alpha) * 255);
                } else {
                  pixels[pixelIndex] = doseColor.r;
                  pixels[pixelIndex + 1] = doseColor.g;
                  pixels[pixelIndex + 2] = doseColor.b;
                  pixels[pixelIndex + 3] = Math.round(alpha * 255);
                }
                
                if (doseValue >= config.highlightThreshold) {
                  pixels[pixelIndex] = 255;
                  pixels[pixelIndex + 1] = 255;
                  pixels[pixelIndex + 2] = 0;
                  pixels[pixelIndex + 3] = Math.round(Math.min(alpha * 1.5, 1) * 255);
                }
              }
            }
          }
        }
      }
    }
  }
  
  ctx.putImageData(imageData, 0, 0);
}

/**
 * Render organ dose overlay - shows dose as heatmap inside organ mask
 */
export function renderOrganDoseOverlay(
  canvas: HTMLCanvasElement,
  organOverlay: OrganOverlay,
  doseData: NiftiData,
  doseConfig: {
    visible: boolean;
    opacity: number;
    minDose: number;
    maxDose: number;
    colorScheme: 'hot' | 'jet' | 'viridis';
  },
  sliceIndex: number,
  dicom?: DicomOrientation
): void {
  if (!organOverlay.config.visible || !doseConfig.visible) return;

  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  const { data: organData, dimensions: organDimensions } = organOverlay.data;
  const { data: doseDataArray, dimensions: doseDimensions } = doseData;
  const [organWidth, organHeight, organDepth] = organDimensions;
  const [doseWidth, doseHeight, doseDepth] = doseDimensions;

  // Check if slice is in range for both datasets
  if (sliceIndex < 0 || sliceIndex >= organDepth) return;

  // Create image data for this slice
  const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
  const pixels = imageData.data;
  const { minDose, maxDose, colorScheme, opacity } = doseConfig;

  // Validate dose range
  if (maxDose <= minDose || maxDose - minDose < 0.001) {
    console.warn('Invalid dose range for organ overlay:', { minDose, maxDose });
    return;
  }

  // If DICOM orientation is provided, use affine mapping for precise alignment
  if (dicom && hasValidNiftiAffine(organOverlay.data.header) && hasValidNiftiAffine(doseData.header)) {
    const organVs = (organOverlay.data.voxelSpacing as [number, number, number] | undefined) ?? [1, 1, 1];
    const organM = buildNiftiVoxelToLPS(organOverlay.data.header, organVs);
    const organInvM = invert4x4(organM);

    const doseVs = (doseData.voxelSpacing as [number, number, number] | undefined) ?? [1, 1, 1];
    const doseM = buildNiftiVoxelToLPS(doseData.header, doseVs);
    const doseInvM = invert4x4(doseM);

    const basis = computePatientBasis(dicom);

    for (let y = 0; y < canvas.height; y++) {
      const Py = addVec3(basis.P0, scaleVec3(basis.dPdy, y as unknown as number));
      let P = Py as [number, number, number];

      for (let x = 0; x < canvas.width; x++) {
        if (x > 0) {
          P = addVec3(P, basis.dPdx) as [number, number, number];
        }

        // Check organ mask
        const [oi, oj, ok] = mapPatientToVoxel(P, organInvM);
        const oii = Math.round(oi);
        const ojj = Math.round(oj);
        const okk = Math.round(ok);

        if (oii >= 0 && oii < organWidth && ojj >= 0 && ojj < organHeight && okk >= 0 && okk < organDepth) {
          const organIndex = okk * organWidth * organHeight + ojj * organWidth + oii;
          const maskValue = organData[organIndex];

          if (maskValue > 0) {
            // Inside organ, get dose value
            const [di, dj, dk] = mapPatientToVoxel(P, doseInvM);
            const dii = Math.round(di);
            const djj = Math.round(dj);
            const dkk = Math.round(dk);

            if (dii >= 0 && dii < doseWidth && djj >= 0 && djj < doseHeight && dkk >= 0 && dkk < doseDepth) {
              const doseIndex = dkk * doseWidth * doseHeight + djj * doseWidth + dii;
              const doseValue = doseDataArray[doseIndex];

              if (doseValue > minDose) {
                const color = getDoseColor(doseValue, minDose, maxDose, colorScheme);
                const pixelIndex = (y * canvas.width + x) * 4;
                const existingAlpha = pixels[pixelIndex + 3] / 255;

                if (existingAlpha > 0) {
                  // Blend with existing pixel
                  pixels[pixelIndex] = Math.round(pixels[pixelIndex] * (1 - opacity) + color.r * opacity);
                  pixels[pixelIndex + 1] = Math.round(pixels[pixelIndex + 1] * (1 - opacity) + color.g * opacity);
                  pixels[pixelIndex + 2] = Math.round(pixels[pixelIndex + 2] * (1 - opacity) + color.b * opacity);
                  pixels[pixelIndex + 3] = Math.round(Math.max(existingAlpha, opacity) * 255);
                } else {
                  // New pixel
                  pixels[pixelIndex] = color.r;
                  pixels[pixelIndex + 1] = color.g;
                  pixels[pixelIndex + 2] = color.b;
                  pixels[pixelIndex + 3] = Math.round(opacity * 255);
                }
              }
            }
          }
        }
      }
    }
  } else {
    // Fallback: Apply same Y-flip and Z-reversal
    const organReversedSliceIndex = organDepth - 1 - sliceIndex;
    const doseReversedSliceIndex = doseDepth - 1 - sliceIndex;

    if (organReversedSliceIndex < 0 || organReversedSliceIndex >= organDepth) return;
    if (doseReversedSliceIndex < 0 || doseReversedSliceIndex >= doseDepth) return;

    const organSliceOffset = organReversedSliceIndex * organWidth * organHeight;
    const doseSliceOffset = doseReversedSliceIndex * doseWidth * doseHeight;

    for (let y = 0; y < Math.min(canvas.height, organHeight); y++) {
      for (let x = 0; x < Math.min(canvas.width, organWidth); x++) {
        // Apply Y-flip only
        const rotatedX = x;
        const rotatedY = organHeight - 1 - y;
        const organIndex = organSliceOffset + rotatedY * organWidth + rotatedX;
        const maskValue = organData[organIndex];

        if (maskValue > 0 && x < doseWidth && rotatedY < doseHeight) {
          // Inside organ, get dose value
          const doseIndex = doseSliceOffset + rotatedY * doseWidth + rotatedX;
          const doseValue = doseDataArray[doseIndex];

          if (doseValue > minDose) {
            const color = getDoseColor(doseValue, minDose, maxDose, colorScheme);
            const pixelIndex = (y * canvas.width + x) * 4;
            const existingAlpha = pixels[pixelIndex + 3] / 255;

            if (existingAlpha > 0) {
              // Blend with existing pixel
              pixels[pixelIndex] = Math.round(pixels[pixelIndex] * (1 - opacity) + color.r * opacity);
              pixels[pixelIndex + 1] = Math.round(pixels[pixelIndex + 1] * (1 - opacity) + color.g * opacity);
              pixels[pixelIndex + 2] = Math.round(pixels[pixelIndex + 2] * (1 - opacity) + color.b * opacity);
              pixels[pixelIndex + 3] = Math.round(Math.max(existingAlpha, opacity) * 255);
            } else {
              // New pixel
              pixels[pixelIndex] = color.r;
              pixels[pixelIndex + 1] = color.g;
              pixels[pixelIndex + 2] = color.b;
              pixels[pixelIndex + 3] = Math.round(opacity * 255);
            }
          }
        }
      }
    }
  }

  ctx.putImageData(imageData, 0, 0);
}

/**
 * Clear overlay canvas
 */
export function clearOverlay(canvas: HTMLCanvasElement): void {
  const ctx = canvas.getContext('2d');
  if (!ctx) return;
  ctx.clearRect(0, 0, canvas.width, canvas.height);
}
