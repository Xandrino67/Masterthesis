/**
 * Intelligent DICOM Image Preloader
 * Preloads images based on user navigation patterns
 */

import cornerstone from 'cornerstone-core';
import { dicomCache } from './dicomCache';

interface NavigationPattern {
  direction: 'forward' | 'backward' | 'random';
  speed: number; // slices per second
  lastSlices: number[];
}

class DicomPreloaderService {
  private preloadQueue: Set<string> = new Set();
  private isPreloading = false;
  private navigationPattern: NavigationPattern = {
    direction: 'forward',
    speed: 1,
    lastSlices: [],
  };
  private readonly MAX_PATTERN_HISTORY = 10;
  private readonly PRELOAD_DISTANCE = 5; // How many slices ahead/behind to preload

  /**
   * Start intelligent preloading based on current slice
   */
  async preloadAround(
    imageIds: string[],
    currentIndex: number,
    studyId: string
  ): Promise<void> {
    this.updateNavigationPattern(currentIndex);
    
    const indicesToPreload = this.calculatePreloadIndices(
      currentIndex,
      imageIds.length
    );

    // Queue preloading with validation - skip already cached images and lazy: IDs
    for (const index of indicesToPreload) {
      const imageId = imageIds[index];
      if (imageId && typeof imageId === 'string' && imageId.trim() !== '' && 
          !imageId.startsWith('lazy:') && !this.preloadQueue.has(imageId)) {
        // Extract storagePath from imageId for cache check
        const storagePath = this.extractStoragePath(imageId);
        
        // Check if already cached using storagePath
        const cached = await dicomCache.has(storagePath);
        if (!cached) {
          this.preloadQueue.add(imageId);
        }
      }
    }

    // Start preloading if not already running
    if (!this.isPreloading) {
      this.startPreloading(studyId);
    }
  }

  /**
   * Preload entire series in background
   */
  async preloadSeries(imageIds: string[], studyId: string): Promise<void> {
    console.log(`Starting background preload of ${imageIds.length} images`);
    
    const batchSize = 10; // Increased for better performance
    let loaded = 0;
    const totalImages = imageIds.length;

    for (let i = 0; i < totalImages; i += batchSize) {
      const batch = imageIds.slice(i, i + batchSize);
      
      await Promise.all(
        batch.map(async (imageId) => {
          // Validate imageId and skip lazy: placeholders
          if (!imageId || typeof imageId !== 'string' || imageId.trim() === '' || imageId.startsWith('lazy:')) {
            return;
          }

          try {
            // Extract storagePath from imageId
            const storagePath = this.extractStoragePath(imageId);
            
            // Check if already cached using storagePath
            const cached = await dicomCache.has(storagePath);
            if (cached) {
              loaded++;
              return;
            }

            // Extract URL from wadouri: scheme
            const url = imageId.replace('wadouri:', '');
            
            // Fetch raw DICOM file as ArrayBuffer
            const response = await fetch(url);
            if (!response.ok) {
              throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }
            
            const arrayBuffer = await response.arrayBuffer();
            
            // Validate ArrayBuffer before caching
            if (arrayBuffer && arrayBuffer.byteLength > 0) {
              await dicomCache.set(storagePath, arrayBuffer, studyId);
              loaded++;
            }
          } catch (error) {
            console.warn(`Failed to preload ${imageId}:`, error);
          }
        })
      );

      // Progress log every batch
      if (i % 50 === 0) {
        console.log(`Preload progress: ${loaded}/${totalImages} images cached`);
      }
    }

    console.log(`Series preload complete: ${loaded}/${totalImages} images cached`);
  }

  /**
   * Cancel all preloading
   */
  cancelPreloading(): void {
    this.preloadQueue.clear();
    this.isPreloading = false;
  }

  /**
   * Get preload progress
   */
  getProgress(): { queued: number; isActive: boolean } {
    return {
      queued: this.preloadQueue.size,
      isActive: this.isPreloading,
    };
  }

  private async startPreloading(studyId: string): Promise<void> {
    if (this.isPreloading) return;
    
    this.isPreloading = true;

    // Process queue in batches for better performance
    const batchSize = 5;
    while (this.preloadQueue.size > 0) {
      const batch = Array.from(this.preloadQueue).slice(0, batchSize);
      
      await Promise.all(
        batch.map(async (imageId) => {
          this.preloadQueue.delete(imageId);

          // Validate imageId before loading and skip lazy: placeholders
          if (!imageId || typeof imageId !== 'string' || imageId.trim() === '' || imageId.startsWith('lazy:')) {
            return;
          }

          try {
            // Extract storagePath from imageId for cache check
            const storagePath = this.extractStoragePath(imageId);
            
            // Check if already cached using storagePath
            const cached = await dicomCache.has(storagePath);
            if (!cached) {
              // Extract URL from wadouri: scheme
              const url = imageId.replace('wadouri:', '');
              
              // Fetch raw DICOM file as ArrayBuffer
              const response = await fetch(url);
              if (response.ok) {
                const arrayBuffer = await response.arrayBuffer();
                if (arrayBuffer && arrayBuffer.byteLength > 0) {
                  await dicomCache.set(storagePath, arrayBuffer, studyId);
                }
              }
            }
          } catch (error) {
            console.warn(`Preload failed for ${imageId}:`, error);
          }
        })
      );
    }

    this.isPreloading = false;
  }

  private updateNavigationPattern(currentIndex: number): void {
    const { lastSlices } = this.navigationPattern;
    
    lastSlices.push(currentIndex);
    if (lastSlices.length > this.MAX_PATTERN_HISTORY) {
      lastSlices.shift();
    }

    if (lastSlices.length >= 3) {
      // Detect direction
      const recent = lastSlices.slice(-3);
      const increasing = recent.every((val, i) => i === 0 || val > recent[i - 1]);
      const decreasing = recent.every((val, i) => i === 0 || val < recent[i - 1]);

      if (increasing) {
        this.navigationPattern.direction = 'forward';
      } else if (decreasing) {
        this.navigationPattern.direction = 'backward';
      } else {
        this.navigationPattern.direction = 'random';
      }

      // Calculate speed (slices per interaction)
      const diffs = recent.slice(1).map((val, i) => Math.abs(val - recent[i]));
      this.navigationPattern.speed = diffs.reduce((a, b) => a + b, 0) / diffs.length;
    }
  }

  private calculatePreloadIndices(currentIndex: number, totalSlices: number): number[] {
    const indices: number[] = [];
    const { direction, speed } = this.navigationPattern;
    
    // Adjust preload distance based on navigation speed
    const distance = Math.ceil(this.PRELOAD_DISTANCE * Math.max(1, speed));

    if (direction === 'forward') {
      // Preload more ahead
      for (let i = 1; i <= distance * 2; i++) {
        const idx = currentIndex + i;
        if (idx < totalSlices) indices.push(idx);
      }
      // Preload few behind
      for (let i = 1; i <= distance; i++) {
        const idx = currentIndex - i;
        if (idx >= 0) indices.push(idx);
      }
    } else if (direction === 'backward') {
      // Preload more behind
      for (let i = 1; i <= distance * 2; i++) {
        const idx = currentIndex - i;
        if (idx >= 0) indices.push(idx);
      }
      // Preload few ahead
      for (let i = 1; i <= distance; i++) {
        const idx = currentIndex + i;
        if (idx < totalSlices) indices.push(idx);
      }
    } else {
      // Random: preload evenly in both directions
      for (let i = 1; i <= distance; i++) {
        const forward = currentIndex + i;
        const backward = currentIndex - i;
        if (forward < totalSlices) indices.push(forward);
        if (backward >= 0) indices.push(backward);
      }
    }

    return indices;
  }

  private extractStoragePath(imageId: string): string {
    // Remove the wadouri: prefix and extract storage path from signed URL
    // Format: wadouri:https://...supabase.co/storage/v1/object/sign/bucket/path?token=...
    const url = imageId.replace('wadouri:', '');
    try {
      const urlObj = new URL(url);
      // Extract path after /sign/
      const pathMatch = urlObj.pathname.match(/\/storage\/v1\/object\/sign\/(.+)/);
      if (pathMatch) {
        return pathMatch[1]; // Returns "bucket/path"
      }
    } catch (e) {
      console.warn('[Preloader] Failed to extract storage path from imageId:', imageId);
    }
    return imageId; // Fallback to original
  }
}

// Export singleton instance
export const dicomPreloader = new DicomPreloaderService();
