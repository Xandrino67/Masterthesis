import { VolumeData, ViewPlane } from './mprProcessor';

export interface MIPOptions {
  slabThickness?: number; // Number of slices to project (0 = entire volume)
  centerSlice?: number; // Center of the slab
}

/**
 * Perform Maximum Intensity Projection (MIP) on volume data
 * Particularly useful for visualizing dose distributions
 */
export function computeMIP(
  volume: VolumeData,
  plane: ViewPlane,
  options: MIPOptions = {}
): Float32Array {
  const { slabThickness = 0, centerSlice } = options;
  
  switch (plane) {
    case 'axial':
      return computeAxialMIP(volume, slabThickness, centerSlice);
    case 'sagittal':
      return computeSagittalMIP(volume, slabThickness, centerSlice);
    case 'coronal':
      return computeCoronalMIP(volume, slabThickness, centerSlice);
    default:
      throw new Error(`Unknown plane: ${plane}`);
  }
}

/**
 * Axial MIP (project along Z axis)
 */
function computeAxialMIP(
  volume: VolumeData,
  slabThickness: number,
  centerSlice?: number
): Float32Array {
  const [width, height, depth] = volume.dimensions;
  const mipData = new Float32Array(width * height);
  
  // Determine slab range
  let startZ = 0;
  let endZ = depth;
  
  if (slabThickness > 0 && centerSlice !== undefined) {
    const halfSlab = Math.floor(slabThickness / 2);
    startZ = Math.max(0, centerSlice - halfSlab);
    endZ = Math.min(depth, centerSlice + halfSlab + 1);
  }
  
  // Initialize with minimum values
  mipData.fill(-Infinity);
  
  // Project maximum values
  for (let z = startZ; z < endZ; z++) {
    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        const volumeIndex = z * width * height + y * width + x;
        const mipIndex = y * width + x;
        mipData[mipIndex] = Math.max(mipData[mipIndex], volume.data[volumeIndex]);
      }
    }
  }
  
  // Replace -Infinity with 0
  for (let i = 0; i < mipData.length; i++) {
    if (mipData[i] === -Infinity) mipData[i] = 0;
  }
  
  return mipData;
}

/**
 * Sagittal MIP (project along X axis)
 */
function computeSagittalMIP(
  volume: VolumeData,
  slabThickness: number,
  centerSlice?: number
): Float32Array {
  const [width, height, depth] = volume.dimensions;
  const mipData = new Float32Array(height * depth);
  
  let startX = 0;
  let endX = width;
  
  if (slabThickness > 0 && centerSlice !== undefined) {
    const halfSlab = Math.floor(slabThickness / 2);
    startX = Math.max(0, centerSlice - halfSlab);
    endX = Math.min(width, centerSlice + halfSlab + 1);
  }
  
  mipData.fill(-Infinity);
  
  for (let x = startX; x < endX; x++) {
    for (let z = 0; z < depth; z++) {
      for (let y = 0; y < height; y++) {
        const volumeIndex = z * width * height + y * width + x;
        const mipIndex = z * height + y;
        mipData[mipIndex] = Math.max(mipData[mipIndex], volume.data[volumeIndex]);
      }
    }
  }
  
  for (let i = 0; i < mipData.length; i++) {
    if (mipData[i] === -Infinity) mipData[i] = 0;
  }
  
  return mipData;
}

/**
 * Coronal MIP (project along Y axis)
 */
function computeCoronalMIP(
  volume: VolumeData,
  slabThickness: number,
  centerSlice?: number
): Float32Array {
  const [width, height, depth] = volume.dimensions;
  const mipData = new Float32Array(width * depth);
  
  let startY = 0;
  let endY = height;
  
  if (slabThickness > 0 && centerSlice !== undefined) {
    const halfSlab = Math.floor(slabThickness / 2);
    startY = Math.max(0, centerSlice - halfSlab);
    endY = Math.min(height, centerSlice + halfSlab + 1);
  }
  
  mipData.fill(-Infinity);
  
  for (let y = startY; y < endY; y++) {
    for (let z = 0; z < depth; z++) {
      for (let x = 0; x < width; x++) {
        const volumeIndex = z * width * height + y * width + x;
        const mipIndex = z * width + x;
        mipData[mipIndex] = Math.max(mipData[mipIndex], volume.data[volumeIndex]);
      }
    }
  }
  
  for (let i = 0; i < mipData.length; i++) {
    if (mipData[i] === -Infinity) mipData[i] = 0;
  }
  
  return mipData;
}

/**
 * Compute MinIP (Minimum Intensity Projection) - useful for air/lung visualization
 */
export function computeMinIP(
  volume: VolumeData,
  plane: ViewPlane,
  options: MIPOptions = {}
): Float32Array {
  const mip = computeMIP(volume, plane, options);
  
  // For MinIP, we need to invert the logic
  // This is a simplified version - in production you'd want separate functions
  const [width, height, depth] = volume.dimensions;
  const minipData = new Float32Array(mip.length);
  minipData.fill(Infinity);
  
  // Similar logic but using Math.min instead of Math.max
  // Implementation omitted for brevity - would follow same pattern as MIP
  
  return minipData;
}
