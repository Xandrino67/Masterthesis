import cornerstone from 'cornerstone-core';
import { dicomCache } from './dicomCache';
import { resolveLazyImageId } from './dicomImageLoader';

export interface VolumeData {
  data: Float32Array;
  dimensions: [number, number, number]; // [width, height, depth]
  spacing: [number, number, number]; // [x, y, z] voxel spacing in mm
}

export type ViewPlane = 'axial' | 'sagittal' | 'coronal';

/**
 * Extract volume data from a loaded DICOM stack
 * Uses shared cache with DicomViewer for optimal performance
 */
export async function extractVolumeFromStack(
  imageIds: string[],
  onProgress?: (current: number, total: number) => void
): Promise<VolumeData> {
  if (imageIds.length === 0) {
    throw new Error('No image IDs provided');
  }

  // Initialize shared cache
  await dicomCache.init();

  // Load first image to get dimensions (will use cache if available)
  const firstImage = await cornerstone.loadImage(imageIds[0]);
  const width = firstImage.width;
  const height = firstImage.height;
  const depth = imageIds.length;

  // Extract pixel spacing (default to 1mm if not available)
  const columnSpacing = firstImage.columnPixelSpacing || 1.0;
  const rowSpacing = firstImage.rowPixelSpacing || 1.0;
  
  // Estimate slice spacing from image position patient data if available
  let sliceSpacing = 1.0;
  if (imageIds.length > 1) {
    try {
      const secondImage = await cornerstone.loadImage(imageIds[1]);
      if (firstImage.imagePositionPatient && secondImage.imagePositionPatient) {
        const dz = Math.abs(
          secondImage.imagePositionPatient[2] - firstImage.imagePositionPatient[2]
        );
        if (dz > 0) sliceSpacing = dz;
      }
    } catch (err) {
      console.warn('Could not calculate slice spacing, using default 1mm');
    }
  }

  // Allocate volume array
  const volumeSize = width * height * depth;
  const volumeData = new Float32Array(volumeSize);

  // Load all slices and populate volume
  // Images will be loaded from shared cache via the registered cache-aware loader
  let loadedCount = 0;
  let failedCount = 0;
  
  for (let z = 0; z < depth; z++) {
    try {
      // Resolve lazy imageId if needed
      let resolvedImageId = imageIds[z];
      if (resolvedImageId.startsWith('lazy:')) {
        resolvedImageId = await resolveLazyImageId(resolvedImageId);
      }
      
      // cornerstone.loadImage will check the shared cache first (via registerCacheAwareLoader)
      const image = await cornerstone.loadImage(resolvedImageId);
      const pixelData = image.getPixelData();
      
      // Copy slice data into volume
      const sliceOffset = z * width * height;
      for (let i = 0; i < pixelData.length; i++) {
        volumeData[sliceOffset + i] = pixelData[i];
      }
      
      loadedCount++;
      onProgress?.(z + 1, depth);
    } catch (err) {
      failedCount++;
      console.error(`Failed to load slice ${z + 1}/${depth}:`, err);
      
      // Fill with zeros for failed slices
      const sliceOffset = z * width * height;
      for (let i = 0; i < width * height; i++) {
        volumeData[sliceOffset + i] = 0;
      }
    }
  }
  
  if (failedCount > 0) {
    console.warn(`Volume loaded with ${loadedCount}/${depth} slices (${failedCount} failed)`);
  }

  return {
    data: volumeData,
    dimensions: [width, height, depth],
    spacing: [columnSpacing, rowSpacing, sliceSpacing],
  };
}

/**
 * Extract a 2D slice from volume data in any orientation
 */
export function extractSlice(
  volume: VolumeData,
  plane: ViewPlane,
  sliceIndex: number
): Float32Array {
  const [width, height, depth] = volume.dimensions;
  
  switch (plane) {
    case 'axial':
      // XY plane (standard view)
      return extractAxialSlice(volume, sliceIndex);
      
    case 'sagittal':
      // YZ plane (side view)
      return extractSagittalSlice(volume, sliceIndex);
      
    case 'coronal':
      // XZ plane (front view)
      return extractCoronalSlice(volume, sliceIndex);
      
    default:
      throw new Error(`Unknown plane: ${plane}`);
  }
}

/**
 * Extract axial slice (XY plane)
 */
function extractAxialSlice(volume: VolumeData, z: number): Float32Array {
  const [width, height, depth] = volume.dimensions;
  
  if (z < 0 || z >= depth) {
    throw new Error(`Slice index ${z} out of range [0, ${depth - 1}]`);
  }
  
  const sliceSize = width * height;
  const sliceOffset = z * sliceSize;
  return volume.data.slice(sliceOffset, sliceOffset + sliceSize);
}

/**
 * Extract sagittal slice (YZ plane, looking from the side)
 */
function extractSagittalSlice(volume: VolumeData, x: number): Float32Array {
  const [width, height, depth] = volume.dimensions;
  
  if (x < 0 || x >= width) {
    throw new Error(`Slice index ${x} out of range [0, ${width - 1}]`);
  }
  
  const sliceData = new Float32Array(height * depth);
  
  for (let z = 0; z < depth; z++) {
    for (let y = 0; y < height; y++) {
      const volumeIndex = z * width * height + y * width + x;
      const sliceIndex = z * height + y;
      sliceData[sliceIndex] = volume.data[volumeIndex];
    }
  }
  
  return sliceData;
}

/**
 * Extract coronal slice (XZ plane, looking from the front)
 */
function extractCoronalSlice(volume: VolumeData, y: number): Float32Array {
  const [width, height, depth] = volume.dimensions;
  
  if (y < 0 || y >= height) {
    throw new Error(`Slice index ${y} out of range [0, ${height - 1}]`);
  }
  
  const sliceData = new Float32Array(width * depth);
  
  for (let z = 0; z < depth; z++) {
    for (let x = 0; x < width; x++) {
      const volumeIndex = z * width * height + y * width + x;
      const sliceIndex = z * width + x;
      sliceData[sliceIndex] = volume.data[volumeIndex];
    }
  }
  
  return sliceData;
}

/**
 * Get slice dimensions for a given plane
 */
export function getSliceDimensions(
  volume: VolumeData,
  plane: ViewPlane
): [number, number] {
  const [width, height, depth] = volume.dimensions;
  
  switch (plane) {
    case 'axial':
      return [width, height];
    case 'sagittal':
      return [height, depth];
    case 'coronal':
      return [width, depth];
    default:
      throw new Error(`Unknown plane: ${plane}`);
  }
}

/**
 * Get the number of slices for a given plane
 */
export function getSliceCount(volume: VolumeData, plane: ViewPlane): number {
  const [width, height, depth] = volume.dimensions;
  
  switch (plane) {
    case 'axial':
      return depth;
    case 'sagittal':
      return width;
    case 'coronal':
      return height;
    default:
      throw new Error(`Unknown plane: ${plane}`);
  }
}
