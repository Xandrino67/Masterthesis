import * as ss from 'simple-statistics';

export interface DVHPoint {
  dose: number;
  volume: number;
}

export interface DVHCurve {
  organId: string;
  organLabel: string;
  studyId: string;
  points: DVHPoint[];
}

export interface AggregateDVH {
  organLabel: string;
  meanCurve: DVHPoint[];
  sdCurve: DVHPoint[];
  upperBound: DVHPoint[];
  lowerBound: DVHPoint[];
  individualCurves: DVHCurve[];
}

export interface DVHMetrics {
  organLabel: string;
  dMean: number;
  dMedian: number;
  dMin: number;
  dMax: number;
  v20: number; // Volume receiving at least 20 Gy
  v50: number; // Volume receiving at least 50 Gy
  d95: number; // Dose received by 95% of volume
}

/**
 * Aggregate multiple DVH curves for the same organ
 */
export function aggregateDVHCurves(curves: DVHCurve[]): AggregateDVH | null {
  if (curves.length === 0) return null;
  
  const organLabel = curves[0].organLabel;
  
  // Find common dose bins
  const allDoses = curves.flatMap(c => c.points.map(p => p.dose));
  const minDose = Math.min(...allDoses);
  const maxDose = Math.max(...allDoses);
  const numBins = 100;
  const doseBins = Array.from({ length: numBins }, (_, i) => 
    minDose + (i * (maxDose - minDose) / (numBins - 1))
  );
  
  // Interpolate each curve to common dose bins
  const interpolatedCurves = curves.map(curve => 
    interpolateDVH(curve.points, doseBins)
  );
  
  // Calculate mean and SD at each dose bin
  const meanCurve: DVHPoint[] = [];
  const sdCurve: DVHPoint[] = [];
  const upperBound: DVHPoint[] = [];
  const lowerBound: DVHPoint[] = [];
  
  for (let i = 0; i < doseBins.length; i++) {
    const volumesAtDose = interpolatedCurves.map(curve => curve[i]);
    const mean = ss.mean(volumesAtDose);
    const sd = volumesAtDose.length > 1 ? ss.standardDeviation(volumesAtDose) : 0;
    
    meanCurve.push({ dose: doseBins[i], volume: mean });
    sdCurve.push({ dose: doseBins[i], volume: sd });
    upperBound.push({ dose: doseBins[i], volume: Math.min(100, mean + sd) });
    lowerBound.push({ dose: doseBins[i], volume: Math.max(0, mean - sd) });
  }
  
  return {
    organLabel,
    meanCurve,
    sdCurve,
    upperBound,
    lowerBound,
    individualCurves: curves
  };
}

/**
 * Interpolate DVH curve to specified dose bins
 */
function interpolateDVH(points: DVHPoint[], targetDoses: number[]): number[] {
  const sorted = [...points].sort((a, b) => a.dose - b.dose);
  
  return targetDoses.map(targetDose => {
    // If target dose is outside range, return boundary values
    if (targetDose <= sorted[0].dose) return sorted[0].volume;
    if (targetDose >= sorted[sorted.length - 1].dose) return sorted[sorted.length - 1].volume;
    
    // Linear interpolation
    for (let i = 0; i < sorted.length - 1; i++) {
      if (targetDose >= sorted[i].dose && targetDose <= sorted[i + 1].dose) {
        const t = (targetDose - sorted[i].dose) / (sorted[i + 1].dose - sorted[i].dose);
        return sorted[i].volume + t * (sorted[i + 1].volume - sorted[i].volume);
      }
    }
    
    return 0;
  });
}

/**
 * Calculate DVH metrics from a curve
 */
export function calculateDVHMetrics(curve: DVHCurve, doseMetrics: {
  d_mean: number;
  d_median: number;
  d_min: number;
  d_max: number;
}): DVHMetrics {
  const points = curve.points;
  
  // V20: Volume receiving at least 20 Gy
  const v20Point = points.find(p => p.dose >= 20);
  const v20 = v20Point ? v20Point.volume : 0;
  
  // V50: Volume receiving at least 50 Gy
  const v50Point = points.find(p => p.dose >= 50);
  const v50 = v50Point ? v50Point.volume : 0;
  
  // D95: Dose received by 95% of volume
  let d95 = 0;
  for (let i = 0; i < points.length - 1; i++) {
    if (points[i].volume >= 95 && points[i + 1].volume < 95) {
      // Linear interpolation
      const t = (95 - points[i + 1].volume) / (points[i].volume - points[i + 1].volume);
      d95 = points[i + 1].dose + t * (points[i].dose - points[i + 1].dose);
      break;
    }
  }
  
  return {
    organLabel: curve.organLabel,
    dMean: doseMetrics.d_mean,
    dMedian: doseMetrics.d_median,
    dMin: doseMetrics.d_min,
    dMax: doseMetrics.d_max,
    v20,
    v50,
    d95
  };
}

/**
 * Prepare DVH data for heatmap visualization
 */
export interface DVHHeatmapData {
  studyId: string;
  [key: string]: number | string; // dose bins as keys
}

export function prepareDVHHeatmap(curves: DVHCurve[], numBins: number = 20): {
  data: DVHHeatmapData[];
  doseBins: string[];
} {
  if (curves.length === 0) return { data: [], doseBins: [] };
  
  const allDoses = curves.flatMap(c => c.points.map(p => p.dose));
  const maxDose = Math.max(...allDoses);
  const binSize = maxDose / numBins;
  
  const doseBins = Array.from({ length: numBins }, (_, i) => 
    `${(i * binSize).toFixed(0)}-${((i + 1) * binSize).toFixed(0)}`
  );
  
  const data: DVHHeatmapData[] = curves.map(curve => {
    const row: DVHHeatmapData = { studyId: curve.studyId };
    
    for (let i = 0; i < numBins; i++) {
      const doseMin = i * binSize;
      const doseMax = (i + 1) * binSize;
      
      // Find volume at this dose range (use dose at bin center)
      const doseMid = (doseMin + doseMax) / 2;
      const volumes = interpolateDVH(curve.points, [doseMid]);
      row[doseBins[i]] = volumes[0];
    }
    
    return row;
  });
  
  return { data, doseBins };
}

/**
 * Calculate confidence interval for DVH curve
 */
export function calculateDVHConfidenceInterval(
  curves: DVHCurve[], 
  confidenceLevel: number = 0.95
): AggregateDVH | null {
  if (curves.length === 0) return null;
  
  const organLabel = curves[0].organLabel;
  const alpha = 1 - confidenceLevel;
  const zScore = 1.96; // For 95% CI
  
  // Find common dose bins
  const allDoses = curves.flatMap(c => c.points.map(p => p.dose));
  const minDose = Math.min(...allDoses);
  const maxDose = Math.max(...allDoses);
  const numBins = 100;
  const doseBins = Array.from({ length: numBins }, (_, i) => 
    minDose + (i * (maxDose - minDose) / (numBins - 1))
  );
  
  // Interpolate each curve
  const interpolatedCurves = curves.map(curve => 
    interpolateDVH(curve.points, doseBins)
  );
  
  const meanCurve: DVHPoint[] = [];
  const upperBound: DVHPoint[] = [];
  const lowerBound: DVHPoint[] = [];
  const sdCurve: DVHPoint[] = [];
  
  for (let i = 0; i < doseBins.length; i++) {
    const volumesAtDose = interpolatedCurves.map(curve => curve[i]);
    const mean = ss.mean(volumesAtDose);
    const sd = volumesAtDose.length > 1 ? ss.standardDeviation(volumesAtDose) : 0;
    const se = sd / Math.sqrt(volumesAtDose.length);
    const margin = zScore * se;
    
    meanCurve.push({ dose: doseBins[i], volume: mean });
    sdCurve.push({ dose: doseBins[i], volume: sd });
    upperBound.push({ dose: doseBins[i], volume: Math.min(100, mean + margin) });
    lowerBound.push({ dose: doseBins[i], volume: Math.max(0, mean - margin) });
  }
  
  return {
    organLabel,
    meanCurve,
    sdCurve,
    upperBound,
    lowerBound,
    individualCurves: curves
  };
}
