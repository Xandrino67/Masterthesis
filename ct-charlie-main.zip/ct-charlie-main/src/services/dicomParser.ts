import * as dicomParser from 'dicom-parser';

export interface DicomMetadata {
  mA: number;
  exposureTime: number;
  patientSex?: string;
  manufacturerModelName?: string;
}

/**
 * Parse DICOM file and extract metadata
 * Extracts: XRayTubeCurrent (mA), ExposureTime (ms), PatientSex, ManufacturerModelName
 */
export async function parseDicomFile(file: ArrayBuffer): Promise<DicomMetadata> {
  try {
    const byteArray = new Uint8Array(file);
    const dataSet = dicomParser.parseDicom(byteArray);

    // Extract metadata - matching Matlab script exactly
    const mA = dataSet.floatString('x00181151'); // XRayTubeCurrent
    const exposureTime = dataSet.floatString('x00181150'); // ExposureTime in ms
    const patientSex = dataSet.string('x00100040'); // PatientSex
    const manufacturerModelName = dataSet.string('x00081090'); // ManufacturerModelName

    if (!mA || !exposureTime) {
      throw new Error('Required DICOM tags (mA or ExposureTime) not found');
    }

    return {
      mA,
      exposureTime,
      patientSex,
      manufacturerModelName,
    };
  } catch (error) {
    console.error('DICOM parsing error:', error);
    throw new Error(`Failed to parse DICOM file: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}

/**
 * Calculate mean mAs from DICOM metadata array
 * Formula: mean(mA × (exposureTime / 1000))
 * Matches Matlab: meanmAs = mean(mA .* (exposureTime / 1000));
 */
export function calculateMeanMAs(metadata: DicomMetadata[]): number {
  if (metadata.length === 0) {
    throw new Error('No DICOM metadata available for mAs calculation');
  }

  const mAsValues = metadata.map(m => m.mA * (m.exposureTime / 1000));
  const sum = mAsValues.reduce((acc, val) => acc + val, 0);
  const meanmAs = sum / mAsValues.length;

  console.log(`Calculated meanmAs: ${meanmAs} from ${metadata.length} DICOM files`);
  return meanmAs;
}
