export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "13.0.5"
  }
  public: {
    Tables: {
      analysis_runs: {
        Row: {
          checksums: Json | null
          code_version: string | null
          created_at: string | null
          created_by: string | null
          finished_at: string | null
          id: string
          impact_mc_version: string | null
          input_refs: Json | null
          is_mock_data: boolean | null
          params: Json | null
          provenance: Json | null
          results: Json | null
          run_id: string
          started_at: string | null
          status: Database["public"]["Enums"]["analysis_status"] | null
          study_id: string
          updated_at: string | null
        }
        Insert: {
          checksums?: Json | null
          code_version?: string | null
          created_at?: string | null
          created_by?: string | null
          finished_at?: string | null
          id?: string
          impact_mc_version?: string | null
          input_refs?: Json | null
          is_mock_data?: boolean | null
          params?: Json | null
          provenance?: Json | null
          results?: Json | null
          run_id: string
          started_at?: string | null
          status?: Database["public"]["Enums"]["analysis_status"] | null
          study_id: string
          updated_at?: string | null
        }
        Update: {
          checksums?: Json | null
          code_version?: string | null
          created_at?: string | null
          created_by?: string | null
          finished_at?: string | null
          id?: string
          impact_mc_version?: string | null
          input_refs?: Json | null
          is_mock_data?: boolean | null
          params?: Json | null
          provenance?: Json | null
          results?: Json | null
          run_id?: string
          started_at?: string | null
          status?: Database["public"]["Enums"]["analysis_status"] | null
          study_id?: string
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "analysis_runs_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "analysis_runs_study_id_fkey"
            columns: ["study_id"]
            isOneToOne: false
            referencedRelation: "studies"
            referencedColumns: ["id"]
          },
        ]
      }
      audit_logs: {
        Row: {
          action: string
          created_at: string | null
          details: Json | null
          id: string
          ip_address: string | null
          resource_id: string | null
          resource_type: string
          user_agent: string | null
          user_id: string | null
        }
        Insert: {
          action: string
          created_at?: string | null
          details?: Json | null
          id?: string
          ip_address?: string | null
          resource_id?: string | null
          resource_type: string
          user_agent?: string | null
          user_id?: string | null
        }
        Update: {
          action?: string
          created_at?: string | null
          details?: Json | null
          id?: string
          ip_address?: string | null
          resource_id?: string | null
          resource_type?: string
          user_agent?: string | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "audit_logs_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      cohort_studies: {
        Row: {
          added_at: string | null
          cohort_id: string
          study_id: string
        }
        Insert: {
          added_at?: string | null
          cohort_id: string
          study_id: string
        }
        Update: {
          added_at?: string | null
          cohort_id?: string
          study_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "cohort_studies_cohort_id_fkey"
            columns: ["cohort_id"]
            isOneToOne: false
            referencedRelation: "cohorts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "cohort_studies_study_id_fkey"
            columns: ["study_id"]
            isOneToOne: false
            referencedRelation: "studies"
            referencedColumns: ["id"]
          },
        ]
      }
      cohorts: {
        Row: {
          created_at: string | null
          created_by: string | null
          description: string | null
          filters: Json | null
          id: string
          include_mock_data: boolean | null
          name: string
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          created_by?: string | null
          description?: string | null
          filters?: Json | null
          id?: string
          include_mock_data?: boolean | null
          name: string
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          created_by?: string | null
          description?: string | null
          filters?: Json | null
          id?: string
          include_mock_data?: boolean | null
          name?: string
          updated_at?: string | null
        }
        Relationships: []
      }
      departments: {
        Row: {
          contact_info: string | null
          created_at: string | null
          created_by: string | null
          id: string
          institution_id: string
          modality_types: Database["public"]["Enums"]["modality_type"][] | null
          name: string
          updated_at: string | null
        }
        Insert: {
          contact_info?: string | null
          created_at?: string | null
          created_by?: string | null
          id?: string
          institution_id: string
          modality_types?: Database["public"]["Enums"]["modality_type"][] | null
          name: string
          updated_at?: string | null
        }
        Update: {
          contact_info?: string | null
          created_at?: string | null
          created_by?: string | null
          id?: string
          institution_id?: string
          modality_types?: Database["public"]["Enums"]["modality_type"][] | null
          name?: string
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "departments_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "departments_institution_id_fkey"
            columns: ["institution_id"]
            isOneToOne: false
            referencedRelation: "institutions"
            referencedColumns: ["id"]
          },
        ]
      }
      devices: {
        Row: {
          bowtie_filter_type: string | null
          created_at: string | null
          created_by: string | null
          department_id: string | null
          device_id: string
          field_size: Json | null
          geometry_params: Json | null
          id: string
          isocenter: Json | null
          kvp_range: Json | null
          mas_range: Json | null
          modality: Database["public"]["Enums"]["modality_type"]
          model: string
          serial_number: string | null
          updated_at: string | null
          vendor: string
        }
        Insert: {
          bowtie_filter_type?: string | null
          created_at?: string | null
          created_by?: string | null
          department_id?: string | null
          device_id: string
          field_size?: Json | null
          geometry_params?: Json | null
          id?: string
          isocenter?: Json | null
          kvp_range?: Json | null
          mas_range?: Json | null
          modality: Database["public"]["Enums"]["modality_type"]
          model: string
          serial_number?: string | null
          updated_at?: string | null
          vendor: string
        }
        Update: {
          bowtie_filter_type?: string | null
          created_at?: string | null
          created_by?: string | null
          department_id?: string | null
          device_id?: string
          field_size?: Json | null
          geometry_params?: Json | null
          id?: string
          isocenter?: Json | null
          kvp_range?: Json | null
          mas_range?: Json | null
          modality?: Database["public"]["Enums"]["modality_type"]
          model?: string
          serial_number?: string | null
          updated_at?: string | null
          vendor?: string
        }
        Relationships: [
          {
            foreignKeyName: "devices_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "devices_department_id_fkey"
            columns: ["department_id"]
            isOneToOne: false
            referencedRelation: "departments"
            referencedColumns: ["id"]
          },
        ]
      }
      extracted_files: {
        Row: {
          created_at: string | null
          created_by: string | null
          file_size: number
          file_type: string
          id: string
          organ_name: string | null
          original_path: string
          parent_path: string | null
          series_number: number | null
          storage_bucket: string
          storage_path: string
          study_id: string
          upload_status: string | null
          uploaded_at: string | null
          uploaded_by: string | null
        }
        Insert: {
          created_at?: string | null
          created_by?: string | null
          file_size: number
          file_type: string
          id?: string
          organ_name?: string | null
          original_path: string
          parent_path?: string | null
          series_number?: number | null
          storage_bucket: string
          storage_path: string
          study_id: string
          upload_status?: string | null
          uploaded_at?: string | null
          uploaded_by?: string | null
        }
        Update: {
          created_at?: string | null
          created_by?: string | null
          file_size?: number
          file_type?: string
          id?: string
          organ_name?: string | null
          original_path?: string
          parent_path?: string | null
          series_number?: number | null
          storage_bucket?: string
          storage_path?: string
          study_id?: string
          upload_status?: string | null
          uploaded_at?: string | null
          uploaded_by?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "extracted_files_study_id_text_fkey"
            columns: ["study_id"]
            isOneToOne: false
            referencedRelation: "studies"
            referencedColumns: ["study_id"]
          },
        ]
      }
      institutions: {
        Row: {
          address: string | null
          country: string | null
          created_at: string | null
          created_by: string | null
          id: string
          name: string
          updated_at: string | null
        }
        Insert: {
          address?: string | null
          country?: string | null
          created_at?: string | null
          created_by?: string | null
          id?: string
          name: string
          updated_at?: string | null
        }
        Update: {
          address?: string | null
          country?: string | null
          created_at?: string | null
          created_by?: string | null
          id?: string
          name?: string
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "institutions_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      organs: {
        Row: {
          color: string | null
          created_at: string | null
          created_by: string | null
          icrp_code: string | null
          id: string
          is_system_default: boolean | null
          label: string
          snomed_code: string | null
          updated_at: string | null
          weight_factor: number | null
        }
        Insert: {
          color?: string | null
          created_at?: string | null
          created_by?: string | null
          icrp_code?: string | null
          id?: string
          is_system_default?: boolean | null
          label: string
          snomed_code?: string | null
          updated_at?: string | null
          weight_factor?: number | null
        }
        Update: {
          color?: string | null
          created_at?: string | null
          created_by?: string | null
          icrp_code?: string | null
          id?: string
          is_system_default?: boolean | null
          label?: string
          snomed_code?: string | null
          updated_at?: string | null
          weight_factor?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "organs_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      patients: {
        Row: {
          birth_year: number | null
          consent_flags: Json | null
          created_at: string | null
          created_by: string | null
          id: string
          is_mock_data: boolean | null
          notes: string | null
          pseudonym_id: string
          sex: string | null
          updated_at: string | null
        }
        Insert: {
          birth_year?: number | null
          consent_flags?: Json | null
          created_at?: string | null
          created_by?: string | null
          id?: string
          is_mock_data?: boolean | null
          notes?: string | null
          pseudonym_id: string
          sex?: string | null
          updated_at?: string | null
        }
        Update: {
          birth_year?: number | null
          consent_flags?: Json | null
          created_at?: string | null
          created_by?: string | null
          id?: string
          is_mock_data?: boolean | null
          notes?: string | null
          pseudonym_id?: string
          sex?: string | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "patients_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      physicians: {
        Row: {
          affiliation: string | null
          created_at: string | null
          created_by: string | null
          id: string
          institution_id: string | null
          name: string
          role: string | null
          updated_at: string | null
        }
        Insert: {
          affiliation?: string | null
          created_at?: string | null
          created_by?: string | null
          id?: string
          institution_id?: string | null
          name: string
          role?: string | null
          updated_at?: string | null
        }
        Update: {
          affiliation?: string | null
          created_at?: string | null
          created_by?: string | null
          id?: string
          institution_id?: string | null
          name?: string
          role?: string | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "physicians_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "physicians_institution_id_fkey"
            columns: ["institution_id"]
            isOneToOne: false
            referencedRelation: "institutions"
            referencedColumns: ["id"]
          },
        ]
      }
      processed_images: {
        Row: {
          created_at: string | null
          created_by: string | null
          file_size: number | null
          format: string
          id: string
          instance_number: number
          resolution: string
          series_id: string
          storage_path: string
          study_id: string
        }
        Insert: {
          created_at?: string | null
          created_by?: string | null
          file_size?: number | null
          format?: string
          id?: string
          instance_number: number
          resolution?: string
          series_id: string
          storage_path: string
          study_id: string
        }
        Update: {
          created_at?: string | null
          created_by?: string | null
          file_size?: number | null
          format?: string
          id?: string
          instance_number?: number
          resolution?: string
          series_id?: string
          storage_path?: string
          study_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "processed_images_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      processed_overlays: {
        Row: {
          created_at: string | null
          created_by: string | null
          format: string
          id: string
          instance_number: number
          organ_name: string | null
          overlay_type: string
          series_id: string
          storage_path: string
          study_id: string
        }
        Insert: {
          created_at?: string | null
          created_by?: string | null
          format?: string
          id?: string
          instance_number: number
          organ_name?: string | null
          overlay_type: string
          series_id: string
          storage_path: string
          study_id: string
        }
        Update: {
          created_at?: string | null
          created_by?: string | null
          format?: string
          id?: string
          instance_number?: number
          organ_name?: string | null
          overlay_type?: string
          series_id?: string
          storage_path?: string
          study_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "processed_overlays_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          created_at: string | null
          display_name: string | null
          email: string | null
          id: string
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          display_name?: string | null
          email?: string | null
          id: string
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          display_name?: string | null
          email?: string | null
          id?: string
          updated_at?: string | null
        }
        Relationships: []
      }
      protocols: {
        Row: {
          collimation: number | null
          created_at: string | null
          created_by: string | null
          exposure_settings: Json | null
          id: string
          kvp: number | null
          mas: number | null
          modality: Database["public"]["Enums"]["modality_type"]
          name: string
          notes: string | null
          pitch: number | null
          rotation_time: number | null
          updated_at: string | null
        }
        Insert: {
          collimation?: number | null
          created_at?: string | null
          created_by?: string | null
          exposure_settings?: Json | null
          id?: string
          kvp?: number | null
          mas?: number | null
          modality: Database["public"]["Enums"]["modality_type"]
          name: string
          notes?: string | null
          pitch?: number | null
          rotation_time?: number | null
          updated_at?: string | null
        }
        Update: {
          collimation?: number | null
          created_at?: string | null
          created_by?: string | null
          exposure_settings?: Json | null
          id?: string
          kvp?: number | null
          mas?: number | null
          modality?: Database["public"]["Enums"]["modality_type"]
          name?: string
          notes?: string | null
          pitch?: number | null
          rotation_time?: number | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "protocols_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      series: {
        Row: {
          checksum: string | null
          created_at: string | null
          created_by: string | null
          file_path: string | null
          frame_of_reference_uid: string | null
          grid_size: Json | null
          id: string
          orientation: Json | null
          origin: Json | null
          series_id: string
          series_type: string
          study_id: string
          unit: string | null
          updated_at: string | null
          voxel_spacing: Json | null
        }
        Insert: {
          checksum?: string | null
          created_at?: string | null
          created_by?: string | null
          file_path?: string | null
          frame_of_reference_uid?: string | null
          grid_size?: Json | null
          id?: string
          orientation?: Json | null
          origin?: Json | null
          series_id: string
          series_type: string
          study_id: string
          unit?: string | null
          updated_at?: string | null
          voxel_spacing?: Json | null
        }
        Update: {
          checksum?: string | null
          created_at?: string | null
          created_by?: string | null
          file_path?: string | null
          frame_of_reference_uid?: string | null
          grid_size?: Json | null
          id?: string
          orientation?: Json | null
          origin?: Json | null
          series_id?: string
          series_type?: string
          study_id?: string
          unit?: string | null
          updated_at?: string | null
          voxel_spacing?: Json | null
        }
        Relationships: [
          {
            foreignKeyName: "series_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "series_study_id_fkey"
            columns: ["study_id"]
            isOneToOne: false
            referencedRelation: "studies"
            referencedColumns: ["id"]
          },
        ]
      }
      studies: {
        Row: {
          created_at: string | null
          created_by: string | null
          device_id: string | null
          id: string
          indication: string | null
          institution_id: string | null
          is_mock_data: boolean | null
          modality_set: Database["public"]["Enums"]["modality_type"][] | null
          patient_id: string
          physician_id: string | null
          protocol_id: string | null
          study_date: string
          study_id: string
          updated_at: string | null
          upload_mode: string | null
        }
        Insert: {
          created_at?: string | null
          created_by?: string | null
          device_id?: string | null
          id?: string
          indication?: string | null
          institution_id?: string | null
          is_mock_data?: boolean | null
          modality_set?: Database["public"]["Enums"]["modality_type"][] | null
          patient_id: string
          physician_id?: string | null
          protocol_id?: string | null
          study_date: string
          study_id: string
          updated_at?: string | null
          upload_mode?: string | null
        }
        Update: {
          created_at?: string | null
          created_by?: string | null
          device_id?: string | null
          id?: string
          indication?: string | null
          institution_id?: string | null
          is_mock_data?: boolean | null
          modality_set?: Database["public"]["Enums"]["modality_type"][] | null
          patient_id?: string
          physician_id?: string | null
          protocol_id?: string | null
          study_date?: string
          study_id?: string
          updated_at?: string | null
          upload_mode?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "studies_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "studies_device_id_fkey"
            columns: ["device_id"]
            isOneToOne: false
            referencedRelation: "devices"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "studies_institution_id_fkey"
            columns: ["institution_id"]
            isOneToOne: false
            referencedRelation: "institutions"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "studies_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "studies_physician_id_fkey"
            columns: ["physician_id"]
            isOneToOne: false
            referencedRelation: "physicians"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "studies_protocol_id_fkey"
            columns: ["protocol_id"]
            isOneToOne: false
            referencedRelation: "protocols"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          created_at: string | null
          created_by: string | null
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string | null
          created_by?: string | null
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string | null
          created_by?: string | null
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_roles_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "user_roles_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
    }
    Enums: {
      analysis_status:
        | "pending"
        | "running"
        | "completed"
        | "failed"
        | "cancelled"
      app_role:
        | "platform_admin"
        | "tenant_admin"
        | "data_manager"
        | "researcher"
        | "viewer"
        | "auditor"
      modality_type: "CT" | "CBCT" | "PET" | "SPECT"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      analysis_status: [
        "pending",
        "running",
        "completed",
        "failed",
        "cancelled",
      ],
      app_role: [
        "platform_admin",
        "tenant_admin",
        "data_manager",
        "researcher",
        "viewer",
        "auditor",
      ],
      modality_type: ["CT", "CBCT", "PET", "SPECT"],
    },
  },
} as const
