# ZIP Upload Architecture for Multi-GB Medical Imaging Data

## Overview

The system supports uploading complete study datasets in ZIP format, including:
- Multi-gigabyte archives (2-5GB typical)
- Nested folder structures
- Hundreds of DICOM files
- Large NIfTI organ masks (100+ MB each)

## Expected ZIP Structure

Based on the reference data structure:

```
G_D_M_14.zip                                    # Root patient/study folder
├── CT_Beelden/                                 # CT Images
│   ├── CT Voor Fusie 1.25 - 3/                # DICOM series
│   │   └── IM-0001-0001-0001 (DICOM files)
│   └── CT WB 3.0 Bot - 4/                     # DICOM series
│       └── IM-0002-0001-0001 (DICOM files)
├── DoseDistribution_WB_CT_NM/                 # *** PRIMARY: Dose distribution
│   └── G_D_M_14_WB_120kV_mAsMod_DoseDistribution/
│       ├── CT00000000.dcm (~400 files)        # Dose DICOM slices
│       ├── CT00000001.dcm
│       └── ...
├── Niftis/                                    # *** PRIMARY: Organ masks
│   ├── G_D_M_14.json                          # Metadata
│   ├── G_D_M_14.nii (217 MB)                  # Full body segmentation
│   ├── hart.nii (108 MB)                      # Heart mask
│   ├── longen.nii (108 MB)                    # Lungs mask
│   ├── nieren.nii (108 MB)                    # Kidneys mask
│   ├── ribben.nii (108 MB)                    # Ribs mask
│   └── wervel.nii (108 MB)                    # Vertebrae mask
├── TotalSegmentator/                          # Alternative segmentations
│   ├── DICE_*.zip                             # Quality metrics
│   └── segmentations/
│       ├── adrenal_gland_left.nii.gz
│       ├── aorta.nii.gz
│       ├── brain.nii.gz
│       ├── esophagus.nii.gz                   # Alternative organ masks
│       ├── liver.nii.gz
│       └── ... (100+ organ segmentations)
└── Segmentatie/                               # Binary masks (ROIs)
    └── ROIs_organen_WB_beelden/
        ├── hart.zip
        ├── lever.zip
        └── ...
```

## File Routing Rules

### Priority 1: Dose Distribution (→ `dose-files` bucket)
- **Path pattern:** `*/DoseDistribution*/***/*_DoseDistribution/*.dcm`
- **Files:** CT00000000.dcm through CT00000XXX.dcm (~400 files)
- **Purpose:** Monte Carlo dose calculation input
- **Extraction:** Extract metadata (mA, exposureTime) from DICOM headers

### Priority 2: Organ Masks (→ `mask-files` bucket)
- **Path pattern 1:** `*/Niftis/*.nii` (Primary - Dutch organ names)
  - hart.nii (Heart)
  - longen.nii (Lungs)
  - lever.nii (Liver) - if available
  - nieren.nii (Kidneys)
  - ribben.nii (Ribs)
  - wervel.nii (Vertebrae)
  - slokdarm.nii (Esophagus) - if available
  
- **Path pattern 2:** `*/TotalSegmentator/segmentations/*.nii.gz` (Alternative - English names)
  - heart.nii.gz
  - lung_*.nii.gz
  - liver.nii.gz
  - kidney_*.nii.gz
  - rib_*.nii.gz
  - vertebrae_*.nii.gz
  - esophagus.nii.gz

### Priority 3: Metadata
- **Path pattern:** `*/Niftis/*.json`
- **Storage:** Extract and store in database
- **Contents:** Study parameters, scan settings

## Upload Workflow

### 1. Client-Side (Frontend)

```typescript
// Accept ZIP files up to 5GB
<input 
  type="file" 
  accept=".zip,.dcm,.nii,.nii.gz" 
  multiple 
/>

// Check file size
if (zipFile.size > 5 * 1024 * 1024 * 1024) {
  // Warn user about large file
}

// Upload with progress tracking
await uploadFile(zipFile, "dose-files", `${study_id}/uploads/${fileName}`);

// Trigger server-side processing
await supabase.functions.invoke('process-zip-upload', {
  body: { study_id, zip_path, file_size }
});
```

### 2. Server-Side (Edge Function)

```typescript
// supabase/functions/process-zip-upload/index.ts

1. Download ZIP from storage (streaming for large files)
2. Parse ZIP central directory (get file list without full extraction)
3. Identify key folders:
   - DoseDistribution path
   - Niftis path  
   - TotalSegmentator/segmentations path
4. Extract files selectively:
   - DICOM dose files → dose-files bucket
   - NIfTI organ masks → mask-files bucket
   - JSON metadata → database
5. Update study record with file paths
6. Return extraction summary
```

### 3. Background Processing (For Multi-GB Files)

For very large ZIP files (>2GB), use background processing:

```typescript
// Queue extraction job
const { data } = await supabase
  .from('extraction_jobs')
  .insert({
    study_id,
    zip_path,
    status: 'queued',
    file_count: estimated_count,
  });

// Process in chunks using EdgeRuntime.waitUntil()
EdgeRuntime.waitUntil(
  processZipInBackground(zip_path, study_id)
);

// Client polls for status
const checkStatus = setInterval(async () => {
  const { data } = await supabase
    .from('extraction_jobs')
    .select('status, progress, extracted_count')
    .eq('id', job_id)
    .single();
    
  if (data.status === 'completed') {
    clearInterval(checkStatus);
    // Trigger dose calculation
  }
}, 5000);
```

## Technical Challenges & Solutions

### Challenge 1: Large File Handling
**Problem:** ZIP files can be 2-5GB  
**Solution:**
- Use chunked uploads (Supabase supports resumable uploads)
- Stream ZIP extraction (don't load entire file in memory)
- Process files in batches

### Challenge 2: ZIP Extraction in Deno
**Problem:** Deno edge functions have limited ZIP support  
**Solution:**
- Option A: Use JavaScript ZIP library (jszip, decompress)
- Option B: Use Deno FFI to call native unzip
- Option C: Use Python microservice for extraction
- **Recommended:** Use jszip for metadata, Python service for extraction

### Challenge 3: File Size Limits
**Problem:** Supabase storage per-file limits  
**Solution:**
- ZIP files: Upload to temporary location
- Extract and delete original ZIP after processing
- Individual files stay within limits (DICOM ~500KB, NIfTI ~100MB)

### Challenge 4: Nested Folder Mapping
**Problem:** Complex nested structure varies by study  
**Solution:**
- Use pattern matching for key folders
- Prioritize known structures (DoseDistribution, Niftis)
- Fall back to file extension-based routing
- Log unrecognized structures for manual review

## Database Schema

### extraction_jobs table

```sql
CREATE TABLE extraction_jobs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  study_id UUID REFERENCES studies(id),
  zip_path TEXT NOT NULL,
  status TEXT DEFAULT 'queued', -- queued, processing, completed, failed
  file_count INTEGER,
  extracted_count INTEGER DEFAULT 0,
  progress INTEGER DEFAULT 0, -- 0-100
  error_message TEXT,
  created_at TIMESTAMPTZ DEFAULT now(),
  completed_at TIMESTAMPTZ
);
```

### Update studies table

```sql
ALTER TABLE studies ADD COLUMN extraction_job_id UUID REFERENCES extraction_jobs(id);
ALTER TABLE studies ADD COLUMN zip_original_path TEXT;
ALTER TABLE studies ADD COLUMN extracted_file_count INTEGER;
```

## Implementation Phases

### Phase 1: Basic ZIP Support ✅
- Accept .zip files in upload UI
- Upload to storage
- Trigger processing edge function
- Return file count estimate

### Phase 2: Extraction Engine 🚧
- Implement ZIP parsing
- Extract DICOM files to dose-files bucket
- Extract NIfTI files to mask-files bucket
- Map files to database records

### Phase 3: Background Processing
- Queue large file extraction
- Implement progress tracking
- Add client-side status polling
- Handle extraction errors/retries

### Phase 4: Automatic Calculation
- Trigger dose calculation after extraction
- Map extracted files to calculation inputs
- Display results automatically

## Performance Targets

- **Upload time:** 2-5 minutes for 3GB ZIP (depends on connection)
- **Extraction time:** 5-10 minutes for 450 files
- **Total processing:** <15 minutes from upload to calculation ready

## Error Handling

1. **Invalid ZIP structure:** Log warning, extract what's possible
2. **Missing key folders:** Alert user, request manual file selection
3. **Corrupted files:** Skip and log, continue with valid files
4. **Storage limits:** Implement cleanup of temporary files
5. **Timeout:** Use background jobs for files >1GB

## Testing

Test with realistic data:
- 3GB ZIP with 400 DICOM + 50 NIfTI files
- Nested folder structure as shown in reference
- Verify correct bucket routing
- Check metadata extraction
- Validate calculation inputs after extraction
